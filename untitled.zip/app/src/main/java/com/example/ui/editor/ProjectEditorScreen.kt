package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Difference
import androidx.compose.material.icons.filled.FindReplace
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.repair.DiffLine
import com.example.domain.repair.DiffType
import com.example.ui.MainViewModel
import com.example.ui.navigation.Screen
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.SuccessGreen
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectEditorScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val projectInfo by viewModel.projectInfo.collectAsState()
    val activeEditorFile by viewModel.activeEditorFile.collectAsState()
    val editorContentState by viewModel.editorContentState.collectAsState()
    val isBinaryFileError by viewModel.isBinaryFileError.collectAsState()
    val projectFiles by viewModel.projectEditableFiles.collectAsState()

    val clipboardManager = LocalClipboardManager.current

    // Local editor text field value and undo/redo stacks
    var textFieldValue by remember(activeEditorFile, editorContentState) {
        mutableStateOf(TextFieldValue(editorContentState))
    }

    val undoStack = remember { mutableStateListOf<String>() }
    val redoStack = remember { mutableStateListOf<String>() }

    // Search and Replace states
    var showSearchRow by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var replaceQuery by remember { mutableStateOf("") }

    // Diff Dialog state
    var showDiffDialog by remember { mutableStateOf(false) }
    var diffLines by remember { mutableStateOf<List<DiffLine>>(emptyList()) }

    // File Selector Drawer/Dialog
    var showFileListDialog by remember { mutableStateOf(false) }

    LaunchedEffect(activeEditorFile) {
        undoStack.clear()
        redoStack.clear()
    }

    val rootDir = projectInfo?.extractedRoot
    val currentFileName = activeEditorFile?.name ?: "اختر ملفاً للتعديل"
    val relativeFilePath = if (activeEditorFile != null && rootDir != null) {
        try { activeEditorFile!!.relativeTo(rootDir).path } catch (_: Exception) { activeEditorFile!!.name }
    } else currentFileName

    val lineCount by remember {
        derivedStateOf {
            textFieldValue.text.lines().size.coerceAtLeast(1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "محرر المشروع (Project Editor)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = relativeFilePath,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.RepairCenter) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "الرجوع"
                        )
                    }
                },
                actions = {
                    // Switch file button
                    IconButton(onClick = {
                        viewModel.refreshEditableFiles()
                        showFileListDialog = true
                    }) {
                        Icon(
                            imageVector = Icons.Default.Folder,
                            contentDescription = "ملفات المشروع",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Search / Replace Toggle
                    IconButton(onClick = { showSearchRow = !showSearchRow }) {
                        Icon(
                            imageVector = Icons.Default.FindReplace,
                            contentDescription = "بحث واستبدال",
                            tint = if (showSearchRow) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Diff comparison
                    IconButton(
                        onClick = {
                            val original = viewModel.editorContentState.value
                            diffLines = viewModel.projectEditorManager.computeDiff(original, textFieldValue.text)
                            showDiffDialog = true
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Difference,
                            contentDescription = "مقارنة التغييرات"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Binary Warning Banner
            if (isBinaryFileError) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = ErrorRose.copy(alpha = 0.12f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = ErrorRose)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "هذا الملف غير قابل للتحرير كنص (ملف ثنائي أو حزمة مخرجات تجميع).",
                            fontSize = 13.sp,
                            color = ErrorRose,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Search & Replace Toolbar
            if (showSearchRow) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    tonalElevation = 2.dp
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                label = { Text("بحث عن نص...", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
                            )

                            OutlinedTextField(
                                value = replaceQuery,
                                onValueChange = { replaceQuery = it },
                                label = { Text("استبدال بـ...", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
                            )

                            Button(
                                onClick = {
                                    if (searchQuery.isNotEmpty()) {
                                        val oldText = textFieldValue.text
                                        undoStack.add(oldText)
                                        val newText = oldText.replace(searchQuery, replaceQuery)
                                        textFieldValue = TextFieldValue(newText)
                                    }
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("استبدال الكل", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // Code Editor Toolbar (Undo, Redo, Select All, Copy, Paste)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(
                        onClick = {
                            if (undoStack.isNotEmpty()) {
                                val previous = undoStack.removeAt(undoStack.size - 1)
                                redoStack.add(textFieldValue.text)
                                textFieldValue = TextFieldValue(previous)
                            }
                        },
                        enabled = undoStack.isNotEmpty()
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.Undo, contentDescription = "تراجع", modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = {
                            if (redoStack.isNotEmpty()) {
                                val next = redoStack.removeAt(redoStack.size - 1)
                                undoStack.add(textFieldValue.text)
                                textFieldValue = TextFieldValue(next)
                            }
                        },
                        enabled = redoStack.isNotEmpty()
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.Redo, contentDescription = "إعادة", modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = {
                            textFieldValue = textFieldValue.copy(
                                selection = TextRange(0, textFieldValue.text.length)
                            )
                        }
                    ) {
                        Icon(imageVector = Icons.Default.SelectAll, contentDescription = "تحديد الكل", modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = {
                            val selected = if (textFieldValue.selection.collapsed) textFieldValue.text
                            else textFieldValue.text.substring(textFieldValue.selection.start, textFieldValue.selection.end)
                            clipboardManager.setText(AnnotatedString(selected))
                        }
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "نسخ", modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = {
                            clipboardManager.getText()?.let { clip ->
                                undoStack.add(textFieldValue.text)
                                val current = textFieldValue.text
                                val start = textFieldValue.selection.start
                                val end = textFieldValue.selection.end
                                val newText = current.substring(0, start) + clip.text + current.substring(end)
                                textFieldValue = TextFieldValue(
                                    text = newText,
                                    selection = TextRange(start + clip.text.length)
                                )
                            }
                        }
                    ) {
                        Icon(imageVector = Icons.Default.ContentPaste, contentDescription = "لصق", modifier = Modifier.size(18.dp))
                    }
                }

                Text(
                    text = "$lineCount سطر",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(end = 8.dp)
                )
            }

            // Code Editor Canvas with Line Numbers
            val horizontalScrollState = rememberScrollState()
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFF1E1E1E))
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    // Line numbers column
                    val lineNumbersText = (1..lineCount).joinToString("\n")
                    Text(
                        text = lineNumbersText,
                        color = Color.Gray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        modifier = Modifier
                            .background(Color(0xFF252526))
                            .padding(horizontal = 8.dp, vertical = 8.dp)
                            .fillMaxHeight()
                    )

                    // Text Field Editor
                    TextField(
                        value = textFieldValue,
                        onValueChange = { newVal ->
                            if (newVal.text != textFieldValue.text) {
                                if (undoStack.size > 50) undoStack.removeAt(0)
                                undoStack.add(textFieldValue.text)
                                redoStack.clear()
                            }
                            textFieldValue = newVal
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(horizontalScrollState)
                            .testTag("project_editor_textarea"),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            color = Color(0xFFD4D4D4),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        ),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF1E1E1E),
                            unfocusedContainerColor = Color(0xFF1E1E1E),
                            cursorColor = Color.Cyan,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )
                }
            }

            // Bottom Action Controls: [ حفظ ] | [ حفظ وإعادة البناء ]
            Surface(
                modifier = Modifier.fillMaxWidth(),
                tonalElevation = 6.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            viewModel.saveEditedFile(textFieldValue.text, rebuildAfter = false)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("editor_save_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ التعديل", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            viewModel.saveEditedFile(textFieldValue.text, rebuildAfter = true)
                        },
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp)
                            .testTag("editor_save_and_rebuild_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ وإعادة البناء", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // File Selector Dialog
    if (showFileListDialog) {
        AlertDialog(
            onDismissRequest = { showFileListDialog = false },
            title = { Text("اختر ملفاً لتعديله", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                ) {
                    items(projectFiles) { file ->
                        val rel = if (rootDir != null) {
                            try { file.relativeTo(rootDir).path } catch (_: Exception) { file.name }
                        } else file.name

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.openFileInEditor(file)
                                    showFileListDialog = false
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = rel,
                                fontSize = 13.sp,
                                fontWeight = if (activeEditorFile?.absolutePath == file.absolutePath) FontWeight.Bold else FontWeight.Normal,
                                color = if (activeEditorFile?.absolutePath == file.absolutePath) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFileListDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Diff Comparison Dialog (Stage 7: Changes Comparison)
    if (showDiffDialog) {
        AlertDialog(
            onDismissRequest = { showDiffDialog = false },
            title = {
                Text("مقارنة التغييرات (Diff)", fontWeight = FontWeight.Bold)
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .background(Color(0xFF1E1E1E))
                        .padding(8.dp)
                ) {
                    items(diffLines) { diff ->
                        val (bgColor, textColor, prefix) = when (diff.type) {
                            DiffType.ADDED -> Triple(Color(0xFF1B3820), Color(0xFF81C784), "+ ")
                            DiffType.REMOVED -> Triple(Color(0xFF3E1C1C), Color(0xFFE57373), "- ")
                            DiffType.UNCHANGED -> Triple(Color.Transparent, Color(0xFFD4D4D4), "  ")
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(bgColor)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = prefix + diff.text,
                                color = textColor,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveEditedFile(textFieldValue.text, rebuildAfter = true)
                        showDiffDialog = false
                    }
                ) {
                    Text("حفظ وإعادة البناء")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        // Revert changes back to original
                        textFieldValue = TextFieldValue(viewModel.editorContentState.value)
                        showDiffDialog = false
                    }
                ) {
                    Text("التراجع عن التعديل")
                }
            }
        )
    }
}
