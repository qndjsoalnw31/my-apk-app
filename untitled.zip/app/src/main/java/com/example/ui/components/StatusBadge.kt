package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.IssueSeverity
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun SeverityBadge(severity: IssueSeverity, modifier: Modifier = Modifier) {
    val (bgColor, textColor, icon, label) = when (severity) {
        IssueSeverity.ERROR -> Quad(ErrorRose.copy(alpha = 0.15f), ErrorRose, Icons.Default.Error, "خطأ (ERROR)")
        IssueSeverity.WARNING -> Quad(WarningAmber.copy(alpha = 0.15f), WarningAmber, Icons.Default.Warning, "تحذير (WARNING)")
        IssueSeverity.INFO -> Quad(InfoBlue.copy(alpha = 0.15f), InfoBlue, Icons.Default.Info, "معلومة (INFO)")
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun BuildStatusBadge(status: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, label) = when (status.uppercase()) {
        "SUCCESS" -> Triple(SuccessGreen.copy(alpha = 0.15f), SuccessGreen, "تم البناء بنجاح ✓")
        "FAILED" -> Triple(ErrorRose.copy(alpha = 0.15f), ErrorRose, "فشل البناء ✗")
        "RUNNING" -> Triple(InfoBlue.copy(alpha = 0.15f), InfoBlue, "جاري البناء...")
        "CANCELLED" -> Triple(Color.Gray.copy(alpha = 0.15f), Color.Gray, "ملغي")
        else -> Triple(Color.Gray.copy(alpha = 0.15f), Color.Gray, status)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
