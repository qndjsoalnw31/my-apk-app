package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Teal / Cyan
val Teal80 = Color(0xFF5EEAD4)
val TealGrey80 = Color(0xFF94A3B8)
val Indigo80 = Color(0xFFA5B4FC)

val Teal40 = Color(0xFF0F766E)
val TealGrey40 = Color(0xFF475569)
val Indigo40 = Color(0xFF4338CA)

// Status colors
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRose = Color(0xFFF43F5E)
val InfoBlue = Color(0xFF38BDF8)

// Dark Surfaces
val DarkBg = Color(0xFF0B0F17)
val DarkSurface = Color(0xFF131B2A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)

// Light Surfaces
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
