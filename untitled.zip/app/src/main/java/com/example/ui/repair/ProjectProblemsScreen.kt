package com.example.ui.repair

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.repair.AiFixProposal
import com.example.domain.repair.DiagnosticProblem
import com.example.domain.repair.DiffType
import com.example.domain.repair.ProblemSeverity
import com.example.domain.repair.RepairActionType
import com.example.ui.MainViewModel
import com.example.ui.navigation.Screen
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectProblemsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val problems by viewModel.detectedProblems.collectAsState()
    val isRepairing by viewModel.isRepairing.collectAsState()
    val clipboardManager = LocalClipboardManager.current

    // Expanded problem details
    var selectedProblemForDetail by remember { mutableStateOf<DiagnosticProblem?>(null) }
    var showWhyDialog by remember { mutableStateOf<DiagnosticProblem?>(null) }
    var aiProposalDialog by remember { mutableStateOf<AiFixProposal?>(null) }

    // User file picker (for google-services.json)
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            viewModel.handleUserProvidedFile(it, "app/google-services.json")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "مشاكل المشروع (${problems.size})",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.RepairCenter) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "الرجوع"
                        )
                    }
                },
                actions = {
                    // Copy sanitized error report for AI
                    IconButton(
                        onClick = {
                            val report = viewModel.generateAiErrorReport()
                            clipboardManager.setText(AnnotatedString(report))
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ تقرير المشاكل للذكاء الاصطناعي"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            if (problems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لم يتم اكتشاف أي مشاكل حرجة!",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "المشروع جاهز لعملية البناء والتجميع إلى APK.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { viewModel.startBuild() }) {
                            Text("بدء البناء الآن")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "تم تشخيص ${problems.size} مشاكل قد تعيق اكتمال البناء. يمكنك مراجعة كل مشكلة وإصلاحها تلقائياً أو يدوياً عبر المحرر المدمج.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(12.dp),
                                lineHeight = 17.sp
                            )
                        }
                    }

                    items(problems) { problem ->
                        ProblemCard(
                            problem = problem,
                            onAutoFix = {
                                viewModel.applyAutoFixForProblem(problem)
                            },
                            onManualEdit = {
                                viewModel.openProblemFileInEditor(problem)
                            },
                            onSelectFile = {
                                filePickerLauncher.launch(arrayOf("*/*"))
                            },
                            onWhyClick = {
                                showWhyDialog = problem
                            },
                            onAiPatchClick = {
                                val proposal = viewModel.generateAiProposalForProblem(problem)
                                if (proposal != null) {
                                    aiProposalDialog = proposal
                                }
                            }
                        )
                    }
                }

                // Bottom Action: [ إصلاح شامل وإعادة البناء ]
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    tonalElevation = 6.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilledTonalButton(
                            onClick = { viewModel.runAutoRepair() },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            enabled = !isRepairing
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoFixHigh,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إصلاح تلقائي للكل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                viewModel.startBuild()
                            },
                            modifier = Modifier
                                .weight(1.3f)
                                .height(50.dp)
                                .testTag("fix_and_rebuild_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إصلاح وإعادة البناء", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Why Happened Dialog
    if (showWhyDialog != null) {
        val p = showWhyDialog!!
        AlertDialog(
            onDismissRequest = { showWhyDialog = null },
            title = {
                Text(text = "لماذا تحدث المشكلة؟", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = p.title,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = p.whyItHappened,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showWhyDialog = null }) {
                    Text("فهمت ذلك")
                }
            }
        )
    }

    // AI Diff & Patch Proposal Dialog (Stage 28 & 29: AI Code Repair with Diff)
    if (aiProposalDialog != null) {
        val proposal = aiProposalDialog!!
        AlertDialog(
            onDismissRequest = { aiProposalDialog = null },
            title = {
                Text(text = "اقتراح الذكاء الاصطناعي للتصحيح", fontWeight = FontWeight.Bold)
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            text = proposal.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = proposal.explanation,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "الملف المتأثر: ${proposal.affectedFilePath}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    if (proposal.warningMessage != null) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = WarningAmber.copy(alpha = 0.15f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(proposal.warningMessage, fontSize = 11.sp, color = WarningAmber, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    item {
                        Text("مقارنة التغييرات المقترحة (Diff):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    items(proposal.diffLines) { diff ->
                        val (bgColor, textColor, prefix) = when (diff.type) {
                            DiffType.ADDED -> Triple(Color(0xFF1B3820), Color(0xFF81C784), "+ ")
                            DiffType.REMOVED -> Triple(Color(0xFF3E1C1C), Color(0xFFE57373), "- ")
                            DiffType.UNCHANGED -> Triple(Color(0xFF2B2B2B), Color(0xFFD4D4D4), "  ")
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(bgColor)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = prefix + diff.text,
                                color = textColor,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.applyAiProposal(proposal)
                        aiProposalDialog = null
                    }
                ) {
                    Text("تطبيق التعديل")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { aiProposalDialog = null }) {
                    Text("رفض")
                }
            }
        )
    }
}

@Composable
fun ProblemCard(
    problem: DiagnosticProblem,
    onAutoFix: () -> Unit,
    onManualEdit: () -> Unit,
    onSelectFile: () -> Unit,
    onWhyClick: () -> Unit,
    onAiPatchClick: () -> Unit
) {
    val (icon, color, severityText) = when (problem.severity) {
        ProblemSeverity.ERROR -> Triple(Icons.Default.Error, ErrorRose, "ERROR")
        ProblemSeverity.WARNING -> Triple(Icons.Default.Warning, WarningAmber, "WARNING")
        ProblemSeverity.INFO -> Triple(Icons.Default.Info, MaterialTheme.colorScheme.primary, "INFO")
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Severity badge + Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(color.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = severityText,
                        color = color,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = problem.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Reason section
            Text(
                text = "السبب:\n${problem.reasonArabic}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Metadata info block (File, Current, Expected)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (problem.affectedFilePath != null) {
                    Row {
                        Text("الملف: ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(problem.affectedFilePath + (if (problem.affectedLineNumber != null) " (السطر: ${problem.affectedLineNumber})" else ""), fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
                if (problem.currentValue != null) {
                    Row {
                        Text("القيمة الحالية: ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(problem.currentValue, fontSize = 11.sp)
                    }
                }
                if (problem.expectedValue != null) {
                    Row {
                        Text("المطلوب: ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(problem.expectedValue, fontSize = 11.sp, color = SuccessGreen)
                    }
                }
                Row {
                    Text("الحالة: ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = when (problem.actionType) {
                            RepairActionType.AUTO_FIX -> "✓ قابل للإصلاح التلقائي"
                            RepairActionType.USER_FILE_REQUIRED -> "✗ يتطلب ملف من المستخدم"
                            RepairActionType.MANUAL_FIX -> "✎ يتطلب تعديل الكود يدوياً"
                            RepairActionType.ENVIRONMENT_FIX -> "⚙ ضبط إعدادات البيئة"
                            RepairActionType.UNSUPPORTED -> " غير مدعوم"
                        },
                        fontSize = 11.sp,
                        color = if (problem.actionType == RepairActionType.AUTO_FIX) SuccessGreen else WarningAmber
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (problem.isAutoFixAvailable) {
                    FilledTonalButton(
                        onClick = onAutoFix,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إصلاح تلقائي", fontSize = 11.sp)
                    }
                }

                if (problem.actionType == RepairActionType.USER_FILE_REQUIRED) {
                    Button(
                        onClick = onSelectFile,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("اختيار الملف", fontSize = 11.sp)
                    }
                }

                OutlinedButton(
                    onClick = onManualEdit,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تعديل يدوي", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onWhyClick) {
                    Icon(imageVector = Icons.Default.HelpOutline, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("لماذا تحدث المشكلة؟", fontSize = 11.sp)
                }

                TextButton(onClick = onAiPatchClick) {
                    Icon(imageVector = Icons.Default.Code, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("اقتراح الذكاء الاصطناعي", fontSize = 11.sp)
                }
            }
        }
    }
}
