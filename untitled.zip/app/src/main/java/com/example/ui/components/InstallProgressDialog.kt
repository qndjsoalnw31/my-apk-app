package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.installer.InstallState
import com.example.ui.theme.SuccessGreen

@Composable
fun InstallProgressDialog(
    installState: InstallState,
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    when (installState) {
        is InstallState.Idle -> {
            // No dialog
        }

        is InstallState.Preparing -> {
            AlertDialog(
                onDismissRequest = { /* Prevent dismissing while transferring */ },
                confirmButton = {},
                icon = {
                    CircularProgressIndicator(
                        modifier = Modifier.size(36.dp),
                        strokeWidth = 3.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                },
                title = {
                    Text(
                        text = "جارٍ تجهيز التثبيت",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = installState.message,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        LinearProgressIndicator(
                            progress = { installState.progress / 100f },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${installState.progress}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                shape = RoundedCornerShape(18.dp)
            )
        }

        is InstallState.PendingUserConfirmation -> {
            AlertDialog(
                onDismissRequest = onDismiss,
                confirmButton = {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("confirm_user_action_button")
                    ) {
                        Text("حسناً")
                    }
                },
                icon = {
                    Icon(
                        imageVector = Icons.Default.HourglassTop,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        text = "تأكيد التثبيت من النظام",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "تم فتح مثبت حزم Android بنجاح.\n\nيرجى تأكيد التثبيت من خلال نافذة النظام التي ظهرت على شاشتك.",
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                shape = RoundedCornerShape(18.dp)
            )
        }

        is InstallState.Success -> {
            AlertDialog(
                onDismissRequest = onDismiss,
                confirmButton = {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        modifier = Modifier.testTag("install_success_ok_button")
                    ) {
                        Text("تم")
                    }
                },
                icon = {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(40.dp)
                    )
                },
                title = {
                    Text(
                        text = "تم التثبيت بنجاح!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Text(
                        text = installState.message,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                shape = RoundedCornerShape(18.dp)
            )
        }

        is InstallState.Error -> {
            AlertDialog(
                onDismissRequest = onDismiss,
                confirmButton = {
                    if (installState.canOpenSettings) {
                        Button(
                            onClick = {
                                onDismiss()
                                onOpenSettings()
                            },
                            modifier = Modifier.testTag("open_install_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("فتح الإعدادات")
                        }
                    } else {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("install_error_ok_button")
                        ) {
                            Text("حسناً")
                        }
                    }
                },
                dismissButton = {
                    if (installState.canOpenSettings) {
                        OutlinedButton(onClick = onDismiss) {
                            Text("إلغاء")
                        }
                    }
                },
                icon = {
                    Icon(
                        imageVector = if (installState.canOpenSettings) Icons.Default.Security else Icons.Default.Error,
                        contentDescription = null,
                        tint = if (installState.canOpenSettings) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        text = installState.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center,
                        color = if (installState.canOpenSettings) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error
                    )
                },
                text = {
                    Column {
                        Text(
                            text = installState.message,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (!installState.detailedLog.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = installState.detailedLog,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                },
                shape = RoundedCornerShape(18.dp)
            )
        }
    }
}
