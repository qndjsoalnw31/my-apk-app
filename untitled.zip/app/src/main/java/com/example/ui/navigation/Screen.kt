package com.example.ui.navigation

sealed class Screen {
    object Home : Screen()
    object Analysis : Screen()
    object BuildProgress : Screen()
    object BuildSuccess : Screen()
    object History : Screen()
    object Settings : Screen()
    object Environment : Screen()
    object RepairCenter : Screen()
    object ProjectProblems : Screen()
    object ProjectEditor : Screen()
    object BuildLogs : Screen()
}

