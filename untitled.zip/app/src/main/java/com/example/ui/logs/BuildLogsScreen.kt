package com.example.ui.logs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.navigation.Screen
import com.example.ui.theme.ErrorRose

enum class LogFilterType {
    ALL,
    ERRORS,
    WARNINGS,
    INFO
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuildLogsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val rawLogList by viewModel.buildManager.logs.collectAsState()
    val parsedError by viewModel.buildManager.parsedError.collectAsState()
    val clipboardManager = LocalClipboardManager.current

    var selectedFilter by remember { mutableStateOf(LogFilterType.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var showSearchBar by remember { mutableStateOf(false) }

    val fullLogString = remember(rawLogList) { rawLogList.joinToString("\n") }

    val filteredLines: List<String> by remember(rawLogList, selectedFilter, searchQuery) {
        derivedStateOf {
            rawLogList.filter { line: String ->
                val matchesQuery = if (searchQuery.isBlank()) true else line.contains(searchQuery, ignoreCase = true)
                val matchesFilter = when (selectedFilter) {
                    LogFilterType.ALL -> true
                    LogFilterType.ERRORS -> line.contains("error", ignoreCase = true) || line.contains("failed", ignoreCase = true) || line.contains("exception", ignoreCase = true)
                    LogFilterType.WARNINGS -> line.contains("warn", ignoreCase = true) || line.contains("deprecated", ignoreCase = true)
                    LogFilterType.INFO -> line.contains("info", ignoreCase = true) || line.contains("task", ignoreCase = true)
                }
                matchesQuery && matchesFilter
            }
        }
    }

    val listState = rememberLazyListState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("سجل البناء المفصل (Build Logs)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.BuildProgress) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "الرجوع"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showSearchBar = !showSearchBar }) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث في السجل",
                            tint = if (showSearchBar) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(fullLogString))
                        }
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "نسخ السجل بالكامل")
                    }

                    IconButton(
                        onClick = {
                            viewModel.navigateTo(Screen.ProjectProblems)
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.BugReport,
                            contentDescription = "تشخيص المشاكل",
                            tint = ErrorRose
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Suggestion / Error Banner if parsed error exists
            if (parsedError != null) {
                val err = parsedError!!
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = ErrorRose.copy(alpha = 0.15f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "خطأ مكتشف: ${err.titleArabic}",
                            fontWeight = FontWeight.Bold,
                            color = ErrorRose,
                            fontSize = 13.sp
                        )
                        Text(
                            text = err.causeArabic,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        Text(
                            text = "الحل المقترح: ${err.actionArabic}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Search Bar
            if (showSearchBar) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("بحث في أسطر السجل...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    singleLine = true
                )
            }

            // Filter Chips (FULL LOG, ERRORS, WARNINGS, INFO)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == LogFilterType.ALL,
                    onClick = { selectedFilter = LogFilterType.ALL },
                    label = { Text("FULL LOG (${rawLogList.size})", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = selectedFilter == LogFilterType.ERRORS,
                    onClick = { selectedFilter = LogFilterType.ERRORS },
                    label = { Text("ERRORS", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = selectedFilter == LogFilterType.WARNINGS,
                    onClick = { selectedFilter = LogFilterType.WARNINGS },
                    label = { Text("WARNINGS", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = selectedFilter == LogFilterType.INFO,
                    onClick = { selectedFilter = LogFilterType.INFO },
                    label = { Text("INFO", fontSize = 11.sp) }
                )
            }

            // Log Console
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFF1E1E1E))
                    .padding(horizontal = 8.dp)
            ) {
                if (filteredLines.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "لا توجد أسطر تطابق التصفية الحالية",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredLines) { line: String ->
                            val textColor = when {
                                line.contains("error", ignoreCase = true) || line.contains("failed", ignoreCase = true) -> Color(0xFFEF5350)
                                line.contains("warn", ignoreCase = true) -> Color(0xFFFFB74D)
                                line.contains("success", ignoreCase = true) || line.contains("up-to-date", ignoreCase = true) -> Color(0xFF81C784)
                                line.startsWith("> Task") -> Color(0xFF4FC3F7)
                                else -> Color(0xFFD4D4D4)
                            }
                            Text(
                                text = line,
                                color = textColor,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                                modifier = Modifier.padding(vertical = 1.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
