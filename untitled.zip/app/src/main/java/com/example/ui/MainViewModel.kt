package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.BuildRecord
import com.example.data.models.BuildSettings
import com.example.data.models.DiagnosticResult
import com.example.data.models.ProjectInfo
import com.example.data.models.ProjectType
import com.example.data.repository.BuildRepository
import com.example.data.repository.SettingsRepository
import com.example.domain.analyzer.ProjectAnalyzer
import com.example.domain.analyzer.ZipExtractor
import com.example.domain.builder.BuildManager
import com.example.domain.builder.EnvironmentDetector
import com.example.domain.builder.EnvironmentStatus
import com.example.domain.diagnostics.ProjectDiagnostics
import com.example.domain.installer.ApkManager
import com.example.domain.installer.InstallState
import com.example.domain.installer.PackageInstallManager
import com.example.domain.repair.AiFixProposal
import com.example.domain.repair.AutoRepairEngine
import com.example.domain.repair.BackupManager
import com.example.domain.repair.BackupSnapshot
import com.example.domain.repair.DiagnosticProblem
import com.example.domain.repair.DiagnosticsEngine
import com.example.domain.repair.ProjectEditorManager
import com.example.domain.repair.RepairHistoryEntry
import com.example.domain.repair.RepairManager
import com.example.ui.navigation.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context = application.applicationContext

    private val database = AppDatabase.getInstance(context)
    val buildRepository = BuildRepository(database.buildRecordDao())
    val settingsRepository = SettingsRepository(context)

    val apkManager = ApkManager(context)
    val packageInstallManager = PackageInstallManager(context)
    val zipExtractor = ZipExtractor(context)
    val projectAnalyzer = ProjectAnalyzer()
    val projectDiagnostics = ProjectDiagnostics()
    val autoRepairEngine = AutoRepairEngine()
    val environmentDetector = EnvironmentDetector(context)

    // Repair & Editor engines
    val backupManager = BackupManager(context.filesDir)
    val projectEditorManager = ProjectEditorManager()
    val diagnosticsEngine = DiagnosticsEngine()
    val repairManager = RepairManager(backupManager, projectEditorManager, diagnosticsEngine)

    val installState = packageInstallManager.installState

    val buildManager = BuildManager(
        context = context,
        buildRepository = buildRepository,
        apkManager = apkManager
    )

    // Navigation State
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Project selection & Extraction state
    private val _selectedZipFileName = MutableStateFlow<String?>(null)
    val selectedZipFileName: StateFlow<String?> = _selectedZipFileName.asStateFlow()

    private val _selectedZipFileSize = MutableStateFlow(0L)
    val selectedZipFileSize: StateFlow<Long> = _selectedZipFileSize.asStateFlow()

    private val _selectedZipSourceFile = MutableStateFlow<File?>(null)
    val selectedZipSourceFile: StateFlow<File?> = _selectedZipSourceFile.asStateFlow()

    private val _isExtracting = MutableStateFlow(false)
    val isExtracting: StateFlow<Boolean> = _isExtracting.asStateFlow()

    private val _extractionProgress = MutableStateFlow("")
    val extractionProgress: StateFlow<String> = _extractionProgress.asStateFlow()

    private val _projectInfo = MutableStateFlow<ProjectInfo?>(null)
    val projectInfo: StateFlow<ProjectInfo?> = _projectInfo.asStateFlow()

    private val _diagnosticResult = MutableStateFlow<DiagnosticResult?>(null)
    val diagnosticResult: StateFlow<DiagnosticResult?> = _diagnosticResult.asStateFlow()

    // Diagnostics Problems & Repair state
    private val _detectedProblems = MutableStateFlow<List<DiagnosticProblem>>(emptyList())
    val detectedProblems: StateFlow<List<DiagnosticProblem>> = _detectedProblems.asStateFlow()

    private val _backupSnapshots = MutableStateFlow<List<BackupSnapshot>>(emptyList())
    val backupSnapshots: StateFlow<List<BackupSnapshot>> = _backupSnapshots.asStateFlow()

    private val _repairHistory = MutableStateFlow<List<RepairHistoryEntry>>(emptyList())
    val repairHistory: StateFlow<List<RepairHistoryEntry>> = _repairHistory.asStateFlow()

    // Project Editor state
    private val _projectEditableFiles = MutableStateFlow<List<File>>(emptyList())
    val projectEditableFiles: StateFlow<List<File>> = _projectEditableFiles.asStateFlow()

    private val _activeEditorFile = MutableStateFlow<File?>(null)
    val activeEditorFile: StateFlow<File?> = _activeEditorFile.asStateFlow()

    private val _editorContentState = MutableStateFlow("")
    val editorContentState: StateFlow<String> = _editorContentState.asStateFlow()

    private val _isBinaryFileError = MutableStateFlow(false)
    val isBinaryFileError: StateFlow<Boolean> = _isBinaryFileError.asStateFlow()

    private val _isRepairing = MutableStateFlow(false)
    val isRepairing: StateFlow<Boolean> = _isRepairing.asStateFlow()

    private val _environmentStatus = MutableStateFlow<EnvironmentStatus?>(null)
    val environmentStatus: StateFlow<EnvironmentStatus?> = _environmentStatus.asStateFlow()

    // Events / Snackbars
    private val _eventFlow = MutableSharedFlow<String>()
    val eventFlow: SharedFlow<String> = _eventFlow.asSharedFlow()

    // Activity Intents (Install / Share)
    private val _intentLaunchFlow = MutableSharedFlow<Intent>()
    val intentLaunchFlow: SharedFlow<Intent> = _intentLaunchFlow.asSharedFlow()

    val buildsHistory: StateFlow<List<BuildRecord>> = buildRepository.allBuilds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestBuild: StateFlow<BuildRecord?> = buildRepository.latestBuild
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val settings: StateFlow<BuildSettings> = settingsRepository.settingsFlow

    init {
        refreshEnvironment()
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun refreshEnvironment() {
        viewModelScope.launch(Dispatchers.IO) {
            val status = environmentDetector.detectEnvironment()
            _environmentStatus.value = status
        }
    }

    fun onZipSelected(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _isExtracting.value = true
            _extractionProgress.value = "جاري قراءة ملف ZIP بأمان..."
            try {
                val tempZip = copyUriToInternalTemp(uri)
                val fileName = getFileNameFromUri(uri) ?: tempZip.name
                val fileSize = tempZip.length()

                _selectedZipFileName.value = fileName
                _selectedZipFileSize.value = fileSize
                _selectedZipSourceFile.value = tempZip

                val buildId = "session_" + UUID.randomUUID().toString().take(6)
                _extractionProgress.value = "جاري فك الضغط وفحص مسارات الحماية..."
                val extractionResult = zipExtractor.extractZip(uri, buildId) { count, name ->
                    _extractionProgress.value = "تم استخراج $count ملف ($name)..."
                }

                _extractionProgress.value = "جاري تحليل بنية المشروع وملفات Gradle..."
                val info = projectAnalyzer.analyze(extractionResult.rootDir, fileName, fileSize)
                _projectInfo.value = info

                val diagnostics = projectDiagnostics.runDiagnostics(info)
                _diagnosticResult.value = diagnostics

                refreshProblems()
                refreshEditableFiles()
                refreshBackups()

                _isExtracting.value = false
                _currentScreen.value = Screen.Analysis
            } catch (e: Exception) {
                _isExtracting.value = false
                _eventFlow.emit("خطأ أثناء معالجة ملف الـ ZIP: ${e.message}")
            }
        }
    }

    fun createAndLoadSampleProject() {
        viewModelScope.launch(Dispatchers.IO) {
            _isExtracting.value = true
            _extractionProgress.value = "جاري إنشاء مشروع Android تجريبي متكامل..."
            try {
                val sampleZip = createSampleAndroidZip()
                _selectedZipFileName.value = sampleZip.name
                _selectedZipFileSize.value = sampleZip.length()
                _selectedZipSourceFile.value = sampleZip

                val buildId = "sample_" + UUID.randomUUID().toString().take(6)
                val extractionResult = zipExtractor.extractZipFile(sampleZip, buildId)

                val info = projectAnalyzer.analyze(extractionResult.rootDir, sampleZip.name, sampleZip.length())
                _projectInfo.value = info

                val diagnostics = projectDiagnostics.runDiagnostics(info)
                _diagnosticResult.value = diagnostics

                refreshProblems()
                refreshEditableFiles()
                refreshBackups()

                _isExtracting.value = false
                _currentScreen.value = Screen.Analysis
                _eventFlow.emit("تم تجهيز المشروع التجريبي بنجاح.")
            } catch (e: Exception) {
                _isExtracting.value = false
                _eventFlow.emit("تعذر إنشاء المشروع التجريبي: ${e.message}")
            }
        }
    }

    fun refreshProblems() {
        val info = _projectInfo.value ?: return
        val currentLogs = buildManager.logs.value.joinToString("\n")
        val diagnosed = diagnosticsEngine.diagnose(info, currentLogs)
        _detectedProblems.value = diagnosed
    }


    fun refreshEditableFiles() {
        val root = _projectInfo.value?.extractedRoot ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val files = projectEditorManager.getProjectEditableFiles(root)
            _projectEditableFiles.value = files
        }
    }

    fun refreshBackups() {
        val root = _projectInfo.value?.extractedRoot ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val list = backupManager.listBackups(root)
            _backupSnapshots.value = list
            _repairHistory.value = repairManager.repairHistory
        }
    }

    fun openFileInEditor(file: File) {
        if (!projectEditorManager.isEditableFile(file)) {
            _isBinaryFileError.value = true
            _activeEditorFile.value = file
            _editorContentState.value = ""
            _currentScreen.value = Screen.ProjectEditor
            return
        }

        try {
            val content = projectEditorManager.readFileContent(file)
            _isBinaryFileError.value = false
            _activeEditorFile.value = file
            _editorContentState.value = content
            _currentScreen.value = Screen.ProjectEditor
        } catch (e: Exception) {
            viewModelScope.launch { _eventFlow.emit("تعذر فتح الملف: ${e.message}") }
        }
    }

    fun openProblemFileInEditor(problem: DiagnosticProblem) {
        val root = _projectInfo.value?.extractedRoot ?: return
        val relPath = problem.affectedFilePath ?: "build.gradle.kts"
        val targetFile = File(root, relPath)
        if (targetFile.exists()) {
            openFileInEditor(targetFile)
        } else {
            // Pick any build.gradle or wrapper properties
            openFirstEditableFile()
        }
    }

    fun openFirstEditableFile() {
        val root = _projectInfo.value?.extractedRoot ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val files = projectEditorManager.getProjectEditableFiles(root)
            _projectEditableFiles.value = files
            val priorityCandidate = files.firstOrNull { it.name.contains("gradle") || it.name.contains("Manifest") }
                ?: files.firstOrNull()

            if (priorityCandidate != null) {
                withContext(Dispatchers.Main) {
                    openFileInEditor(priorityCandidate)
                }
            } else {
                _eventFlow.emit("لم يتم العثور على ملفات نصية قابلة للتحرير.")
            }
        }
    }

    fun saveEditedFile(newContent: String, rebuildAfter: Boolean = false) {
        val activeFile = _activeEditorFile.value ?: return
        val root = _projectInfo.value?.extractedRoot ?: return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Safety backup
                backupManager.createBackup(root, "نسخة احتياطية قبل تعديل ${activeFile.name}")
                projectEditorManager.saveFileContent(activeFile, newContent)
                _editorContentState.value = newContent

                // Refresh info & diagnostics
                val updatedInfo = projectAnalyzer.analyze(root, _selectedZipFileName.value ?: "Project.zip", _selectedZipFileSize.value)
                _projectInfo.value = updatedInfo
                refreshProblems()
                refreshBackups()

                _eventFlow.emit("تم حفظ التعديلات في ${activeFile.name} بنجاح.")

                if (rebuildAfter) {
                    withContext(Dispatchers.Main) {
                        startBuild()
                    }
                }
            } catch (e: Exception) {
                _eventFlow.emit("فشل حفظ الملف: ${e.message}")
            }
        }
    }

    fun applyAutoFixForProblem(problem: DiagnosticProblem) {
        val root = _projectInfo.value?.extractedRoot ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _isRepairing.value = true
            val success = repairManager.executeAutoFix(root, problem, _projectInfo.value)
            if (success) {
                val updatedInfo = projectAnalyzer.analyze(root, _selectedZipFileName.value ?: "Project.zip", _selectedZipFileSize.value)
                _projectInfo.value = updatedInfo
                refreshProblems()
                refreshBackups()
                _eventFlow.emit("تم تطبيق الإصلاح التلقائي بنجاح!")
            } else {
                _eventFlow.emit("تعذر تطبيق الإصلاح التلقائي لهذه المشكلة.")
            }
            _isRepairing.value = false
        }
    }

    fun generateAiProposalForProblem(problem: DiagnosticProblem): AiFixProposal? {
        val root = _projectInfo.value?.extractedRoot ?: return null
        return repairManager.generateAiPatchProposal(root, problem)
    }

    fun applyAiProposal(proposal: AiFixProposal) {
        val root = _projectInfo.value?.extractedRoot ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val success = repairManager.applyAiPatch(root, proposal)
            if (success) {
                val updatedInfo = projectAnalyzer.analyze(root, _selectedZipFileName.value ?: "Project.zip", _selectedZipFileSize.value)
                _projectInfo.value = updatedInfo
                refreshProblems()
                refreshBackups()
                _eventFlow.emit("تم تطبيق اقتراح التعديل بنجاح!")
            } else {
                _eventFlow.emit("تعذر تطبيق التعديل المقترح.")
            }
        }
    }

    fun handleUserProvidedFile(uri: Uri, targetRelativePath: String) {
        val root = _projectInfo.value?.extractedRoot ?: return
        val destFile = File(root, targetRelativePath)

        viewModelScope.launch(Dispatchers.IO) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val success = projectEditorManager.copyUserFile(stream, destFile)
                    if (success) {
                        val updatedInfo = projectAnalyzer.analyze(root, _selectedZipFileName.value ?: "Project.zip", _selectedZipFileSize.value)
                        _projectInfo.value = updatedInfo
                        refreshProblems()
                        refreshBackups()
                        _eventFlow.emit("تم استيراد $targetRelativePath بنجاح!")
                    } else {
                        _eventFlow.emit("تعذر حفظ الملف المحدد.")
                    }
                }
            } catch (e: Exception) {
                _eventFlow.emit("خطأ أثناء استيراد الملف: ${e.message}")
            }
        }
    }

    fun restoreBackupSnapshot(snapshot: BackupSnapshot) {
        val root = _projectInfo.value?.extractedRoot ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val restored = backupManager.restoreBackup(root, snapshot)
            if (restored) {
                val updatedInfo = projectAnalyzer.analyze(root, _selectedZipFileName.value ?: "Project.zip", _selectedZipFileSize.value)
                _projectInfo.value = updatedInfo
                refreshProblems()
                refreshBackups()
                _eventFlow.emit("تمت استعادة النسخة الاحتياطية (${snapshot.dateFormatted}) بنجاح.")
            } else {
                _eventFlow.emit("فشلت عملية استعادة النسخة الاحتياطية.")
            }
        }
    }

    fun generateAiErrorReport(): String {
        return repairManager.buildSanitizedErrorReport(
            projectInfo = _projectInfo.value,
            problems = _detectedProblems.value,
            buildLog = buildManager.logs.value.joinToString("\n")
        )
    }


    fun runAutoRepair() {
        val info = _projectInfo.value ?: return
        val diag = _diagnosticResult.value ?: return

        viewModelScope.launch(Dispatchers.IO) {
            _isRepairing.value = true
            val result = autoRepairEngine.repairProject(info, diag.issues)
            if (result.isSuccess) {
                val updatedInfo = projectAnalyzer.analyze(info.extractedRoot, info.zipFileName, info.zipFileSize)
                _projectInfo.value = updatedInfo
                val updatedDiag = projectDiagnostics.runDiagnostics(updatedInfo)
                _diagnosticResult.value = updatedDiag

                refreshProblems()
                refreshBackups()
                _eventFlow.emit(result.message)
            } else {
                _eventFlow.emit(result.message)
            }
            _isRepairing.value = false
        }
    }

    fun startBuild(isRemote: Boolean = false) {
        val info = _projectInfo.value
        val zipFile = _selectedZipSourceFile.value
        if (info == null || zipFile == null) {
            viewModelScope.launch { _eventFlow.emit("الرجاء اختيار مشروع ZIP أولاً") }
            return
        }

        if (info.projectType == ProjectType.UNSUPPORTED) {
            viewModelScope.launch { _eventFlow.emit("هذا الملف لا يبدو كمشروع Android قابل للبناء.") }
            return
        }

        _currentScreen.value = Screen.BuildProgress
        buildManager.startBuild(
            projectInfo = info,
            zipSourceFile = zipFile,
            settings = settings.value,
            isRemote = isRemote
        )
    }

    fun cancelBuild() {
        buildManager.cancelCurrentBuild()
    }

    fun installApk(apkFile: File, buildId: String? = null) {
        val targetBuildId = buildId ?: buildManager.currentBuildId.value ?: "build_${System.currentTimeMillis()}"
        viewModelScope.launch(Dispatchers.IO) {
            val success = packageInstallManager.startInstallation(apkFile, targetBuildId)
            if (!success) {
                val currentState = packageInstallManager.installState.value
                if (currentState is com.example.domain.installer.InstallState.Error) {
                    _eventFlow.emit(currentState.message)
                }
            }
        }
    }

    fun dismissInstallState() {
        packageInstallManager.resetState()
    }

    fun openUnknownSourcesSettings() {
        val settingsIntent = packageInstallManager.getUnknownSourcesSettingsIntent()
        viewModelScope.launch {
            _intentLaunchFlow.emit(settingsIntent)
        }
    }

    fun validateApkFile(apkFile: File?): com.example.domain.installer.ApkPreCheckResult {
        return packageInstallManager.validateApk(apkFile)
    }

    fun shareApk(apkFile: File) {
        try {
            val shareIntent = apkManager.createShareIntent(apkFile)
            viewModelScope.launch { _intentLaunchFlow.emit(shareIntent) }
        } catch (e: Exception) {
            viewModelScope.launch { _eventFlow.emit("تعذر مشاركة الحزمة: ${e.message}") }
        }
    }

    fun exportApk(apkFile: File, destinationUri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = apkManager.exportApkToUri(apkFile, destinationUri)
            if (success) {
                _eventFlow.emit("تم تصدير ملف APK بنجاح إلى وحدة التخزين.")
            } else {
                _eventFlow.emit("فشل تصدير ملف APK إلى المسار المحدد.")
            }
        }
    }

    fun deleteBuildRecord(record: BuildRecord) {
        viewModelScope.launch(Dispatchers.IO) {
            buildRepository.deleteBuild(record)
            _eventFlow.emit("تم حذف سجل البناء والملفات التابعة له.")
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            buildRepository.clearAll()
            _eventFlow.emit("تم مسح سجل البناء بالكامل.")
        }
    }

    fun clearTempFiles() {
        viewModelScope.launch(Dispatchers.IO) {
            val buildsDir = File(context.filesDir, "builds")
            if (buildsDir.exists()) {
                buildsDir.deleteRecursively()
                buildsDir.mkdirs()
            }
            val cacheDir = context.cacheDir
            cacheDir.listFiles()?.forEach { it.deleteRecursively() }
            _eventFlow.emit("تم تنظيف جميع ملفات البناء المؤقتة ومخزن الكاش.")
            refreshEnvironment()
        }
    }

    fun updateSettings(newSettings: BuildSettings) {
        settingsRepository.updateSettings(newSettings)
        viewModelScope.launch { _eventFlow.emit("تم حفظ الإعدادات بنجاح.") }
    }

    private fun copyUriToInternalTemp(uri: Uri): File {
        val fileName = getFileNameFromUri(uri) ?: "project_${System.currentTimeMillis()}.zip"
        val tempFile = File(context.cacheDir, fileName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tempFile).use { output ->
                input.copyTo(output)
            }
        }
        return tempFile
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        result = it.getString(nameIndex)
                    }
                }
            }
        }
        if (result == null) {
            result = uri.path?.let {
                val cut = it.lastIndexOf('/')
                if (cut != -1) it.substring(cut + 1) else it
            }
        }
        return result
    }

    private fun createSampleAndroidZip(): File {
        val sampleZipFile = File(context.cacheDir, "SampleCounterApp.zip")
        if (sampleZipFile.exists()) sampleZipFile.delete()

        ZipOutputStream(FileOutputStream(sampleZipFile)).use { zos ->
            addZipEntry(zos, "settings.gradle.kts", """
                pluginManagement {
                    repositories {
                        google()
                        mavenCentral()
                        gradlePluginPortal()
                    }
                }
                dependencyResolutionManagement {
                    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                    repositories {
                        google()
                        mavenCentral()
                    }
                }
                rootProject.name = "SampleCounterApp"
                include(":app")
            """.trimIndent())

            addZipEntry(zos, "build.gradle.kts", """
                plugins {
                    id("com.android.application") version "8.7.0" apply false
                    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
                }
            """.trimIndent())

            addZipEntry(zos, "gradle/wrapper/gradle-wrapper.properties", """
                distributionBase=GRADLE_USER_HOME
                distributionPath=wrapper/dists
                distributionUrl=https\://services.gradle.org/distributions/gradle-8.7-bin.zip
                networkTimeout=10000
                validateDistributionUrl=true
                zipStoreBase=GRADLE_USER_HOME
                zipStorePath=wrapper/dists
            """.trimIndent())

            addZipEntry(zos, "app/build.gradle.kts", """
                plugins {
                    id("com.android.application")
                    id("org.jetbrains.kotlin.android")
                }
                android {
                    namespace = "com.example.samplecounter"
                    compileSdk = 34

                    defaultConfig {
                        applicationId = "com.example.samplecounter"
                        minSdk = 24
                        targetSdk = 34
                        versionCode = 1
                        versionName = "1.0"
                    }
                    buildTypes {
                        release {
                            isMinifyEnabled = false
                        }
                    }
                }
                dependencies {
                    implementation("androidx.core:core-ktx:1.12.0")
                    implementation("androidx.appcompat:appcompat:1.6.1")
                }
            """.trimIndent())

            addZipEntry(zos, "app/src/main/AndroidManifest.xml", """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                    <application
                        android:allowBackup="true"
                        android:icon="@mipmap/ic_launcher"
                        android:label="تطبيق العداد التجريبي"
                        android:supportsRtl="true">
                        <activity
                            android:name=".MainActivity"
                            android:exported="true">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>
                </manifest>
            """.trimIndent())

            addZipEntry(zos, "app/src/main/java/com/example/samplecounter/MainActivity.kt", """
                package com.example.samplecounter

                import android.os.Bundle
                import androidx.appcompat.app.AppCompatActivity

                class MainActivity : AppCompatActivity() {
                    override fun onCreate(savedInstanceState: Bundle?) {
                        super.onCreate(savedInstanceState)
                    }
                }
            """.trimIndent())
        }

        return sampleZipFile
    }

    private fun addZipEntry(zos: ZipOutputStream, path: String, content: String) {
        val entry = ZipEntry(path)
        zos.putNextEntry(entry)
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }
}
