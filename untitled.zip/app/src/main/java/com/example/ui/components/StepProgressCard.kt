package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.BuildStep
import com.example.data.models.StepState
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.SuccessGreen

@Composable
fun StepProgressCard(
    step: BuildStep,
    isLast: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Step State Indicator
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(
                    when (step.state) {
                        StepState.SUCCESS -> SuccessGreen.copy(alpha = 0.2f)
                        StepState.RUNNING -> MaterialTheme.colorScheme.primaryContainer
                        StepState.FAILED -> ErrorRose.copy(alpha = 0.2f)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                )
                .border(
                    1.dp,
                    when (step.state) {
                        StepState.SUCCESS -> SuccessGreen
                        StepState.RUNNING -> MaterialTheme.colorScheme.primary
                        StepState.FAILED -> ErrorRose
                        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                    },
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            when (step.state) {
                StepState.SUCCESS -> {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Success",
                        tint = SuccessGreen,
                        modifier = Modifier.size(18.dp)
                    )
                }
                StepState.RUNNING -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                StepState.FAILED -> {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Failed",
                        tint = ErrorRose,
                        modifier = Modifier.size(18.dp)
                    )
                }
                else -> {
                    Text(
                        text = "${step.stepIndex}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Step titles
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "الخطوة ${step.stepIndex}/6: ${step.titleArabic}",
                    fontSize = 14.sp,
                    fontWeight = if (step.state == StepState.RUNNING) FontWeight.Bold else FontWeight.Medium,
                    color = when (step.state) {
                        StepState.SUCCESS -> MaterialTheme.colorScheme.onSurface
                        StepState.RUNNING -> MaterialTheme.colorScheme.primary
                        StepState.FAILED -> ErrorRose
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }
            Text(
                text = step.description,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
        }

        // State label
        Text(
            text = when (step.state) {
                StepState.SUCCESS -> "✓ تم"
                StepState.RUNNING -> "جاري..."
                StepState.FAILED -> "✗ خطأ"
                StepState.SKIPPED -> "تخطي"
                StepState.PENDING -> "قيد الانتظار"
            },
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = when (step.state) {
                StepState.SUCCESS -> SuccessGreen
                StepState.RUNNING -> MaterialTheme.colorScheme.primary
                StepState.FAILED -> ErrorRose
                else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            }
        )
    }
}
