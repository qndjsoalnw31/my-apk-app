package com.example.data.models

enum class IssueSeverity {
    ERROR,
    WARNING,
    INFO
}

data class DiagnosticIssue(
    val id: String,
    val severity: IssueSeverity,
    val title: String,
    val description: String,
    val isAutoFixable: Boolean = false,
    val fixActionTitle: String? = null,
    val suggestedAction: String? = null
)
