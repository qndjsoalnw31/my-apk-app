package com.example.data.models

enum class ProjectType(val displayNameArabic: String, val isSupported: Boolean, val supportLevel: SupportLevel) {
    ANDROID_GRADLE_KOTLIN("مشروع Android (Kotlin / Gradle)", true, SupportLevel.SUPPORTED),
    ANDROID_GRADLE_JAVA("مشروع Android (Java / Gradle)", true, SupportLevel.SUPPORTED),
    ANDROID_GRADLE_GENERAL("مشروع Android Gradle", true, SupportLevel.SUPPORTED),
    ANDROID_GRADLE_PROBABLE("مشروع Android محتمل (Gradle)", true, SupportLevel.SUPPORTED),
    FLUTTER("مشروع Flutter (يحتوي كود أندرويد)", true, SupportLevel.PARTIALLY_SUPPORTED),
    REACT_NATIVE("مشروع React Native (يحتوي كود أندرويد)", true, SupportLevel.PARTIALLY_SUPPORTED),
    UNSUPPORTED("مشروع غير مدعوم (لا يحتوي ملفات Android)", false, SupportLevel.UNSUPPORTED);

    enum class SupportLevel(val labelArabic: String) {
        SUPPORTED("مدعوم بالكامل"),
        PARTIALLY_SUPPORTED("مدعوم جزئياً (يتطلب وحدة android/)"),
        UNSUPPORTED("غير مدعوم")
    }
}
