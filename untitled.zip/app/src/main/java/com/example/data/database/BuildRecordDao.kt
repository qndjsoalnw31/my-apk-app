package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BuildRecordDao {
    @Query("SELECT * FROM build_records ORDER BY startTime DESC")
    fun getAllBuilds(): Flow<List<BuildRecord>>

    @Query("SELECT * FROM build_records WHERE id = :id LIMIT 1")
    suspend fun getBuildById(id: String): BuildRecord?

    @Query("SELECT * FROM build_records ORDER BY startTime DESC LIMIT 1")
    fun getLatestBuild(): Flow<BuildRecord?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuild(build: BuildRecord)

    @Update
    suspend fun updateBuild(build: BuildRecord)

    @Query("DELETE FROM build_records WHERE id = :id")
    suspend fun deleteBuildById(id: String)

    @Query("DELETE FROM build_records")
    suspend fun clearAllBuilds()
}
