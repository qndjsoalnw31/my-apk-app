package com.example.data.models

data class BuildSettings(
    val buildVariant: String = "debug", // "debug" or "release"
    val cleanBeforeBuild: Boolean = true,
    val parallelBuild: Boolean = true,
    val offlineMode: Boolean = false,
    val memoryLimitMb: Int = 2048,
    val isHybridMode: Boolean = true,
    val remoteServerUrl: String = "http://10.0.2.2:8000",
    val buildTimeoutSeconds: Int = 300,
    val autoRepairBeforeBuild: Boolean = true
)
