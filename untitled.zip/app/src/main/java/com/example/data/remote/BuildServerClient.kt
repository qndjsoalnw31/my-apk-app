package com.example.data.remote

import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

class BuildServerClient(private val baseUrl: String) {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val api: BuildServerApi = retrofit.create(BuildServerApi::class.java)

    suspend fun pingServer(): Boolean {
        return try {
            val res = api.checkHealth()
            res.isSuccessful && res.body()?.status == "ok"
        } catch (e: Exception) {
            false
        }
    }

    suspend fun startRemoteBuild(
        zipFile: File,
        buildVariant: String = "debug",
        cleanBeforeBuild: Boolean = true
    ): BuildTriggerResponse? {
        val mediaType = "application/zip".toMediaTypeOrNull()
        val requestFile = zipFile.asRequestBody(mediaType)
        val body = MultipartBody.Part.createFormData("zipFile", zipFile.name, requestFile)
        val variantBody = buildVariant.toRequestBody("text/plain".toMediaTypeOrNull())
        val cleanBody = cleanBeforeBuild.toString().toRequestBody("text/plain".toMediaTypeOrNull())

        val res = api.triggerBuild(body, variantBody, cleanBody)
        return if (res.isSuccessful) res.body() else null
    }
}
