package com.example.data.models

enum class StepState {
    PENDING,
    RUNNING,
    SUCCESS,
    FAILED,
    SKIPPED
}

data class BuildStep(
    val stepIndex: Int,
    val titleArabic: String,
    val description: String,
    val state: StepState = StepState.PENDING,
    val progressPercent: Int = 0
)

object BuildStepsFactory {
    fun createDefaultSteps(): List<BuildStep> = listOf(
        BuildStep(1, "تجهيز المشروع والملفات", "Preparing project files", StepState.PENDING),
        BuildStep(2, "فحص إعدادات Gradle", "Checking Gradle wrapper & environment", StepState.PENDING),
        BuildStep(3, "حل وتنزيل الاعتماديات", "Resolving dependencies", StepState.PENDING),
        BuildStep(4, "ترجمة الأكواد والموارد", "Compiling sources & resources", StepState.PENDING),
        BuildStep(5, "تجميع الحزمة APK", "Packaging APK binaries", StepState.PENDING),
        BuildStep(6, "توقيع الحزمة وإخراج الملف", "Signing & finalizing APK", StepState.PENDING)
    )
}
