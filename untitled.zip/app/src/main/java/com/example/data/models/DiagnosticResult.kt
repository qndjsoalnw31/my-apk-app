package com.example.data.models

data class DiagnosticResult(
    val issues: List<DiagnosticIssue>,
    val isReadyToBuild: Boolean,
    val canAutoRepair: Boolean,
    val errorCount: Int = issues.count { it.severity == IssueSeverity.ERROR },
    val warningCount: Int = issues.count { it.severity == IssueSeverity.WARNING },
    val infoCount: Int = issues.count { it.severity == IssueSeverity.INFO }
)
