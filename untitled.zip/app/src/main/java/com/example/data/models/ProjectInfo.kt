package com.example.data.models

import java.io.File

data class ProjectInfo(
    val zipFileName: String,
    val zipFileSize: Long,
    val extractedRoot: File,
    val projectType: ProjectType,
    val gradleVersion: String? = null,
    val agpVersion: String? = null,
    val kotlinVersion: String? = null,
    val compileSdk: Int? = null,
    val targetSdk: Int? = null,
    val minSdk: Int? = null,
    val namespace: String? = null,
    val applicationId: String? = null,
    val appModuleName: String = "app",
    val hasGradleWrapper: Boolean = false,
    val hasWrapperJar: Boolean = false,
    val hasWrapperProperties: Boolean = false,
    val hasAndroidManifest: Boolean = false,
    val hasGoogleServicesJson: Boolean = false,
    val requiresGoogleServices: Boolean = false,
    val hasDebugKeystore: Boolean = false,
    val hasBuildGradle: Boolean = false,
    val isKotlinDsl: Boolean = false,
    val buildTypes: List<String> = listOf("debug", "release"),
    val detectedDependencies: List<String> = emptyList(),
    val totalFilesCount: Int = 0
)
