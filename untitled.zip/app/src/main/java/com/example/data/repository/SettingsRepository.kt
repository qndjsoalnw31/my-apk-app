package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.models.BuildSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("apk_builder_settings", Context.MODE_PRIVATE)

    private val _settingsFlow = MutableStateFlow(loadSettings())
    val settingsFlow: StateFlow<BuildSettings> = _settingsFlow.asStateFlow()

    fun loadSettings(): BuildSettings {
        return BuildSettings(
            buildVariant = prefs.getString("build_variant", "debug") ?: "debug",
            cleanBeforeBuild = prefs.getBoolean("clean_before_build", true),
            parallelBuild = prefs.getBoolean("parallel_build", true),
            offlineMode = prefs.getBoolean("offline_mode", false),
            memoryLimitMb = prefs.getInt("memory_limit_mb", 2048),
            isHybridMode = prefs.getBoolean("is_hybrid_mode", true),
            remoteServerUrl = prefs.getString("remote_server_url", "http://10.0.2.2:8000") ?: "http://10.0.2.2:8000",
            buildTimeoutSeconds = prefs.getInt("build_timeout_sec", 300),
            autoRepairBeforeBuild = prefs.getBoolean("auto_repair_before_build", true)
        )
    }

    fun updateSettings(settings: BuildSettings) {
        prefs.edit()
            .putString("build_variant", settings.buildVariant)
            .putBoolean("clean_before_build", settings.cleanBeforeBuild)
            .putBoolean("parallel_build", settings.parallelBuild)
            .putBoolean("offline_mode", settings.offlineMode)
            .putInt("memory_limit_mb", settings.memoryLimitMb)
            .putBoolean("is_hybrid_mode", settings.isHybridMode)
            .putString("remote_server_url", settings.remoteServerUrl)
            .putInt("build_timeout_sec", settings.buildTimeoutSeconds)
            .putBoolean("auto_repair_before_build", settings.autoRepairBeforeBuild)
            .apply()
        _settingsFlow.value = settings
    }
}
