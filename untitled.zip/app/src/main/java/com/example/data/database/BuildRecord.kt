package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "build_records")
data class BuildRecord(
    @PrimaryKey val id: String,
    val projectName: String,
    val zipFileName: String,
    val status: String, // "SUCCESS", "FAILED", "RUNNING", "CANCELLED"
    val startTime: Long,
    val endTime: Long? = null,
    val durationSeconds: Long = 0,
    val apkPath: String? = null,
    val apkSize: Long = 0,
    val apkFileName: String? = null,
    val errorDetails: String? = null,
    val errorArabicDiagnosis: String? = null,
    val errorFixAction: String? = null,
    val gradleVersion: String? = null,
    val agpVersion: String? = null,
    val compileSdk: Int? = null,
    val packageName: String? = null,
    val buildVariant: String = "debug",
    val isRemoteBuild: Boolean = false,
    val logOutput: String = ""
)
