package com.example.data.remote

import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Streaming

data class HealthResponse(
    val status: String,
    val gradleVersion: String?,
    val javaVersion: String?,
    val androidHome: String?
)

data class BuildTriggerResponse(
    val buildId: String,
    val status: String,
    val message: String
)

data class BuildStatusResponse(
    val buildId: String,
    val status: String, // "PENDING", "BUILDING", "SUCCESS", "FAILED", "CANCELLED"
    val currentStep: Int,
    val progressPercent: Int,
    val message: String,
    val apkUrl: String? = null,
    val apkSize: Long? = null,
    val errorMessage: String? = null
)

data class BuildLogsResponse(
    val buildId: String,
    val logs: String
)

interface BuildServerApi {

    @GET("/api/health")
    suspend fun checkHealth(): Response<HealthResponse>

    @Multipart
    @POST("/api/build")
    suspend fun triggerBuild(
        @Part zipFile: MultipartBody.Part,
        @Part("buildVariant") buildVariant: RequestBody,
        @Part("cleanBeforeBuild") clean: RequestBody
    ): Response<BuildTriggerResponse>

    @GET("/api/build/{id}")
    suspend fun getBuildStatus(@Path("id") buildId: String): Response<BuildStatusResponse>

    @GET("/api/build/{id}/logs")
    suspend fun getBuildLogs(@Path("id") buildId: String): Response<BuildLogsResponse>

    @POST("/api/build/{id}/cancel")
    suspend fun cancelBuild(@Path("id") buildId: String): Response<BuildTriggerResponse>

    @Streaming
    @GET("/api/build/{id}/apk")
    suspend fun downloadApk(@Path("id") buildId: String): Response<ResponseBody>
}
