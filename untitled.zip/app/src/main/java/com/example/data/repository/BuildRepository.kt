package com.example.data.repository

import com.example.data.database.BuildRecord
import com.example.data.database.BuildRecordDao
import kotlinx.coroutines.flow.Flow
import java.io.File

class BuildRepository(private val buildDao: BuildRecordDao) {

    val allBuilds: Flow<List<BuildRecord>> = buildDao.getAllBuilds()
    val latestBuild: Flow<BuildRecord?> = buildDao.getLatestBuild()

    suspend fun getBuildById(id: String): BuildRecord? = buildDao.getBuildById(id)

    suspend fun insertOrUpdate(record: BuildRecord) = buildDao.insertBuild(record)

    suspend fun deleteBuild(record: BuildRecord) {
        // Delete APK file if exists
        record.apkPath?.let { path ->
            val file = File(path)
            if (file.exists()) {
                file.delete()
            }
        }
        buildDao.deleteBuildById(record.id)
    }

    suspend fun clearAll() = buildDao.clearAllBuilds()
}
