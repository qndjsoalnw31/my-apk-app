package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.ui.MainViewModel
import com.example.ui.analyzer.ProjectAnalysisScreen
import com.example.ui.builder.BuildProgressScreen
import com.example.ui.builder.BuildSuccessScreen
import com.example.ui.components.InstallProgressDialog
import com.example.ui.editor.ProjectEditorScreen
import com.example.ui.environment.EnvironmentScreen
import com.example.ui.history.HistoryScreen
import com.example.ui.home.HomeScreen
import com.example.ui.logs.BuildLogsScreen
import com.example.ui.navigation.Screen
import com.example.ui.repair.ProjectProblemsScreen
import com.example.ui.repair.RepairCenterScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val context = LocalContext.current
                    val installState by viewModel.installState.collectAsState()

                    // Collect Intent launches (for Settings, Sharing, Direct Install fallbacks)
                    LaunchedEffect(Unit) {
                        viewModel.intentLaunchFlow.collect { intent ->
                            try {
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "تعذر فتح التطبيق المطلوب: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }

                    // Collect Toast events
                    LaunchedEffect(Unit) {
                        viewModel.eventFlow.collect { message ->
                            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                        }
                    }

                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AppNavigation(viewModel = viewModel)

                            // Universal PackageInstaller status & dialog
                            InstallProgressDialog(
                                installState = installState,
                                onDismiss = { viewModel.dismissInstallState() },
                                onOpenSettings = { viewModel.openUnknownSourcesSettings() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            is Screen.Home -> HomeScreen(viewModel = viewModel)
            is Screen.Analysis -> ProjectAnalysisScreen(viewModel = viewModel)
            is Screen.BuildProgress -> BuildProgressScreen(viewModel = viewModel)
            is Screen.BuildSuccess -> BuildSuccessScreen(viewModel = viewModel)
            is Screen.History -> HistoryScreen(viewModel = viewModel)
            is Screen.Settings -> SettingsScreen(viewModel = viewModel)
            is Screen.Environment -> EnvironmentScreen(viewModel = viewModel)
            is Screen.RepairCenter -> RepairCenterScreen(viewModel = viewModel)
            is Screen.ProjectProblems -> ProjectProblemsScreen(viewModel = viewModel)
            is Screen.ProjectEditor -> ProjectEditorScreen(viewModel = viewModel)
            is Screen.BuildLogs -> BuildLogsScreen(viewModel = viewModel)
        }
    }
}


