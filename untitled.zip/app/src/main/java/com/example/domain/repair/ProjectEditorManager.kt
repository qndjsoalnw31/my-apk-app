package com.example.domain.repair

import java.io.File
import java.io.FileInputStream
import java.io.InputStream

class ProjectEditorManager {

    companion object {
        // Allowed editable extensions
        val EDITABLE_EXTENSIONS = setOf(
            "gradle", "kts", "properties", "xml", "pro", "kt", "java", "json", "txt", "md", "cfg"
        )

        // Dangerous or forbidden binary files
        val FORBIDDEN_EXTENSIONS = setOf(
            "apk", "aab", "keystore", "jks", "jar", "aar", "so", "class", "dex", "lock", "bin", "png", "jpg", "jpeg", "webp"
        )
    }

    /**
     * Checks whether a file inside the project directory is safe and editable as text.
     */
    fun isEditableFile(file: File): Boolean {
        if (!file.exists() || !file.isFile) return false

        val ext = file.extension.lowercase()
        if (FORBIDDEN_EXTENSIONS.contains(ext)) return false
        if (EDITABLE_EXTENSIONS.contains(ext)) return true

        // Binary check: read first 512 bytes for null bytes or control characters
        return try {
            FileInputStream(file).use { fis ->
                val buffer = ByteArray(512)
                val read = fis.read(buffer)
                if (read > 0) {
                    for (i in 0 until read) {
                        val b = buffer[i].toInt()
                        if (b == 0) return false // null byte indicates binary
                    }
                }
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Lists all editable files in the project sorted hierarchically.
     */
    fun getProjectEditableFiles(projectDir: File): List<File> {
        if (!projectDir.exists() || !projectDir.isDirectory) return emptyList()

        val filesList = mutableListOf<File>()
        projectDir.walkTopDown()
            .filter { file ->
                file.isFile &&
                !file.path.contains("/.gradle/") &&
                !file.path.contains("/build/") &&
                !file.path.contains("/.idea/") &&
                !file.path.contains("/backups/") &&
                isEditableFile(file)
            }
            .forEach { filesList.add(it) }

        return filesList.sortedBy { it.relativeTo(projectDir).path }
    }

    /**
     * Reads text content of an editable file safely.
     */
    fun readFileContent(file: File): String {
        if (!isEditableFile(file)) {
            throw IllegalArgumentException("هذا الملف غير قابل للتحرير كنص لأنه ملف ثنائي أو غير مدعوم.")
        }
        return file.readText(Charsets.UTF_8)
    }

    /**
     * Saves text content to file safely.
     */
    fun saveFileContent(file: File, newContent: String) {
        if (!isEditableFile(file) && file.exists()) {
            throw IllegalArgumentException("لا يمكن الكتابة على ملف ثنائي.")
        }
        file.parentFile?.mkdirs()
        file.writeText(newContent, Charsets.UTF_8)
    }

    /**
     * Copies a user-selected file (like google-services.json) from stream into destination project file.
     */
    fun copyUserFile(inputStream: InputStream, destinationFile: File): Boolean {
        return try {
            destinationFile.parentFile?.mkdirs()
            destinationFile.outputStream().use { output ->
                inputStream.copyTo(output)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Generates line-by-line diff between original and modified text.
     */
    fun computeDiff(original: String, modified: String): List<DiffLine> {
        val originalLines = original.lines()
        val modifiedLines = modified.lines()
        val diff = mutableListOf<DiffLine>()

        var i = 0
        var j = 0

        while (i < originalLines.size || j < modifiedLines.size) {
            if (i < originalLines.size && j < modifiedLines.size) {
                if (originalLines[i] == modifiedLines[j]) {
                    diff.add(DiffLine(DiffType.UNCHANGED, originalLines[i]))
                    i++
                    j++
                } else {
                    diff.add(DiffLine(DiffType.REMOVED, originalLines[i]))
                    diff.add(DiffLine(DiffType.ADDED, modifiedLines[j]))
                    i++
                    j++
                }
            } else if (i < originalLines.size) {
                diff.add(DiffLine(DiffType.REMOVED, originalLines[i]))
                i++
            } else if (j < modifiedLines.size) {
                diff.add(DiffLine(DiffType.ADDED, modifiedLines[j]))
                j++
            }
        }

        return diff
    }
}
