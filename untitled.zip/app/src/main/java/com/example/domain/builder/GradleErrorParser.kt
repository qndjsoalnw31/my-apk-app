package com.example.domain.builder

data class ParsedGradleError(
    val titleArabic: String,
    val causeArabic: String,
    val actionArabic: String,
    val rawSnippet: String? = null
)

class GradleErrorParser {

    fun parseErrorLog(fullLog: String): ParsedGradleError {
        val lower = fullLog.lowercase()

        return when {
            lower.contains("minimum supported gradle version") || lower.contains("is not compatible with this version of the android gradle plugin") -> {
                ParsedGradleError(
                    titleArabic = "عدم توافق إصدار Gradle مع AGP",
                    causeArabic = "إصدار Gradle الحالي في المشروع غير متوافق مع إصدار Android Gradle Plugin المستخدم.",
                    actionArabic = "تغيير distributionUrl في ملف gradle-wrapper.properties إلى الإصدار المتوافق أو الضغط على زر 'إصلاح المشاكل تلقائياً'."
                )
            }

            lower.contains("sdk location not found") || lower.contains("android_home") || lower.contains("sdk.dir") -> {
                ParsedGradleError(
                    titleArabic = "مسار Android SDK غير موجود",
                    causeArabic = "نظام البناء لا يجد مسار حزم Android SDK وأدوات الترجمة.",
                    actionArabic = "تأكد من ضبط متغير البيئة ANDROID_HOME أو توفر مسار SDK صحيح في ملف local.properties، أو استخدام سيرفر البناء السحابي."
                )
            }

            lower.contains("google-services.json is missing") || lower.contains("file google-services.json is missing") -> {
                ParsedGradleError(
                    titleArabic = "ملف google-services.json مفقود",
                    causeArabic = "المشروع يستخدم إضافات Firebase / Google Play Services ولكنه لا يحتوي على ملف التهيئة في مجلد app/.",
                    actionArabic = "قم بتنزيل ملف google-services.json من لوحة تحكم Firebase Console وأضفه داخل مجلد app/ داخل المشروع."
                )
            }

            lower.contains("validatesigningdebug") || lower.contains("keystore") || lower.contains("key password") -> {
                ParsedGradleError(
                    titleArabic = "مشكلة في إعدادات توقيع التطبيق",
                    causeArabic = "مفتاح التوقيع التجريبي أو النهائي debug.keystore غير موجود أو كلمة المرور غير صحيحة.",
                    actionArabic = "افحص كتلة signingConfigs في ملف build.gradle أو تأكد من وجود ملف debug.keystore صالح."
                )
            }

            lower.contains("outofmemoryerror") || lower.contains("java heap space") || lower.contains("metaspace") -> {
                ParsedGradleError(
                    titleArabic = "نفاد ذاكرة البناء (Out Of Memory)",
                    causeArabic = "استهلكت عملية الترجمة وبناء الحزمة كامل الذاكرة المخصصة لـ JVM.",
                    actionArabic = "قم بزيادة حد الذاكرة (Memory Limit) في صفحة الإعدادات أو أوقف العمليات الخلفية في الهاتف."
                )
            }

            lower.contains("manifest merger failed") -> {
                ParsedGradleError(
                    titleArabic = "تعارض في دمج AndroidManifest",
                    causeArabic = "حدث تضارب بين سمات ملف AndroidManifest.xml الخاص بالتطبيق وإحدى المكتبات المستخدمة (مثل allowBackup أو theme).",
                    actionArabic = "أضف tools:replace=\"android:allowBackup\" أو السمة المتعارضة في وسم <application> داخل Manifest."
                )
            }

            lower.contains("duplicate class") -> {
                ParsedGradleError(
                    titleArabic = "تضارب اعتمادات مكررة (Duplicate Classes)",
                    causeArabic = "توجد مكتبتان مختلفتان تقومان بتضمين نفس الكلاس في المشروع.",
                    actionArabic = "استخدم exclude group أو قم بترقية المكتبات القديمة لتفادي النسخ المتكررة."
                )
            }

            lower.contains("unresolved reference") || lower.contains("cannot find symbol") -> {
                ParsedGradleError(
                    titleArabic = "خطأ برمجي في كود المشروع",
                    causeArabic = "يوجد كود يستدعي كلاس أو دالة أو متغير غير معرف، أو مكتبة مفقودة في dependencies.",
                    actionArabic = "راجع ملفات الكود التي تظهر في سجل البناء وتأكد من تضمين جميع المكتبات المطلوبة في build.gradle."
                )
            }

            lower.contains("namespace not specified") || lower.contains("namespace is not specified") -> {
                ParsedGradleError(
                    titleArabic = "خاصية namespace مفقودة",
                    causeArabic = "يتطلب AGP الحديث تحديد namespace صريح داخل كتلة android { ... }.",
                    actionArabic = "استخدم زر 'إصلاح المشاكل تلقائياً' لإضافة المعرف تلقائياً."
                )
            }

            else -> {
                ParsedGradleError(
                    titleArabic = "فشل في عملية البناء",
                    causeArabic = "أوقف Gradle عملية الترجمة لوجود خطأ أثناء تنفيذ المهام.",
                    actionArabic = "راجع سجل البناء الكامل أدناه لمعرفة السطر المحدد المتسبب بالخطأ."
                )
            }
        }
    }
}
