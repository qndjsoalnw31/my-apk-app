package com.example.domain.repair

import java.io.File

enum class RepairActionType {
    AUTO_FIX,
    MANUAL_FIX,
    USER_FILE_REQUIRED,
    ENVIRONMENT_FIX,
    UNSUPPORTED
}

enum class ProblemSeverity {
    ERROR,
    WARNING,
    INFO
}

data class DiagnosticProblem(
    val id: String,
    val title: String,
    val severity: ProblemSeverity,
    val reasonArabic: String,
    val affectedFilePath: String?,
    val affectedLineNumber: Int? = null,
    val currentValue: String? = null,
    val expectedValue: String? = null,
    val actionType: RepairActionType,
    val whyItHappened: String,
    val suggestedFixArabic: String,
    val autoFixCode: String? = null,
    val isAutoFixAvailable: Boolean = false,
    val userFileKey: String? = null // e.g. "google-services.json"
)

data class RepairHistoryEntry(
    val id: String,
    val timestamp: Long,
    val dateFormatted: String,
    val problemTitle: String,
    val actionDescription: String,
    val affectedFile: String,
    val isSuccess: Boolean,
    val failureReason: String? = null
)

data class AiFixProposal(
    val problemId: String,
    val title: String,
    val explanation: String,
    val affectedFilePath: String,
    val originalSnippet: String,
    val proposedSnippet: String,
    val fullModifiedContent: String,
    val diffLines: List<DiffLine>,
    val warningMessage: String? = null
)

data class DiffLine(
    val type: DiffType,
    val text: String
)

enum class DiffType {
    ADDED,
    REMOVED,
    UNCHANGED
}
