package com.example.domain.builder

import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.File

data class EnvironmentItem(
    val title: String,
    val isAvailable: Boolean,
    val detail: String,
    val isRequired: Boolean = true
)

data class EnvironmentStatus(
    val isReadyForLocalBuild: Boolean,
    val items: List<EnvironmentItem>,
    val javaVersion: String,
    val availableStorageMb: Long,
    val totalRamMb: Long,
    val summaryArabic: String
)

class EnvironmentDetector(private val context: Context) {

    fun detectEnvironment(): EnvironmentStatus {
        val items = mutableListOf<EnvironmentItem>()

        // 1. JDK Check
        val javaVersion = System.getProperty("java.version") ?: "Android Runtime"
        val javaVendor = System.getProperty("java.vendor") ?: "Google / Android"
        val hasJdk = !javaVersion.isNullOrBlank()
        items.add(
            EnvironmentItem(
                title = "بيئة تشغيل Java / JDK",
                isAvailable = hasJdk,
                detail = "$javaVersion ($javaVendor)"
            )
        )

        // 2. Android SDK Check
        val envAndroidHome = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT")
        val hasAndroidHome = !envAndroidHome.isNullOrBlank() && File(envAndroidHome).exists()
        val sdkDetail = if (hasAndroidHome) {
            "مسار SDK: $envAndroidHome"
        } else {
            "غير متوفر محلياً في مسار قياسي (يحتاج تثبيت أو سيرفر بناء)"
        }
        items.add(
            EnvironmentItem(
                title = "Android SDK & Platform Tools",
                isAvailable = hasAndroidHome,
                detail = sdkDetail
            )
        )

        // 3. Gradle Tooling Check
        val gradleHome = System.getenv("GRADLE_HOME")
        val hasGradle = !gradleHome.isNullOrBlank() && File(gradleHome).exists()
        items.add(
            EnvironmentItem(
                title = "أداة Gradle للبناء",
                isAvailable = hasGradle || hasAndroidHome,
                detail = if (hasGradle) "مسار: $gradleHome" else "يتم تشغيلها عبر Gradle Wrapper أو السيرفر السحابي"
            )
        )

        // 4. Build Tools Check
        items.add(
            EnvironmentItem(
                title = "أدوات Build Tools (aapt2, d8, zipalign)",
                isAvailable = hasAndroidHome,
                detail = if (hasAndroidHome) "متوفرة مع حزمة Android SDK" else "يتم توفيرها بواسطة بيئة البناء"
            )
        )

        // 5. Storage Space Check
        val statFs = StatFs(context.filesDir.absolutePath)
        val availableBytes = statFs.availableBlocksLong * statFs.blockSizeLong
        val availableMb = availableBytes / (1024 * 1024)
        val hasEnoughStorage = availableMb >= 300 // at least 300MB
        items.add(
            EnvironmentItem(
                title = "مساحة التخزين الداخلية الشاغرة",
                isAvailable = hasEnoughStorage,
                detail = "$availableMb ميجابايت متاحة"
            )
        )

        val isReadyForLocal = hasJdk && hasAndroidHome && hasEnoughStorage
        val summary = if (isReadyForLocal) {
            "البيئة المحلية جاهزة للبناء المباشر بالكامل على الهاتف."
        } else {
            "البيئة مهيأة للعمل بنمط Hybrid فائق السرعة عبر محرك البناء المعزول."
        }

        return EnvironmentStatus(
            isReadyForLocalBuild = isReadyForLocal,
            items = items,
            javaVersion = javaVersion,
            availableStorageMb = availableMb,
            totalRamMb = Runtime.getRuntime().maxMemory() / (1024 * 1024),
            summaryArabic = summary
        )
    }
}
