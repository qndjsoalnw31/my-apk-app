package com.example.domain.installer

import java.io.File

sealed interface InstallState {
    object Idle : InstallState

    data class Preparing(
        val progress: Int,
        val message: String
    ) : InstallState

    data class PendingUserConfirmation(
        val message: String
    ) : InstallState

    data class Success(
        val message: String,
        val packageName: String? = null
    ) : InstallState

    data class Error(
        val title: String,
        val message: String,
        val canOpenSettings: Boolean = false,
        val detailedLog: String? = null
    ) : InstallState
}

data class ApkPreCheckResult(
    val isValid: Boolean,
    val errorMessage: String? = null,
    val resolvedFile: File? = null,
    val packageName: String? = null,
    val versionName: String? = null,
    val versionCode: Long? = null,
    val appLabel: String? = null,
    val fileSizeBytes: Long = 0L,
    val isZipValid: Boolean = false,
    val hasManifest: Boolean = false,
    val detailedDiagnosis: String? = null
)

