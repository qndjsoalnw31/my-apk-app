package com.example.domain.builder

import com.example.data.models.ProjectInfo

object GitHubWorkflowGenerator {

    /**
     * Generates a fully dynamic and resilient GitHub Actions Workflow YAML for any Android project.
     * Automatically adapts to nested directories, Java versions, Gradle wrappers, and APK locations.
     */
    fun generateWorkflowYaml(projectInfo: ProjectInfo): String {
        val javaVer = projectInfo.javaVersion ?: "17"
        val compileSdk = projectInfo.compileSdk ?: 34
        val primaryModule = projectInfo.appModuleName.removePrefix(":")
        val projName = projectInfo.projectName

        return """
name: Android APK Build (Automated CI)

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    name: Build Debug APK
    runs-on: ubuntu-latest
    timeout-minutes: 45

    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Locate Android Project Root
        id: locate-root
        run: |
          echo "=== Scanning for Android Gradle Root Directory ==="
          SETTINGS_FILE=${'$'}(find . -maxdepth 4 -name "settings.gradle*" | head -n 1)
          if [ -n "${'$'}SETTINGS_FILE" ]; then
            ROOT_DIR=${'$'}(dirname "${'$'}SETTINGS_FILE")
            echo "Found settings file at: ${'$'}SETTINGS_FILE"
            echo "project_root=${'$'}ROOT_DIR" >> ${'$'}GITHUB_OUTPUT
          else
            BUILD_FILE=${'$'}(find . -maxdepth 4 -name "build.gradle*" | head -n 1)
            if [ -n "${'$'}BUILD_FILE" ]; then
              ROOT_DIR=${'$'}(dirname "${'$'}BUILD_FILE")
              echo "Found build file at: ${'$'}BUILD_FILE"
              echo "project_root=${'$'}ROOT_DIR" >> ${'$'}GITHUB_OUTPUT
            else
              echo "project_root=." >> ${'$'}GITHUB_OUTPUT
            fi
          fi

      - name: Set up JDK $javaVer
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '$javaVer'
          cache: 'gradle'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3
        with:
          cmdline-tools-version: 11076708

      - name: Accept Android SDK Licenses & Install Platform
        run: |
          yes | sdkmanager --licenses || true
          sdkmanager "platforms;android-$compileSdk" "build-tools;$compileSdk.0.0" || true

      - name: Grant Execute Permission to Gradle Wrapper
        working-directory: ${'$'}{{ steps.locate-root.outputs.project_root }}
        run: |
          if [ -f "gradlew" ]; then
            chmod +x gradlew
          else
            echo "Gradlew not found, generating wrapper using gradle..."
            gradle wrapper || true
            chmod +x gradlew || true
          fi

      - name: Verify Gradle Projects
        working-directory: ${'$'}{{ steps.locate-root.outputs.project_root }}
        run: |
          ./gradlew projects --no-daemon || gradle projects

      - name: Build Debug APK
        working-directory: ${'$'}{{ steps.locate-root.outputs.project_root }}
        run: |
          echo "Starting assembleDebug on module '$primaryModule'..."
          ./gradlew assembleDebug --stacktrace --no-daemon || ./gradlew :$primaryModule:assembleDebug --stacktrace --no-daemon

      - name: Discover & Collect Generated APKs
        id: find-apk
        run: |
          echo "=== Recursive APK Discovery ==="
          mkdir -p output_apks
          find . -type f -name "*.apk" -not -path "*/output_apks/*" | while read -r apk_file; do
            echo "Discovered APK: ${'$'}apk_file"
            cp "${'$'}apk_file" output_apks/
          done
          APK_COUNT=${'$'}(ls -1 output_apks | wc -l)
          echo "Found ${'$'}APK_COUNT APK files."
          if [ "${'$'}APK_COUNT" -eq 0 ]; then
            echo "Error: No APK file was generated."
            exit 1
          fi

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: $projName-debug-apk
          path: output_apks/*.apk
          retention-days: 14
""".trimIndent()
    }
}
