package com.example.domain.repair

import com.example.data.models.ProjectInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RepairManager(
    private val backupManager: BackupManager,
    private val projectEditorManager: ProjectEditorManager,
    private val diagnosticsEngine: DiagnosticsEngine
) {

    private val _repairHistory = mutableListOf<RepairHistoryEntry>()
    val repairHistory: List<RepairHistoryEntry> get() = _repairHistory.toList()

    /**
     * Executes an idempotent auto-repair action for a specific diagnostic problem.
     */
    fun executeAutoFix(
        projectDir: File,
        problem: DiagnosticProblem,
        projectInfo: ProjectInfo?
    ): Boolean {
        // 1. Create a safety backup first
        backupManager.createBackup(projectDir, "نسخة أمان قبل إصلاح: ${problem.title}")

        val now = System.currentTimeMillis()
        val dateFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(now))

        var success = false
        var failureReason: String? = null
        var actionDescription = ""

        try {
            when {
                problem.id == "gradle_version_mismatch" -> {
                    val targetGradle = problem.expectedValue?.removePrefix("Gradle ") ?: "8.11.1"
                    val wrapperProps = File(projectDir, "gradle/wrapper/gradle-wrapper.properties")
                    wrapperProps.parentFile?.mkdirs()

                    val newContent = """
                        distributionBase=GRADLE_USER_HOME
                        distributionPath=wrapper/dists
                        distributionUrl=https\://services.gradle.org/distributions/gradle-$targetGradle-bin.zip
                        networkTimeout=10000
                        validateDistributionUrl=true
                        zipStoreBase=GRADLE_USER_HOME
                        zipStorePath=wrapper/dists
                    """.trimIndent()
                    wrapperProps.writeText(newContent)

                    actionDescription = "تحديث إصدار Gradle إلى $targetGradle في gradle-wrapper.properties"
                    success = true
                }

                problem.id == "debug_signing_problem" -> {
                    val appGradle = findAppBuildGradle(projectDir)
                    if (appGradle != null && appGradle.exists()) {
                        var content = appGradle.readText()
                        if (!content.contains("signingConfigs")) {
                            content = content.replaceFirst("android\\s*\\{".toRegex(), """
                                android {
                                    signingConfigs {
                                        getByName("debug") {
                                            // Debug signing configured
                                        }
                                    }
                            """.trimIndent())
                            appGradle.writeText(content)
                        }
                    }
                    actionDescription = "تجهيز وتصحيح إعدادات Debug Signing"
                    success = true
                }

                problem.id == "jvm_memory_problem" -> {
                    val gradleProps = File(projectDir, "gradle.properties")
                    val existing = if (gradleProps.exists()) gradleProps.readText() else ""
                    val jvmLine = problem.expectedValue ?: "org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m"

                    val updated = if (existing.contains("org.gradle.jvmargs")) {
                        existing.replace(Regex("org\\.gradle\\.jvmargs=.*"), jvmLine)
                    } else {
                        existing + "\n" + jvmLine + "\n"
                    }
                    gradleProps.writeText(updated)

                    actionDescription = "ضبط حد الذاكرة $jvmLine في gradle.properties"
                    success = true
                }

                problem.id == "missing_namespace" -> {
                    val appGradle = findAppBuildGradle(projectDir)
                    val targetNs = problem.expectedValue?.removePrefix("namespace = ")?.trim('"', '\'', ' ') ?: "com.example.app"
                    if (appGradle != null && appGradle.exists()) {
                        var content = appGradle.readText()
                        if (!content.contains("namespace") && !content.contains("namespace =")) {
                            val isKts = appGradle.name.endsWith(".kts")
                            val line = if (isKts) "    namespace = \"$targetNs\"\n" else "    namespace '$targetNs'\n"
                            content = content.replaceFirst("android\\s*\\{".toRegex(), "android {\n$line")
                            appGradle.writeText(content)
                            actionDescription = "إضافة namespace = \"$targetNs\" في ${appGradle.name}"
                            success = true
                        } else {
                            actionDescription = "خاصية namespace موجودة بالفعل"
                            success = true
                        }
                    } else {
                        failureReason = "لم يتم العثور على ملف build.gradle الخاص بالتطبيق."
                    }
                }

                problem.id == "missing_sdk_location" -> {
                    val localProps = File(projectDir, "local.properties")
                    val sdkPath = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT") ?: "/android-sdk"
                    localProps.writeText("sdk.dir=${sdkPath.replace("\\", "/")}\n")
                    actionDescription = "إنشاء local.properties بمسار sdk.dir=$sdkPath"
                    success = true
                }

                problem.id == "missing_compile_sdk" -> {
                    val appGradle = findAppBuildGradle(projectDir)
                    if (appGradle != null && appGradle.exists()) {
                        var content = appGradle.readText()
                        if (!content.contains("compileSdk") && !content.contains("compileSdkVersion")) {
                            val isKts = appGradle.name.endsWith(".kts")
                            val sdkLine = if (isKts) "    compileSdk = 34\n" else "    compileSdkVersion 34\n"
                            content = content.replaceFirst("android\\s*\\{".toRegex(), "android {\n$sdkLine")
                            appGradle.writeText(content)
                        }
                        actionDescription = "تعيين compileSdk = 34 في ${appGradle.name}"
                        success = true
                    }
                }

                problem.id == "dependency_resolution_error" -> {
                    val settingsGradle = File(projectDir, "settings.gradle.kts").takeIf { it.exists() }
                        ?: File(projectDir, "settings.gradle").takeIf { it.exists() }
                    if (settingsGradle != null) {
                        var content = settingsGradle.readText()
                        if (!content.contains("google()")) {
                            content = content.replace("repositories {", "repositories {\n        google()\n        mavenCentral()\n        gradlePluginPortal()")
                            settingsGradle.writeText(content)
                        }
                        actionDescription = "تضمين مستودعات google() و mavenCentral() في settings.gradle"
                        success = true
                    }
                }

                problem.id == "jvm_target_mismatch" -> {
                    val appGradle = findAppBuildGradle(projectDir)
                    if (appGradle != null && appGradle.exists()) {
                        var content = appGradle.readText()
                        val jvmBlock = """
                            compileOptions {
                                sourceCompatibility = JavaVersion.VERSION_17
                                targetCompatibility = JavaVersion.VERSION_17
                            }
                            kotlinOptions {
                                jvmTarget = "17"
                            }
                        """.trimIndent()
                        if (!content.contains("JavaVersion.VERSION_17") && !content.contains("JavaVersion.VERSION_21")) {
                            content = content.replaceFirst("android\\s*\\{".toRegex(), "android {\n    $jvmBlock\n")
                            appGradle.writeText(content)
                        }
                        actionDescription = "توحيد JavaVersion.VERSION_17 و jvmTarget = 17"
                        success = true
                    }
                }

                else -> {
                    failureReason = "نوع المشكلة غير قابل للإصلاح التلقائي المباشر."
                }
            }
        } catch (e: Exception) {
            success = false
            failureReason = e.message
        }

        _repairHistory.add(
            0,
            RepairHistoryEntry(
                id = "repair_${System.currentTimeMillis()}",
                timestamp = now,
                dateFormatted = dateFormatted,
                problemTitle = problem.title,
                actionDescription = actionDescription.ifEmpty { "محاولة إصلاح" },
                affectedFile = problem.affectedFilePath ?: "غير محدد",
                isSuccess = success,
                failureReason = failureReason
            )
        )

        // Write or update repair-report.json in project working root
        writeRepairReportJson(projectDir, projectInfo)

        return success
    }

    /**
     * Generates and writes repair-report.json inside the working directory.
     */
    fun writeRepairReportJson(projectDir: File, projectInfo: ProjectInfo?) {
        try {
            val reportObj = JSONObject()
            reportObj.put("detected_project", projectInfo?.projectName ?: "unknown")
            reportObj.put("root_directory", projectInfo?.extractedRoot?.absolutePath ?: projectDir.absolutePath)
            reportObj.put("relative_root", projectInfo?.relativeProjectRoot ?: "")
            reportObj.put("gradle_version", projectInfo?.gradleVersion ?: "unknown")
            reportObj.put("agp_version", projectInfo?.agpVersion ?: "unknown")
            reportObj.put("kotlin_version", projectInfo?.kotlinVersion ?: "unknown")
            reportObj.put("ksp_version", projectInfo?.kspVersion ?: "none")
            reportObj.put("java_version", projectInfo?.javaVersion ?: "17")
            reportObj.put("compile_sdk", projectInfo?.compileSdk ?: 34)
            reportObj.put("target_sdk", projectInfo?.targetSdk ?: 34)
            reportObj.put("min_sdk", projectInfo?.minSdk ?: 24)

            val appMods = JSONArray()
            projectInfo?.applicationModules?.forEach { appMods.put(it) }
            reportObj.put("application_modules", appMods)

            val libMods = JSONArray()
            projectInfo?.libraryModules?.forEach { libMods.put(it) }
            reportObj.put("library_modules", libMods)

            val repairsArray = JSONArray()
            _repairHistory.forEach { entry ->
                val rep = JSONObject()
                rep.put("problem", entry.problemTitle)
                rep.put("action", entry.actionDescription)
                rep.put("file", entry.affectedFile)
                rep.put("success", entry.isSuccess)
                rep.put("timestamp", entry.timestamp)
                repairsArray.put(rep)
            }
            reportObj.put("repairs", repairsArray)

            val reportFile = File(projectDir, "repair-report.json")
            reportFile.writeText(reportObj.toString(2))
        } catch (_: Exception) {}
    }

    /**
     * Generates an AI rule-based code patch proposal with a diff for review before applying.
     */
    fun generateAiPatchProposal(projectDir: File, problem: DiagnosticProblem): AiFixProposal? {
        val relPath = problem.affectedFilePath ?: return null
        val targetFile = File(projectDir, relPath)
        if (!targetFile.exists() || !projectEditorManager.isEditableFile(targetFile)) return null

        val originalContent = targetFile.readText()
        var modifiedContent = originalContent
        var originalSnippet = ""
        var proposedSnippet = ""
        var explanation = ""
        var warning: String? = null

        when (problem.id) {
            "gradle_version_mismatch" -> {
                val targetGradle = problem.expectedValue?.removePrefix("Gradle ") ?: "8.11.1"
                originalSnippet = originalContent.lines().firstOrNull { it.contains("distributionUrl") } ?: ""
                proposedSnippet = "distributionUrl=https\\://services.gradle.org/distributions/gradle-$targetGradle-bin.zip"
                modifiedContent = originalContent.replace(Regex("distributionUrl=.*"), proposedSnippet)
                explanation = "تحديث إصدار حزمة توزيع Gradle لتتوافق مع إضافة Android Gradle Plugin."
                warning = "يرجى التحقق من توفر اتصال بالإنترنت أثناء البناء لتحميل إصدار Gradle الجديد."
            }

            "missing_namespace" -> {
                val targetNs = problem.expectedValue?.removePrefix("namespace = ")?.trim('"', '\'', ' ') ?: "com.example.app"
                val isKts = targetFile.name.endsWith(".kts")
                originalSnippet = "android {"
                proposedSnippet = "android {\n    namespace = \"$targetNs\""
                val replacement = if (isKts) "android {\n    namespace = \"$targetNs\"\n" else "android {\n    namespace '$targetNs'\n"
                modifiedContent = originalContent.replaceFirst("android\\s*\\{".toRegex(), replacement)
                explanation = "إضافة تعريف namespace المطلوب صراحة لتوليد ملفات الموارد R بدون تعارض."
            }

            "jvm_memory_problem" -> {
                val jvmLine = problem.expectedValue ?: "org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m"
                originalSnippet = originalContent.lines().firstOrNull { it.contains("org.gradle.jvmargs") } ?: "(غير موجود)"
                proposedSnippet = jvmLine
                modifiedContent = if (originalContent.contains("org.gradle.jvmargs")) {
                    originalContent.replace(Regex("org\\.gradle\\.jvmargs=.*"), jvmLine)
                } else {
                    originalContent + "\n" + jvmLine + "\n"
                }
                explanation = "زيادة الحد الأقصى لذاكرة JVM Heap لتجنب نفاد الذاكرة أثناء معالجة ملفات Dex."
            }

            "jvm_target_mismatch" -> {
                originalSnippet = "compileOptions { ... }"
                proposedSnippet = """
                    compileOptions {
                        sourceCompatibility = JavaVersion.VERSION_17
                        targetCompatibility = JavaVersion.VERSION_17
                    }
                    kotlinOptions {
                        jvmTarget = "17"
                    }
                """.trimIndent()
                modifiedContent = originalContent.replaceFirst("android\\s*\\{".toRegex(), "android {\n    $proposedSnippet\n")
                explanation = "توحيد إصدار بايت كود Java و Kotlin إلى Java 17 المتوافق مع AGP 8+."
                warning = "تعديل إعدادات التجميع قد يتطلب توافق المكتبات الخارجية مع Java 17."
            }

            else -> return null
        }

        val diff = projectEditorManager.computeDiff(originalContent, modifiedContent)

        return AiFixProposal(
            problemId = problem.id,
            title = "اقتراح تصحيح ذكي: ${problem.title}",
            explanation = explanation,
            affectedFilePath = relPath,
            originalSnippet = originalSnippet,
            proposedSnippet = proposedSnippet,
            fullModifiedContent = modifiedContent,
            diffLines = diff,
            warningMessage = warning
        )
    }

    /**
     * Applies an AI fix patch after user explicit confirmation.
     */
    fun applyAiPatch(projectDir: File, proposal: AiFixProposal): Boolean {
        val targetFile = File(projectDir, proposal.affectedFilePath)
        backupManager.createBackup(projectDir, "نسخة أمان قبل تطبيق اقتراح الذكاء الاصطناعي على ${targetFile.name}")
        projectEditorManager.saveFileContent(targetFile, proposal.fullModifiedContent)

        _repairHistory.add(
            0,
            RepairHistoryEntry(
                id = "ai_patch_${System.currentTimeMillis()}",
                timestamp = System.currentTimeMillis(),
                dateFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()),
                problemTitle = proposal.title,
                actionDescription = "تطبيق تعديل الذكاء الاصطناعي على ${proposal.affectedFilePath}",
                affectedFile = proposal.affectedFilePath,
                isSuccess = true
            )
        )
        return true
    }

    /**
     * Builds a sanitized, shareable AI error report without any sensitive keys or passwords.
     */
    fun buildSanitizedErrorReport(
        projectInfo: ProjectInfo?,
        problems: List<DiagnosticProblem>,
        buildLog: String?
    ): String {
        val sb = StringBuilder()
        sb.appendLine("=== تقرير تشخيص مشكلة المشروع (APK Builder Mobile) ===")
        sb.appendLine("Project Name: ${projectInfo?.projectName ?: "Unknown"}")
        sb.appendLine("Project Root: ${projectInfo?.relativeProjectRoot.takeIf { !it.isNullOrBlank() } ?: "."}")
        sb.appendLine("Project Type: ${projectInfo?.projectType?.displayNameArabic ?: "Android Gradle"}")
        sb.appendLine("Score: ${projectInfo?.confidenceScore ?: 0}%")
        sb.appendLine("Gradle Version: ${projectInfo?.gradleVersion ?: "غير محدد"}")
        sb.appendLine("AGP Version: ${projectInfo?.agpVersion ?: "غير محدد"}")
        sb.appendLine("Kotlin Version: ${projectInfo?.kotlinVersion ?: "غير محدد"}")
        sb.appendLine("Java Target: Java ${projectInfo?.javaVersion ?: "17"}")
        sb.appendLine("Compile SDK: ${projectInfo?.compileSdk ?: "غير محدد"}")
        sb.appendLine("Target SDK: ${projectInfo?.targetSdk ?: "غير محدد"}")
        sb.appendLine("Min SDK: ${projectInfo?.minSdk ?: "غير محدد"}")
        sb.appendLine("Modules: ${projectInfo?.allModules?.joinToString(", ")}")
        sb.appendLine("Has AndroidManifest: ${projectInfo?.hasAndroidManifest}")
        sb.appendLine("Has Google Services: ${projectInfo?.hasGoogleServicesJson}")
        sb.appendLine()
        sb.appendLine("--- المشاكل المكتشفة (${problems.size}) ---")
        problems.forEachIndexed { i, p ->
            sb.appendLine("${i + 1}. [${p.severity.name}] ${p.title}")
            sb.appendLine("   - السبب: ${p.reasonArabic}")
            sb.appendLine("   - الملف المتأثر: ${p.affectedFilePath ?: "غير محدد"} (السطر: ${p.affectedLineNumber ?: "غير محدد"})")
            sb.appendLine("   - القيمة الحالية: ${p.currentValue ?: "-"}")
            sb.appendLine("   - القيمة المطلوبة: ${p.expectedValue ?: "-"}")
            sb.appendLine("   - نوع الإصلاح: ${p.actionType.name}")
            sb.appendLine()
        }

        if (!buildLog.isNullOrBlank()) {
            sb.appendLine("--- مقتطف من سجل الأخطاء (Sanitized Log) ---")
            val sanitized = sanitizeLogs(buildLog)
            sb.appendLine(sanitized.takeLast(2000))
        }

        return sb.toString()
    }

    private fun sanitizeLogs(raw: String): String {
        return raw
            .replace(Regex("password=[^&\\s]+", RegexOption.IGNORE_CASE), "password=***")
            .replace(Regex("key=[^&\\s]+", RegexOption.IGNORE_CASE), "key=***")
            .replace(Regex("token=[^&\\s]+", RegexOption.IGNORE_CASE), "token=***")
            .replace(Regex("authorization:\\s*bearer\\s+[\\w.-]+", RegexOption.IGNORE_CASE), "authorization: Bearer ***")
    }

    private fun findAppBuildGradle(projectDir: File): File? {
        val candidates = listOf("app", "mobile", "android", "client", "launcher")
        for (cand in candidates) {
            val sub = File(projectDir, cand)
            if (sub.exists()) {
                val kts = File(sub, "build.gradle.kts")
                if (kts.exists()) return kts
                val groovy = File(sub, "build.gradle")
                if (groovy.exists()) return groovy
            }
        }
        val rootKts = File(projectDir, "build.gradle.kts")
        if (rootKts.exists()) return rootKts
        val rootGroovy = File(projectDir, "build.gradle")
        if (rootGroovy.exists()) return rootGroovy
        return null
    }
}
