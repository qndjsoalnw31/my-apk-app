package com.example.domain.installer

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipFile

data class DiscoveredApk(
    val file: File,
    val fileName: String,
    val sizeBytes: Long,
    val sizeFormatted: String,
    val variant: String, // "debug", "release", "unsigned"
    val relativePath: String,
    val packageName: String? = null,
    val versionName: String? = null,
    val versionCode: Long? = null,
    val isValid: Boolean = true
)

class ApkManager(private val context: Context) {

    companion object {
        private const val TAG = "ApkManager"
    }

    /**
     * Comprehensive validation of an APK file.
     * Checks filesystem existence, size, ZIP structure, AndroidManifest.xml presence,
     * and Android PackageManager archive parsing.
     */
    fun validateApk(apkFile: File?): ApkPreCheckResult {
        if (apkFile == null) {
            return ApkPreCheckResult(
                isValid = false,
                errorMessage = "تعذر بدء الفحص: لم يتم تحديد ملف APK."
            )
        }

        if (!apkFile.exists()) {
            return ApkPreCheckResult(
                isValid = false,
                errorMessage = "ملف APK غير موجود في المسار:\n${apkFile.absolutePath}"
            )
        }

        if (!apkFile.isFile) {
            return ApkPreCheckResult(
                isValid = false,
                errorMessage = "المسار المحدد ليس ملفاً صالحاً:\n${apkFile.absolutePath}"
            )
        }

        val sizeBytes = apkFile.length()
        if (sizeBytes <= 0L) {
            return ApkPreCheckResult(
                isValid = false,
                fileSizeBytes = 0L,
                errorMessage = "ملف APK فارغ (حجمه 0 بايت). لم يتم إنتاج ملف الحزمة بشكل سليم."
            )
        }

        if (!apkFile.extension.equals("apk", ignoreCase = true)) {
            return ApkPreCheckResult(
                isValid = false,
                fileSizeBytes = sizeBytes,
                errorMessage = "امتداد الملف ليس (.apk) بل (${apkFile.extension})."
            )
        }

        if (!apkFile.canRead()) {
            return ApkPreCheckResult(
                isValid = false,
                fileSizeBytes = sizeBytes,
                errorMessage = "التطبيق لا يملك صلاحية قراءة ملف APK من التخزين."
            )
        }

        // 1. Verify ZIP header signature (PK\x03\x04 = 0x50, 0x4B, 0x03, 0x04)
        var isZip = false
        try {
            FileInputStream(apkFile).use { fis ->
                val header = ByteArray(4)
                val read = fis.read(header)
                if (read == 4 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() &&
                    header[2] == 0x03.toByte() && header[3] == 0x04.toByte()
                ) {
                    isZip = true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking ZIP header", e)
        }

        if (!isZip) {
            return ApkPreCheckResult(
                isValid = false,
                fileSizeBytes = sizeBytes,
                isZipValid = false,
                errorMessage = "الملف ليس ملف ZIP/APK صالحاً (توقيع الـ ZIP مفقود أو الملف تالف)."
            )
        }

        // 2. Verify presence of AndroidManifest.xml inside the APK ZIP
        var hasManifest = false
        try {
            ZipFile(apkFile).use { zip ->
                val entry = zip.getEntry("AndroidManifest.xml")
                if (entry != null && entry.size >= 0) {
                    hasManifest = true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error inspecting APK zip contents", e)
            return ApkPreCheckResult(
                isValid = false,
                fileSizeBytes = sizeBytes,
                isZipValid = true,
                hasManifest = false,
                errorMessage = "تعذر قراءة محتويات ملف الـ ZIP/APK: ${e.message}"
            )
        }

        if (!hasManifest) {
            return ApkPreCheckResult(
                isValid = false,
                fileSizeBytes = sizeBytes,
                isZipValid = true,
                hasManifest = false,
                errorMessage = "ملف APK موجود ولكن لا يحتوي على ملف AndroidManifest.xml داخله."
            )
        }

        // 3. Verify that Android's PackageManager can parse the package archive info
        try {
            val packageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageArchiveInfo(
                    apkFile.absolutePath,
                    PackageManager.PackageInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageArchiveInfo(apkFile.absolutePath, 0)
            }

            if (packageInfo == null) {
                return ApkPreCheckResult(
                    isValid = false,
                    fileSizeBytes = sizeBytes,
                    isZipValid = true,
                    hasManifest = true,
                    errorMessage = "Android (PackageManager) لم يستطع قراءة معلومات الحزمة من ملف APK الناتج. قد يكون الملف غير موقع أو يحتوي على بيانات تالفة."
                )
            }

            val packageName = packageInfo.packageName
            val versionName = packageInfo.versionName ?: "1.0"
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                packageInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                packageInfo.versionCode.toLong()
            }

            // Set source dir to allow loading app label if possible
            packageInfo.applicationInfo?.sourceDir = apkFile.absolutePath
            packageInfo.applicationInfo?.publicSourceDir = apkFile.absolutePath
            val appLabel = try {
                packageInfo.applicationInfo?.loadLabel(context.packageManager)?.toString()
            } catch (_: Exception) {
                null
            }

            return ApkPreCheckResult(
                isValid = true,
                resolvedFile = apkFile,
                packageName = packageName,
                versionName = versionName,
                versionCode = versionCode,
                appLabel = appLabel,
                fileSizeBytes = sizeBytes,
                isZipValid = true,
                hasManifest = true,
                detailedDiagnosis = "تم فحص الـ APK بنجاح: حزمة $packageName إصدار $versionName ($versionCode)"
            )
        } catch (e: Exception) {
            Log.e(TAG, "PackageManager archive parsing failed", e)
            return ApkPreCheckResult(
                isValid = false,
                fileSizeBytes = sizeBytes,
                isZipValid = true,
                hasManifest = true,
                errorMessage = "خطأ أثناء قراءة الحزمة بواسطة Android PackageManager: ${e.message}"
            )
        }
    }

    /**
     * Recursively discovers all APK files in the project outputs and isolated build directories,
     * validates each APK, and returns a prioritized list.
     */
    fun discoverApks(projectDir: File, buildId: String? = null): List<DiscoveredApk> {
        val discoveredList = mutableListOf<DiscoveredApk>()
        val seenPaths = mutableSetOf<String>()

        val searchDirs = mutableListOf<File>()
        if (!buildId.isNullOrBlank()) {
            searchDirs.add(File(context.filesDir, "apks/$buildId"))
            searchDirs.add(File(context.filesDir, "builds/$buildId/output"))
        }
        if (projectDir.exists()) {
            searchDirs.add(File(projectDir, "app/build/outputs/apk/debug"))
            searchDirs.add(File(projectDir, "app/build/outputs/apk/release"))
            searchDirs.add(File(projectDir, "app/build/outputs/apk"))
            searchDirs.add(File(projectDir, "build/outputs/apk"))
            searchDirs.add(projectDir)
        }

        for (dir in searchDirs) {
            if (!dir.exists()) continue
            val apkFiles = if (dir.isDirectory) {
                dir.walkTopDown().filter { it.isFile && it.extension.equals("apk", ignoreCase = true) }.toList()
            } else if (dir.isFile && dir.extension.equals("apk", ignoreCase = true)) {
                listOf(dir)
            } else {
                emptyList()
            }

            for (apkFile in apkFiles) {
                val canonicalPath = apkFile.canonicalPath
                if (seenPaths.contains(canonicalPath)) continue
                seenPaths.add(canonicalPath)

                val validation = validateApk(apkFile)
                val sizeBytes = apkFile.length()
                if (sizeBytes <= 0L) continue // Skip empty dummy files

                val variant = when {
                    apkFile.name.contains("debug", ignoreCase = true) -> "debug"
                    apkFile.name.contains("release", ignoreCase = true) -> "release"
                    apkFile.name.contains("unsigned", ignoreCase = true) -> "unsigned"
                    else -> "apk"
                }

                val relativePath = if (projectDir.exists() && canonicalPath.startsWith(projectDir.canonicalPath)) {
                    apkFile.relativeToOrSelf(projectDir).path
                } else {
                    "apks/${apkFile.name}"
                }

                discoveredList.add(
                    DiscoveredApk(
                        file = apkFile,
                        fileName = apkFile.name,
                        sizeBytes = sizeBytes,
                        sizeFormatted = formatFileSize(sizeBytes),
                        variant = variant,
                        relativePath = relativePath,
                        packageName = validation.packageName,
                        versionName = validation.versionName,
                        versionCode = validation.versionCode,
                        isValid = validation.isValid
                    )
                )
            }
        }

        // Prioritize: Valid APKs first, then current buildId path, then debug, then newest
        return discoveredList.sortedWith(
            compareByDescending<DiscoveredApk> { it.isValid }
                .thenByDescending { !buildId.isNullOrBlank() && it.file.absolutePath.contains(buildId) }
                .thenByDescending { it.variant == "debug" }
                .thenByDescending { it.file.lastModified() }
        )
    }

    fun getFileProviderUri(apkFile: File): Uri {
        val authority = "${context.packageName}.fileprovider"
        return FileProvider.getUriForFile(context, authority, apkFile)
    }

    /**
     * Attempts to trigger APK installation using PackageInstaller / Intent.ACTION_VIEW
     */
    fun createInstallIntent(apkFile: File): Pair<Intent, Boolean> {
        val needsUnknownSourcesPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            !context.packageManager.canRequestPackageInstalls()
        } else {
            false
        }

        if (needsUnknownSourcesPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val permissionIntent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return Pair(permissionIntent, true)
        }

        val apkUri = getFileProviderUri(apkFile)
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return Pair(installIntent, false)
    }

    /**
     * Creates an Intent to share the APK using Android Sharesheet
     */
    fun createShareIntent(apkFile: File): Intent {
        val apkUri = getFileProviderUri(apkFile)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, apkUri)
            putExtra(Intent.EXTRA_SUBJECT, "ملف APK: ${apkFile.name}")
            putExtra(Intent.EXTRA_TEXT, "تم إنشاء ملف APK (${apkFile.name}) بواسطة تطبيق APK Builder Mobile.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(shareIntent, "مشاركة ملف APK عبر...").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    /**
     * Exports the APK file to a destination URI selected via Storage Access Framework
     */
    fun exportApkToUri(apkFile: File, destinationUri: Uri): Boolean {
        return try {
            context.contentResolver.openOutputStream(destinationUri)?.use { outputStream ->
                FileInputStream(apkFile).use { inputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to export APK to URI", e)
            false
        }
    }

    fun formatFileSize(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 -> String.format("%.2f MB", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> String.format("%.2f KB", bytes.toDouble() / 1024)
            else -> "$bytes B"
        }
    }
}

