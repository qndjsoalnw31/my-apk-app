package com.example.domain.analyzer

import com.example.data.models.ProjectInfo
import com.example.data.models.ProjectType
import java.io.File
import java.io.FileInputStream
import java.util.Properties

class ProjectAnalyzer {

    fun analyze(
        projectDir: File,
        zipFileName: String,
        zipFileSize: Long,
        relativeRootPath: String = ""
    ): ProjectInfo {
        val allFiles = projectDir.walkTopDown().toList()
        val totalFilesCount = allFiles.size

        // 1. Locate Root Project Configuration Files
        val settingsGradleKts = findFile(projectDir, "settings.gradle.kts")
        val settingsGradleGroovy = findFile(projectDir, "settings.gradle")
        val settingsFile = settingsGradleKts ?: settingsGradleGroovy

        val rootBuildKts = findFile(projectDir, "build.gradle.kts")
        val rootBuildGroovy = findFile(projectDir, "build.gradle")
        val rootBuildFile = rootBuildKts ?: rootBuildGroovy

        val versionCatalogFile = findFile(projectDir, "gradle/libs.versions.toml")
            ?: findFile(projectDir, "libs.versions.toml")
            ?: allFiles.firstOrNull { it.name == "libs.versions.toml" }

        val wrapperPropsFile = findFile(projectDir, "gradle/wrapper/gradle-wrapper.properties")
            ?: allFiles.firstOrNull { it.name == "gradle-wrapper.properties" }
        val wrapperJarFile = findFile(projectDir, "gradle/wrapper/gradle-wrapper.jar")
            ?: allFiles.firstOrNull { it.name == "gradle-wrapper.jar" }

        // 2. Parse Project Name from settings or fallback to zip filename
        val detectedProjectName = parseProjectName(settingsFile)
            ?: zipFileName.removeSuffix(".zip").removeSuffix(".tar.gz").ifBlank { "android-project" }

        // 3. Parse Version Catalog (libs.versions.toml) if present
        val catalogData = versionCatalogFile?.let { parseVersionCatalog(it) } ?: VersionCatalogData()

        // 4. Discover all modules in the project
        val detectedModules = parseModulesFromSettings(settingsFile, projectDir)
        val moduleAnalyses = analyzeModules(projectDir, detectedModules, catalogData)

        // 5. Select primary Application Module
        val appModule = moduleAnalyses.firstOrNull { it.isApplication }
            ?: moduleAnalyses.firstOrNull { it.name == "app" || it.name == ":app" || it.name == "mobile" }
            ?: moduleAnalyses.firstOrNull()

        val primaryModuleName = appModule?.name ?: "app"
        val primaryAppBuildFile = appModule?.buildFile ?: rootBuildFile

        // 6. Find AndroidManifest.xml
        val primaryManifestFile = appModule?.manifestFile
            ?: findFile(projectDir, "src/main/AndroidManifest.xml")
            ?: allFiles.firstOrNull { it.name == "AndroidManifest.xml" }

        // 7. Calculate Project Android Scoring
        val (score, scoreDetails, projectType) = calculateProjectScoreAndType(
            projectDir = projectDir,
            allFiles = allFiles,
            settingsFile = settingsFile,
            rootBuildFile = rootBuildFile,
            wrapperProps = wrapperPropsFile,
            manifestFile = primaryManifestFile,
            moduleAnalyses = moduleAnalyses,
            versionCatalog = versionCatalogFile
        )

        // 8. Extract Gradle Version from wrapper or infer from AGP
        val extractedGradleVer = wrapperPropsFile?.let { extractGradleVersion(it) }

        // 9. Extract AGP & Kotlin & KSP Versions
        val (agpVersion, kotlinVersion, kspVersion) = extractPluginsAndToolsVersions(
            rootBuildFile = rootBuildFile,
            appBuildFile = primaryAppBuildFile,
            settingsFile = settingsFile,
            catalogData = catalogData,
            allFiles = allFiles
        )

        val finalGradleVersion = extractedGradleVer ?: inferGradleVersionForAgp(agpVersion)

        // 10. Extract SDK properties, namespace, and applicationId
        val allBuildTexts = buildString {
            if (primaryAppBuildFile?.exists() == true) append(primaryAppBuildFile.readText()).append("\n")
            if (rootBuildFile?.exists() == true && rootBuildFile != primaryAppBuildFile) append(rootBuildFile.readText())
        }

        val compileSdk = appModule?.compileSdk ?: extractIntProperty(allBuildTexts, listOf("compileSdk", "compileSdkVersion"))
        val targetSdk = appModule?.targetSdk ?: extractIntProperty(allBuildTexts, listOf("targetSdk", "targetSdkVersion"))
        val minSdk = appModule?.minSdk ?: extractIntProperty(allBuildTexts, listOf("minSdk", "minSdkVersion"))
        val namespace = appModule?.namespace ?: extractStringProperty(allBuildTexts, "namespace")
        val applicationId = appModule?.applicationId ?: extractStringProperty(allBuildTexts, "applicationId")

        // 11. Inspect Manifest for package name fallback
        val manifestPackage = primaryManifestFile?.let { extractManifestPackage(it) }
        val finalNamespace = namespace ?: manifestPackage
        val finalApplicationId = applicationId ?: finalNamespace

        // 12. Extract Java / JVM Target Version
        val javaVersion = extractJavaVersion(allBuildTexts, primaryAppBuildFile)

        // 13. Inspect Google Services & Keystore
        val requiresGoogleServices = allBuildTexts.contains("com.google.gms.google-services") ||
                allBuildTexts.contains("google-services") ||
                catalogData.plugins.any { it.contains("google-services") }
        val googleServicesJson = (appModule?.dir?.let { findFile(it, "google-services.json") }
            ?: findFile(projectDir, "google-services.json")
            ?: allFiles.firstOrNull { it.name == "google-services.json" }) != null

        val debugKeystore = findFile(projectDir, "debug.keystore") != null ||
                allFiles.any { it.name == "debug.keystore" }

        // 14. Detected dependencies and flags
        val dependencies = extractDependencies(allBuildTexts)
        val hasCompose = allBuildTexts.contains("compose", ignoreCase = true) ||
                catalogData.libraries.any { it.contains("compose", ignoreCase = true) }
        val hasRoom = allBuildTexts.contains("room", ignoreCase = true) ||
                catalogData.libraries.any { it.contains("room", ignoreCase = true) }
        val hasKsp = allBuildTexts.contains("ksp", ignoreCase = true) ||
                kspVersion != null || catalogData.plugins.any { it.contains("ksp", ignoreCase = true) }
        val hasCoroutines = allBuildTexts.contains("coroutines", ignoreCase = true) ||
                catalogData.libraries.any { it.contains("coroutines", ignoreCase = true) }

        val appModulesList = moduleAnalyses.filter { it.isApplication }.map { it.name }
        val libModulesList = moduleAnalyses.filter { it.isLibrary }.map { it.name }
        val allModulesList = if (moduleAnalyses.isNotEmpty()) moduleAnalyses.map { it.name } else listOf("app")

        return ProjectInfo(
            zipFileName = zipFileName,
            zipFileSize = zipFileSize,
            extractedRoot = projectDir,
            workingRoot = projectDir,
            originalRoot = projectDir,
            projectName = detectedProjectName,
            relativeProjectRoot = relativeRootPath,
            projectType = projectType,
            confidenceScore = score,
            scoreDetails = scoreDetails,
            gradleVersion = finalGradleVersion,
            agpVersion = agpVersion,
            kotlinVersion = kotlinVersion,
            kspVersion = kspVersion,
            javaVersion = javaVersion,
            compileSdk = compileSdk,
            targetSdk = targetSdk,
            minSdk = minSdk,
            namespace = finalNamespace,
            applicationId = finalApplicationId,
            appModuleName = primaryModuleName,
            allModules = allModulesList,
            applicationModules = if (appModulesList.isNotEmpty()) appModulesList else listOf(primaryModuleName),
            libraryModules = libModulesList,
            hasGradleWrapper = findFile(projectDir, "gradlew") != null || findFile(projectDir, "gradlew.bat") != null,
            hasWrapperJar = wrapperJarFile?.exists() == true,
            hasWrapperProperties = wrapperPropsFile?.exists() == true,
            hasAndroidManifest = primaryManifestFile?.exists() == true,
            hasGoogleServicesJson = googleServicesJson,
            requiresGoogleServices = requiresGoogleServices,
            hasDebugKeystore = debugKeystore,
            hasBuildGradle = rootBuildFile?.exists() == true || primaryAppBuildFile?.exists() == true,
            isKotlinDsl = primaryAppBuildFile?.name?.endsWith(".kts") == true || rootBuildFile?.name?.endsWith(".kts") == true,
            hasVersionCatalog = versionCatalogFile != null,
            versionCatalogPath = versionCatalogFile?.let { it.relativeToOrNull(projectDir)?.path ?: it.name },
            hasCompose = hasCompose,
            hasRoom = hasRoom,
            hasKsp = hasKsp,
            hasCoroutines = hasCoroutines,
            buildTypes = listOf("debug", "release"),
            detectedDependencies = dependencies,
            totalFilesCount = totalFilesCount
        )
    }

    // ==========================================
    // 1. Scoring & Project Type Classification
    // ==========================================

    private fun calculateProjectScoreAndType(
        projectDir: File,
        allFiles: List<File>,
        settingsFile: File?,
        rootBuildFile: File?,
        wrapperProps: File?,
        manifestFile: File?,
        moduleAnalyses: List<ModuleAnalysis>,
        versionCatalog: File?
    ): Triple<Int, List<String>, ProjectType> {
        var score = 0
        val details = mutableListOf<String>()

        if (settingsFile != null) {
            score += 25
            details.add("+25 ملف الإعدادات (${settingsFile.name})")
        }

        if (rootBuildFile != null) {
            score += 20
            details.add("+20 ملف البناء الرئيسي (${rootBuildFile.name})")
        }

        val hasGradlew = File(projectDir, "gradlew").exists() || File(projectDir, "gradlew.bat").exists()
        if (hasGradlew) {
            score += 15
            details.add("+15 مشغل Gradle Wrapper (gradlew)")
        }

        if (wrapperProps != null) {
            score += 15
            details.add("+15 إعدادات إصدار Gradle (gradle-wrapper.properties)")
        }

        if (manifestFile != null && manifestFile.exists()) {
            score += 20
            details.add("+20 ملف البيان الرئيسي (AndroidManifest.xml)")
        }

        val hasAppPlugin = moduleAnalyses.any { it.isApplication }
        if (hasAppPlugin) {
            score += 30
            details.add("+30 إضافة تطبيق أندرويد (com.android.application)")
        }

        val hasLibPlugin = moduleAnalyses.any { it.isLibrary }
        if (hasLibPlugin) {
            score += 20
            details.add("+20 إضافة مكتبة أندرويد (com.android.library)")
        }

        val hasAndroidBlock = moduleAnalyses.any { it.hasAndroidBlock }
        if (hasAndroidBlock) {
            score += 25
            details.add("+25 كتلة إعدادات أندرويد (android { })")
        }

        val hasSrcMain = allFiles.any { it.path.contains("src/main") || it.path.contains("src\\main") }
        if (hasSrcMain) {
            score += 15
            details.add("+15 هيكلية مسارات الكود القياسية (src/main)")
        }

        if (versionCatalog != null) {
            score += 10
            details.add("+10 كتالوج الإصدارات (libs.versions.toml)")
        }

        val hasKotlinFiles = allFiles.any { it.extension == "kt" || it.extension == "kts" }
        val hasJavaFiles = allFiles.any { it.extension == "java" }

        val type: ProjectType = when {
            score >= 40 && hasKotlinFiles -> ProjectType.ANDROID_GRADLE_KOTLIN
            score >= 40 && hasJavaFiles -> ProjectType.ANDROID_GRADLE_JAVA
            score >= 40 -> ProjectType.ANDROID_GRADLE_GENERAL
            score >= 25 -> ProjectType.ANDROID_GRADLE_PROBABLE
            allFiles.any { it.name == "pubspec.yaml" } -> ProjectType.FLUTTER
            allFiles.any { it.name == "package.json" } && allFiles.any { it.name.contains("react-native", true) } -> ProjectType.REACT_NATIVE
            else -> ProjectType.UNSUPPORTED
        }

        return Triple(score.coerceIn(0, 100), details, type)
    }

    // ==========================================
    // 2. Module Discovery & Multi-Module Support
    // ==========================================

    data class ModuleAnalysis(
        val name: String,
        val dir: File,
        val buildFile: File?,
        val manifestFile: File?,
        val isApplication: Boolean,
        val isLibrary: Boolean,
        val hasAndroidBlock: Boolean,
        val compileSdk: Int?,
        val targetSdk: Int?,
        val minSdk: Int?,
        val namespace: String?,
        val applicationId: String?
    )

    private fun parseModulesFromSettings(settingsFile: File?, projectDir: File): List<String> {
        val modules = mutableListOf<String>()
        if (settingsFile != null && settingsFile.exists()) {
            val content = settingsFile.readText()
            // Match include(":app"), include(":feature:home"), include 'app', include ':app', ':mobile'
            val includeRegex = """include\s*\(?([^)\n\r]+)\)?""".toRegex()
            includeRegex.findAll(content).forEach { match ->
                val line = match.groupValues[1]
                val tokens = line.split(",", "+")
                for (token in tokens) {
                    val cleaned = token.replace("\"", "").replace("'", "").trim()
                    if (cleaned.isNotBlank() && !cleaned.startsWith("//")) {
                        modules.add(cleaned)
                    }
                }
            }
        }

        // If no modules declared in settings, auto-discover by directories
        if (modules.isEmpty()) {
            projectDir.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.forEach { sub ->
                if (File(sub, "build.gradle").exists() || File(sub, "build.gradle.kts").exists() || File(sub, "src/main/AndroidManifest.xml").exists()) {
                    modules.add(":${sub.name}")
                }
            }
        }

        if (modules.isEmpty()) {
            modules.add(":app")
        }

        return modules.distinct()
    }

    private fun analyzeModules(
        projectDir: File,
        modules: List<String>,
        catalogData: VersionCatalogData
    ): List<ModuleAnalysis> {
        val analyses = mutableListOf<ModuleAnalysis>()

        for (moduleName in modules) {
            val relativeDirName = moduleName.removePrefix(":").replace(":", "/")
            val moduleDir = if (relativeDirName.isBlank()) projectDir else File(projectDir, relativeDirName)

            val buildFile = if (moduleDir.exists()) {
                findFile(moduleDir, "build.gradle.kts") ?: findFile(moduleDir, "build.gradle")
            } else null

            val manifestFile = if (moduleDir.exists()) {
                findFile(moduleDir, "src/main/AndroidManifest.xml")
                    ?: moduleDir.walkTopDown().firstOrNull { it.name == "AndroidManifest.xml" }
            } else null

            val buildContent = buildFile?.takeIf { it.exists() }?.readText() ?: ""

            val isApp = buildContent.contains("com.android.application") ||
                    buildContent.contains("apply plugin: 'android'") ||
                    catalogData.isAliasForApplication(buildContent)

            val isLib = buildContent.contains("com.android.library") ||
                    catalogData.isAliasForLibrary(buildContent)

            val hasAndroid = buildContent.contains("android {") || buildContent.contains("android{")

            val compileSdk = extractIntProperty(buildContent, listOf("compileSdk", "compileSdkVersion"))
            val targetSdk = extractIntProperty(buildContent, listOf("targetSdk", "targetSdkVersion"))
            val minSdk = extractIntProperty(buildContent, listOf("minSdk", "minSdkVersion"))
            val namespace = extractStringProperty(buildContent, "namespace")
            val applicationId = extractStringProperty(buildContent, "applicationId")

            analyses.add(
                ModuleAnalysis(
                    name = moduleName,
                    dir = moduleDir,
                    buildFile = buildFile,
                    manifestFile = manifestFile,
                    isApplication = isApp,
                    isLibrary = isLib,
                    hasAndroidBlock = hasAndroid,
                    compileSdk = compileSdk,
                    targetSdk = targetSdk,
                    minSdk = minSdk,
                    namespace = namespace,
                    applicationId = applicationId
                )
            )
        }

        return analyses
    }

    // ==========================================
    // 3. Version Catalog (.toml) Parser
    // ==========================================

    data class VersionCatalogData(
        val versions: Map<String, String> = emptyMap(),
        val libraries: List<String> = emptyList(),
        val plugins: List<String> = emptyList(),
        val appPluginAlias: String? = null,
        val libPluginAlias: String? = null
    ) {
        fun isAliasForApplication(content: String): Boolean {
            if (appPluginAlias != null && content.contains(appPluginAlias)) return true
            return content.contains("libs.plugins.android.application") ||
                    content.contains("libs.plugins.androidApplication") ||
                    content.contains("libs.plugins.android_application")
        }

        fun isAliasForLibrary(content: String): Boolean {
            if (libPluginAlias != null && content.contains(libPluginAlias)) return true
            return content.contains("libs.plugins.android.library") ||
                    content.contains("libs.plugins.androidLibrary") ||
                    content.contains("libs.plugins.android_library")
        }
    }

    private fun parseVersionCatalog(tomlFile: File): VersionCatalogData {
        val versions = mutableMapOf<String, String>()
        val libraries = mutableListOf<String>()
        val plugins = mutableListOf<String>()
        var appPluginAlias: String? = null
        var libPluginAlias: String? = null

        try {
            var currentSection = ""
            tomlFile.forEachLine { rawLine ->
                val line = rawLine.trim()
                if (line.startsWith("[") && line.endsWith("]")) {
                    currentSection = line.substring(1, line.length - 1).trim().lowercase()
                } else if (line.isNotBlank() && !line.startsWith("#")) {
                    when (currentSection) {
                        "versions" -> {
                            val parts = line.split("=", limit = 2)
                            if (parts.size == 2) {
                                val key = parts[0].trim()
                                val value = parts[1].trim().trim('"', '\'')
                                versions[key] = value
                            }
                        }
                        "libraries" -> {
                            libraries.add(line)
                        }
                        "plugins" -> {
                            plugins.add(line)
                            if (line.contains("com.android.application")) {
                                appPluginAlias = line.split("=").firstOrNull()?.trim()
                            }
                            if (line.contains("com.android.library")) {
                                libPluginAlias = line.split("=").firstOrNull()?.trim()
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        return VersionCatalogData(
            versions = versions,
            libraries = libraries,
            plugins = plugins,
            appPluginAlias = appPluginAlias,
            libPluginAlias = libPluginAlias
        )
    }

    // ==========================================
    // 4. Tools & Plugins Version Extraction
    // ==========================================

    private fun extractPluginsAndToolsVersions(
        rootBuildFile: File?,
        appBuildFile: File?,
        settingsFile: File?,
        catalogData: VersionCatalogData,
        allFiles: List<File>
    ): Triple<String?, String?, String?> {
        var agp: String? = catalogData.versions["agp"]
            ?: catalogData.versions["android-gradle-plugin"]
            ?: catalogData.versions["androidGradlePlugin"]
            ?: catalogData.versions["android_gradle_plugin"]

        var kotlin: String? = catalogData.versions["kotlin"]
            ?: catalogData.versions["kotlin-version"]
            ?: catalogData.versions["kotlinVersion"]

        var ksp: String? = catalogData.versions["ksp"]
            ?: catalogData.versions["ksp-version"]
            ?: catalogData.versions["kspVersion"]

        val searchTargets = listOfNotNull(rootBuildFile, appBuildFile, settingsFile)
        for (target in searchTargets) {
            if (!target.exists()) continue
            val text = target.readText()

            if (agp == null) {
                val agpMatch = """com\.android\.tools\.build:gradle:([0-9.]+)""".toRegex().find(text)
                    ?: """id\s*\(?['"]com\.android\.application['"]\)?\s*version\s*['"]([0-9.]+)['"]""".toRegex().find(text)
                    ?: """id\s*['"]com\.android\.application['"]\s*version\s*['"]([0-9.]+)['"]""".toRegex().find(text)
                agp = agpMatch?.groupValues?.get(1)
            }

            if (kotlin == null) {
                val kotlinMatch = """org\.jetbrains\.kotlin:kotlin-gradle-plugin:([0-9.]+)""".toRegex().find(text)
                    ?: """id\s*\(?['"]org\.jetbrains\.kotlin\.android['"]\)?\s*version\s*['"]([0-9.]+)['"]""".toRegex().find(text)
                    ?: """kotlin\(["']jvm["']\)\s*version\s*['"]([0-9.]+)['"]""".toRegex().find(text)
                kotlin = kotlinMatch?.groupValues?.get(1)
            }

            if (ksp == null) {
                val kspMatch = """com\.google\.devtools\.ksp.*?([0-9.]+-[0-9.]+|[0-9.]+)""".toRegex().find(text)
                ksp = kspMatch?.groupValues?.get(1)
            }
        }

        return Triple(agp, kotlin, ksp)
    }

    private fun extractGradleVersion(propertiesFile: File): String? {
        return try {
            val props = Properties()
            FileInputStream(propertiesFile).use { props.load(it) }
            val distributionUrl = props.getProperty("distributionUrl") ?: return null
            val regex = """gradle-([0-9.]+)-(bin|all)\.zip""".toRegex()
            regex.find(distributionUrl)?.groupValues?.get(1)
        } catch (e: Exception) {
            null
        }
    }

    private fun inferGradleVersionForAgp(agpVersion: String?): String {
        if (agpVersion == null) return "8.11.1"
        return when {
            agpVersion.startsWith("9.") -> "8.11.1"
            agpVersion.startsWith("8.7") || agpVersion.startsWith("8.8") -> "8.11.1"
            agpVersion.startsWith("8.") -> "8.7"
            agpVersion.startsWith("7.") -> "7.6.4"
            else -> "8.11.1"
        }
    }

    // ==========================================
    // 5. Java Target Version Detection
    // ==========================================

    private fun extractJavaVersion(buildText: String, appBuildFile: File?): String {
        // Look for jvmToolchain(21), JavaVersion.VERSION_17, JavaLanguageVersion.of(17), jvmTarget = "17"
        val toolchainRegex = """jvmToolchain\s*\(?\s*([0-9]+)\s*\)?""".toRegex()
        toolchainRegex.find(buildText)?.groupValues?.get(1)?.let { return it }

        val javaVersionRegex = """JavaVersion\.VERSION_([0-9_]+)""".toRegex()
        javaVersionRegex.find(buildText)?.groupValues?.get(1)?.let {
            return it.replace("_", ".")
        }

        val jvmTargetRegex = """jvmTarget\s*=?\s*["']([0-9.]+)["']""".toRegex()
        jvmTargetRegex.find(buildText)?.groupValues?.get(1)?.let { return it }

        val langVerRegex = """JavaLanguageVersion\.of\s*\(\s*([0-9]+)\s*\)""".toRegex()
        langVerRegex.find(buildText)?.groupValues?.get(1)?.let { return it }

        return "17"
    }

    // ==========================================
    // 6. Manifest & Properties Helpers
    // ==========================================

    private fun parseProjectName(settingsFile: File?): String? {
        if (settingsFile != null && settingsFile.exists()) {
            val text = settingsFile.readText()
            val match = """rootProject\.name\s*=\s*["']([^"']+)["']""".toRegex().find(text)
            if (match != null) {
                return match.groupValues[1].trim()
            }
        }
        return null
    }

    private fun extractManifestPackage(manifestFile: File): String? {
        return try {
            val text = manifestFile.readText()
            val match = """package\s*=\s*["']([^"']+)["']""".toRegex().find(text)
            match?.groupValues?.get(1)
        } catch (e: Exception) {
            null
        }
    }

    private fun extractIntProperty(content: String, keys: List<String>): Int? {
        for (key in keys) {
            val pattern1 = """$key\s*=?\s*([0-9]+)""".toRegex()
            val match1 = pattern1.find(content)
            if (match1 != null) {
                return match1.groupValues[1].toIntOrNull()
            }
            val pattern2 = """$key\s*\(\s*([0-9]+)\s*\)""".toRegex()
            val match2 = pattern2.find(content)
            if (match2 != null) {
                return match2.groupValues[1].toIntOrNull()
            }
            val pattern3 = """$key\s*=\s*release\s*\(\s*([0-9]+)\s*\)""".toRegex()
            val match3 = pattern3.find(content)
            if (match3 != null) {
                return match3.groupValues[1].toIntOrNull()
            }
        }
        return null
    }

    private fun extractStringProperty(content: String, key: String): String? {
        val pattern = """$key\s*=?\s*["']([^"']+)["']""".toRegex()
        return pattern.find(content)?.groupValues?.get(1)
    }

    private fun extractDependencies(content: String): List<String> {
        val deps = mutableListOf<String>()
        val regex = """(implementation|api|kapt|ksp)\s*\(?['"]([^'"]+)['"]\)?""".toRegex()
        regex.findAll(content).forEach { match ->
            val dep = match.groupValues[2]
            if (dep.isNotBlank() && !deps.contains(dep)) {
                deps.add(dep)
            }
        }
        return deps
    }

    private fun findFile(parent: File, relativePath: String): File? {
        val target = File(parent, relativePath)
        return if (target.exists()) target else null
    }
}
