package com.example.domain.analyzer

import com.example.data.models.ProjectInfo
import com.example.data.models.ProjectType
import java.io.File
import java.io.FileInputStream
import java.util.Properties

class ProjectAnalyzer {

    fun analyze(projectDir: File, zipFileName: String, zipFileSize: Long): ProjectInfo {
        val allFiles = projectDir.walkTopDown().toList()
        val totalFilesCount = allFiles.size

        // 1. Detect project type
        val projectType = detectProjectType(projectDir, allFiles)

        // 2. Locate Gradle files
        val wrapperPropertiesFile = findFile(projectDir, "gradle/wrapper/gradle-wrapper.properties")
            ?: allFiles.firstOrNull { it.name == "gradle-wrapper.properties" }
        val wrapperJarFile = findFile(projectDir, "gradle/wrapper/gradle-wrapper.jar")
            ?: allFiles.firstOrNull { it.name == "gradle-wrapper.jar" }

        val settingsGradle = findFile(projectDir, "settings.gradle.kts") ?: findFile(projectDir, "settings.gradle")
        val rootBuildGradle = findFile(projectDir, "build.gradle.kts") ?: findFile(projectDir, "build.gradle")

        val appModuleDir = findAppModuleDir(projectDir)
        val appBuildGradle = if (appModuleDir != null) {
            findFile(appModuleDir, "build.gradle.kts") ?: findFile(appModuleDir, "build.gradle")
        } else {
            rootBuildGradle
        }

        val manifestFile = findAndroidManifest(projectDir, appModuleDir)

        // 3. Extract Gradle Version from wrapper
        val gradleVersion = wrapperPropertiesFile?.let { extractGradleVersion(it) }

        // 4. Extract AGP Version & Kotlin Version
        val (agpVersion, kotlinVersion) = extractPluginsVersions(rootBuildGradle, appBuildGradle, settingsGradle, projectDir)

        // 5. Extract SDK configs, namespace, applicationId from app build gradle
        val buildGradleText = buildString {
            if (appBuildGradle?.exists() == true) append(appBuildGradle.readText()).append("\n")
            if (rootBuildGradle?.exists() == true && rootBuildGradle != appBuildGradle) append(rootBuildGradle.readText())
        }

        val compileSdk = extractIntProperty(buildGradleText, listOf("compileSdk", "compileSdkVersion"))
        val targetSdk = extractIntProperty(buildGradleText, listOf("targetSdk", "targetSdkVersion"))
        val minSdk = extractIntProperty(buildGradleText, listOf("minSdk", "minSdkVersion"))
        val namespace = extractStringProperty(buildGradleText, "namespace")
        val applicationId = extractStringProperty(buildGradleText, "applicationId")

        // 6. Inspect Manifest for package name fallback
        val manifestPackage = manifestFile?.let { extractManifestPackage(it) }
        val finalNamespace = namespace ?: manifestPackage
        val finalApplicationId = applicationId ?: finalNamespace

        // 7. Inspect Google Services requirements
        val requiresGoogleServices = buildGradleText.contains("com.google.gms.google-services") ||
                buildGradleText.contains("google-services")
        val googleServicesJson = (appModuleDir?.let { findFile(it, "google-services.json") }
            ?: findFile(projectDir, "google-services.json")) != null

        // 8. Inspect debug keystore
        val debugKeystore = findFile(projectDir, "debug.keystore") != null ||
                allFiles.any { it.name == "debug.keystore" }

        // 9. Detected dependencies
        val dependencies = extractDependencies(buildGradleText)

        return ProjectInfo(
            zipFileName = zipFileName,
            zipFileSize = zipFileSize,
            extractedRoot = projectDir,
            projectType = projectType,
            gradleVersion = gradleVersion,
            agpVersion = agpVersion,
            kotlinVersion = kotlinVersion,
            compileSdk = compileSdk,
            targetSdk = targetSdk,
            minSdk = minSdk,
            namespace = finalNamespace,
            applicationId = finalApplicationId,
            appModuleName = appModuleDir?.name ?: "app",
            hasGradleWrapper = findFile(projectDir, "gradlew") != null || findFile(projectDir, "gradlew.bat") != null,
            hasWrapperJar = wrapperJarFile?.exists() == true,
            hasWrapperProperties = wrapperPropertiesFile?.exists() == true,
            hasAndroidManifest = manifestFile?.exists() == true,
            hasGoogleServicesJson = googleServicesJson,
            requiresGoogleServices = requiresGoogleServices,
            hasDebugKeystore = debugKeystore,
            hasBuildGradle = rootBuildGradle?.exists() == true || appBuildGradle?.exists() == true,
            isKotlinDsl = appBuildGradle?.name?.endsWith(".kts") == true || rootBuildGradle?.name?.endsWith(".kts") == true,
            buildTypes = listOf("debug", "release"),
            detectedDependencies = dependencies,
            totalFilesCount = totalFilesCount
        )
    }

    private fun detectProjectType(projectDir: File, allFiles: List<File>): ProjectType {
        val hasPubspec = findFile(projectDir, "pubspec.yaml") != null
        if (hasPubspec) return ProjectType.FLUTTER

        val hasPackageJson = findFile(projectDir, "package.json") != null
        val hasReactNative = hasPackageJson && allFiles.any { it.name.contains("react-native", ignoreCase = true) }
        if (hasReactNative) return ProjectType.REACT_NATIVE

        val hasGradleBuild = allFiles.any {
            it.name == "build.gradle" || it.name == "build.gradle.kts" || it.name == "settings.gradle" || it.name == "settings.gradle.kts"
        }

        if (!hasGradleBuild) {
            return ProjectType.UNSUPPORTED
        }

        val hasKotlinFiles = allFiles.any { it.extension == "kt" || it.extension == "kts" }
        val hasJavaFiles = allFiles.any { it.extension == "java" }

        return when {
            hasKotlinFiles -> ProjectType.ANDROID_GRADLE_KOTLIN
            hasJavaFiles -> ProjectType.ANDROID_GRADLE_JAVA
            else -> ProjectType.ANDROID_GRADLE_GENERAL
        }
    }

    private fun findAppModuleDir(projectDir: File): File? {
        val appFolder = File(projectDir, "app")
        if (appFolder.exists() && appFolder.isDirectory) return appFolder

        // Look for any subfolder with build.gradle or AndroidManifest.xml
        val candidate = projectDir.listFiles()?.firstOrNull { sub ->
            sub.isDirectory && (File(sub, "build.gradle").exists() || File(sub, "build.gradle.kts").exists() || File(sub, "src/main/AndroidManifest.xml").exists())
        }
        return candidate ?: projectDir
    }

    private fun findAndroidManifest(projectDir: File, appModuleDir: File?): File? {
        if (appModuleDir != null) {
            val standardPath = File(appModuleDir, "src/main/AndroidManifest.xml")
            if (standardPath.exists()) return standardPath
        }
        val directPath = File(projectDir, "src/main/AndroidManifest.xml")
        if (directPath.exists()) return directPath

        return projectDir.walkTopDown().firstOrNull { it.name == "AndroidManifest.xml" }
    }

    private fun findFile(parent: File, relativePath: String): File? {
        val target = File(parent, relativePath)
        return if (target.exists()) target else null
    }

    private fun extractGradleVersion(propertiesFile: File): String? {
        return try {
            val props = Properties()
            FileInputStream(propertiesFile).use { props.load(it) }
            val distributionUrl = props.getProperty("distributionUrl") ?: return null
            // Example: https\://services.gradle.org/distributions/gradle-8.11.1-bin.zip
            val regex = """gradle-([0-9.]+)-(bin|all)\.zip""".toRegex()
            regex.find(distributionUrl)?.groupValues?.get(1)
        } catch (e: Exception) {
            null
        }
    }

    private fun extractPluginsVersions(vararg filesAndDir: Any?): Pair<String?, String?> {
        var agp: String? = null
        var kotlin: String? = null

        for (item in filesAndDir) {
            if (item is File && item.exists()) {
                if (item.isDirectory) {
                    // Check libs.versions.toml if present in gradle folder
                    val tomlFile = File(item, "gradle/libs.versions.toml")
                    if (tomlFile.exists()) {
                        val tomlText = tomlFile.readText()
                        if (agp == null) {
                            agp = extractVersionFromToml(tomlText, "agp") ?: extractVersionFromToml(tomlText, "android-gradle-plugin")
                        }
                        if (kotlin == null) {
                            kotlin = extractVersionFromToml(tomlText, "kotlin")
                        }
                    }
                } else {
                    val text = item.readText()
                    if (agp == null) {
                        val agpMatch = """com\.android\.tools\.build:gradle:([0-9.]+)""".toRegex().find(text)
                            ?: """id\s*\(?['"]com\.android\.application['"]\)?\s*version\s*['"]([0-9.]+)['"]""".toRegex().find(text)
                            ?: """id\s*['"]com\.android\.application['"]\s*version\s*['"]([0-9.]+)['"]""".toRegex().find(text)
                        agp = agpMatch?.groupValues?.get(1)
                    }
                    if (kotlin == null) {
                        val kotlinMatch = """org\.jetbrains\.kotlin:kotlin-gradle-plugin:([0-9.]+)""".toRegex().find(text)
                            ?: """id\s*\(?['"]org\.jetbrains\.kotlin\.android['"]\)?\s*version\s*['"]([0-9.]+)['"]""".toRegex().find(text)
                            ?: """kotlin\(["']jvm["']\)\s*version\s*['"]([0-9.]+)['"]""".toRegex().find(text)
                        kotlin = kotlinMatch?.groupValues?.get(1)
                    }
                }
            }
        }
        return Pair(agp, kotlin)
    }

    private fun extractVersionFromToml(tomlContent: String, key: String): String? {
        val regex = """$key\s*=\s*["']([^"']+)["']""".toRegex()
        return regex.find(tomlContent)?.groupValues?.get(1)
    }

    private fun extractIntProperty(content: String, keys: List<String>): Int? {
        for (key in keys) {
            val pattern1 = """$key\s*=?\s*([0-9]+)""".toRegex()
            val match1 = pattern1.find(content)
            if (match1 != null) {
                return match1.groupValues[1].toIntOrNull()
            }
            val pattern2 = """$key\s*\(\s*([0-9]+)\s*\)""".toRegex()
            val match2 = pattern2.find(content)
            if (match2 != null) {
                return match2.groupValues[1].toIntOrNull()
            }
            val pattern3 = """$key\s*=\s*release\s*\(\s*([0-9]+)\s*\)""".toRegex()
            val match3 = pattern3.find(content)
            if (match3 != null) {
                return match3.groupValues[1].toIntOrNull()
            }
        }
        return null
    }

    private fun extractStringProperty(content: String, key: String): String? {
        val pattern = """$key\s*=?\s*["']([^"']+)["']""".toRegex()
        return pattern.find(content)?.groupValues?.get(1)
    }

    private fun extractManifestPackage(manifestFile: File): String? {
        return try {
            val text = manifestFile.readText()
            val match = """package\s*=\s*["']([^"']+)["']""".toRegex().find(text)
            match?.groupValues?.get(1)
        } catch (e: Exception) {
            null
        }
    }

    private fun extractDependencies(content: String): List<String> {
        val deps = mutableListOf<String>()
        val regex = """(implementation|api|kapt|ksp)\s*\(?['"]([^'"]+)['"]\)?""".toRegex()
        regex.findAll(content).forEach { match ->
            val dep = match.groupValues[2]
            if (dep.isNotBlank() && !deps.contains(dep)) {
                deps.add(dep)
            }
        }
        return deps
    }
}
