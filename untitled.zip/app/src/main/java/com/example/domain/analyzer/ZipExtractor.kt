package com.example.domain.analyzer

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class ZipExtractor(private val context: Context) {

    companion object {
        private const val MAX_ENTRIES = 35000
        private const val MAX_TOTAL_SIZE_BYTES = 1000L * 1024L * 1024L // 1 GB limit
        private const val MAX_SINGLE_FILE_SIZE_BYTES = 250L * 1024L * 1024L // 250 MB limit
        private const val BUFFER_SIZE = 16384
    }

    data class ExtractionResult(
        val destinationDir: File,
        val originalDir: File,
        val workingDir: File,
        val rootDir: File,
        val relativeProjectRoot: String,
        val totalFiles: Int,
        val totalBytes: Long
    )

    /**
     * Safely extracts a ZIP from an Android Uri to a sandbox workspace directory:
     * filesDir/builds/<build_id>/
     *   ├── original/ (unmodified backup)
     *   └── working/  (active workspace)
     */
    fun extractZip(sourceUri: Uri, buildId: String, onProgress: ((Int, String) -> Unit)? = null): ExtractionResult {
        val buildsBaseDir = File(context.filesDir, "builds")
        if (!buildsBaseDir.exists()) {
            buildsBaseDir.mkdirs()
        }

        val buildWorkspaceDir = File(buildsBaseDir, buildId)
        if (buildWorkspaceDir.exists()) {
            buildWorkspaceDir.deleteRecursively()
        }
        buildWorkspaceDir.mkdirs()

        val originalDir = File(buildWorkspaceDir, "original")
        val workingDir = File(buildWorkspaceDir, "working")
        originalDir.mkdirs()
        workingDir.mkdirs()

        val inputStream = context.contentResolver.openInputStream(sourceUri)
            ?: throw IllegalStateException("تعذر فتح ملف الـ ZIP المحدد من قبل النظام")

        val extraction = extractFromStream(inputStream, originalDir, onProgress)

        // Copy original to working directory
        copyDirectory(originalDir, workingDir)

        // Discover real Gradle root directory inside working directory
        val relativeRoot = findRelativeGradleRoot(originalDir)
        val finalRootDir = if (relativeRoot.isBlank()) workingDir else File(workingDir, relativeRoot)

        return ExtractionResult(
            destinationDir = buildWorkspaceDir,
            originalDir = originalDir,
            workingDir = workingDir,
            rootDir = finalRootDir,
            relativeProjectRoot = relativeRoot,
            totalFiles = extraction.totalFiles,
            totalBytes = extraction.totalBytes
        )
    }

    fun extractZipFile(zipFile: File, buildId: String, onProgress: ((Int, String) -> Unit)? = null): ExtractionResult {
        val buildsBaseDir = File(context.filesDir, "builds")
        if (!buildsBaseDir.exists()) {
            buildsBaseDir.mkdirs()
        }

        val buildWorkspaceDir = File(buildsBaseDir, buildId)
        if (buildWorkspaceDir.exists()) {
            buildWorkspaceDir.deleteRecursively()
        }
        buildWorkspaceDir.mkdirs()

        val originalDir = File(buildWorkspaceDir, "original")
        val workingDir = File(buildWorkspaceDir, "working")
        originalDir.mkdirs()
        workingDir.mkdirs()

        val inputStream = FileInputStream(zipFile)
        val extraction = extractFromStream(inputStream, originalDir, onProgress)

        // Copy original to working directory
        copyDirectory(originalDir, workingDir)

        // Discover real Gradle root directory inside working directory
        val relativeRoot = findRelativeGradleRoot(originalDir)
        val finalRootDir = if (relativeRoot.isBlank()) workingDir else File(workingDir, relativeRoot)

        return ExtractionResult(
            destinationDir = buildWorkspaceDir,
            originalDir = originalDir,
            workingDir = workingDir,
            rootDir = finalRootDir,
            relativeProjectRoot = relativeRoot,
            totalFiles = extraction.totalFiles,
            totalBytes = extraction.totalBytes
        )
    }

    private data class RawExtractionData(val totalFiles: Int, val totalBytes: Long)

    private fun extractFromStream(
        rawInputStream: InputStream,
        targetDir: File,
        onProgress: ((Int, String) -> Unit)? = null
    ): RawExtractionData {
        var totalEntries = 0
        var totalBytes = 0L
        val canonicalDestDirPath = targetDir.canonicalPath + File.separator

        BufferedInputStream(rawInputStream).use { bis ->
            ZipInputStream(bis).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    totalEntries++
                    if (totalEntries > MAX_ENTRIES) {
                        throw SecurityException("تحذير أمني: ملف الـ ZIP يحتوي على عدد ملفات يتجاوز الحد المسموح ($MAX_ENTRIES)")
                    }

                    val normalizedName = entry.name.replace('\\', '/').trimStart('/')
                    if (normalizedName.isNotBlank()) {
                        val destinationFile = File(targetDir, normalizedName)
                        val canonicalDestFile = destinationFile.canonicalPath

                        // Zip Slip / Path Traversal Prevention
                        if (!canonicalDestFile.startsWith(canonicalDestDirPath)) {
                            throw SecurityException("تحذير أمني خطير (Zip Slip): تم اكتشاف مسار يحاول الخروج من مجلد البناء: ${entry.name}")
                        }

                        if (entry.isDirectory) {
                            if (!destinationFile.exists()) {
                                destinationFile.mkdirs()
                            }
                        } else {
                            val parentFile = destinationFile.parentFile
                            if (parentFile != null && !parentFile.exists()) {
                                parentFile.mkdirs()
                            }

                            var entrySize = 0L
                            val buffer = ByteArray(BUFFER_SIZE)
                            BufferedOutputStream(FileOutputStream(destinationFile)).use { fos ->
                                var len: Int
                                while (zis.read(buffer).also { len = it } > 0) {
                                    entrySize += len
                                    totalBytes += len

                                    if (entrySize > MAX_SINGLE_FILE_SIZE_BYTES) {
                                        throw SecurityException("تحذير أمني: حجم ملف فردي داخل الـ ZIP كبير جداً (${entry.name})")
                                    }
                                    if (totalBytes > MAX_TOTAL_SIZE_BYTES) {
                                        throw SecurityException("تحذير أمني: حجم فك الضغط الإجمالي يتجاوز الحد المسموح به (1 جيجابايت)")
                                    }
                                    fos.write(buffer, 0, len)
                                }
                                fos.flush()
                            }

                            onProgress?.invoke(totalEntries, destinationFile.name)
                        }
                    }

                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }

        if (totalEntries == 0) {
            throw IllegalArgumentException("ملف الـ ZIP فارغ أو تالف ولا يحتوي على ملفات قابلة للقراءة")
        }

        return RawExtractionData(totalEntries, totalBytes)
    }

    /**
     * Recursively scans directory structure and finds the best candidate root for the Android Gradle project.
     * Evaluates settings.gradle[.kts], build.gradle[.kts], android/ folders, and manifest locations.
     */
    fun findRelativeGradleRoot(baseDir: File): String {
        // Candidate scoring for each directory in tree
        var bestDir = baseDir
        var bestScore = -1

        baseDir.walkTopDown().maxDepth(5).filter { it.isDirectory }.forEach { dir ->
            var score = 0
            val hasSettingsKts = File(dir, "settings.gradle.kts").exists()
            val hasSettingsGroovy = File(dir, "settings.gradle").exists()
            val hasRootBuildKts = File(dir, "build.gradle.kts").exists()
            val hasRootBuildGroovy = File(dir, "build.gradle").exists()
            val hasGradlew = File(dir, "gradlew").exists() || File(dir, "gradlew.bat").exists()
            val hasWrapper = File(dir, "gradle/wrapper/gradle-wrapper.properties").exists()
            val hasLibsToml = File(dir, "gradle/libs.versions.toml").exists() || File(dir, "libs.versions.toml").exists()

            if (hasSettingsKts || hasSettingsGroovy) score += 50
            if (hasRootBuildKts || hasRootBuildGroovy) score += 30
            if (hasGradlew) score += 20
            if (hasWrapper) score += 15
            if (hasLibsToml) score += 10

            // Check if it has any subfolder with build.gradle / AndroidManifest.xml
            val children = dir.listFiles() ?: emptyArray()
            if (children.any { sub -> sub.isDirectory && (File(sub, "build.gradle").exists() || File(sub, "build.gradle.kts").exists() || File(sub, "src/main/AndroidManifest.xml").exists()) }) {
                score += 25
            }

            // Prefer shorter paths (closer to root) when scores are equal
            val depth = dir.canonicalPath.count { it == '/' || it == '\\' }
            val weightedScore = score * 100 - depth

            if (weightedScore > bestScore && score >= 30) {
                bestScore = weightedScore
                bestDir = dir
            }
        }

        val baseCanonical = baseDir.canonicalPath
        val targetCanonical = bestDir.canonicalPath
        if (targetCanonical == baseCanonical) return ""

        return if (targetCanonical.startsWith(baseCanonical)) {
            targetCanonical.removePrefix(baseCanonical).trimStart('/', '\\')
        } else {
            ""
        }
    }

    private fun copyDirectory(source: File, target: File) {
        if (!source.exists()) return
        if (source.isDirectory) {
            if (!target.exists()) target.mkdirs()
            source.listFiles()?.forEach { child ->
                copyDirectory(child, File(target, child.name))
            }
        } else {
            target.parentFile?.mkdirs()
            FileInputStream(source).use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output)
                }
            }
        }
    }
}
