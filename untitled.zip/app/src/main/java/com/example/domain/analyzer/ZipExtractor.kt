package com.example.domain.analyzer

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class ZipExtractor(private val context: Context) {

    companion object {
        private const val MAX_ENTRIES = 25000
        private const val MAX_TOTAL_SIZE_BYTES = 600L * 1024L * 1024L // 600 MB limit
        private const val MAX_SINGLE_FILE_SIZE_BYTES = 150L * 1024L * 1024L // 150 MB limit
        private const val BUFFER_SIZE = 8192
    }

    data class ExtractionResult(
        val destinationDir: File,
        val totalFiles: Int,
        val totalBytes: Long,
        val rootDir: File
    )

    /**
     * Safely extracts a ZIP from an Android Uri or File to a sandbox directory in filesDir/builds/<build_id>/
     */
    fun extractZip(sourceUri: Uri, buildId: String, onProgress: ((Int, String) -> Unit)? = null): ExtractionResult {
        val buildsBaseDir = File(context.filesDir, "builds")
        if (!buildsBaseDir.exists()) {
            buildsBaseDir.mkdirs()
        }

        val targetDir = File(buildsBaseDir, buildId)
        if (targetDir.exists()) {
            targetDir.deleteRecursively()
        }
        targetDir.mkdirs()

        val inputStream = context.contentResolver.openInputStream(sourceUri)
            ?: throw IllegalStateException("تعذر فتح ملف الـ ZIP المحدد من قبل النظام")

        return extractFromStream(inputStream, targetDir, onProgress)
    }

    fun extractZipFile(zipFile: File, buildId: String, onProgress: ((Int, String) -> Unit)? = null): ExtractionResult {
        val buildsBaseDir = File(context.filesDir, "builds")
        if (!buildsBaseDir.exists()) {
            buildsBaseDir.mkdirs()
        }

        val targetDir = File(buildsBaseDir, buildId)
        if (targetDir.exists()) {
            targetDir.deleteRecursively()
        }
        targetDir.mkdirs()

        val inputStream = FileInputStream(zipFile)
        return extractFromStream(inputStream, targetDir, onProgress)
    }

    private fun extractFromStream(
        rawInputStream: InputStream,
        targetDir: File,
        onProgress: ((Int, String) -> Unit)? = null
    ): ExtractionResult {
        var totalEntries = 0
        var totalBytes = 0L
        val canonicalDestDirPath = targetDir.canonicalPath + File.separator

        BufferedInputStream(rawInputStream).use { bis ->
            ZipInputStream(bis).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    totalEntries++
                    if (totalEntries > MAX_ENTRIES) {
                        throw SecurityException("تحذير أمني: ملف الـ ZIP يحتوي على عدد ملفات يتجاوز الحد المسموح ($MAX_ENTRIES)")
                    }

                    val normalizedName = entry.name.replace('\\', '/')
                    val destinationFile = File(targetDir, normalizedName)
                    val canonicalDestFile = destinationFile.canonicalPath

                    // Zip Slip / Path Traversal Prevention
                    if (!canonicalDestFile.startsWith(canonicalDestDirPath)) {
                        throw SecurityException("تحذير أمني خطير (Zip Slip): تم اكتشاف مسار يحاول الخروج من مجلد البناء: ${entry.name}")
                    }

                    if (entry.isDirectory) {
                        if (!destinationFile.exists()) {
                            destinationFile.mkdirs()
                        }
                    } else {
                        val parentFile = destinationFile.parentFile
                        if (parentFile != null && !parentFile.exists()) {
                            parentFile.mkdirs()
                        }

                        var entrySize = 0L
                        val buffer = ByteArray(BUFFER_SIZE)
                        BufferedOutputStream(FileOutputStream(destinationFile)).use { fos ->
                            var len: Int
                            while (zis.read(buffer).also { len = it } > 0) {
                                entrySize += len
                                totalBytes += len

                                if (entrySize > MAX_SINGLE_FILE_SIZE_BYTES) {
                                    throw SecurityException("تحذير أمني: حجم ملف فردي داخل الـ ZIP كبير جداً (${entry.name})")
                                }
                                if (totalBytes > MAX_TOTAL_SIZE_BYTES) {
                                    throw SecurityException("تحذير أمني: حجم فك الضغط الإجمالي يتجاوز الحد المسموح به (600 ميجابايت)")
                                }
                                fos.write(buffer, 0, len)
                            }
                            fos.flush()
                        }

                        onProgress?.invoke(totalEntries, destinationFile.name)
                    }

                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }

        if (totalEntries == 0) {
            throw IllegalArgumentException("ملف الـ ZIP فارغ أو تالف ولا يحتوي على ملفات قابلة للقراءة")
        }

        // Find actual root directory (in case the zip has a single root folder wrapping the project)
        val projectRoot = findProjectRoot(targetDir)

        return ExtractionResult(
            destinationDir = targetDir,
            totalFiles = totalEntries,
            totalBytes = totalBytes,
            rootDir = projectRoot
        )
    }

    /**
     * Discovers the actual project root if the ZIP contains a top-level wrapper directory
     */
    fun findProjectRoot(extractedDir: File): File {
        val directChildren = extractedDir.listFiles() ?: return extractedDir
        val nonHiddenChildren = directChildren.filter { !it.name.startsWith(".") }

        // If all top-level files contain a single folder and no build/settings gradle directly at root, step inside
        val hasGradleAtRoot = nonHiddenChildren.any {
            it.name.contains("settings.gradle") || it.name.contains("build.gradle")
        }

        if (!hasGradleAtRoot && nonHiddenChildren.size == 1 && nonHiddenChildren.first().isDirectory) {
            return nonHiddenChildren.first()
        }

        return extractedDir
    }
}
