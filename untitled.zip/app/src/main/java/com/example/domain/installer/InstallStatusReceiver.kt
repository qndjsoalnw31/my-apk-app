package com.example.domain.installer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.util.Log

class InstallStatusReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val statusMessage = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
        val otherPackageName = intent.getStringExtra(PackageInstaller.EXTRA_OTHER_PACKAGE_NAME)
        val buildId = intent.getStringExtra(EXTRA_BUILD_ID)

        Log.d(TAG, "InstallStatusReceiver onReceive - status=$status, msg=$statusMessage, otherPkg=$otherPackageName, buildId=$buildId")

        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirmationIntent: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_INTENT)
                }

                if (confirmationIntent != null) {
                    confirmationIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(confirmationIntent)
                        PackageInstallManager.notifyState(
                            InstallState.PendingUserConfirmation("تم إرسال APK إلى Android Installer - بانتظار تأكيد المستخدم...")
                        )
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to launch user confirmation intent", e)
                        PackageInstallManager.notifyState(
                            InstallState.Error(
                                title = "تعذر فتح شاشة تأكيد التثبيت",
                                message = "حدث خطأ أثناء فتح واجهة تثبيت Android: ${e.message}"
                            )
                        )
                    }
                } else {
                    PackageInstallManager.notifyState(
                        InstallState.PendingUserConfirmation("بانتظار تأكيد المستخدم...")
                    )
                }
            }

            PackageInstaller.STATUS_SUCCESS -> {
                PackageInstallManager.notifyState(
                    InstallState.Success("تم تثبيت التطبيق بنجاح على الهاتف!")
                )
            }

            PackageInstaller.STATUS_FAILURE_ABORTED -> {
                PackageInstallManager.notifyState(
                    InstallState.Error(
                        title = "تم إلغاء التثبيت",
                        message = "تم إلغاء عملية التثبيت من قبل المستخدم."
                    )
                )
            }

            PackageInstaller.STATUS_FAILURE_CONFLICT -> {
                val pkgDetail = if (!otherPackageName.isNullOrBlank()) " ($otherPackageName)" else ""
                PackageInstallManager.notifyState(
                    InstallState.Error(
                        title = "تعارض في الحزمة (Package Conflict)",
                        message = "تعذر التثبيت: يوجد تطبيق مثبت بنفس الحزمة$pkgDetail ولكن بتوقيع رقمي مختلف (Signature mismatch). يرجى إلغاء تثبيت النسخة القديمة أولاً."
                    )
                )
            }

            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> {
                PackageInstallManager.notifyState(
                    InstallState.Error(
                        title = "إصدار غير متوافق",
                        message = "تعذر التثبيت: إصدار Android على الجهاز أو معمارية المعالج غير متوافقة مع متطلبات هذا التطبيق."
                    )
                )
            }

            PackageInstaller.STATUS_FAILURE_INVALID -> {
                PackageInstallManager.notifyState(
                    InstallState.Error(
                        title = "ملف APK غير صالح",
                        message = "تعذر التثبيت: ملف APK غير صالح أو تالف أو تعذر قراءة بيانات الحزمة."
                    )
                )
            }

            PackageInstaller.STATUS_FAILURE_STORAGE -> {
                PackageInstallManager.notifyState(
                    InstallState.Error(
                        title = "مساحة التخزين غير كافية",
                        message = "تعذر التثبيت: لا توجد مساحة تخزين كافية على الجهاز لتثبيت التطبيق."
                    )
                )
            }

            PackageInstaller.STATUS_FAILURE_BLOCKED -> {
                PackageInstallManager.notifyState(
                    InstallState.Error(
                        title = "عملية التثبيت محظورة",
                        message = "تعذر التثبيت: تم حظر عملية التثبيت بواسطة سياسات حماية الجهاز أو تطبيق إدارة."
                    )
                )
            }

            else -> {
                val detailed = if (statusMessage.isNotBlank()) statusMessage else "رمز الحالة: $status"
                PackageInstallManager.notifyState(
                    InstallState.Error(
                        title = "فشل التثبيت",
                        message = "تعذر إتمام عملية التثبيت بواسطة Android PackageInstaller.",
                        detailedLog = detailed
                    )
                )
            }
        }
    }

    companion object {
        private const val TAG = "InstallStatusReceiver"
        const val ACTION_INSTALL_STATUS = "com.example.INSTALL_STATUS"
        const val EXTRA_BUILD_ID = "extra_build_id"
        const val EXTRA_APK_PATH = "extra_apk_path"
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
    }
}
