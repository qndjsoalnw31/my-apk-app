package com.example.domain.installer

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class PackageInstallManager(
    private val context: Context,
    private val apkManager: ApkManager = ApkManager(context)
) {

    val installState: StateFlow<InstallState> = _installState.asStateFlow()

    fun resetState() {
        _installState.value = InstallState.Idle
    }

    /**
     * Comprehensive validation of the APK file using ApkManager.
     */
    fun validateApk(apkFile: File?): ApkPreCheckResult {
        return apkManager.validateApk(apkFile)
    }

    /**
     * Checks if the app has permission to request package installations (Android 8.0+ / API 26+)
     */
    fun canRequestPackageInstalls(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.packageManager.canRequestPackageInstalls()
        } else {
            true
        }
    }

    /**
     * Creates intent to open Android Settings for "Install Unknown Apps"
     */
    fun getUnknownSourcesSettingsIntent(): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        } else {
            Intent(Settings.ACTION_SECURITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
    }

    /**
     * Performs standard Android PackageInstaller installation on a background coroutine with full binary checks and logging.
     */
    suspend fun startInstallation(
        sourceApkFile: File,
        buildId: String = "build_${System.currentTimeMillis()}"
    ): Boolean = withContext(Dispatchers.IO) {
        val logBuilder = StringBuilder()
        fun logStep(msg: String) {
            Log.d(TAG, msg)
            logBuilder.appendLine(msg)
        }

        logStep("[PackageInstaller] --- بدء مرحلة تثبيت APK ---")
        logStep("[PackageInstaller] مسار الملف الأصلي: ${sourceApkFile.absolutePath}")
        logStep("[PackageInstaller] وجود الملف: ${sourceApkFile.exists()}")
        logStep("[PackageInstaller] حجم الملف الأصلي: ${sourceApkFile.length()} بايت")

        // 1. Validate APK file comprehensively
        val validation = validateApk(sourceApkFile)
        logStep("[PackageInstaller] نتيجة فحص الـ APK: ${if (validation.isValid) "PASS ✓" else "FAIL ✗"}")
        if (validation.packageName != null) {
            logStep("[PackageInstaller] Package Name: ${validation.packageName}")
            logStep("[PackageInstaller] Version: ${validation.versionName} (${validation.versionCode})")
        }

        if (!validation.isValid) {
            val errMsg = validation.errorMessage ?: "ملف APK غير صالح أو تعذر قراءة بيانات الحزمة."
            logStep("[PackageInstaller] خطأ الفحص: $errMsg")
            _installState.value = InstallState.Error(
                title = "تعذر بدء التثبيت: ملف APK غير صالح",
                message = errMsg,
                detailedLog = logBuilder.toString()
            )
            return@withContext false
        }

        // 2. Validate Unknown Sources permission
        if (!canRequestPackageInstalls()) {
            logStep("[PackageInstaller] الصلاحية مفقودة: REQUEST_INSTALL_PACKAGES غير مفعلة في الإعدادات")
            _installState.value = InstallState.Error(
                title = "السماح بالتثبيت (Unknown Sources)",
                message = "Android يمنع هذا التطبيق حالياً من تثبيت التطبيقات من هذا المصدر.\n\nيرجى فتح إعدادات السماح بالتثبيت ثم إعادة المحاولة.",
                canOpenSettings = true,
                detailedLog = logBuilder.toString()
            )
            return@withContext false
        }

        _installState.value = InstallState.Preparing(
            progress = 10,
            message = "جارٍ التحقق من سلامة الحزمة وتجهيز جلسة التثبيت..."
        )

        // 3. Prepare dedicated file in files/apks/<buildId>/ directory using safe binary stream
        val dedicatedApksDir = File(context.filesDir, "apks/$buildId")
        if (!dedicatedApksDir.exists()) {
            dedicatedApksDir.mkdirs()
        }

        val targetApkFile = File(dedicatedApksDir, sourceApkFile.name)
        var fileToInstall: File = sourceApkFile

        if (sourceApkFile.canonicalPath != targetApkFile.canonicalPath) {
            logStep("[PackageInstaller] نسخ APK ثنائياً إلى مجلد التثبيت المعزول: ${targetApkFile.absolutePath}")
            try {
                FileInputStream(sourceApkFile).use { input ->
                    FileOutputStream(targetApkFile).use { output ->
                        val buffer = ByteArray(65536)
                        var bytesRead: Int
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                        }
                        output.flush()
                    }
                }
                logStep("[PackageInstaller] حجم الملف المنسوخ: ${targetApkFile.length()} بايت")

                if (targetApkFile.length() != sourceApkFile.length()) {
                    val msg = "فشل نسخ APK: حجم الملف المنسوخ (${targetApkFile.length()}) لا يطابق حجم الملف الأصلي (${sourceApkFile.length()})"
                    logStep("[PackageInstaller] ✗ $msg")
                    _installState.value = InstallState.Error(
                        title = "خطأ في نسخ الحزمة",
                        message = msg,
                        detailedLog = logBuilder.toString()
                    )
                    return@withContext false
                }

                // Re-validate copied file
                val copiedValidation = validateApk(targetApkFile)
                if (!copiedValidation.isValid) {
                    val msg = "فشل التحقق من الملف المنسوخ: ${copiedValidation.errorMessage}"
                    logStep("[PackageInstaller] ✗ $msg")
                    _installState.value = InstallState.Error(
                        title = "تلف في النسخة المعزولة",
                        message = msg,
                        detailedLog = logBuilder.toString()
                    )
                    return@withContext false
                }
                logStep("[PackageInstaller] Copied APK validation: PASS ✓")
                fileToInstall = targetApkFile
            } catch (e: Exception) {
                logStep("[PackageInstaller] تحذير: تعذر النسخ إلى مجلد apks، سيتم استخدام الملف الأصلي مباشرة: ${e.message}")
                fileToInstall = sourceApkFile
            }
        } else {
            fileToInstall = sourceApkFile
        }

        // 4. Create and execute PackageInstaller Session
        var sessionId = -1
        var session: PackageInstaller.Session? = null
        try {
            val packageInstaller = context.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
                setSize(fileToInstall.length())
                validation.packageName?.let { setAppPackageName(it) }
            }

            sessionId = packageInstaller.createSession(params)
            logStep("[PackageInstaller] SESSION_CREATED (sessionId=$sessionId)")
            session = packageInstaller.openSession(sessionId)

            val totalBytes = fileToInstall.length()
            var totalWritten = 0L

            _installState.value = InstallState.Preparing(
                progress = 20,
                message = "جارٍ نقل ملف APK ثنائياً إلى محرك التثبيت (PackageInstaller)..."
            )

            val sessionStreamName = "package_${buildId}_${System.currentTimeMillis()}"
            val outStream = session.openWrite(sessionStreamName, 0, totalBytes)
            val inStream = FileInputStream(fileToInstall)

            try {
                val buffer = ByteArray(65536) // 64 KB buffer
                var bytesRead: Int
                while (inStream.read(buffer).also { bytesRead = it } != -1) {
                    outStream.write(buffer, 0, bytesRead)
                    totalWritten += bytesRead
                    if (totalBytes > 0) {
                        val percent = ((totalWritten * 100) / totalBytes).toInt().coerceIn(20, 95)
                        _installState.value = InstallState.Preparing(
                            progress = percent,
                            message = "جارٍ نقل ملف APK إلى محرك التثبيت... $percent%"
                        )
                    }
                }
                outStream.flush()
                session.fsync(outStream)
                logStep("[PackageInstaller] FSYNC_DONE: تم نقل $totalWritten بايت بنجاح (المتوقع: $totalBytes بايت)")
            } finally {
                try { outStream.close() } catch (_: Exception) {}
                try { inStream.close() } catch (_: Exception) {}
            }

            if (totalWritten != totalBytes) {
                val mismatchError = "خطأ نقل البيانات: عدد البايتات المكتوبة للجلسة ($totalWritten) لا يطابق حجم الملف ($totalBytes)."
                logStep("[PackageInstaller] ✗ $mismatchError")
                try { session.abandon() } catch (_: Exception) {}
                _installState.value = InstallState.Error(
                    title = "فشل نقل الحزمة إلى الجلسة",
                    message = mismatchError,
                    detailedLog = logBuilder.toString()
                )
                return@withContext false
            }

            _installState.value = InstallState.Preparing(
                progress = 98,
                message = "تم إرسال APK إلى Android Installer - بانتظار تأكيد المستخدم..."
            )

            // 5. Prepare callback IntentSender
            val callbackIntent = Intent(context, InstallStatusReceiver::class.java).apply {
                action = InstallStatusReceiver.ACTION_INSTALL_STATUS
                putExtra(InstallStatusReceiver.EXTRA_BUILD_ID, buildId)
                putExtra(InstallStatusReceiver.EXTRA_APK_PATH, fileToInstall.absolutePath)
                putExtra(InstallStatusReceiver.EXTRA_PACKAGE_NAME, validation.packageName)
                `package` = context.packageName
            }

            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                sessionId,
                callbackIntent,
                flags
            )

            logStep("[PackageInstaller] COMMIT: جاري تأكيد الجلسة واستدعاء واجهة النظام...")
            session.commit(pendingIntent.intentSender)
            session.close()
            session = null

            _installState.value = InstallState.PendingUserConfirmation(
                message = "تم إرسال الحزمة بنجاح إلى مثبت Android. بانتظار تأكيد التثبيت من نافذة النظام..."
            )
            logStep("[PackageInstaller] انتهت مرحلة الإرسال بنجاح. في انتظار رد النظام عبر InstallStatusReceiver.")
            true
        } catch (e: Exception) {
            logStep("[PackageInstaller] ✗ استثناء أثناء جلسة PackageInstaller: ${e.message}")
            try {
                session?.abandon()
            } catch (_: Exception) {}

            // Try fallback via FileProvider Intent if PackageInstaller session fails
            logStep("[PackageInstaller] محاولة التثبيت البديل عبر FileProvider...")
            val fallbackSuccess = launchFileProviderInstallFallback(fileToInstall)
            if (!fallbackSuccess) {
                _installState.value = InstallState.Error(
                    title = "تعذر إتمام التثبيت",
                    message = "حدث خطأ أثناء محاولة تثبيت التطبيق: ${e.message}",
                    detailedLog = logBuilder.toString() + "\n" + e.stackTraceToString()
                )
            }
            fallbackSuccess
        }
    }

    /**
     * Fallback mechanism using FileProvider + Intent.ACTION_VIEW
     */
    private fun launchFileProviderInstallFallback(apkFile: File): Boolean {
        return try {
            val authority = "${context.packageName}.fileprovider"
            val apkUri = FileProvider.getUriForFile(context, authority, apkFile)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            _installState.value = InstallState.PendingUserConfirmation(
                message = "تم فتح مثبت الحزم عبر FileProvider - بانتظار تأكيد التثبيت من واجهة Android..."
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Fallback FileProvider install failed", e)
            false
        }
    }

    companion object {
        private const val TAG = "PackageInstallManager"
        private val _installState = MutableStateFlow<InstallState>(InstallState.Idle)

        fun notifyState(state: InstallState) {
            _installState.value = state
        }
    }
}

