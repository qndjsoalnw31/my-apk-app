package com.example.domain.repair

import com.example.data.models.DiagnosticIssue
import com.example.data.models.ProjectInfo
import java.io.File
import java.io.FileOutputStream

class AutoRepairEngine {

    data class RepairResult(
        val isSuccess: Boolean,
        val appliedFixes: List<String>,
        val backupDirectory: File?,
        val message: String
    )

    fun repairProject(projectInfo: ProjectInfo, issues: List<DiagnosticIssue>): RepairResult {
        val rootDir = projectInfo.extractedRoot
        if (!rootDir.exists()) {
            return RepairResult(false, emptyList(), null, "مجلد المشروع غير موجود")
        }

        val appliedFixes = mutableListOf<String>()

        // 1. Create safety backup first
        val backupDir = File(rootDir, "_backup_before_repair_${System.currentTimeMillis()}")
        try {
            backupDir.mkdirs()
            copyImportantFilesForBackup(rootDir, backupDir)
        } catch (e: Exception) {
            return RepairResult(false, emptyList(), null, "فشل إنشاء النسخة الاحتياطية قبل الإصلاح: ${e.message}")
        }

        try {
            // 2. Fix Wrapper Properties & gradlew
            val needsWrapperFix = issues.any { it.id == "missing_gradlew" || it.id == "missing_wrapper_properties" || it.id == "incompatible_gradle_agp" }
            if (needsWrapperFix) {
                val fixedGradle = fixGradleWrapper(rootDir, projectInfo.agpVersion)
                if (fixedGradle) {
                    appliedFixes.add("تم إنشاء وتحديث إعدادات Gradle Wrapper بالإصدار المتوافق")
                }
            }

            // 3. Fix Android Build Gradle (namespace, compileSdk, minSdk)
            val appBuildGradle = findAppBuildGradle(rootDir)
            if (appBuildGradle != null && appBuildGradle.exists()) {
                var content = appBuildGradle.readText()
                var modified = false

                // Missing namespace
                if (issues.any { it.id == "missing_namespace" }) {
                    val targetNamespace = projectInfo.namespace ?: projectInfo.applicationId ?: "com.example.apkbuilder"
                    val isKts = appBuildGradle.name.endsWith(".kts")
                    val namespaceLine = if (isKts) "    namespace = \"$targetNamespace\"\n" else "    namespace '$targetNamespace'\n"

                    if (!content.contains("namespace")) {
                        content = content.replaceFirst("android\\s*\\{".toRegex(), "android {\n$namespaceLine")
                        modified = true
                        appliedFixes.add("تمت إضافة namespace = \"$targetNamespace\"")
                    }
                }

                // Missing compileSdk
                if (issues.any { it.id == "missing_compile_sdk" }) {
                    val isKts = appBuildGradle.name.endsWith(".kts")
                    val sdkLine = if (isKts) "    compileSdk = 34\n" else "    compileSdkVersion 34\n"
                    if (!content.contains("compileSdk")) {
                        content = content.replaceFirst("android\\s*\\{".toRegex(), "android {\n$sdkLine")
                        modified = true
                        appliedFixes.add("تم تعيين compileSdk = 34")
                    }
                }

                // Missing minSdk / targetSdk inside defaultConfig
                if (issues.any { it.id == "missing_min_sdk" || it.id == "missing_target_sdk" || it.id == "missing_application_id" }) {
                    val isKts = appBuildGradle.name.endsWith(".kts")
                    if (content.contains("defaultConfig\\s*\\{".toRegex())) {
                        var defaultConfigAdditions = ""
                        if (issues.any { it.id == "missing_min_sdk" } && !content.contains("minSdk")) {
                            defaultConfigAdditions += if (isKts) "        minSdk = 24\n" else "        minSdkVersion 24\n"
                            appliedFixes.add("تم تعيين minSdk = 24")
                        }
                        if (issues.any { it.id == "missing_target_sdk" } && !content.contains("targetSdk")) {
                            defaultConfigAdditions += if (isKts) "        targetSdk = 34\n" else "        targetSdkVersion 34\n"
                            appliedFixes.add("تم تعيين targetSdk = 34")
                        }
                        if (issues.any { it.id == "missing_application_id" } && !content.contains("applicationId")) {
                            val appId = projectInfo.namespace ?: "com.example.apkbuilder"
                            defaultConfigAdditions += if (isKts) "        applicationId = \"$appId\"\n" else "        applicationId '$appId'\n"
                            appliedFixes.add("تم تعيين applicationId = \"$appId\"")
                        }

                        if (defaultConfigAdditions.isNotBlank()) {
                            content = content.replaceFirst("defaultConfig\\s*\\{".toRegex(), "defaultConfig {\n$defaultConfigAdditions")
                            modified = true
                        }
                    }
                }

                if (modified) {
                    appBuildGradle.writeText(content)
                }
            }

            // 4. Ensure local.properties with standard sdk.dir pointer if needed
            val localProperties = File(rootDir, "local.properties")
            if (!localProperties.exists()) {
                val sdkPath = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT") ?: "/android-sdk"
                localProperties.writeText("sdk.dir=${sdkPath.replace("\\", "/")}\n")
                appliedFixes.add("تم إنشاء ملف local.properties")
            }

            return RepairResult(
                isSuccess = true,
                appliedFixes = appliedFixes,
                backupDirectory = backupDir,
                message = "تم تطبيق ${appliedFixes.size} إصلاحات بنجاح، وتم حفظ نسخة احتياطية في مجلد المشروع."
            )
        } catch (e: Exception) {
            return RepairResult(false, appliedFixes, backupDir, "حدث خطأ أثناء الإصلاح: ${e.message}")
        }
    }

    private fun copyImportantFilesForBackup(rootDir: File, backupDir: File) {
        val targets = listOf(
            "build.gradle", "build.gradle.kts",
            "settings.gradle", "settings.gradle.kts",
            "app/build.gradle", "app/build.gradle.kts",
            "gradle/wrapper/gradle-wrapper.properties"
        )
        for (relativePath in targets) {
            val file = File(rootDir, relativePath)
            if (file.exists()) {
                val destFile = File(backupDir, relativePath)
                destFile.parentFile?.mkdirs()
                file.copyTo(destFile, overwrite = true)
            }
        }
    }

    private fun fixGradleWrapper(rootDir: File, agpVersion: String?): Boolean {
        val wrapperDir = File(rootDir, "gradle/wrapper")
        wrapperDir.mkdirs()

        val propertiesFile = File(wrapperDir, "gradle-wrapper.properties")
        val gradleVersionToUse = selectCompatibleGradleVersion(agpVersion)

        val propertiesContent = """
            distributionBase=GRADLE_USER_HOME
            distributionPath=wrapper/dists
            distributionUrl=https\://services.gradle.org/distributions/gradle-$gradleVersionToUse-bin.zip
            networkTimeout=10000
            validateDistributionUrl=true
            zipStoreBase=GRADLE_USER_HOME
            zipStorePath=wrapper/dists
        """.trimIndent()
        propertiesFile.writeText(propertiesContent)

        // Create basic gradlew script if missing
        val gradlewFile = File(rootDir, "gradlew")
        if (!gradlewFile.exists()) {
            gradlewFile.writeText("""
                #!/usr/bin/env sh
                exec gradle "$@"
            """.trimIndent())
            gradlewFile.setExecutable(true)
        }

        return true
    }

    private fun selectCompatibleGradleVersion(agpVersion: String?): String {
        if (agpVersion == null) return "8.11.1"
        return when {
            agpVersion.startsWith("9.") -> "8.11.1"
            agpVersion.startsWith("8.") -> "8.7"
            agpVersion.startsWith("7.") -> "7.6.4"
            else -> "8.7"
        }
    }

    private fun findAppBuildGradle(rootDir: File): File? {
        val appFolder = File(rootDir, "app")
        if (appFolder.exists()) {
            val kts = File(appFolder, "build.gradle.kts")
            if (kts.exists()) return kts
            val groovy = File(appFolder, "build.gradle")
            if (groovy.exists()) return groovy
        }
        val rootKts = File(rootDir, "build.gradle.kts")
        if (rootKts.exists()) return rootKts
        val rootGroovy = File(rootDir, "build.gradle")
        if (rootGroovy.exists()) return rootGroovy
        return null
    }
}
