package com.example.domain.repair

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupSnapshot(
    val id: String,
    val timestamp: Long,
    val dateFormatted: String,
    val backupDir: File,
    val filesCount: Int,
    val fileList: List<String>,
    val note: String
)

class BackupManager(private val baseProjectsDir: File) {

    fun createBackup(projectDir: File, note: String = "نسخة احتياطية قبل التعديل"): BackupSnapshot {
        val backupsRootDir = File(projectDir, "backups")
        if (!backupsRootDir.exists()) backupsRootDir.mkdirs()

        val id = "backup_${System.currentTimeMillis()}"
        val snapshotDir = File(backupsRootDir, id)
        snapshotDir.mkdirs()

        val backedUpFiles = mutableListOf<String>()

        // Important files to include in backup
        val candidatePaths = listOf(
            "build.gradle",
            "build.gradle.kts",
            "settings.gradle",
            "settings.gradle.kts",
            "gradle.properties",
            "local.properties",
            "proguard-rules.pro",
            "gradle/wrapper/gradle-wrapper.properties",
            "app/build.gradle",
            "app/build.gradle.kts",
            "app/proguard-rules.pro",
            "app/google-services.json",
            "app/src/main/AndroidManifest.xml"
        )

        for (rel in candidatePaths) {
            val sourceFile = File(projectDir, rel)
            if (sourceFile.exists() && sourceFile.isFile) {
                val destFile = File(snapshotDir, rel)
                destFile.parentFile?.mkdirs()
                sourceFile.copyTo(destFile, overwrite = true)
                backedUpFiles.add(rel)
            }
        }

        // Also save metadata note
        val noteFile = File(snapshotDir, "_metadata.txt")
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        noteFile.writeText("date=$dateStr\nnote=$note\nfiles=${backedUpFiles.joinToString(",")}")

        return BackupSnapshot(
            id = id,
            timestamp = System.currentTimeMillis(),
            dateFormatted = dateStr,
            backupDir = snapshotDir,
            filesCount = backedUpFiles.size,
            fileList = backedUpFiles,
            note = note
        )
    }

    fun listBackups(projectDir: File): List<BackupSnapshot> {
        val backupsRootDir = File(projectDir, "backups")
        if (!backupsRootDir.exists() || !backupsRootDir.isDirectory) return emptyList()

        val snapshots = mutableListOf<BackupSnapshot>()
        backupsRootDir.listFiles()?.filter { it.isDirectory }?.forEach { dir ->
            val noteFile = File(dir, "_metadata.txt")
            var note = "نسخة احتياطية"
            var dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(dir.lastModified()))
            var filesList = mutableListOf<String>()

            if (noteFile.exists()) {
                val lines = noteFile.readLines()
                for (line in lines) {
                    if (line.startsWith("date=")) dateStr = line.removePrefix("date=")
                    if (line.startsWith("note=")) note = line.removePrefix("note=")
                    if (line.startsWith("files=")) {
                        filesList = line.removePrefix("files=").split(",").filter { it.isNotBlank() }.toMutableList()
                    }
                }
            } else {
                dir.walkTopDown().filter { it.isFile && it.name != "_metadata.txt" }.forEach { f ->
                    filesList.add(f.relativeTo(dir).path)
                }
            }

            snapshots.add(
                BackupSnapshot(
                    id = dir.name,
                    timestamp = dir.lastModified(),
                    dateFormatted = dateStr,
                    backupDir = dir,
                    filesCount = filesList.size,
                    fileList = filesList,
                    note = note
                )
            )
        }

        return snapshots.sortedByDescending { it.timestamp }
    }

    fun restoreBackup(projectDir: File, snapshot: BackupSnapshot): Boolean {
        if (!snapshot.backupDir.exists()) return false

        // First, create a safety backup of current state
        createBackup(projectDir, "نسخة أمان قبل استعادة (${snapshot.dateFormatted})")

        // Copy files back
        snapshot.backupDir.walkTopDown().filter { it.isFile && it.name != "_metadata.txt" }.forEach { f ->
            val rel = f.relativeTo(snapshot.backupDir).path
            val destFile = File(projectDir, rel)
            destFile.parentFile?.mkdirs()
            f.copyTo(destFile, overwrite = true)
        }
        return true
    }
}
