package com.example.domain.diagnostics

import com.example.data.models.DiagnosticIssue
import com.example.data.models.DiagnosticResult
import com.example.data.models.IssueSeverity
import com.example.data.models.ProjectInfo
import com.example.data.models.ProjectType

class ProjectDiagnostics {

    fun runDiagnostics(info: ProjectInfo): DiagnosticResult {
        val issues = mutableListOf<DiagnosticIssue>()

        // 1. Check Project Type support
        if (info.projectType == ProjectType.UNSUPPORTED) {
            issues.add(
                DiagnosticIssue(
                    id = "unsupported_type",
                    severity = IssueSeverity.ERROR,
                    title = "مشروع غير مدعوم للبناء",
                    description = "الملف لا يحتوي على بنية مشروع Android مع Gradle.",
                    isAutoFixable = false,
                    suggestedAction = "تأكد من اختيار ملف ZIP لمشروع Android مكتمل يحتوي على build.gradle و AndroidManifest.xml"
                )
            )
            return DiagnosticResult(issues, isReadyToBuild = false, canAutoRepair = false)
        }

        if (info.projectType == ProjectType.FLUTTER || info.projectType == ProjectType.REACT_NATIVE) {
            issues.add(
                DiagnosticIssue(
                    id = "framework_export_needed",
                    severity = IssueSeverity.WARNING,
                    title = "مشروع يحتاج تصدير كود أندرويد",
                    description = "هذا المشروع من نوع ${info.projectType.displayNameArabic}، تأكد من وجود مجلد 'android/' كاملاً ليتمكن Gradle من البناء.",
                    isAutoFixable = false,
                    suggestedAction = "قم بتضمين مجلد android الناتج عن المشروع في ملف الـ ZIP."
                )
            )
        }

        // 2. Gradle Wrapper
        if (!info.hasGradleWrapper) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_gradlew",
                    severity = IssueSeverity.WARNING,
                    title = "ملف تشغيل Gradle (gradlew) مفقود",
                    description = "المشروع لا يحتوي على سكريبت gradlew لتنفيذ البناء تلقائياً.",
                    isAutoFixable = true,
                    fixActionTitle = "إنشاء سكريبت gradlew متوافق",
                    suggestedAction = "سيقوم نظام الإصلاح التلقائي بإنشاء سكريبت Wrapper مناسب."
                )
            )
        }

        // 3. Wrapper Properties
        if (!info.hasWrapperProperties) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_wrapper_properties",
                    severity = IssueSeverity.WARNING,
                    title = "ملف gradle-wrapper.properties مفقود",
                    description = "لا يوجد تحديد لإصدار Gradle المطلوب للبناء.",
                    isAutoFixable = true,
                    fixActionTitle = "إنشاء إعدادات Wrapper بالإصدار المتوافق",
                    suggestedAction = "توليد ملف gradle-wrapper.properties بالإصدار المناسب لـ AGP."
                )
            )
        }

        // 4. Wrapper Jar
        if (!info.hasWrapperJar) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_wrapper_jar",
                    severity = IssueSeverity.INFO,
                    title = "حزمة gradle-wrapper.jar غير مدمجة",
                    description = "سيتم استخدام بيئة Gradle المثبتة في نظام البناء.",
                    isAutoFixable = false,
                    suggestedAction = "بيئة البناء السحابية/المحلية ستوفر مشغل Gradle تلقائياً."
                )
            )
        }

        // 5. AndroidManifest.xml
        if (!info.hasAndroidManifest) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_manifest",
                    severity = IssueSeverity.ERROR,
                    title = "ملف AndroidManifest.xml مفقود",
                    description = "لا يمكن بناء أي تطبيق أندرويد بدون ملف البيان الرئيسي.",
                    isAutoFixable = false,
                    suggestedAction = "أضف ملف AndroidManifest.xml في مسار src/main/"
                )
            )
        }

        // 6. Namespace
        if (info.namespace.isNullOrBlank()) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_namespace",
                    severity = IssueSeverity.ERROR,
                    title = "خاصية namespace مفقودة في build.gradle",
                    description = "تتطلب إصدارات Android Gradle Plugin الحديثة (AGP 7+) تحديد namespace صريح.",
                    isAutoFixable = true,
                    fixActionTitle = "إضافة namespace مستخرج من Package Name",
                    suggestedAction = "استخراج المعرف من AndroidManifest أو applicationId وإضافته لـ build.gradle."
                )
            )
        }

        // 7. ApplicationId
        if (info.applicationId.isNullOrBlank()) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_application_id",
                    severity = IssueSeverity.WARNING,
                    title = "معرف التطبيق applicationId غير محدد",
                    description = "سيتم الاعتماد على namespace أو Package كمعرف افتراضي للتطبيق.",
                    isAutoFixable = true,
                    fixActionTitle = "تعيين applicationId مطابق لـ namespace",
                    suggestedAction = "إضافة applicationId في defaultConfig داخل build.gradle."
                )
            )
        }

        // 8. Compile SDK
        if (info.compileSdk == null) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_compile_sdk",
                    severity = IssueSeverity.ERROR,
                    title = "إصدار compileSdk مفقود",
                    description = "لم يتم العثور على إصدار compileSdk في ملفات build.gradle.",
                    isAutoFixable = true,
                    fixActionTitle = "تعيين compileSdk إلى 34 (أو SDK المتوافق)",
                    suggestedAction = "تحديد compileSdk متوافق مع مكتبات المشروع."
                )
            )
        }

        // 9. Min SDK
        if (info.minSdk == null) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_min_sdk",
                    severity = IssueSeverity.INFO,
                    title = "إصدار minSdk غير محدد صراحة",
                    description = "سيتم اعتماد minSdk = 24 كحد أدنى افتراضي للأجهزة المدعومة.",
                    isAutoFixable = true,
                    fixActionTitle = "تثبيت minSdk = 24",
                    suggestedAction = "إضافة minSdk = 24 في defaultConfig."
                )
            )
        }

        // 10. Target SDK
        if (info.targetSdk == null) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_target_sdk",
                    severity = IssueSeverity.INFO,
                    title = "إصدار targetSdk غير محدد",
                    description = "يفضل مطابقة targetSdk مع compileSdk.",
                    isAutoFixable = true,
                    fixActionTitle = "مطابقة targetSdk مع compileSdk",
                    suggestedAction = "إضافة targetSdk في defaultConfig."
                )
            )
        }

        // 11. Google Services
        if (info.requiresGoogleServices && !info.hasGoogleServicesJson) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_google_services_json",
                    severity = IssueSeverity.WARNING,
                    title = "ملف google-services.json مطلوب للمشروع ومفقود",
                    description = "المشروع يستخدم إضافات Firebase / Google Services لكن الملف المطلوب غير موجود في مجلد app/.",
                    isAutoFixable = false,
                    suggestedAction = "قم بتنزيل google-services.json من منصة Firebase Console وضعه داخل مجلد app/."
                )
            )
        }

        // 12. Gradle and AGP Version Compatibility
        val gradleVer = info.gradleVersion
        val agpVer = info.agpVersion
        if (gradleVer != null && agpVer != null) {
            val isCompatible = checkAgpGradleCompatibility(agpVer, gradleVer)
            if (!isCompatible) {
                issues.add(
                    DiagnosticIssue(
                        id = "incompatible_gradle_agp",
                        severity = IssueSeverity.ERROR,
                        title = "عدم توافق بين إصدار Gradle ($gradleVer) و AGP ($agpVer)",
                        description = "يتطلب إصدار أندرويد Gradle Plugin إصداراً متوافقاً من Gradle حتى يكتمل البناء بنجاح.",
                        isAutoFixable = true,
                        fixActionTitle = "تحديث Gradle Wrapper إلى الإصدار المتوافق",
                        suggestedAction = "تعديل distributionUrl في gradle-wrapper.properties إلى الإصدار المناسب."
                    )
                )
            }
        }

        // 13. Debug Keystore
        if (!info.hasDebugKeystore) {
            issues.add(
                DiagnosticIssue(
                    id = "missing_debug_keystore",
                    severity = IssueSeverity.INFO,
                    title = "مفتاح التوقيع التجريبي debug.keystore",
                    description = "سيتم استخدام مفتاح Debug الافتراضي الرسمي من Android SDK لتوقيع ملف APK.",
                    isAutoFixable = true,
                    fixActionTitle = "تجهيز مفتاح debug.keystore تلقائياً",
                    suggestedAction = "توفير debug keystore قياسي في بيئة البناء."
                )
            )
        }

        val hasBlockingErrors = issues.any { it.severity == IssueSeverity.ERROR && !it.isAutoFixable }
        val canAutoRepair = issues.any { it.isAutoFixable }

        return DiagnosticResult(
            issues = issues,
            isReadyToBuild = !hasBlockingErrors,
            canAutoRepair = canAutoRepair
        )
    }

    private fun checkAgpGradleCompatibility(agp: String, gradle: String): Boolean {
        val agpMajor = extractMajorMinor(agp)
        val gradleMajor = extractMajorMinor(gradle)

        // AGP 8.0+ requires Gradle 8.0+
        if (agpMajor >= 8.0f && gradleMajor < 8.0f) return false
        // AGP 7.0+ requires Gradle 7.0+
        if (agpMajor >= 7.0f && gradleMajor < 7.0f) return false
        // AGP 9.0+ requires Gradle 8.7+ or 9.0+
        if (agpMajor >= 9.0f && gradleMajor < 8.7f) return false

        return true
    }

    private fun extractMajorMinor(version: String): Float {
        return try {
            val parts = version.split(".")
            if (parts.size >= 2) {
                "${parts[0]}.${parts[1]}".toFloat()
            } else {
                parts[0].toFloat()
            }
        } catch (e: Exception) {
            8.0f
        }
    }
}
