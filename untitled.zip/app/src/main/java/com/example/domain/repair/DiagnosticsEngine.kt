package com.example.domain.repair

import com.example.data.models.ProjectInfo
import java.io.File
import java.util.regex.Pattern

class DiagnosticsEngine {

    /**
     * Analyzes both the project structure and build execution logs to produce comprehensive DiagnosticProblem items.
     */
    fun diagnose(projectInfo: ProjectInfo?, buildLog: String? = null): List<DiagnosticProblem> {
        val problems = mutableListOf<DiagnosticProblem>()
        val rootDir = projectInfo?.extractedRoot

        val log = buildLog ?: ""
        val logLower = log.lowercase()

        // 1. Gradle Version Mismatch
        if (logLower.contains("minimum supported gradle version") ||
            logLower.contains("is not compatible with this version of the android gradle plugin") ||
            (projectInfo?.gradleVersion != null && projectInfo.agpVersion != null && !isGradleAgpCompatible(projectInfo.agpVersion, projectInfo.gradleVersion))
        ) {
            val requiredGradle = extractRequiredGradleVersion(log) ?: selectBestGradleForAgp(projectInfo?.agpVersion)
            val currentGradle = projectInfo?.gradleVersion ?: extractCurrentGradle(rootDir) ?: "غير محدد"

            problems.add(
                DiagnosticProblem(
                    id = "gradle_version_mismatch",
                    title = "Gradle غير متوافق مع Android Gradle Plugin",
                    severity = ProblemSeverity.ERROR,
                    reasonArabic = "إصدار Gradle الحالي ($currentGradle) لا يتوافق مع إصدار Android Gradle Plugin (${projectInfo?.agpVersion ?: "المستخدم"}) في المشروع.",
                    affectedFilePath = "gradle/wrapper/gradle-wrapper.properties",
                    affectedLineNumber = findLineNumberInFile(rootDir, "gradle/wrapper/gradle-wrapper.properties", "distributionUrl"),
                    currentValue = "Gradle $currentGradle",
                    expectedValue = "Gradle $requiredGradle",
                    actionType = RepairActionType.AUTO_FIX,
                    whyItHappened = "كل إصدار من إضافة أندرويد (AGP) يتطلب إصداراً أدنى من محرك Gradle. استخدام إصدار أقدم يؤدي لتوقف عملية الترجمة فوراً.",
                    suggestedFixArabic = "تحديث distributionUrl في ملف gradle-wrapper.properties إلى الإصدار $requiredGradle.",
                    isAutoFixAvailable = true,
                    autoFixCode = "gradle_update_$requiredGradle"
                )
            )
        }

        // 2. Google Services JSON Missing
        if (logLower.contains("google-services.json is missing") ||
            logLower.contains("file google-services.json is missing") ||
            (projectInfo?.requiresGoogleServices == true && !projectInfo.hasGoogleServicesJson)
        ) {
            problems.add(
                DiagnosticProblem(
                    id = "missing_google_services_json",
                    title = "google-services.json غير موجود",
                    severity = ProblemSeverity.WARNING,
                    reasonArabic = "المشروع يستخدم إضافات Firebase / Google Services لكن ملف التهيئة google-services.json غير موجود في مجلد app/.",
                    affectedFilePath = "app/google-services.json",
                    currentValue = "الملف مفقود",
                    expectedValue = "ملف تهيئة Firebase صالح (app/google-services.json)",
                    actionType = RepairActionType.USER_FILE_REQUIRED,
                    whyItHappened = "إضافة Google Services Gradle Plugin تبحث عن مفاتيح وبيانات تطبيق Firebase أثناء مرحلة البناء ولا يمكن استكمال البناء بدونها.",
                    suggestedFixArabic = "قم باختيار وتضمين ملف google-services.json الأصلي من لوحة تحكم مشروع Firebase الخاص بك.",
                    isAutoFixAvailable = false,
                    userFileKey = "google-services.json"
                )
            )
        }

        // 3. Debug Keystore Missing / Signing Issue
        if (logLower.contains("validatesigningdebug") ||
            logLower.contains("keystore file not found") ||
            logLower.contains("debug.keystore") ||
            (projectInfo != null && !projectInfo.hasDebugKeystore && logLower.contains("signing"))
        ) {
            problems.add(
                DiagnosticProblem(
                    id = "debug_signing_problem",
                    title = "Debug Keystore مفقود أو إعدادات التوقيع غير صحيحة",
                    severity = ProblemSeverity.ERROR,
                    reasonArabic = "مفتاح التوقيع التجريبي debug.keystore غير متوفر أو مسار التوقيع في build.gradle يشير لملف غير موجود.",
                    affectedFilePath = findAppBuildGradleRelative(rootDir) ?: "app/build.gradle.kts",
                    currentValue = "مفتاح التوقيع مفقود",
                    expectedValue = "debug.keystore صالح",
                    actionType = RepairActionType.AUTO_FIX,
                    whyItHappened = "نظام Android يتطلب توقيع كل حزمة APK رقمياً حتى في وضع التطوير (Debug).",
                    suggestedFixArabic = "توليد ملف debug.keystore قياسي وتعديل إعدادات التوقيع تلقائياً في المشروع.",
                    isAutoFixAvailable = true,
                    autoFixCode = "create_debug_keystore"
                )
            )
        }

        // 4. JVM Heap / Memory Issue
        if (logLower.contains("outofmemoryerror") ||
            logLower.contains("the maximum heap size is insufficient") ||
            logLower.contains("java heap space") ||
            logLower.contains("metaspace")
        ) {
            val maxAvailMb = Runtime.getRuntime().maxMemory() / (1024 * 1024)
            val suggestedHeap = if (maxAvailMb >= 3000) "2048m" else "1024m"

            problems.add(
                DiagnosticProblem(
                    id = "jvm_memory_problem",
                    title = "مشكلة ذاكرة JVM Heap",
                    severity = ProblemSeverity.ERROR,
                    reasonArabic = "استهلكت عملية تجميع المشروع الذاكرة المخصصة لمحرك Gradle بالكامل.",
                    affectedFilePath = "gradle.properties",
                    currentValue = "غير محدد أو غير كافٍ",
                    expectedValue = "org.gradle.jvmargs=-Xmx$suggestedHeap -XX:MaxMetaspaceSize=512m",
                    actionType = RepairActionType.AUTO_FIX,
                    whyItHappened = "المشاريع الكبيرة التي تحتوي على مكتبات ضخمة تتطلب مساحة Heap كافية لمعالجة الرموز والترجمة.",
                    suggestedFixArabic = "إضافة وتعديل إعدادات org.gradle.jvmargs في ملف gradle.properties بما يناسب إمكانيات الجهاز.",
                    isAutoFixAvailable = true,
                    autoFixCode = "fix_jvm_args_$suggestedHeap"
                )
            )
        }

        // 5. Namespace Missing
        if (logLower.contains("namespace not specified") ||
            logLower.contains("namespace is not specified") ||
            (projectInfo != null && projectInfo.namespace.isNullOrBlank())
        ) {
            val suggestedNamespace = projectInfo?.applicationId ?: "com.example.app"
            val appGradle = findAppBuildGradleRelative(rootDir) ?: "app/build.gradle.kts"

            problems.add(
                DiagnosticProblem(
                    id = "missing_namespace",
                    title = "خاصية Namespace مفقودة",
                    severity = ProblemSeverity.ERROR,
                    reasonArabic = "إصدارات Android Gradle Plugin الحديثة (AGP 7+) تفرض تحديد خاصية namespace صراحة.",
                    affectedFilePath = appGradle,
                    currentValue = "namespace غير محدد",
                    expectedValue = "namespace = \"$suggestedNamespace\"",
                    actionType = RepairActionType.AUTO_FIX,
                    whyItHappened = "فصلت Google بين applicationId (معرف متجر Play) و namespace (حزمة كود R وجافا) لتسهيل تعدد الإصدارات.",
                    suggestedFixArabic = "إضافة namespace \"$suggestedNamespace\" داخل كتلة android { ... } في ملف $appGradle.",
                    isAutoFixAvailable = true,
                    autoFixCode = "add_namespace_$suggestedNamespace"
                )
            )
        }

        // 6. Build Tools Missing
        if (logLower.contains("failed to find build tools") || logLower.contains("build tools revision")) {
            val matcher = Pattern.compile("build tools revision ([0-9.]+)").matcher(logLower)
            val requestedVersion = if (matcher.find()) matcher.group(1) else "34.0.0"

            problems.add(
                DiagnosticProblem(
                    id = "missing_build_tools",
                    title = "Android Build Tools مفقود أو غير متوفر",
                    severity = ProblemSeverity.ERROR,
                    reasonArabic = "إصدار Build Tools المطلوب ($requestedVersion) غير متوفر في بيئة البناء الحالية.",
                    affectedFilePath = findAppBuildGradleRelative(rootDir) ?: "app/build.gradle.kts",
                    currentValue = requestedVersion,
                    expectedValue = "استخدام الإصدار المتوفر (34.0.0 أو التحديث السحابي)",
                    actionType = RepairActionType.AUTO_FIX,
                    whyItHappened = "ملف build.gradle يحدد خاصية buildToolsVersion بإصدار قديم أو غير مثبت.",
                    suggestedFixArabic = "تحديث buildToolsVersion أو إزالته للاعتماد على الإصدار الافتراضي المتوافق مع compileSdk.",
                    isAutoFixAvailable = true,
                    autoFixCode = "fix_build_tools"
                )
            )
        }

        // 7. Android SDK Location Missing
        if (logLower.contains("sdk location not found") || logLower.contains("android_home")) {
            problems.add(
                DiagnosticProblem(
                    id = "missing_sdk_location",
                    title = "مسار Android SDK غير مضبوط",
                    severity = ProblemSeverity.ERROR,
                    reasonArabic = "لم يتمكن Gradle من العثور على مسار تثبيت Android SDK وأدوات الترجمة.",
                    affectedFilePath = "local.properties",
                    currentValue = "sdk.dir مفقود",
                    expectedValue = "sdk.dir=/android-sdk",
                    actionType = RepairActionType.ENVIRONMENT_FIX,
                    whyItHappened = "يحتاج محرك Gradle لمعرفة مسار ملفات المنصة وترجمة حزم أندرويد.",
                    suggestedFixArabic = "إنشاء ملف local.properties وضبط sdk.dir تلقائياً، أو استخدام خادم البناء السحابي.",
                    isAutoFixAvailable = true,
                    autoFixCode = "create_local_properties"
                )
            )
        }

        // 8. Compile / Target SDK Missing or Incompatible
        if (projectInfo != null && (projectInfo.compileSdk == null || projectInfo.compileSdk ?: 0 < 21)) {
            val appGradle = findAppBuildGradleRelative(rootDir) ?: "app/build.gradle.kts"
            problems.add(
                DiagnosticProblem(
                    id = "missing_compile_sdk",
                    title = "إصدار compileSdk مفقود أو قديم",
                    severity = ProblemSeverity.WARNING,
                    reasonArabic = "إصدار compileSdk غير محدد بشكل سليم في إعدادات build.gradle.",
                    affectedFilePath = appGradle,
                    currentValue = "${projectInfo.compileSdk ?: "غير محدد"}",
                    expectedValue = "compileSdk = 34",
                    actionType = RepairActionType.AUTO_FIX,
                    whyItHappened = "تحديد compileSdk ضروري لترجمة التطبيق وفق واجهات برمجة أندرويد الحديثة.",
                    suggestedFixArabic = "تعيين compileSdk = 34 و targetSdk = 34 داخل $appGradle.",
                    isAutoFixAvailable = true,
                    autoFixCode = "fix_compile_sdk_34"
                )
            )
        }

        // 9. Dependency Resolution Problems
        if (logLower.contains("could not resolve") || logLower.contains("failed to resolve")) {
            val appGradle = findAppBuildGradleRelative(rootDir) ?: "app/build.gradle.kts"
            problems.add(
                DiagnosticProblem(
                    id = "dependency_resolution_error",
                    title = "فشل تحميل الاعتماديات (Dependency Error)",
                    severity = ProblemSeverity.ERROR,
                    reasonArabic = "تعذر تحميل إحدى المكتبات من مستودعات Google أو MavenCentral.",
                    affectedFilePath = appGradle,
                    currentValue = "مستودعات غير مكتملة أو إصدار غير متاح",
                    expectedValue = "تضمين google(), mavenCentral() و gradlePluginPortal()",
                    actionType = RepairActionType.MANUAL_FIX,
                    whyItHappened = "قد يكون الإصدار المحدد غير موجود، أو ينقص رابط المستودع في settings.gradle، أو لا يتوفر اتصال بالإنترنت.",
                    suggestedFixArabic = "افحص قائمة dependencies والمستودعات في settings.gradle و build.gradle.",
                    isAutoFixAvailable = true,
                    autoFixCode = "ensure_standard_repositories"
                )
            )
        }

        // 10. Java / Kotlin JVM Compatibility
        if (logLower.contains("unsupported class file major version") ||
            logLower.contains("jvm target compatibility") ||
            logLower.contains("inconsistent jvm-target")
        ) {
            val appGradle = findAppBuildGradleRelative(rootDir) ?: "app/build.gradle.kts"
            problems.add(
                DiagnosticProblem(
                    id = "jvm_target_mismatch",
                    title = "عدم توافق إصدار Java / Kotlin JVM Target",
                    severity = ProblemSeverity.ERROR,
                    reasonArabic = "تضارب بين إصدار Java المستهدف في compileOptions وإصدار Kotlin jvmTarget.",
                    affectedFilePath = appGradle,
                    currentValue = "JVM Target غير متطابق",
                    expectedValue = "JavaVersion.VERSION_17 و jvmTarget = \"17\"",
                    actionType = RepairActionType.AUTO_FIX,
                    whyItHappened = "تتطلب إصدارات Kotlin و Java الحديثة توحيد إصدار البايت كود المترجم.",
                    suggestedFixArabic = "توحيد compileOptions و kotlinOptions ليكون الهدف JavaVersion.VERSION_17.",
                    isAutoFixAvailable = true,
                    autoFixCode = "unify_jvm_target_17"
                )
            )
        }

        // 11. AndroidManifest.xml Error
        if (logLower.contains("manifest merger failed") || logLower.contains("androidmanifest.xml")) {
            val lineMatcher = Pattern.compile("AndroidManifest\\.xml:([0-9]+)").matcher(log)
            val lineNum = if (lineMatcher.find()) lineMatcher.group(1).toIntOrNull() else 1

            problems.add(
                DiagnosticProblem(
                    id = "manifest_merger_error",
                    title = "خطأ في دمج AndroidManifest.xml",
                    severity = ProblemSeverity.ERROR,
                    reasonArabic = "تعارض في سمات ملف AndroidManifest.xml بين التطبيق والمكتبات المدمجة.",
                    affectedFilePath = "app/src/main/AndroidManifest.xml",
                    affectedLineNumber = lineNum,
                    currentValue = "تعارض في السمات (مثل allowBackup أو theme)",
                    expectedValue = "إضافة tools:replace أو إصلاح السمة المتعارضة",
                    actionType = RepairActionType.MANUAL_FIX,
                    whyItHappened = "عند دمج ملفات Manifest للمكتبات مع ملف التطبيق، قد تتكرر بعض الخصائص بقيم مختلفة.",
                    suggestedFixArabic = "فتح AndroidManifest.xml وإضافة xmlns:tools و tools:replace للسمة المتسببة.",
                    isAutoFixAvailable = false
                )
            )
        }

        return problems
    }

    private fun isGradleAgpCompatible(agp: String, gradle: String): Boolean {
        val agpFloat = agp.take(3).toFloatOrNull() ?: 8.0f
        val gradleFloat = gradle.take(3).toFloatOrNull() ?: 8.0f

        if (agpFloat >= 8.7f && gradleFloat < 8.7f) return false
        if (agpFloat >= 8.0f && gradleFloat < 8.0f) return false
        if (agpFloat >= 7.0f && gradleFloat < 7.0f) return false
        return true
    }

    private fun selectBestGradleForAgp(agp: String?): String {
        if (agp == null) return "8.7"
        return when {
            agp.startsWith("8.7") || agp.startsWith("8.8") || agp.startsWith("8.9") || agp.startsWith("9.") -> "8.11.1"
            agp.startsWith("8.") -> "8.7"
            agp.startsWith("7.") -> "7.6.4"
            else -> "8.7"
        }
    }

    private fun extractRequiredGradleVersion(log: String): String? {
        val matcher = Pattern.compile("minimum supported gradle version is ([0-9.]+)").matcher(log.lowercase())
        return if (matcher.find()) matcher.group(1) else null
    }

    private fun extractCurrentGradle(rootDir: File?): String? {
        if (rootDir == null) return null
        val propsFile = File(rootDir, "gradle/wrapper/gradle-wrapper.properties")
        if (propsFile.exists()) {
            val text = propsFile.readText()
            val matcher = Pattern.compile("gradle-([0-9.]+)-").matcher(text)
            if (matcher.find()) return matcher.group(1)
        }
        return null
    }

    private fun findAppBuildGradleRelative(rootDir: File?): String? {
        if (rootDir == null) return "app/build.gradle.kts"
        if (File(rootDir, "app/build.gradle.kts").exists()) return "app/build.gradle.kts"
        if (File(rootDir, "app/build.gradle").exists()) return "app/build.gradle"
        if (File(rootDir, "build.gradle.kts").exists()) return "build.gradle.kts"
        if (File(rootDir, "build.gradle").exists()) return "build.gradle"
        return "app/build.gradle.kts"
    }

    private fun findLineNumberInFile(rootDir: File?, relPath: String, searchSub: String): Int? {
        if (rootDir == null) return null
        val f = File(rootDir, relPath)
        if (!f.exists()) return null
        try {
            f.readLines().forEachIndexed { index, line ->
                if (line.contains(searchSub)) return index + 1
            }
        } catch (_: Exception) {}
        return null
    }
}
