package com.example

import com.example.data.models.ProjectType
import com.example.domain.analyzer.ProjectAnalyzer
import com.example.domain.builder.GitHubWorkflowGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ProjectAnalyzerTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private val analyzer = ProjectAnalyzer()

    @Test
    fun `test metropolis-architect nested project discovery and scoring`() {
        val rootDir = tempFolder.newFolder("metropolis_workspace")
        val nestedAppDir = File(rootDir, "metropolis-architect/android").apply { mkdirs() }

        // Create root files
        File(nestedAppDir, "settings.gradle.kts").writeText(
            """
            rootProject.name = "metropolis-architect"
            include(":app")
            include(":core-model")
            """.trimIndent()
        )

        File(nestedAppDir, "gradlew").writeText("#!/bin/sh\n")
        File(nestedAppDir, "gradlew.bat").writeText("@echo off\n")

        val wrapperDir = File(nestedAppDir, "gradle/wrapper").apply { mkdirs() }
        File(wrapperDir, "gradle-wrapper.properties").writeText(
            "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.11.1-bin.zip\n"
        )

        val appModuleDir = File(nestedAppDir, "app").apply { mkdirs() }
        File(appModuleDir, "build.gradle.kts").writeText(
            """
            plugins {
                id("com.android.application")
                id("org.jetbrains.kotlin.android")
            }
            android {
                namespace = "com.metropolis.architect"
                compileSdk = 35
                defaultConfig {
                    applicationId = "com.metropolis.architect"
                    minSdk = 26
                    targetSdk = 35
                }
                compileOptions {
                    sourceCompatibility = JavaVersion.VERSION_17
                    targetCompatibility = JavaVersion.VERSION_17
                }
                buildFeatures {
                    compose = true
                }
            }
            dependencies {
                implementation("androidx.room:room-runtime:2.6.1")
                implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")
            }
            """.trimIndent()
        )

        val manifestDir = File(appModuleDir, "src/main").apply { mkdirs() }
        File(manifestDir, "AndroidManifest.xml").writeText(
            """
            <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                <application android:label="Metropolis Architect" />
            </manifest>
            """.trimIndent()
        )

        val projectInfo = analyzer.analyze(
            extractedDir = rootDir,
            zipFileName = "metropolis-architect.zip",
            zipFileSize = 1048576L
        )

        assertEquals("metropolis-architect", projectInfo.projectName)
        assertTrue(projectInfo.confidenceScore >= 70)
        assertTrue(projectInfo.projectType.isSupported)
        assertEquals("com.metropolis.architect", projectInfo.namespace)
        assertEquals(35, projectInfo.compileSdk)
        assertEquals(26, projectInfo.minSdk)
        assertEquals("17", projectInfo.javaVersion)
        assertEquals("8.11.1", projectInfo.gradleVersion)
        assertTrue(projectInfo.hasCompose)
        assertTrue(projectInfo.hasRoom)
        assertTrue(projectInfo.hasCoroutines)
        assertTrue(projectInfo.applicationModules.contains(":app"))

        // Test CI workflow generation
        val workflowYaml = GitHubWorkflowGenerator.generateWorkflowYaml(projectInfo)
        assertNotNull(workflowYaml)
        assertTrue(workflowYaml.contains("Android APK Build"))
        assertTrue(workflowYaml.contains("metropolis-architect-debug-apk"))
    }

    @Test
    fun `test libs versions toml parsing`() {
        val rootDir = tempFolder.newFolder("toml_project")
        val gradleDir = File(rootDir, "gradle").apply { mkdirs() }

        File(rootDir, "settings.gradle").writeText("rootProject.name = 'SampleTomlApp'\ninclude ':app'")
        File(gradleDir, "libs.versions.toml").writeText(
            """
            [versions]
            agp = "8.7.2"
            kotlin = "2.0.21"
            compose-bom = "2024.10.01"

            [libraries]
            androidx-room-runtime = { group = "androidx.room", name = "room-runtime", version = "2.6.1" }
            """.trimIndent()
        )

        val appDir = File(rootDir, "app").apply { mkdirs() }
        File(appDir, "build.gradle").writeText(
            """
            plugins {
                id 'com.android.application'
            }
            android {
                namespace 'com.example.toml'
                compileSdk 34
            }
            """.trimIndent()
        )

        val manifestDir = File(appDir, "src/main").apply { mkdirs() }
        File(manifestDir, "AndroidManifest.xml").writeText("<manifest package=\"com.example.toml\" />")

        val info = analyzer.analyze(rootDir, "toml_project.zip", 500000L)
        assertEquals("8.7.2", info.agpVersion)
        assertTrue(info.hasVersionCatalog)
        assertEquals("SampleTomlApp", info.projectName)
    }
}
