package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.MediaRepository
import com.example.ui.screens.camera.CameraScreen
import com.example.ui.screens.editor.MediaEditorScreen
import com.example.ui.screens.gallery.GalleryScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.viewer.MediaViewerScreen
import com.example.ui.theme.CineBlack
import com.example.ui.theme.CineProTheme

sealed class Screen(val route: String) {
    data object Camera : Screen("camera")
    data object Gallery : Screen("gallery")
    data object Viewer : Screen("viewer/{mediaId}") {
        fun createRoute(mediaId: String) = "viewer/$mediaId"
    }
    data object Editor : Screen("editor/{mediaId}") {
        fun createRoute(mediaId: String) = "editor/$mediaId"
    }
    data object Settings : Screen("settings")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = MediaRepository(applicationContext)

        setContent {
            CineProTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CineBlack
                ) {
                    CineProApp(repository = repository)
                }
            }
        }
    }
}

@Composable
fun CineProApp(repository: MediaRepository) {
    val navController = rememberNavController()

    // Pre-seed demo cinema footage & photos if vault is empty
    LaunchedEffect(Unit) {
        repository.seedDemoCinemaAssetsIfEmpty()
    }

    NavHost(
        navController = navController,
        startDestination = Screen.Camera.route,
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        composable(Screen.Camera.route) {
            CameraScreen(
                repository = repository,
                onNavigateToGallery = {
                    navController.navigate(Screen.Gallery.route)
                },
                onNavigateToSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        composable(Screen.Gallery.route) {
            GalleryScreen(
                repository = repository,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onOpenMediaItem = { mediaId ->
                    navController.navigate(Screen.Viewer.createRoute(mediaId))
                }
            )
        }

        composable(
            route = Screen.Viewer.route,
            arguments = listOf(navArgument("mediaId") { type = NavType.StringType })
        ) { backStackEntry ->
            val mediaId = backStackEntry.arguments?.getString("mediaId") ?: ""
            MediaViewerScreen(
                mediaId = mediaId,
                repository = repository,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToEditor = { id ->
                    navController.navigate(Screen.Editor.createRoute(id))
                }
            )
        }

        composable(
            route = Screen.Editor.route,
            arguments = listOf(navArgument("mediaId") { type = NavType.StringType })
        ) { backStackEntry ->
            val mediaId = backStackEntry.arguments?.getString("mediaId") ?: ""
            MediaEditorScreen(
                mediaId = mediaId,
                repository = repository,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onSaved = { newId ->
                    navController.popBackStack()
                    navController.navigate(Screen.Viewer.createRoute(newId))
                }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
