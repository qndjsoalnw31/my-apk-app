package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MediaDao {
    @Query("SELECT * FROM cinema_media ORDER BY dateAdded DESC")
    fun getAllMedia(): Flow<List<MediaEntity>>

    @Query("SELECT * FROM cinema_media WHERE isVideo = 1 ORDER BY dateAdded DESC")
    fun getVideos(): Flow<List<MediaEntity>>

    @Query("SELECT * FROM cinema_media WHERE isVideo = 0 ORDER BY dateAdded DESC")
    fun getPhotos(): Flow<List<MediaEntity>>

    @Query("SELECT * FROM cinema_media WHERE isFavorite = 1 ORDER BY dateAdded DESC")
    fun getFavorites(): Flow<List<MediaEntity>>

    @Query("SELECT * FROM cinema_media WHERE id = :id LIMIT 1")
    suspend fun getMediaById(id: String): MediaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedia(item: MediaEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<MediaEntity>)

    @Update
    suspend fun updateMedia(item: MediaEntity)

    @Delete
    suspend fun deleteMedia(item: MediaEntity)

    @Query("DELETE FROM cinema_media WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<String>)

    @Query("UPDATE cinema_media SET isFavorite = :isFav WHERE id = :id")
    suspend fun updateFavorite(id: String, isFav: Boolean)

    @Query("UPDATE cinema_media SET title = :newTitle WHERE id = :id")
    suspend fun renameMedia(id: String, newTitle: String)
}
