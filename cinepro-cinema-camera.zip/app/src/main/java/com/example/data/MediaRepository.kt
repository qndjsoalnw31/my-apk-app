package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.FilmLook
import com.example.model.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class MediaRepository(private val context: Context) {
    private val database = CinemaDatabase.getInstance(context)
    private val dao = database.mediaDao()

    val allMedia: Flow<List<MediaItem>> = dao.getAllMedia().map { list -> list.map { it.toModel() } }
    val videos: Flow<List<MediaItem>> = dao.getVideos().map { list -> list.map { it.toModel() } }
    val photos: Flow<List<MediaItem>> = dao.getPhotos().map { list -> list.map { it.toModel() } }
    val favorites: Flow<List<MediaItem>> = dao.getFavorites().map { list -> list.map { it.toModel() } }

    suspend fun getMediaById(id: String): MediaItem? {
        return dao.getMediaById(id)?.toModel()
    }

    suspend fun saveMediaItem(item: MediaItem) {
        dao.insertMedia(MediaEntity.fromModel(item))
    }

    suspend fun deleteMedia(item: MediaItem) {
        dao.deleteMedia(MediaEntity.fromModel(item))
        item.filePath?.let { path ->
            try {
                val f = File(path)
                if (f.exists()) f.delete()
            } catch (_: Exception) {}
        }
    }

    suspend fun deleteMultiple(items: List<MediaItem>) {
        dao.deleteByIds(items.map { it.id })
        items.forEach { item ->
            item.filePath?.let { path ->
                try {
                    val f = File(path)
                    if (f.exists()) f.delete()
                } catch (_: Exception) {}
            }
        }
    }

    suspend fun toggleFavorite(id: String, isFav: Boolean) {
        dao.updateFavorite(id, isFav)
    }

    suspend fun renameMedia(id: String, newTitle: String) {
        dao.renameMedia(id, newTitle)
    }

    /**
     * Imports one or more files selected by the user via file picker or photo picker.
     */
    suspend fun importFromUri(uri: Uri): MediaItem? = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            var displayName = "imported_${System.currentTimeMillis()}"
            var sizeBytes = 0L

            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) displayName = cursor.getString(nameIndex) ?: displayName
                    if (sizeIndex != -1) sizeBytes = cursor.getLong(sizeIndex)
                }
            }

            val mimeType = contentResolver.getType(uri) ?: when {
                displayName.endsWith(".mp4", true) -> "video/mp4"
                displayName.endsWith(".mov", true) -> "video/quicktime"
                displayName.endsWith(".mkv", true) -> "video/x-matroska"
                displayName.endsWith(".webm", true) -> "video/webm"
                displayName.endsWith(".png", true) -> "image/png"
                displayName.endsWith(".jpg", true) || displayName.endsWith(".jpeg", true) -> "image/jpeg"
                displayName.endsWith(".dng", true) -> "image/x-adobe-dng"
                displayName.endsWith(".mp3", true) -> "audio/mpeg"
                displayName.endsWith(".wav", true) -> "audio/wav"
                else -> "application/octet-stream"
            }

            val isVideo = mimeType.startsWith("video/")
            val isAudio = mimeType.startsWith("audio/")

            // Copy to app private files so it is always accessible and persistent
            val destDir = File(context.filesDir, if (isVideo) "cinema_videos" else "cinema_photos")
            if (!destDir.exists()) destDir.mkdirs()
            val safeFileName = "${System.currentTimeMillis()}_${displayName.replace(" ", "_")}"
            val destFile = File(destDir, safeFileName)

            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }

            sizeBytes = destFile.length()

            var width = 1920
            var height = 1080
            var durationMs = 0L

            if (isVideo || isAudio) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(destFile.absolutePath)
                    val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    durationMs = durStr?.toLongOrNull() ?: 0L
                    val wStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    val hStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    width = wStr?.toIntOrNull() ?: 1920
                    height = hStr?.toIntOrNull() ?: 1080
                } catch (_: Exception) {
                } finally {
                    try { retriever.release() } catch (_: Exception) {}
                }
            } else {
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(destFile.absolutePath, options)
                if (options.outWidth > 0 && options.outHeight > 0) {
                    width = options.outWidth
                    height = options.outHeight
                }
            }

            val newItem = MediaItem(
                id = UUID.randomUUID().toString(),
                title = displayName,
                uriString = Uri.fromFile(destFile).toString(),
                filePath = destFile.absolutePath,
                mimeType = mimeType,
                isVideo = isVideo,
                durationMs = durationMs,
                width = width,
                height = height,
                sizeBytes = sizeBytes,
                dateAdded = System.currentTimeMillis(),
                iso = 400,
                shutterSpeed = "1/50s",
                aperture = "f/1.8",
                focalLength = "24mm",
                fps = if (isVideo) 24 else null,
                colorProfile = "Rec. 709",
                album = "Imported"
            )

            dao.insertMedia(MediaEntity.fromModel(newItem))
            newItem
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Extracts a frame from a video at the specified timestamp in milliseconds
     * and saves it as a new photo in the Media Vault.
     */
    suspend fun extractFrame(videoItem: MediaItem, timestampMs: Long): MediaItem? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            val path = videoItem.filePath ?: Uri.parse(videoItem.uriString).path ?: return@withContext null
            retriever.setDataSource(path)
            val bitmap = retriever.getFrameAtTime(timestampMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return@withContext null

            val destDir = File(context.filesDir, "cinema_photos")
            if (!destDir.exists()) destDir.mkdirs()
            val fileName = "STILL_${videoItem.title.substringBeforeLast('.')}_${timestampMs}ms.jpg"
            val destFile = File(destDir, fileName)

            FileOutputStream(destFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }

            val newItem = MediaItem(
                id = UUID.randomUUID().toString(),
                title = fileName,
                uriString = Uri.fromFile(destFile).toString(),
                filePath = destFile.absolutePath,
                mimeType = "image/jpeg",
                isVideo = false,
                width = bitmap.width,
                height = bitmap.height,
                sizeBytes = destFile.length(),
                dateAdded = System.currentTimeMillis(),
                iso = videoItem.iso ?: 400,
                shutterSpeed = videoItem.shutterSpeed ?: "1/50s",
                aperture = videoItem.aperture ?: "f/1.8",
                focalLength = videoItem.focalLength ?: "35mm",
                colorProfile = videoItem.colorProfile ?: "Film Look",
                album = "Extracted Frames"
            )
            dao.insertMedia(MediaEntity.fromModel(newItem))
            newItem
        } catch (e: Exception) {
            e.printStackTrace()
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    /**
     * Edits a photo: applies rotation, cropping, color adjustments, and film look,
     * saving as a new copy to preserve the original.
     */
    suspend fun editAndSavePhoto(
        sourceItem: MediaItem,
        rotationDegrees: Float,
        cropRect: android.graphics.RectF?, // 0.0 to 1.0 relative
        filmLook: FilmLook,
        exposureOffset: Float, // -2.0 to +2.0
        contrastMultiplier: Float, // 0.5 to 2.0
        saturationMultiplier: Float // 0.0 to 2.0
    ): MediaItem? = withContext(Dispatchers.IO) {
        try {
            val path = sourceItem.filePath ?: Uri.parse(sourceItem.uriString).path ?: return@withContext null
            val srcBitmap = BitmapFactory.decodeFile(path) ?: return@withContext null

            // 1. Rotate
            val matrix = Matrix()
            if (rotationDegrees != 0f) {
                matrix.postRotate(rotationDegrees)
            }

            var transformed = Bitmap.createBitmap(srcBitmap, 0, 0, srcBitmap.width, srcBitmap.height, matrix, true)

            // 2. Crop if provided
            if (cropRect != null) {
                val cx = (cropRect.left * transformed.width).toInt().coerceIn(0, transformed.width - 1)
                val cy = (cropRect.top * transformed.height).toInt().coerceIn(0, transformed.height - 1)
                val cw = ((cropRect.width()) * transformed.width).toInt().coerceIn(1, transformed.width - cx)
                val ch = ((cropRect.height()) * transformed.height).toInt().coerceIn(1, transformed.height - cy)
                transformed = Bitmap.createBitmap(transformed, cx, cy, cw, ch)
            }

            // 3. Color matrix for LUT / grading
            val finalBitmap = Bitmap.createBitmap(transformed.width, transformed.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(finalBitmap)
            val paint = Paint()

            val cm = ColorMatrix()
            val totalContrast = contrastMultiplier * filmLook.contrast
            val totalSaturation = saturationMultiplier * filmLook.saturation
            cm.setSaturation(if (filmLook.isBw) 0f else totalSaturation)

            // Contrast & Exposure adjustments
            val scale = totalContrast
            val translate = (1.0f - scale) * 128f + (exposureOffset + filmLook.exposure) * 40f
            val contrastMatrix = ColorMatrix(
                floatArrayOf(
                    scale, 0f, 0f, 0f, translate,
                    0f, scale, 0f, 0f, translate,
                    0f, 0f, scale, 0f, translate,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            cm.postConcat(contrastMatrix)

            paint.colorFilter = ColorMatrixColorFilter(cm)
            canvas.drawBitmap(transformed, 0f, 0f, paint)

            val destDir = File(context.filesDir, "cinema_photos")
            if (!destDir.exists()) destDir.mkdirs()
            val fileName = "GRADE_${System.currentTimeMillis()}_${sourceItem.title}"
            val destFile = File(destDir, fileName)

            FileOutputStream(destFile).use { out ->
                finalBitmap.compress(Bitmap.CompressFormat.JPEG, 96, out)
            }

            val editedItem = MediaItem(
                id = UUID.randomUUID().toString(),
                title = fileName,
                uriString = Uri.fromFile(destFile).toString(),
                filePath = destFile.absolutePath,
                mimeType = "image/jpeg",
                isVideo = false,
                width = finalBitmap.width,
                height = finalBitmap.height,
                sizeBytes = destFile.length(),
                dateAdded = System.currentTimeMillis(),
                iso = sourceItem.iso,
                shutterSpeed = sourceItem.shutterSpeed,
                aperture = sourceItem.aperture,
                focalLength = sourceItem.focalLength,
                colorProfile = filmLook.name,
                album = "Color Graded"
            )
            dao.insertMedia(MediaEntity.fromModel(editedItem))
            editedItem
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Seeds initial cinematic sample assets so the user has immediate rich content
     * to inspect, preview, and test in the Media Vault and Video/Photo Editor.
     */
    suspend fun seedDemoCinemaAssetsIfEmpty() = withContext(Dispatchers.IO) {
        val count = dao.getMediaById("sample_cinema_1")
        if (count != null) return@withContext

        val dir = File(context.filesDir, "cinema_samples")
        if (!dir.exists()) dir.mkdirs()

        val sample1File = File(dir, "SCENE_01_ANAMORPHIC_SUNSET.jpg")
        if (!sample1File.exists()) {
            val bmp = Bitmap.createBitmap(1920, 800, Bitmap.Config.ARGB_8888).apply {
                eraseColor(android.graphics.Color.rgb(20, 24, 34))
            }
            FileOutputStream(sample1File).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        }

        val sample2File = File(dir, "SCENE_02_CYBERPUNK_NIGHT.jpg")
        if (!sample2File.exists()) {
            val bmp = Bitmap.createBitmap(1920, 1080, Bitmap.Config.ARGB_8888).apply {
                eraseColor(android.graphics.Color.rgb(15, 20, 28))
            }
            FileOutputStream(sample2File).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        }

        val samples = listOf(
            MediaItem(
                id = "sample_cinema_1",
                title = "A001_C004_GOLDEN_HOUR.RAW",
                uriString = Uri.fromFile(sample1File).toString(),
                filePath = sample1File.absolutePath,
                mimeType = "image/jpeg",
                isVideo = false,
                width = 1920,
                height = 800,
                sizeBytes = sample1File.length(),
                dateAdded = System.currentTimeMillis() - 3600000,
                iso = 800,
                shutterSpeed = "1/48s",
                aperture = "f/1.4",
                focalLength = "50mm Anamorphic",
                colorProfile = "Kodak Portra 400",
                isFavorite = true,
                album = "Production A"
            ),
            MediaItem(
                id = "sample_cinema_2",
                title = "A002_C012_NEON_ALLEY.MOV",
                uriString = Uri.fromFile(sample2File).toString(),
                filePath = sample2File.absolutePath,
                mimeType = "image/jpeg",
                isVideo = false,
                width = 1920,
                height = 1080,
                sizeBytes = sample2File.length(),
                dateAdded = System.currentTimeMillis() - 7200000,
                iso = 1600,
                shutterSpeed = "1/50s",
                aperture = "f/2.0",
                focalLength = "24mm Prime",
                colorProfile = "Teal & Orange",
                isFavorite = false,
                album = "Production A"
            )
        )

        dao.insertAll(samples.map { MediaEntity.fromModel(it) })
    }
}
