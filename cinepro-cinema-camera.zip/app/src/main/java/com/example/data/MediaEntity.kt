package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.MediaItem

@Entity(tableName = "cinema_media")
data class MediaEntity(
    @PrimaryKey val id: String,
    val title: String,
    val uriString: String,
    val filePath: String?,
    val mimeType: String,
    val isVideo: Boolean,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val dateAdded: Long,
    val iso: Int?,
    val shutterSpeed: String?,
    val aperture: String?,
    val focalLength: String?,
    val fps: Int?,
    val colorProfile: String?,
    val isFavorite: Boolean,
    val album: String
) {
    fun toModel(): MediaItem = MediaItem(
        id = id,
        title = title,
        uriString = uriString,
        filePath = filePath,
        mimeType = mimeType,
        isVideo = isVideo,
        durationMs = durationMs,
        width = width,
        height = height,
        sizeBytes = sizeBytes,
        dateAdded = dateAdded,
        iso = iso,
        shutterSpeed = shutterSpeed,
        aperture = aperture,
        focalLength = focalLength,
        fps = fps,
        colorProfile = colorProfile,
        isFavorite = isFavorite,
        album = album
    )

    companion object {
        fun fromModel(model: MediaItem): MediaEntity = MediaEntity(
            id = model.id,
            title = model.title,
            uriString = model.uriString,
            filePath = model.filePath,
            mimeType = model.mimeType,
            isVideo = model.isVideo,
            durationMs = model.durationMs,
            width = model.width,
            height = model.height,
            sizeBytes = model.sizeBytes,
            dateAdded = model.dateAdded,
            iso = model.iso,
            shutterSpeed = model.shutterSpeed,
            aperture = model.aperture,
            focalLength = model.focalLength,
            fps = model.fps,
            colorProfile = model.colorProfile,
            isFavorite = model.isFavorite,
            album = model.album
        )
    }
}
