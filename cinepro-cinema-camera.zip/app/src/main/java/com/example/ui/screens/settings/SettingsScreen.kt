package com.example.ui.screens.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CineAmber
import com.example.ui.theme.CineBlack
import com.example.ui.theme.CineCyan
import com.example.ui.theme.CineRed
import com.example.ui.theme.CineSurface
import com.example.ui.theme.CineSurfaceElevated

@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current

    var videoCodec by remember { mutableStateOf("H.264 (High Profile)") }
    var defaultRes by remember { mutableStateOf("1080p FHD (1920x1080)") }
    var defaultFps by remember { mutableStateOf("24 fps (Cinema Standard)") }
    var stabilizationEnabled by remember { mutableStateOf(true) }
    var antiFlicker by remember { mutableStateOf("60 Hz (NTSC)") }
    var photoFormat by remember { mutableStateOf("JPEG (High Quality)") }
    var audioSource by remember { mutableStateOf("Internal Stereo Mics") }
    var audioSampleRate by remember { mutableStateOf("48 kHz (Broadcast 24-bit)") }
    var vuMeterEnabled by remember { mutableStateOf(true) }
    var histogramEnabled by remember { mutableStateOf(true) }
    var gyroLevelEnabled by remember { mutableStateOf(true) }
    var showResetDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CineBlack,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CineSurface)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("settings_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }

                Text(
                    text = "CINEMA CAMERA CONFIGURATION",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                IconButton(
                    onClick = { showResetDialog = true },
                    modifier = Modifier.testTag("settings_reset_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset to Defaults", tint = CineAmber)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Video Engine
            SettingsSectionHeader(icon = Icons.Default.Videocam, title = "VIDEO RECORDING ENGINE")
            SettingsSelectRow(label = "Default Resolution", value = defaultRes) {
                defaultRes = if (defaultRes.contains("1080p")) "4K UHD (3840x2160)" else if (defaultRes.contains("4K")) "720p HD (1280x720)" else "1080p FHD (1920x1080)"
            }
            SettingsSelectRow(label = "Cinema Frame Rate", value = defaultFps) {
                defaultFps = if (defaultFps.contains("24")) "30 fps (Standard)" else if (defaultFps.contains("30")) "60 fps (Smooth)" else "24 fps (Cinema Standard)"
            }
            SettingsSelectRow(label = "Video Codec Profile", value = videoCodec) {
                videoCodec = if (videoCodec.contains("H.264")) "HEVC / H.265 (ProRes Look)" else "H.264 (High Profile)"
            }
            SettingsToggleRow(
                label = "EIS Video Stabilization",
                description = "Electronic gyro-assisted sensor smoothing",
                checked = stabilizationEnabled,
                onCheckedChange = { stabilizationEnabled = it }
            )

            // Optics & Exposure
            SettingsSectionHeader(icon = Icons.Default.CameraAlt, title = "OPTICS & EXPOSURE")
            SettingsSelectRow(label = "Anti-Flicker Frequency", value = antiFlicker) {
                antiFlicker = if (antiFlicker.contains("60")) "50 Hz (PAL / Euro)" else "60 Hz (NTSC)"
            }
            SettingsSelectRow(label = "Default Photo Format", value = photoFormat) {
                photoFormat = if (photoFormat.contains("JPEG")) "RAW / DNG 14-bit Uncompressed" else "JPEG (High Quality)"
            }

            // Audio & Monitoring
            SettingsSectionHeader(icon = Icons.Default.Audiotrack, title = "AUDIO TELEMETRY & VU")
            SettingsSelectRow(label = "Audio Input Channel", value = audioSource) {
                audioSource = if (audioSource.contains("Internal")) "External USB-C / 3.5mm Mic" else "Internal Stereo Mics"
            }
            SettingsSelectRow(label = "Sampling Rate", value = audioSampleRate) {
                audioSampleRate = if (audioSampleRate.contains("48")) "44.1 kHz (CD Audio)" else "48 kHz (Broadcast 24-bit)"
            }
            SettingsToggleRow(
                label = "Live Stereo VU Meters",
                description = "Display dBFS left/right volume bars",
                checked = vuMeterEnabled,
                onCheckedChange = { vuMeterEnabled = it }
            )

            // Viewfinder & Scopes
            SettingsSectionHeader(icon = Icons.Default.Visibility, title = "VIEWFINDER OVERLAYS")
            SettingsToggleRow(
                label = "Real-Time Histogram",
                description = "RGB + Luminance curve monitor",
                checked = histogramEnabled,
                onCheckedChange = { histogramEnabled = it }
            )
            SettingsToggleRow(
                label = "Artificial Horizon Level",
                description = "Gyro tilt & roll alignment indicator",
                checked = gyroLevelEnabled,
                onCheckedChange = { gyroLevelEnabled = it }
            )

            // Storage info
            SettingsSectionHeader(icon = Icons.Default.SdStorage, title = "STORAGE & VAULT")
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CineSurfaceElevated, RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFF2B3245), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Vault Directory", color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text(context.filesDir.absolutePath, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Format Support: MP4, MOV, MKV, WEBM, JPG, PNG, DNG RAW", color = CineCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset to Cinema Defaults?", color = Color.White, fontFamily = FontFamily.Monospace) },
            text = { Text("Restores standard 24fps 1080p Rec.709 settings.", color = Color(0xFF94A3B8)) },
            confirmButton = {
                Button(
                    onClick = {
                        videoCodec = "H.264 (High Profile)"
                        defaultRes = "1080p FHD (1920x1080)"
                        defaultFps = "24 fps (Cinema Standard)"
                        stabilizationEnabled = true
                        photoFormat = "JPEG (High Quality)"
                        audioSource = "Internal Stereo Mics"
                        vuMeterEnabled = true
                        histogramEnabled = true
                        gyroLevelEnabled = true
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CineAmber)
                ) {
                    Text("Reset", color = CineBlack)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = CineSurface
        )
    }
}

@Composable
private fun SettingsSectionHeader(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 8.dp)
    ) {
        Icon(icon, contentDescription = null, tint = CineAmber, modifier = Modifier.size(16.dp))
        Text(
            text = title,
            color = CineAmber,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun SettingsSelectRow(
    label: String,
    value: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CineSurfaceElevated, RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF2B3245), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = CineCyan, fontSize = 11.sp, fontWeight = FontWeight.Medium, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun SettingsToggleRow(
    label: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CineSurfaceElevated, RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF2B3245), RoundedCornerShape(8.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(text = label, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Text(text = description, color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CineAmber,
                checkedTrackColor = CineAmber.copy(alpha = 0.4f),
                uncheckedThumbColor = Color(0xFF94A3B8),
                uncheckedTrackColor = Color(0xFF1B202C)
            )
        )
    }
}
