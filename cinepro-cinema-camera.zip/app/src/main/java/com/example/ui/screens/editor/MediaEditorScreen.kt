package com.example.ui.screens.editor

import android.graphics.RectF
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.MediaRepository
import com.example.model.FilmLook
import com.example.model.MediaItem
import com.example.ui.theme.CineAmber
import com.example.ui.theme.CineBlack
import com.example.ui.theme.CineCyan
import com.example.ui.theme.CineGreen
import com.example.ui.theme.CineRed
import com.example.ui.theme.CineSurface
import com.example.ui.theme.CineSurfaceElevated
import kotlinx.coroutines.launch

@Composable
fun MediaEditorScreen(
    mediaId: String,
    repository: MediaRepository,
    onNavigateBack: () -> Unit,
    onSaved: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val scope = rememberCoroutineScope()

    var mediaItem by remember { mutableStateOf<MediaItem?>(null) }
    var isSaving by remember { mutableStateOf(false) }
    var saveSuccessMessage by remember { mutableStateOf<String?>(null) }

    // Editor tab: 0 -> Film Looks, 1 -> Adjustments, 2 -> Crop & Geometry (for photo) / Trimming & Speed (for video)
    var selectedTab by remember { mutableIntStateOf(0) }

    // Color Grading Parameters
    var selectedLook by remember { mutableStateOf(FilmLook.ALL_LOOKS.first()) }
    var exposure by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }

    // Photo geometry
    var rotationAngle by remember { mutableFloatStateOf(0f) }
    var selectedCropRatio by remember { mutableStateOf("ORIGINAL") } // ORIGINAL, 1:1, 16:9, 2.39:1

    // Video Trimming parameters
    var videoTrimRange by remember { mutableStateOf(0f..1f) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    LaunchedEffect(mediaId) {
        mediaItem = repository.getMediaById(mediaId)
    }

    val item = mediaItem

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CineBlack,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CineSurface)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("editor_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }

                Text(
                    text = if (item?.isVideo == true) "VIDEO GRADER & TRIMMER" else "CINEMA PHOTO EDITOR",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Button(
                    onClick = {
                        item?.let { src ->
                            isSaving = true
                            scope.launch {
                                val cropRect = when (selectedCropRatio) {
                                    "1:1" -> RectF(0.15f, 0.15f, 0.85f, 0.85f)
                                    "2.39:1" -> RectF(0f, 0.2f, 1f, 0.8f)
                                    "16:9" -> RectF(0f, 0.1f, 1f, 0.9f)
                                    else -> null
                                }

                                val saved = repository.editAndSavePhoto(
                                    sourceItem = src,
                                    rotationDegrees = rotationAngle,
                                    cropRect = cropRect,
                                    filmLook = selectedLook,
                                    exposureOffset = exposure,
                                    contrastMultiplier = contrast,
                                    saturationMultiplier = saturation
                                )
                                isSaving = false
                                if (saved != null) {
                                    onSaved(saved.id)
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CineAmber),
                    shape = RoundedCornerShape(8.dp),
                    enabled = !isSaving && item != null,
                    modifier = Modifier.testTag("editor_save_button")
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(color = CineBlack, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Text("SAVE COPY", color = CineBlack, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CineSurface)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // Editor Navigation Tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = CineAmber,
                            height = 2.dp
                        )
                    }
                ) {
                    val tabs = if (item?.isVideo == true) {
                        listOf("LOOKS", "GRADING", "TRIM & SPEED")
                    } else {
                        listOf("LOOKS", "GRADING", "CROP & ROTATE")
                    }
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    title,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == index) CineAmber else Color(0xFF94A3B8),
                                    fontFamily = FontFamily.Monospace
                                )
                            },
                            modifier = Modifier.testTag("editor_tab_$index")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                when (selectedTab) {
                    0 -> FilmLookSelectorRow(
                        selectedLook = selectedLook,
                        onSelectLook = { selectedLook = it }
                    )
                    1 -> ColorAdjustmentsControls(
                        exposure = exposure,
                        contrast = contrast,
                        saturation = saturation,
                        onExposureChange = { exposure = it },
                        onContrastChange = { contrast = it },
                        onSaturationChange = { saturation = it },
                        onReset = {
                            exposure = 0f
                            contrast = 1f
                            saturation = 1f
                        }
                    )
                    2 -> {
                        if (item?.isVideo == true) {
                            VideoTrimControls(
                                trimRange = videoTrimRange,
                                onTrimRangeChange = { videoTrimRange = it },
                                speed = playbackSpeed,
                                onSpeedChange = { playbackSpeed = it }
                            )
                        } else {
                            PhotoGeometryControls(
                                rotationAngle = rotationAngle,
                                onRotate = { rotationAngle = (rotationAngle + 90f) % 360f },
                                selectedRatio = selectedCropRatio,
                                onSelectRatio = { selectedCropRatio = it }
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            if (item != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Preview with rotation
                    AsyncImage(
                        model = item.filePath ?: item.uriString,
                        contentDescription = "Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(rotationAngle)
                    )

                    // Color Tint Preview Simulation
                    if (selectedLook.id != "rec709") {
                        val overlay = when (selectedLook.id) {
                            "teal_orange" -> Color(0x3300E5FF)
                            "kodak_portra" -> Color(0x33FFAA00)
                            "fuji_eterna" -> Color(0x2200FFCC)
                            "bw_tri_x" -> Color(0x66000000)
                            "moody_noir" -> Color(0x550B0D11)
                            "golden_hour" -> Color(0x44FF9800)
                            "nordic_cold" -> Color(0x334FC3F7)
                            else -> Color.Transparent
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(overlay)
                        )
                    }

                    // Crop guide box if aspect ratio is selected
                    if (selectedCropRatio != "ORIGINAL") {
                        Box(
                            modifier = Modifier
                                .size(240.dp)
                                .border(1.5.dp, CineAmber, RoundedCornerShape(4.dp))
                        ) {
                            Text(
                                selectedCropRatio,
                                color = CineAmber,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.align(Alignment.TopStart).padding(4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilmLookSelectorRow(
    selectedLook: FilmLook,
    onSelectLook: (FilmLook) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(FilmLook.ALL_LOOKS) { look ->
            val isSelected = selectedLook.id == look.id
            Column(
                modifier = Modifier
                    .width(88.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) Color(0xFF1B202C) else CineSurfaceElevated)
                    .border(
                        1.dp,
                        if (isSelected) CineAmber else Color(0xFF2B3245),
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onSelectLook(look) }
                    .padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(
                            when (look.id) {
                                "teal_orange" -> CineCyan
                                "kodak_portra" -> CineAmber
                                "bw_tri_x" -> Color.White
                                "moody_noir" -> Color(0xFF4B5563)
                                "golden_hour" -> Color(0xFFFF9800)
                                else -> CineGreen
                            },
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = CineBlack, modifier = Modifier.size(16.dp))
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = look.name,
                    color = if (isSelected) CineAmber else Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun ColorAdjustmentsControls(
    exposure: Float,
    contrast: Float,
    saturation: Float,
    onExposureChange: (Float) -> Unit,
    onContrastChange: (Float) -> Unit,
    onSaturationChange: (Float) -> Unit,
    onReset: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Exposure
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("EXPOSURE", fontSize = 9.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
            Text(String.format(java.util.Locale.US, "%+.1f EV", exposure), fontSize = 9.sp, color = CineAmber, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = exposure,
            onValueChange = onExposureChange,
            valueRange = -2f..2f,
            colors = SliderDefaults.colors(thumbColor = CineAmber, activeTrackColor = CineAmber),
            modifier = Modifier.height(24.dp)
        )

        // Contrast
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("CONTRAST", fontSize = 9.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
            Text(String.format(java.util.Locale.US, "%.2fx", contrast), fontSize = 9.sp, color = CineCyan, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = contrast,
            onValueChange = onContrastChange,
            valueRange = 0.5f..1.8f,
            colors = SliderDefaults.colors(thumbColor = CineCyan, activeTrackColor = CineCyan),
            modifier = Modifier.height(24.dp)
        )

        // Saturation
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("SATURATION", fontSize = 9.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
            Text(String.format(java.util.Locale.US, "%.2fx", saturation), fontSize = 9.sp, color = CineGreen, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = saturation,
            onValueChange = onSaturationChange,
            valueRange = 0f..2f,
            colors = SliderDefaults.colors(thumbColor = CineGreen, activeTrackColor = CineGreen),
            modifier = Modifier.height(24.dp)
        )
    }
}

@Composable
private fun PhotoGeometryControls(
    rotationAngle: Float,
    onRotate: () -> Unit,
    selectedRatio: String,
    onSelectRatio: (String) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ASPECT RATIO CROP", fontSize = 10.sp, color = CineAmber, fontFamily = FontFamily.Monospace)

            Button(
                onClick = onRotate,
                colors = ButtonDefaults.buttonColors(containerColor = CineSurfaceElevated),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(Icons.Default.RotateRight, contentDescription = "Rotate", tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("ROTATE 90°", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val ratios = listOf("ORIGINAL", "1:1", "16:9", "2.39:1")
            ratios.forEach { r ->
                val isSel = selectedRatio == r
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (isSel) CineAmber else CineSurfaceElevated, RoundedCornerShape(6.dp))
                        .clickable { onSelectRatio(r) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = r,
                        color = if (isSel) CineBlack else Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun VideoTrimControls(
    trimRange: ClosedFloatingPointRange<Float>,
    onTrimRangeChange: (ClosedFloatingPointRange<Float>) -> Unit,
    speed: Float,
    onSpeedChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("TIMELINE IN / OUT MARKERS", fontSize = 10.sp, color = CineAmber, fontFamily = FontFamily.Monospace)

        RangeSlider(
            value = trimRange,
            onValueChange = onTrimRangeChange,
            valueRange = 0f..1f,
            colors = SliderDefaults.colors(
                thumbColor = CineAmber,
                activeTrackColor = CineAmber,
                inactiveTrackColor = Color(0xFF2B3245)
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("PLAYBACK SPEED", fontSize = 10.sp, color = CineCyan, fontFamily = FontFamily.Monospace)

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0.5f, 1.0f, 1.5f, 2.0f).forEach { s ->
                    val isSel = speed == s
                    Box(
                        modifier = Modifier
                            .background(if (isSel) CineCyan else CineSurfaceElevated, RoundedCornerShape(4.dp))
                            .clickable { onSpeedChange(s) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "${s}x",
                            color = if (isSel) CineBlack else Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
