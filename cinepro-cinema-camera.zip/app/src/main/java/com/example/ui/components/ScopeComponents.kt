package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.AudioVUState
import com.example.camera.HorizonLevelState
import com.example.model.AspectRatioGuide
import com.example.model.GridType

/**
 * Blackmagic Cinema Histogram (as seen in reference image).
 * Labeled "Apple Log - HDR" with multi-channel RGB curves and vertical level meters.
 */
@Composable
fun CinemaHistogram(
    modifier: Modifier = Modifier,
    label: String = "Apple Log - HDR",
    isoVal: Int = 800,
    evVal: Float = 0f
) {
    Column(
        modifier = modifier
            .width(175.dp)
            .background(Color(0xD90B121C), RoundedCornerShape(6.dp))
            .border(1.dp, Color(0xFF26384D), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 4.dp)
            .testTag("cinema_histogram")
    ) {
        Text(
            text = label,
            color = Color(0xFFCBD5E1),
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.SansSerif,
            modifier = Modifier.padding(bottom = 3.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
        ) {
            // Main waveform canvas
            Canvas(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(Color(0xFF070B11), RoundedCornerShape(3.dp))
                    .border(0.5.dp, Color(0xFF1E293B), RoundedCornerShape(3.dp))
            ) {
                val w = size.width
                val h = size.height

                // Grid reference lines
                val gridColor = Color(0x22FFFFFF)
                drawLine(gridColor, Offset(0f, h * 0.25f), Offset(w, h * 0.25f), 1f)
                drawLine(gridColor, Offset(0f, h * 0.5f), Offset(w, h * 0.5f), 1f)
                drawLine(gridColor, Offset(0f, h * 0.75f), Offset(w, h * 0.75f), 1f)
                drawLine(gridColor, Offset(w * 0.33f, 0f), Offset(w * 0.33f, h), 1f)
                drawLine(gridColor, Offset(w * 0.66f, 0f), Offset(w * 0.66f, h), 1f)

                // White/Grey Luminance curve
                val pathLum = Path().apply {
                    moveTo(0f, h)
                    val steps = 30
                    for (i in 0..steps) {
                        val x = (i / steps.toFloat()) * w
                        val peak1 = kotlin.math.exp(-((x - w * 0.25f) / 18f) * ((x - w * 0.25f) / 18f))
                        val peak2 = kotlin.math.exp(-((x - w * 0.7f) / 28f) * ((x - w * 0.7f) / 28f))
                        val y = h - ((peak1 * 0.7f + peak2 * 0.85f) * (h * 0.88f)).toFloat().coerceIn(2f, h - 2f)
                        lineTo(x, y)
                    }
                    lineTo(w, h)
                    close()
                }
                drawPath(pathLum, Color(0x40FFFFFF))
                drawPath(pathLum, Color(0xCCFFFFFF), style = Stroke(1.2f))

                // Red channel curve
                val pathR = Path().apply {
                    moveTo(0f, h)
                    val steps = 24
                    for (i in 0..steps) {
                        val x = (i / steps.toFloat()) * w
                        val peak = kotlin.math.exp(-((x - w * 0.65f) / 24f) * ((x - w * 0.65f) / 24f))
                        val y = h - (peak * (h * 0.75f)).toFloat().coerceIn(2f, h - 2f)
                        lineTo(x, y)
                    }
                    lineTo(w, h)
                }
                drawPath(pathR, Color(0xFFFF334B), style = Stroke(1.2f))

                // Green channel curve
                val pathG = Path().apply {
                    moveTo(0f, h)
                    val steps = 24
                    for (i in 0..steps) {
                        val x = (i / steps.toFloat()) * w
                        val peak = kotlin.math.exp(-((x - w * 0.45f) / 30f) * ((x - w * 0.45f) / 30f))
                        val y = h - (peak * (h * 0.65f)).toFloat().coerceIn(2f, h - 2f)
                        lineTo(x, y)
                    }
                    lineTo(w, h)
                }
                drawPath(pathG, Color(0xFF00E676), style = Stroke(1.2f))

                // Blue channel curve
                val pathB = Path().apply {
                    moveTo(0f, h)
                    val steps = 24
                    for (i in 0..steps) {
                        val x = (i / steps.toFloat()) * w
                        val peak = kotlin.math.exp(-((x - w * 0.3f) / 20f) * ((x - w * 0.3f) / 20f))
                        val y = h - (peak * (h * 0.8f)).toFloat().coerceIn(2f, h - 2f)
                        lineTo(x, y)
                    }
                    lineTo(w, h)
                }
                drawPath(pathB, Color(0xFF00A3FF), style = Stroke(1.2f))
            }

            Spacer(modifier = Modifier.width(4.dp))

            // 4 Vertical level bars (as seen on right edge of scope in reference image)
            Row(
                modifier = Modifier
                    .width(18.dp)
                    .fillMaxHeight(),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                val heights = listOf(0.75f, 0.9f, 0.6f, 0.45f)
                val colors = listOf(Color(0xFF00A3FF), Color(0xFF00E676), Color(0xFFFF334B), Color(0xFFCBD5E1))
                for (i in 0..3) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(Color(0xFF070B11), RoundedCornerShape(1.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(heights[i])
                                .align(Alignment.BottomCenter)
                                .background(colors[i], RoundedCornerShape(1.dp))
                        )
                    }
                }
            }
        }
    }
}

/**
 * Calibrated Blackmagic Stereo Audio VU Meter with dB scale (matching reference image).
 * Scale: -45, -30, -20, -10, -6, -3, 0 dB
 */
@Composable
fun AudioVUMeter(
    vuState: AudioVUState,
    modifier: Modifier = Modifier,
    micLabel: String = "Micrófono iPhone"
) {
    Column(
        modifier = modifier
            .width(190.dp)
            .background(Color(0xD90B121C), RoundedCornerShape(6.dp))
            .border(1.dp, Color(0xFF26384D), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 5.dp)
            .testTag("audio_vu_meter")
    ) {
        Text(
            text = micLabel,
            color = Color(0xFFCBD5E1),
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.SansSerif,
            modifier = Modifier.padding(bottom = 3.dp)
        )

        // Channel 1 bar
        AudioChannelBar(channelNum = "1", dbfs = vuState.leftDbfs)

        Spacer(modifier = Modifier.height(2.dp))

        // Channel 2 bar
        AudioChannelBar(channelNum = "2", dbfs = vuState.rightDbfs)

        Spacer(modifier = Modifier.height(3.dp))

        // Calibrated tick labels: -45, -30, -20, -10, -6, -3, 0
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val ticks = listOf("-45", "-30", "-20", "-10", "-6", "-3", "0")
            ticks.forEach { t ->
                Text(
                    text = t,
                    color = Color(0xFF94A3B8),
                    fontSize = 7.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun AudioChannelBar(channelNum: String, dbfs: Float) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = channelNum,
            color = Color(0xFF94A3B8),
            fontSize = 7.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(10.dp)
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(Color(0xFF0F172A), RoundedCornerShape(2.dp))
        ) {
            // Fraction between -50dB and 0dB
            val fraction = ((dbfs + 50f) / 50f).coerceIn(0.05f, 1f)

            // Segmented colored bar: Green up to -10dB, Yellow to -3dB, Red to 0dB
            Canvas(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
            ) {
                val w = size.width
                val h = size.height

                // Green zone: 0 to 75% (-10dB)
                val greenEnd = w.coerceAtMost(size.width * 0.75f)
                drawRect(Color(0xFF00E676), Offset(0f, 0f), Size(greenEnd, h))

                // Yellow zone: 75% to 92% (-3dB)
                if (w > size.width * 0.75f) {
                    val yellowEnd = (w - size.width * 0.75f).coerceAtMost(size.width * 0.17f)
                    drawRect(Color(0xFFFFB300), Offset(size.width * 0.75f, 0f), Size(yellowEnd, h))
                }

                // Red zone: 92% to 100% (0dB)
                if (w > size.width * 0.92f) {
                    val redLen = w - size.width * 0.92f
                    drawRect(Color(0xFFFF2A3B), Offset(size.width * 0.92f, 0f), Size(redLen, h))
                }
            }
        }
    }
}

/**
 * Artificial Horizon Level meter.
 */
@Composable
fun HorizonLevelOverlay(
    levelState: HorizonLevelState,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val lineLen = 120f

        val color = if (levelState.isLevel) Color(0xFF00E676) else Color(0xCCFFFFFF)

        // Center reticle circle
        drawCircle(color = color, radius = 3.5f, center = Offset(cx, cy))
        drawCircle(color = color.copy(alpha = 0.4f), radius = 16f, center = Offset(cx, cy), style = Stroke(1.2f))

        // Horizon line
        val angleRad = Math.toRadians(levelState.rollDegrees.toDouble())
        val cosA = kotlin.math.cos(angleRad).toFloat()
        val sinA = kotlin.math.sin(angleRad).toFloat()

        val p1 = Offset(cx - cosA * lineLen, cy - sinA * lineLen)
        val p2 = Offset(cx + cosA * lineLen, cy + sinA * lineLen)
        drawLine(color = color, start = p1, end = p2, strokeWidth = 2f)
    }
}

/**
 * Composition framing guides.
 */
@Composable
fun FramingGridOverlay(
    gridType: GridType,
    modifier: Modifier = Modifier
) {
    if (gridType == GridType.NONE) return

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val color = Color(0x55FFFFFF)

        when (gridType) {
            GridType.RULE_OF_THIRDS -> {
                drawLine(color, Offset(w / 3f, 0f), Offset(w / 3f, h), 1f)
                drawLine(color, Offset(2 * w / 3f, 0f), Offset(2 * w / 3f, h), 1f)
                drawLine(color, Offset(0f, h / 3f), Offset(w, h / 3f), 1f)
                drawLine(color, Offset(0f, 2 * h / 3f), Offset(w, 2 * h / 3f), 1f)
            }
            GridType.GOLDEN_RATIO -> {
                val phi = 0.618f
                drawLine(color, Offset(w * (1f - phi), 0f), Offset(w * (1f - phi), h), 1f)
                drawLine(color, Offset(w * phi, 0f), Offset(w * phi, h), 1f)
                drawLine(color, Offset(0f, h * (1f - phi)), Offset(w, h * (1f - phi)), 1f)
                drawLine(color, Offset(0f, h * phi), Offset(w, h * phi), 1f)
            }
            GridType.CROSSHAIR -> {
                val cx = w / 2f
                val cy = h / 2f
                drawLine(color, Offset(cx - 30f, cy), Offset(cx + 30f, cy), 1.2f)
                drawLine(color, Offset(cx, cy - 30f), Offset(cx, cy + 30f), 1.2f)
            }
            GridType.DOT -> {
                drawCircle(color = Color(0xFF00A3FF), radius = 4f, center = Offset(w / 2f, h / 2f))
            }
            GridType.NONE -> {}
        }
    }
}

/**
 * Cinematic Aspect Ratio Mask Overlay.
 */
@Composable
fun AspectRatioMaskOverlay(
    guide: AspectRatioGuide,
    modifier: Modifier = Modifier
) {
    if (guide == AspectRatioGuide.OFF || guide.ratio <= 0f) return

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val currentRatio = w / h
        val targetRatio = guide.ratio

        val maskColor = Color(0xDD000000)
        val guideBorderColor = Color(0xAA00A3FF)

        if (targetRatio > currentRatio) {
            val targetHeight = w / targetRatio
            val barHeight = (h - targetHeight) / 2f
            if (barHeight > 0f) {
                drawRect(maskColor, Offset(0f, 0f), Size(w, barHeight))
                drawRect(maskColor, Offset(0f, h - barHeight), Size(w, barHeight))
                drawLine(guideBorderColor, Offset(0f, barHeight), Offset(w, barHeight), 1.5f)
                drawLine(guideBorderColor, Offset(0f, h - barHeight), Offset(w, h - barHeight), 1.5f)
            }
        } else {
            val targetWidth = h * targetRatio
            val barWidth = (w - targetWidth) / 2f
            if (barWidth > 0f) {
                drawRect(maskColor, Offset(0f, 0f), Size(barWidth, h))
                drawRect(maskColor, Offset(w - barWidth, 0f), Size(barWidth, h))
                drawLine(guideBorderColor, Offset(barWidth, 0f), Offset(barWidth, h), 1.5f)
                drawLine(guideBorderColor, Offset(w - barWidth, 0f), Offset(w - barWidth, h), 1.5f)
            }
        }
    }
}
