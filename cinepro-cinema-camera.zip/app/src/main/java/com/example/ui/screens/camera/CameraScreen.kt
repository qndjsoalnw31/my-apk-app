package com.example.ui.screens.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.camera.AudioMeterTracker
import com.example.camera.CameraManagerHelper
import com.example.camera.OrientationSensorTracker
import com.example.data.MediaRepository
import com.example.model.AspectRatioGuide
import com.example.model.CaptureMode
import com.example.model.FilmLook
import com.example.model.FpsOption
import com.example.model.GridType
import com.example.model.IsoValue
import com.example.model.MediaItem
import com.example.model.ResolutionOption
import com.example.model.ShutterSpeed
import com.example.model.WhiteBalancePreset
import com.example.ui.components.CinemaHUD
import com.example.ui.theme.CineAmber
import com.example.ui.theme.CineGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@SuppressLint("MissingPermission")
@Composable
fun CameraScreen(
    repository: MediaRepository,
    onNavigateToGallery: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    // Permission states
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasCameraPermission = permissions[Manifest.permission.CAMERA] ?: hasCameraPermission
        hasAudioPermission = permissions[Manifest.permission.RECORD_AUDIO] ?: hasAudioPermission
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission || !hasAudioPermission) {
            permissionLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    // Audio and Sensor Trackers
    val audioTracker = remember { AudioMeterTracker(scope) }
    val sensorTracker = remember { OrientationSensorTracker(context) }
    val cameraManager = remember {
        CameraManagerHelper(context, lifecycleOwner, scope, repository)
    }

    DisposableEffect(Unit) {
        sensorTracker.start()
        audioTracker.startMonitoring(hasAudioPermission)
        onDispose {
            sensorTracker.stop()
            audioTracker.stopMonitoring()
            cameraManager.release()
        }
    }

    // Telemetry & Sensor States
    val telemetry by cameraManager.telemetry.collectAsState()
    val vuState by audioTracker.vuState.collectAsState()
    val levelState by sensorTracker.levelState.collectAsState()

    // Camera parameters
    var captureMode by remember { mutableStateOf(CaptureMode.VIDEO) }
    var resolution by remember { mutableStateOf(ResolutionOption.RES_1080P) }
    var fps by remember { mutableStateOf(FpsOption.FPS_24) }
    var shutter by remember { mutableStateOf(ShutterSpeed.S_1_50) }
    var iso by remember { mutableStateOf(IsoValue.ISO_400) }
    var whiteBalance by remember { mutableStateOf(WhiteBalancePreset.DAYLIGHT) }
    var activeLook by remember { mutableStateOf(FilmLook.ALL_LOOKS.first()) }
    var gridType by remember { mutableStateOf(GridType.RULE_OF_THIRDS) }
    var aspectGuide by remember { mutableStateOf(AspectRatioGuide.SCOPE_2_39) }

    var showScopes by remember { mutableStateOf(true) }
    var showLevel by remember { mutableStateOf(true) }
    var isCleanFeed by remember { mutableStateOf(false) }

    // Tap to focus reticle
    var focusTapOffset by remember { mutableStateOf<IntOffset?>(null) }
    var isFocusing by remember { mutableStateOf(false) }

    // Latest media item for vault thumbnail
    val allMedia by repository.allMedia.collectAsState(initial = emptyList())
    val latestMedia = allMedia.firstOrNull()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        focusTapOffset = IntOffset(offset.x.toInt(), offset.y.toInt())
                        isFocusing = true
                        cameraManager.tapToFocus(offset.x / size.width.toFloat(), offset.y / size.height.toFloat())
                        scope.launch {
                            delay(1500)
                            isFocusing = false
                            focusTapOffset = null
                        }
                    }
                )
            }
            .testTag("camera_viewfinder_root")
    ) {
        // 1. Live Camera Preview
        if (hasCameraPermission) {
            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        cameraManager.bindToPreviewView(this, true)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Dark professional standby screen
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0A0E17)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "CAMERA STANDBY",
                    color = Color(0xFF64748B),
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                )
            }
        }

        // Tap to focus reticle
        focusTapOffset?.let { offset ->
            FocusReticle(
                offset = offset,
                isFocusing = isFocusing
            )
        }

        // 2. Cinema HUD
        CinemaHUD(
            telemetry = telemetry,
            vuState = vuState,
            levelState = levelState,
            captureMode = captureMode,
            resolution = resolution,
            fps = fps,
            shutter = shutter,
            iso = iso,
            whiteBalance = whiteBalance,
            activeLook = activeLook,
            gridType = gridType,
            aspectGuide = aspectGuide,
            latestMedia = latestMedia,
            showScopes = showScopes,
            showLevel = showLevel,
            isCleanFeed = isCleanFeed,
            onModeChange = { mode ->
                captureMode = mode
                cameraManager.setCaptureMode(mode)
            },
            onLensChange = { lens -> cameraManager.setLens(lens) },
            onResolutionChange = { res ->
                resolution = res
                cameraManager.setResolution(res)
            },
            onFpsChange = { f ->
                fps = f
                cameraManager.setFps(f)
            },
            onShutterChange = { s ->
                shutter = s
                cameraManager.setShutterSpeed(s)
            },
            onIsoChange = { i ->
                iso = i
                cameraManager.setIso(i)
            },
            onWhiteBalanceChange = { wb ->
                whiteBalance = wb
                cameraManager.setWhiteBalance(wb)
            },
            onLookChange = { look ->
                activeLook = look
                cameraManager.setFilmLook(look)
            },
            onEvChange = { ev -> cameraManager.setExposureCompensation(ev) },
            onFocusDistanceChange = { d -> cameraManager.setFocusDistance(d) },
            onToggleTorch = { cameraManager.toggleTorch() },
            onToggleScopes = { showScopes = !showScopes },
            onToggleLevel = { showLevel = !showLevel },
            onToggleCleanFeed = { isCleanFeed = !isCleanFeed },
            onCycleGrid = {
                gridType = when (gridType) {
                    GridType.NONE -> GridType.RULE_OF_THIRDS
                    GridType.RULE_OF_THIRDS -> GridType.GOLDEN_RATIO
                    GridType.GOLDEN_RATIO -> GridType.CROSSHAIR
                    GridType.CROSSHAIR -> GridType.DOT
                    GridType.DOT -> GridType.NONE
                }
            },
            onCycleAspectGuide = {
                aspectGuide = when (aspectGuide) {
                    AspectRatioGuide.OFF -> AspectRatioGuide.SCOPE_2_39
                    AspectRatioGuide.SCOPE_2_39 -> AspectRatioGuide.ACADEMY_1_85
                    AspectRatioGuide.ACADEMY_1_85 -> AspectRatioGuide.RATIO_16_9
                    AspectRatioGuide.RATIO_16_9 -> AspectRatioGuide.RATIO_4_3
                    AspectRatioGuide.RATIO_4_3 -> AspectRatioGuide.RATIO_1_1
                    AspectRatioGuide.RATIO_1_1 -> AspectRatioGuide.RATIO_9_16
                    AspectRatioGuide.RATIO_9_16 -> AspectRatioGuide.OFF
                }
            },
            onRecordOrShutterClick = {
                if (captureMode.isVideo) {
                    if (telemetry.isRecording) {
                        cameraManager.stopVideoRecording()
                    } else {
                        cameraManager.startVideoRecording(hasAudioPermission) {}
                    }
                } else {
                    cameraManager.takePhoto {}
                }
            },
            onPauseResumeClick = {
                if (telemetry.isPaused) {
                    cameraManager.resumeVideoRecording()
                } else {
                    cameraManager.pauseVideoRecording()
                }
            },
            onOpenGallery = onNavigateToGallery,
            onOpenSettings = onNavigateToSettings
        )
    }
}

@Composable
private fun FocusReticle(
    offset: IntOffset,
    isFocusing: Boolean
) {
    Box(
        modifier = Modifier
            .offset { IntOffset(offset.x - 30, offset.y - 30) }
            .size(60.dp)
            .border(
                1.5.dp,
                if (isFocusing) CineGreen else CineAmber,
                RoundedCornerShape(4.dp)
            )
            .testTag("focus_reticle")
    )
}


