package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Cinema Dark Palette
val CineBlack = Color(0xFF090A0E)
val CineSurface = Color(0xFF13161F)
val CineSurfaceElevated = Color(0xFF1B202C)
val CineSurfaceBorder = Color(0xFF2B3245)

val CineRed = Color(0xFFFF2A3B)
val CineRedGlow = Color(0x66FF2A3B)
val CineAmber = Color(0xFFFFB300)
val CineCyan = Color(0xFF00E5FF)
val CineGreen = Color(0xFF10B981)

val CineTextPrimary = Color(0xFFF1F5F9)
val CineTextSecondary = Color(0xFF94A3B8)
val CineTextMuted = Color(0xFF64748B)

val CineOverlay = Color(0xAA090A0E)
val CineOverlayLight = Color(0x55090A0E)
