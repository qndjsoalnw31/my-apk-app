package com.example.ui.screens.viewer

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.data.MediaRepository
import com.example.model.MediaItem
import com.example.ui.theme.CineAmber
import com.example.ui.theme.CineBlack
import com.example.ui.theme.CineCyan
import com.example.ui.theme.CineGreen
import com.example.ui.theme.CineRed
import com.example.ui.theme.CineSurface
import com.example.ui.theme.CineSurfaceElevated
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaViewerScreen(
    mediaId: String,
    repository: MediaRepository,
    onNavigateBack: () -> Unit,
    onNavigateToEditor: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var mediaItem by remember { mutableStateOf<MediaItem?>(null) }
    var showInspectorSheet by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var frameExtractedMessage by remember { mutableStateOf<String?>(null) }

    // Video Player state
    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableIntStateOf(0) }
    var videoDurationMs by remember { mutableIntStateOf(0) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }

    LaunchedEffect(mediaId) {
        mediaItem = repository.getMediaById(mediaId)
    }

    // Polling player progress
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            videoViewRef?.let { vv ->
                currentPositionMs = vv.currentPosition
                if (!vv.isPlaying && currentPositionMs >= videoDurationMs - 100) {
                    isPlaying = false
                }
            }
            delay(100)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            videoViewRef?.stopPlayback()
        }
    }

    val item = mediaItem

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CineBlack,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xCC090A0E))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("viewer_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }

                Column(
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = item?.title ?: "CINEMA MEDIA",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1
                    )
                    Text(
                        text = "${item?.extension} • ${item?.resolutionLabel} • ${item?.colorProfile}",
                        color = CineAmber,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row {
                    IconButton(
                        onClick = {
                            item?.let {
                                scope.launch {
                                    repository.toggleFavorite(it.id, !it.isFavorite)
                                    mediaItem = it.copy(isFavorite = !it.isFavorite)
                                }
                            }
                        },
                        modifier = Modifier.testTag("viewer_fav_button")
                    ) {
                        Icon(
                            imageVector = if (item?.isFavorite == true) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (item?.isFavorite == true) CineAmber else Color.White
                        )
                    }

                    IconButton(
                        onClick = { showInspectorSheet = true },
                        modifier = Modifier.testTag("viewer_inspect_button")
                    ) {
                        Icon(Icons.Default.Info, contentDescription = "Inspector", tint = CineCyan)
                    }
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xEE090A0E))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // Video Playback Controls (if Video)
                if (item?.isVideo == true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatTimecode(currentPositionMs),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Slider(
                            value = currentPositionMs.toFloat(),
                            onValueChange = { pos ->
                                currentPositionMs = pos.toInt()
                                videoViewRef?.seekTo(pos.toInt())
                            },
                            valueRange = 0f..(videoDurationMs.toFloat().coerceAtLeast(1f)),
                            colors = SliderDefaults.colors(
                                thumbColor = CineAmber,
                                activeTrackColor = CineAmber,
                                inactiveTrackColor = Color(0xFF2B3245)
                            ),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                        )

                        Text(
                            text = formatTimecode(videoDurationMs),
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (item?.isVideo == true) {
                        // Play/Pause
                        IconButton(
                            onClick = {
                                videoViewRef?.let { vv ->
                                    if (isPlaying) {
                                        vv.pause()
                                        isPlaying = false
                                    } else {
                                        vv.start()
                                        isPlaying = true
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .background(CineAmber, CircleShape)
                                .testTag("viewer_play_pause")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = CineBlack
                            )
                        }

                        // Extract Still Frame
                        Button(
                            onClick = {
                                item.let { v ->
                                    scope.launch {
                                        val frame = repository.extractFrame(v, currentPositionMs.toLong())
                                        if (frame != null) {
                                            frameExtractedMessage = "Extracted still frame to Vault!"
                                        }
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CineSurfaceElevated),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("extract_frame_button")
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = CineCyan, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("GRAB FRAME", color = CineCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    // Edit
                    Button(
                        onClick = { item?.let { onNavigateToEditor(it.id) } },
                        colors = ButtonDefaults.buttonColors(containerColor = CineAmber),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("viewer_edit_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, tint = CineBlack, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("GRADE & EDIT", color = CineBlack, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    // Share
                    IconButton(
                        onClick = {
                            item?.let {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = it.mimeType
                                    it.filePath?.let { path ->
                                        putExtra(Intent.EXTRA_STREAM, Uri.fromFile(File(path)))
                                    } ?: putExtra(Intent.EXTRA_STREAM, Uri.parse(it.uriString))
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Cinema Asset"))
                            }
                        },
                        modifier = Modifier.testTag("viewer_share_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                    }

                    // Delete
                    IconButton(
                        onClick = { showDeleteDialog = true },
                        modifier = Modifier.testTag("viewer_delete_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CineRed)
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            if (item == null) {
                Text("LOADING ASSET...", color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
            } else if (item.isVideo) {
                // Video Player
                AndroidView(
                    factory = { ctx ->
                        VideoView(ctx).apply {
                            val uri = item.filePath?.let { Uri.fromFile(File(it)) } ?: Uri.parse(item.uriString)
                            setVideoURI(uri)
                            setOnPreparedListener { mp ->
                                videoDurationMs = mp.duration
                                mp.isLooping = true
                            }
                            setOnCompletionListener {
                                isPlaying = false
                            }
                            videoViewRef = this
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // Photo Viewer
                AsyncImage(
                    model = item.filePath ?: item.uriString,
                    contentDescription = item.title,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Banner notification if frame extracted
            frameExtractedMessage?.let { msg ->
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 16.dp)
                        .background(CineGreen, RoundedCornerShape(8.dp))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(msg, color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                LaunchedEffect(msg) {
                    delay(2500)
                    frameExtractedMessage = null
                }
            }
        }
    }

    // Technical Metadata Inspector Sheet
    if (showInspectorSheet && item != null) {
        ModalBottomSheet(
            onDismissRequest = { showInspectorSheet = false },
            sheetState = rememberModalBottomSheetState(),
            containerColor = CineSurface,
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TECHNICAL METADATA INSPECTOR",
                        color = CineAmber,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Box(
                        modifier = Modifier
                            .background(CineCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(item.extension, color = CineCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                MetaRow("File Name", item.title)
                MetaRow("Resolution", "${item.width} x ${item.height} (${item.resolutionLabel})")
                MetaRow("Format / Codec", item.mimeType)
                if (item.isVideo) {
                    MetaRow("Duration", item.formattedDuration)
                    MetaRow("Frame Rate", "${item.fps ?: 24} fps")
                }
                MetaRow("File Size", item.formattedSize)
                MetaRow("Capture Date", item.formattedDate)
                MetaRow("Color Space / Look", item.colorProfile ?: "Rec. 709")
                MetaRow("ISO Sensitivity", item.iso?.let { "ISO $it" } ?: "ISO 400")
                MetaRow("Shutter Speed", item.shutterSpeed ?: "1/50s")
                MetaRow("Aperture", item.aperture ?: "f/1.8")
                MetaRow("Focal Length", item.focalLength ?: "24mm Prime")
                MetaRow("Album", item.album)
                MetaRow("Local Path", item.filePath ?: item.uriString)

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Delete confirmation dialog
    if (showDeleteDialog && item != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Cinema Asset?", color = Color.White, fontFamily = FontFamily.Monospace) },
            text = { Text("Are you sure you want to permanently delete \"${item.title}\"?", color = Color(0xFF94A3B8)) },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            repository.deleteMedia(item)
                            showDeleteDialog = false
                            onNavigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CineRed)
                ) {
                    Text("Delete", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = CineSurface
        )
    }
}

@Composable
private fun MetaRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = Color(0xFF94A3B8), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Text(
            text = value,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}

private fun formatTimecode(millis: Int): String {
    val totalSecs = millis / 1000
    val m = totalSecs / 60
    val s = totalSecs % 60
    val f = (millis % 1000) / 40
    return String.format(java.util.Locale.US, "%02d:%02d:%02d", m, s, f)
}
