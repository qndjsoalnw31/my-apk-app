package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CinemaColorScheme = darkColorScheme(
    primary = CineRed,
    onPrimary = CineTextPrimary,
    primaryContainer = CineSurfaceElevated,
    onPrimaryContainer = CineTextPrimary,
    secondary = CineAmber,
    onSecondary = CineBlack,
    secondaryContainer = CineSurfaceElevated,
    onSecondaryContainer = CineAmber,
    tertiary = CineCyan,
    onTertiary = CineBlack,
    background = CineBlack,
    onBackground = CineTextPrimary,
    surface = CineSurface,
    onSurface = CineTextPrimary,
    surfaceVariant = CineSurfaceElevated,
    onSurfaceVariant = CineTextSecondary,
    outline = CineSurfaceBorder
)

@Composable
fun CineProTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CinemaColorScheme,
        typography = Typography,
        content = content
    )
}
