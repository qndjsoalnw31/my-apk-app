package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.FilterCenterFocus
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.camera.AudioVUState
import com.example.camera.CameraTelemetry
import com.example.camera.HorizonLevelState
import com.example.model.AspectRatioGuide
import com.example.model.CaptureMode
import com.example.model.FilmLook
import com.example.model.FpsOption
import com.example.model.GridType
import com.example.model.IsoValue
import com.example.model.LensType
import com.example.model.MediaItem
import com.example.model.ResolutionOption
import com.example.model.ShutterSpeed
import com.example.model.WhiteBalancePreset

// Exact Blackmagic Cinema palette from reference image
val BMBlue = Color(0xFF00A3FF)
val BMDarkGlass = Color(0xE60A111A)
val BMBorder = Color(0xFF1E2D40)
val BMTextMuted = Color(0xFF94A3B8)
val BMTextWhite = Color(0xFFF8FAFC)
val BMRecordRed = Color(0xFFFF2A3B)

@Composable
fun CinemaHUD(
    telemetry: CameraTelemetry,
    vuState: AudioVUState,
    levelState: HorizonLevelState,
    captureMode: CaptureMode,
    resolution: ResolutionOption,
    fps: FpsOption,
    shutter: ShutterSpeed,
    iso: IsoValue,
    whiteBalance: WhiteBalancePreset,
    activeLook: FilmLook,
    gridType: GridType,
    aspectGuide: AspectRatioGuide,
    latestMedia: MediaItem?,
    showScopes: Boolean,
    showLevel: Boolean,
    isCleanFeed: Boolean,
    onModeChange: (CaptureMode) -> Unit,
    onLensChange: (LensType) -> Unit,
    onResolutionChange: (ResolutionOption) -> Unit,
    onFpsChange: (FpsOption) -> Unit,
    onShutterChange: (ShutterSpeed) -> Unit,
    onIsoChange: (IsoValue) -> Unit,
    onWhiteBalanceChange: (WhiteBalancePreset) -> Unit,
    onLookChange: (FilmLook) -> Unit,
    onEvChange: (Float) -> Unit,
    onFocusDistanceChange: (Float) -> Unit,
    onToggleTorch: () -> Unit,
    onToggleScopes: () -> Unit,
    onToggleLevel: () -> Unit,
    onToggleCleanFeed: () -> Unit,
    onCycleGrid: () -> Unit,
    onCycleAspectGuide: () -> Unit,
    onRecordOrShutterClick: () -> Unit,
    onPauseResumeClick: () -> Unit,
    onOpenGallery: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showFpsDialog by remember { mutableStateOf(false) }
    var showResDialog by remember { mutableStateOf(false) }
    var showShutterDialog by remember { mutableStateOf(false) }
    var showIsoDialog by remember { mutableStateOf(false) }
    var showWbDialog by remember { mutableStateOf(false) }
    var showLooksDialog by remember { mutableStateOf(false) }
    var activeFocalLength by remember { mutableStateOf("48mm") }
    var activeZoomFactor by remember { mutableStateOf("2x") }

    // Pulsing tally animation during recording
    val infiniteTransition = rememberInfiniteTransition(label = "rec_tally")
    val tallyAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(animation = tween(500), repeatMode = RepeatMode.Reverse),
        label = "tally_pulse"
    )

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isLandscape = maxWidth > maxHeight

        // Grids & Aspect guides
        FramingGridOverlay(gridType = gridType)
        AspectRatioMaskOverlay(guide = aspectGuide)

        if (showLevel && !isCleanFeed) {
            HorizonLevelOverlay(levelState = levelState)
        }

        // Clean feed toggle icon (subtle, bottom left)
        IconButton(
            onClick = onToggleCleanFeed,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 12.dp, bottom = 12.dp)
                .size(32.dp)
                .background(Color(0x99000000), CircleShape)
                .testTag("toggle_clean_feed")
        ) {
            Icon(
                imageVector = if (isCleanFeed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                contentDescription = "Clean Feed",
                tint = if (isCleanFeed) BMBlue else Color.White,
                modifier = Modifier.size(18.dp)
            )
        }

        if (!isCleanFeed) {
            // TOP TELEMETRY RIBBON (Exact Blackmagic Cinema style)
            BlackmagicTopRibbon(
                telemetry = telemetry,
                fps = fps,
                shutter = shutter,
                iso = iso,
                whiteBalance = whiteBalance,
                focalLength = activeFocalLength,
                isLandscape = isLandscape,
                onOpenFps = { showFpsDialog = true },
                onOpenShutter = { showShutterDialog = true },
                onOpenIso = { showIsoDialog = true },
                onOpenWb = { showWbDialog = true },
                modifier = Modifier.align(Alignment.TopCenter)
            )

            // BOTTOM SCOPES: Histogram (Left) & Audio VU (Right)
            if (showScopes) {
                if (isLandscape) {
                    // In landscape: Positioned at bottom-left and bottom-right
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 16.dp, bottom = 16.dp)
                    ) {
                        CinemaHistogram(
                            label = "${activeLook.name} - HDR",
                            isoVal = iso.value,
                            evVal = telemetry.currentEv
                        )
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 16.dp)
                    ) {
                        AudioVUMeter(vuState = vuState, micLabel = "Micrófono iPhone")
                    }
                } else {
                    // In portrait: Neatly stack scopes above the controls
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 8.dp, bottom = 130.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CinemaHistogram(
                            label = "Rec.709 - Log",
                            isoVal = iso.value,
                            evVal = telemetry.currentEv
                        )
                        AudioVUMeter(vuState = vuState, micLabel = "Micrófono Estéreo")
                    }
                }
            }

            // RIGHT CONTROLS: Lens wheel + Action Toolbar
            if (isLandscape) {
                Row(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Column 1: Lens / Zoom wheel
                    BlackmagicZoomWheel(
                        activeZoom = activeZoomFactor,
                        activeFocal = activeFocalLength,
                        onSelectZoom = { z, f, lens ->
                            activeZoomFactor = z
                            activeFocalLength = f
                            onLensChange(lens)
                        },
                        onCycleGrid = onCycleGrid,
                        onCycleAspect = onCycleAspectGuide
                    )

                    // Column 2: Right Action Toolbar
                    BlackmagicActionToolbar(
                        telemetry = telemetry,
                        captureMode = captureMode,
                        onRecordOrShutterClick = onRecordOrShutterClick,
                        onPauseResumeClick = onPauseResumeClick,
                        onToggleScopes = onToggleScopes,
                        onToggleLevel = onToggleLevel,
                        onOpenLooks = { showLooksDialog = true },
                        onModeChange = onModeChange,
                        onOpenGallery = onOpenGallery,
                        onOpenSettings = onOpenSettings
                    )
                }
            } else {
                // In Portrait: Arrange controls neatly along the bottom and right
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 8.dp, bottom = 16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BlackmagicZoomWheel(
                            activeZoom = activeZoomFactor,
                            activeFocal = activeFocalLength,
                            onSelectZoom = { z, f, lens ->
                                activeZoomFactor = z
                                activeFocalLength = f
                                onLensChange(lens)
                            },
                            onCycleGrid = onCycleGrid,
                            onCycleAspect = onCycleAspectGuide,
                            compact = true
                        )
                        BlackmagicActionToolbar(
                            telemetry = telemetry,
                            captureMode = captureMode,
                            onRecordOrShutterClick = onRecordOrShutterClick,
                            onPauseResumeClick = onPauseResumeClick,
                            onToggleScopes = onToggleScopes,
                            onToggleLevel = onToggleLevel,
                            onOpenLooks = { showLooksDialog = true },
                            onModeChange = onModeChange,
                            onOpenGallery = onOpenGallery,
                            onOpenSettings = onOpenSettings,
                            compact = true
                        )
                    }
                }
            }
        }
    }

    // Pickers Dialogs
    if (showFpsDialog) {
        OptionPickerDialog(
            title = "FRAME RATE (F/S)",
            options = FpsOption.entries,
            selected = fps,
            onSelect = { onFpsChange(it); showFpsDialog = false },
            onDismiss = { showFpsDialog = false }
        ) { it.label }
    }

    if (showShutterDialog) {
        OptionPickerDialog(
            title = "SHUTTER SPEED (OBT.)",
            options = ShutterSpeed.entries,
            selected = shutter,
            onSelect = { onShutterChange(it); showShutterDialog = false },
            onDismiss = { showShutterDialog = false }
        ) { it.label }
    }

    if (showIsoDialog) {
        OptionPickerDialog(
            title = "ISO SENSITIVITY",
            options = IsoValue.entries,
            selected = iso,
            onSelect = { onIsoChange(it); showIsoDialog = false },
            onDismiss = { showIsoDialog = false }
        ) { if (it == IsoValue.AUTO) "AUTO" else "ISO ${it.label}" }
    }

    if (showWbDialog) {
        OptionPickerDialog(
            title = "WHITE BALANCE (BAL. B.)",
            options = WhiteBalancePreset.entries,
            selected = whiteBalance,
            onSelect = { onWhiteBalanceChange(it); showWbDialog = false },
            onDismiss = { showWbDialog = false }
        ) { it.label }
    }

    if (showLooksDialog) {
        OptionPickerDialog(
            title = "FILM LOOK / LUT",
            options = FilmLook.ALL_LOOKS,
            selected = activeLook,
            onSelect = { onLookChange(it); showLooksDialog = false },
            onDismiss = { showLooksDialog = false }
        ) { "${it.name} - ${it.description}" }
    }
}

/**
 * Top Telemetry Ribbon matching reference image:
 * [OBJ. 48mm] [F/S 30] [OBT. 1/120] [AP. f1.8]   [Short Films] 00:00:04:12   [ISO 800] [BAL. B. 5600K] [TIN. -10]
 */
@Composable
private fun BlackmagicTopRibbon(
    telemetry: CameraTelemetry,
    fps: FpsOption,
    shutter: ShutterSpeed,
    iso: IsoValue,
    whiteBalance: WhiteBalancePreset,
    focalLength: String,
    isLandscape: Boolean,
    onOpenFps: () -> Unit,
    onOpenShutter: () -> Unit,
    onOpenIso: () -> Unit,
    onOpenWb: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xD90A131F))
            .border(1.dp, Color(0x3300A3FF))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left Parameters: OBJ, F/S, OBT, AP
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Highlighted blue badge for Lens
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(BMBlue)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("OBJ.", color = Color.White.copy(alpha = 0.8f), fontSize = 7.sp, fontWeight = FontWeight.Bold)
                    Text(focalLength, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }

            TelemetryItem(label = "F/S", value = "${fps.fps}", onClick = onOpenFps)
            TelemetryItem(label = "OBT.", value = shutter.label, onClick = onOpenShutter)
            TelemetryItem(label = "AP.", value = telemetry.currentAperture, onClick = {})
        }

        // Center Timecode with Project Tag
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .background(Color(0x6600A3FF), RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp, vertical = 1.dp)
            ) {
                Icon(Icons.Default.CloudQueue, contentDescription = null, tint = Color.White, modifier = Modifier.size(10.dp))
                Text("Short Films", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
            }

            Text(
                text = telemetry.timecode,
                color = if (telemetry.isRecording) BMRecordRed else Color.White,
                fontSize = if (isLandscape) 18.sp else 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        // Right Parameters: ISO, BAL. B., TIN.
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TelemetryItem(
                label = "ISO",
                value = if (iso == IsoValue.AUTO) "AUTO" else iso.label,
                onClick = onOpenIso
            )
            TelemetryItem(
                label = "BAL. B.",
                value = if (whiteBalance == WhiteBalancePreset.AUTO) "AWB" else "${whiteBalance.kelvin}K",
                onClick = onOpenWb
            )
            TelemetryItem(label = "TIN.", value = "-10", onClick = {})
        }
    }
}

@Composable
private fun TelemetryItem(
    label: String,
    value: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        Text(label, color = BMTextMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        Text(value, color = BMTextWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
    }
}

/**
 * Vertical Lens & Zoom Wheel (matching reference image column with 15x, 8x, 4x, 2x and focal lengths)
 */
@Composable
private fun BlackmagicZoomWheel(
    activeZoom: String,
    activeFocal: String,
    onSelectZoom: (String, String, LensType) -> Unit,
    onCycleGrid: () -> Unit,
    onCycleAspect: () -> Unit,
    compact: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxHeight(if (compact) 0.65f else 0.88f)
            .background(Color(0xD90A111A), RoundedCornerShape(topStart = 10.dp, bottomStart = 10.dp))
            .border(1.dp, Color(0xFF1E2D40), RoundedCornerShape(topStart = 10.dp, bottomStart = 10.dp))
            .padding(horizontal = 6.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Zoom quick multiplier pills (15x, 8x, 4x, 2x)
        Column(
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxHeight()
        ) {
            val zoomSteps = listOf("15x", "8x", "4x", "2x")
            zoomSteps.forEach { step ->
                val isSel = activeZoom == step
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) BMBlue else Color(0x331E293B))
                        .clickable {
                            val focal = when (step) {
                                "15x" -> "200mm"
                                "8x" -> "100mm"
                                "4x" -> "48mm"
                                else -> "24mm"
                            }
                            val lens = when (step) {
                                "15x" -> LensType.TELE_3X
                                "8x" -> LensType.TELE_3X
                                "4x" -> LensType.TELE_2X
                                else -> LensType.WIDE
                            }
                            onSelectZoom(step, focal, lens)
                        }
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = step,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Lens focal length list with circle icon
        Column(
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxHeight()
        ) {
            val lenses = listOf(
                Triple("200mm", "15x", LensType.TELE_3X),
                Triple("100mm", "8x", LensType.TELE_3X),
                Triple("48mm", "4x", LensType.TELE_2X),
                Triple("24mm", "2x", LensType.WIDE),
                Triple("13mm", "1x", LensType.WIDE),
                Triple("Frontal", "1x", LensType.FRONT),
                Triple("Amplio", "0.5x", LensType.ULTRA_WIDE)
            )

            lenses.take(if (compact) 4 else 7).forEach { (focal, zoom, lens) ->
                val isSel = activeFocal == focal
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onSelectZoom(zoom, focal, lens) }
                        .padding(vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (compact) 16.dp else 22.dp)
                            .background(
                                if (isSel) BMBlue.copy(alpha = 0.2f) else Color.Transparent,
                                CircleShape
                            )
                            .border(
                                width = if (isSel) 2.dp else 1.dp,
                                color = if (isSel) BMBlue else Color(0x66FFFFFF),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(if (isSel) BMBlue else Color.Transparent, CircleShape)
                        )
                    }
                    Text(
                        text = focal,
                        color = if (isSel) BMBlue else Color(0xFF94A3B8),
                        fontSize = 7.sp,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

/**
 * Right Action Toolbar matching reference image:
 * Framing, Focus, Zebra, Big Circular Record Button, Cámara, Multimedia, Ajustes
 */
@Composable
private fun BlackmagicActionToolbar(
    telemetry: CameraTelemetry,
    captureMode: CaptureMode,
    onRecordOrShutterClick: () -> Unit,
    onPauseResumeClick: () -> Unit,
    onToggleScopes: () -> Unit,
    onToggleLevel: () -> Unit,
    onOpenLooks: () -> Unit,
    onModeChange: (CaptureMode) -> Unit,
    onOpenGallery: () -> Unit,
    onOpenSettings: () -> Unit,
    compact: Boolean = false
) {
    Column(
        modifier = Modifier
            .fillMaxHeight(if (compact) 0.75f else 0.95f)
            .width(if (compact) 55.dp else 70.dp)
            .background(Color(0xF0080E17))
            .border(1.dp, Color(0xFF1E2D40))
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Tools: Reticle, Focus, Zebra
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(if (compact) 4.dp else 8.dp)
        ) {
            ToolbarIconButton(
                icon = Icons.Default.CropFree,
                contentDesc = "Framing Guides",
                onClick = onToggleLevel,
                compact = compact
            )
            ToolbarIconButton(
                icon = Icons.Default.FilterCenterFocus,
                contentDesc = "Focus Reticle",
                onClick = onToggleScopes,
                compact = compact
            )
            ToolbarIconButton(
                icon = Icons.Default.AspectRatio,
                contentDesc = "Film Look",
                onClick = onOpenLooks,
                compact = compact
            )
        }

        // BIG RECORD / SHUTTER BUTTON (White outer ring, red circular button)
        Box(
            modifier = Modifier
                .size(if (compact) 50.dp else 64.dp)
                .border(2.5.dp, Color.White, CircleShape)
                .padding(4.dp)
                .clickable(onClick = onRecordOrShutterClick)
                .testTag("blackmagic_record_button"),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(if (telemetry.isRecording) 26.dp else 46.dp)
                    .background(
                        if (captureMode.isVideo) BMRecordRed else Color.White,
                        if (telemetry.isRecording) RoundedCornerShape(4.dp) else CircleShape
                    )
            )
        }

        // Bottom Actions: Cámara, Multimedia, Ajustes
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(if (compact) 4.dp else 8.dp)
        ) {
            ToolbarActionButton(
                icon = Icons.Default.Videocam,
                label = "Cámara",
                active = true,
                onClick = {
                    onModeChange(if (captureMode == CaptureMode.VIDEO) CaptureMode.PHOTO else CaptureMode.VIDEO)
                },
                compact = compact
            )

            ToolbarActionButton(
                icon = Icons.Default.VideoLibrary,
                label = "Multimedia",
                active = false,
                onClick = onOpenGallery,
                compact = compact
            )

            ToolbarActionButton(
                icon = Icons.Default.Settings,
                label = "Ajustes",
                active = false,
                onClick = onOpenSettings,
                compact = compact
            )
        }
    }
}

@Composable
private fun ToolbarIconButton(
    icon: ImageVector,
    contentDesc: String,
    onClick: () -> Unit,
    compact: Boolean = false
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.size(if (compact) 26.dp else 34.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDesc,
            tint = Color(0xFFCBD5E1),
            modifier = Modifier.size(if (compact) 16.dp else 20.dp)
        )
    }
}

@Composable
private fun ToolbarActionButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    compact: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(vertical = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(if (compact) 28.dp else 34.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (active) BMBlue.copy(alpha = 0.2f) else Color(0x331E293B))
                .border(1.dp, if (active) BMBlue else Color(0xFF26384D), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) BMBlue else Color(0xFF94A3B8),
                modifier = Modifier.size(if (compact) 15.dp else 18.dp)
            )
        }
        Text(
            text = label,
            color = if (active) BMBlue else Color(0xFF94A3B8),
            fontSize = 7.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.SansSerif
        )
    }
}

@Composable
private fun <T> OptionPickerDialog(
    title: String,
    options: List<T>,
    selected: T,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit,
    labelProvider: (T) -> String
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF0F172A),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth(0.85f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = BMBlue,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    options.forEach { opt ->
                        val isSel = opt == selected
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (isSel) Color(0xFF1E293B) else Color.Transparent, RoundedCornerShape(6.dp))
                                .border(1.dp, if (isSel) BMBlue else Color(0xFF334155), RoundedCornerShape(6.dp))
                                .clickable { onSelect(opt) }
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = labelProvider(opt),
                                color = if (isSel) BMBlue else Color.White,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
