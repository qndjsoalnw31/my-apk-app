package com.example.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MediaItem(
    val id: String,
    val title: String,
    val uriString: String,
    val filePath: String? = null,
    val mimeType: String,
    val isVideo: Boolean,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val sizeBytes: Long = 0L,
    val dateAdded: Long = System.currentTimeMillis(),
    val iso: Int? = 400,
    val shutterSpeed: String? = "1/50s",
    val aperture: String? = "f/1.8",
    val focalLength: String? = "24mm",
    val fps: Int? = 24,
    val colorProfile: String? = "Rec. 709",
    val isFavorite: Boolean = false,
    val album: String = "Cinema Vault"
) {
    val formattedDuration: String
        get() {
            if (!isVideo) return ""
            val totalSecs = durationMs / 1000
            val minutes = totalSecs / 60
            val seconds = totalSecs % 60
            val millis = (durationMs % 1000) / 10
            return String.format(Locale.US, "%02d:%02d.%02d", minutes, seconds, millis)
        }

    val formattedSize: String
        get() {
            if (sizeBytes <= 0) return "--"
            val kb = sizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
                mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
                else -> String.format(Locale.US, "%.0f KB", kb)
            }
        }

    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("MMM dd, yyyy  HH:mm", Locale.getDefault())
            return sdf.format(Date(dateAdded))
        }

    val resolutionLabel: String
        get() {
            return when {
                width >= 3800 || height >= 2100 -> "4K UHD"
                width >= 1900 || height >= 1000 -> "1080p FHD"
                width >= 1200 || height >= 700 -> "720p HD"
                width > 0 && height > 0 -> "${width}x${height}"
                else -> if (isVideo) "HD Video" else "High-Res"
            }
        }

    val extension: String
        get() {
            val fromTitle = title.substringAfterLast('.', "")
            if (fromTitle.isNotBlank()) return fromTitle.uppercase()
            return when {
                mimeType.contains("mp4") -> "MP4"
                mimeType.contains("mkv") -> "MKV"
                mimeType.contains("webm") -> "WEBM"
                mimeType.contains("quicktime") -> "MOV"
                mimeType.contains("png") -> "PNG"
                mimeType.contains("jpeg") || mimeType.contains("jpg") -> "JPG"
                mimeType.contains("dng") || mimeType.contains("raw") -> "RAW/DNG"
                mimeType.contains("audio") -> "AUDIO"
                else -> if (isVideo) "VIDEO" else "IMAGE"
            }
        }
}
