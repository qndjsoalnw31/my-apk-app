package com.example.model

enum class CaptureMode(val label: String, val isVideo: Boolean) {
    PHOTO("PHOTO", false),
    VIDEO("VIDEO", true),
    SLOW_MO("SLOW-MO", true),
    TIMELAPSE("TIME-LAPSE", true)
}

enum class LensType(val label: String, val factor: Float, val isFront: Boolean = false) {
    ULTRA_WIDE("0.5x", 0.5f),
    WIDE("1.0x", 1.0f),
    TELE_2X("2.0x", 2.0f),
    TELE_3X("3.0x", 3.0f),
    FRONT("FRONT", 1.0f, true)
}

enum class ResolutionOption(val label: String, val width: Int, val height: Int) {
    RES_720P("720p HD", 1280, 720),
    RES_1080P("1080p FHD", 1920, 1080),
    RES_4K("4K UHD", 3840, 2160)
}

enum class FpsOption(val fps: Int, val label: String) {
    FPS_24(24, "24 fps (Cinema)"),
    FPS_25(25, "25 fps (PAL)"),
    FPS_30(30, "30 fps (Standard)"),
    FPS_50(50, "50 fps (Euro)"),
    FPS_60(60, "60 fps (Smooth)"),
    FPS_120(120, "120 fps (HFR)")
}

enum class ShutterSpeed(val label: String, val denominator: Int) {
    AUTO("AUTO", 0),
    S_1_24("1/24s", 24),
    S_1_48("1/48s", 48),
    S_1_50("1/50s", 50),
    S_1_60("1/60s", 60),
    S_1_96("1/96s", 96),
    S_1_120("1/120s", 120),
    S_1_250("1/250s", 250),
    S_1_500("1/500s", 500),
    S_1_1000("1/1000s", 1000),
    S_1_2000("1/2000s", 2000)
}

enum class IsoValue(val label: String, val value: Int) {
    AUTO("AUTO", 0),
    ISO_50("50", 50),
    ISO_100("100", 100),
    ISO_200("200", 200),
    ISO_400("400", 400),
    ISO_800("800", 800),
    ISO_1600("1600", 1600),
    ISO_3200("3200", 3200),
    ISO_6400("6400", 6400)
}

enum class WhiteBalancePreset(val label: String, val kelvin: Int) {
    AUTO("AUTO", 0),
    TUNGSTEN("3200K (Tungsten)", 3200),
    FLUORESCENT("4000K (Fluorescent)", 4000),
    DAYLIGHT("5600K (Daylight)", 5600),
    CLOUDY("6500K (Cloudy)", 6500),
    SHADE("7500K (Shade)", 7500)
}

enum class GridType(val label: String) {
    NONE("None"),
    RULE_OF_THIRDS("3x3 Rule of Thirds"),
    GOLDEN_RATIO("Golden Ratio"),
    CROSSHAIR("Center Crosshair"),
    DOT("Center Target")
}

enum class AspectRatioGuide(val label: String, val ratio: Float) {
    OFF("Full Sensor", 0f),
    SCOPE_2_39("2.39:1 CinemaScope", 2.39f),
    ACADEMY_1_85("1.85:1 Flat", 1.85f),
    RATIO_16_9("16:9 Standard", 16f / 9f),
    RATIO_4_3("4:3 Classic", 4f / 3f),
    RATIO_1_1("1:1 Square", 1f),
    RATIO_9_16("9:16 Reel/Story", 9f / 16f)
}

data class FilmLook(
    val id: String,
    val name: String,
    val description: String,
    val contrast: Float = 1.0f,
    val saturation: Float = 1.0f,
    val temperature: Float = 0.0f, // -1.0 cool to +1.0 warm
    val tint: Float = 0.0f, // -1.0 green to +1.0 magenta
    val exposure: Float = 0.0f, // -2.0 to +2.0
    val vignette: Float = 0.0f, // 0.0 to 1.0
    val isBw: Boolean = false,
    val isFlatLog: Boolean = false
) {
    companion object {
        val ALL_LOOKS = listOf(
            FilmLook(
                id = "rec709",
                name = "Rec. 709",
                description = "True-to-life broadcast standard with natural roll-off",
                contrast = 1.0f,
                saturation = 1.0f
            ),
            FilmLook(
                id = "teal_orange",
                name = "Teal & Orange",
                description = "Modern Hollywood blockbuster look with complementary skin tones",
                contrast = 1.25f,
                saturation = 1.2f,
                temperature = 0.2f,
                tint = -0.1f,
                vignette = 0.25f
            ),
            FilmLook(
                id = "kodak_portra",
                name = "Kodak Portra 400",
                description = "Organic warm skin highlights, soft cinema grain emulation",
                contrast = 1.05f,
                saturation = 1.15f,
                temperature = 0.35f,
                tint = 0.1f,
                vignette = 0.15f
            ),
            FilmLook(
                id = "fuji_eterna",
                name = "Fuji Eterna",
                description = "Subtle cinematic shadows, gentle contrast, pastel hues",
                contrast = 0.88f,
                saturation = 0.85f,
                temperature = -0.1f,
                tint = -0.05f
            ),
            FilmLook(
                id = "bw_tri_x",
                name = "Tri-X 400 B&W",
                description = "High dynamic range silver halide black & white photography",
                contrast = 1.35f,
                saturation = 0.0f,
                isBw = true,
                vignette = 0.3f
            ),
            FilmLook(
                id = "flat_log",
                name = "Flat / Log Sim",
                description = "Desaturated flat preview maximizing shadow & highlight monitoring",
                contrast = 0.75f,
                saturation = 0.65f,
                isFlatLog = true
            ),
            FilmLook(
                id = "moody_noir",
                name = "Moody Noir",
                description = "Dark crushed shadows, intense contrast, mystery cinema",
                contrast = 1.4f,
                saturation = 0.75f,
                temperature = -0.25f,
                vignette = 0.45f
            ),
            FilmLook(
                id = "golden_hour",
                name = "Golden Hour",
                description = "Rich sunset amber radiance and glowing skin tones",
                contrast = 1.1f,
                saturation = 1.3f,
                temperature = 0.5f,
                tint = 0.15f,
                vignette = 0.2f
            ),
            FilmLook(
                id = "nordic_cold",
                name = "Nordic Cold",
                description = "Subtle icy steel tones with subdued earthy colors",
                contrast = 1.15f,
                saturation = 0.8f,
                temperature = -0.4f,
                tint = -0.1f
            )
        )
    }
}
