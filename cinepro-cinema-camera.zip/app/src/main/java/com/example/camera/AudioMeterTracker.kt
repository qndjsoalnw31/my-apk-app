package com.example.camera

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.log10
import kotlin.math.sqrt

data class AudioVUState(
    val leftDbfs: Float = -60f, // -60dB to 0dB
    val rightDbfs: Float = -60f,
    val isClipping: Boolean = false
)

class AudioMeterTracker(private val scope: CoroutineScope) {
    private val _vuState = MutableStateFlow(AudioVUState())
    val vuState: StateFlow<AudioVUState> = _vuState

    private var audioRecord: AudioRecord? = null
    private var trackingJob: Job? = null
    private var isRecordingSim = false

    @SuppressLint("MissingPermission")
    fun startMonitoring(hasPermission: Boolean) {
        stopMonitoring()
        if (!hasPermission) {
            startSimulation()
            return
        }

        try {
            val sampleRate = 44100
            val channelConfig = AudioFormat.CHANNEL_IN_STEREO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat).coerceAtLeast(2048)

            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                audioRecord?.release()
                audioRecord = null
                startSimulation()
                return
            }

            audioRecord?.startRecording()

            trackingJob = scope.launch(Dispatchers.Default) {
                val buffer = ShortArray(bufferSize / 2)
                var currentLeft = -60f
                var currentRight = -60f

                while (isActive && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        var sumSqL = 0.0
                        var sumSqR = 0.0
                        var countL = 0
                        var countR = 0

                        for (i in 0 until read step 2) {
                            val sampleL = buffer[i]
                            sumSqL += sampleL * sampleL
                            countL++
                            if (i + 1 < read) {
                                val sampleR = buffer[i + 1]
                                sumSqR += sampleR * sampleR
                                countR++
                            }
                        }

                        val rmsL = if (countL > 0) sqrt(sumSqL / countL) else 0.0
                        val rmsR = if (countR > 0) sqrt(sumSqR / countR) else 0.0

                        val dbfsL = if (rmsL > 0.0) (20 * log10(rmsL / 32767.0)).toFloat().coerceIn(-60f, 0f) else -60f
                        val dbfsR = if (rmsR > 0.0) (20 * log10(rmsR / 32767.0)).toFloat().coerceIn(-60f, 0f) else -60f

                        // Smooth ballistics (fast attack, slower decay)
                        currentLeft = if (dbfsL > currentLeft) dbfsL else currentLeft * 0.85f + dbfsL * 0.15f
                        currentRight = if (dbfsR > currentRight) dbfsR else currentRight * 0.85f + dbfsR * 0.15f

                        _vuState.value = AudioVUState(
                            leftDbfs = currentLeft,
                            rightDbfs = currentRight,
                            isClipping = currentLeft >= -1.0f || currentRight >= -1.0f
                        )
                    }
                    kotlinx.coroutines.delay(40)
                }
            }
        } catch (_: Exception) {
            startSimulation()
        }
    }

    private fun startSimulation() {
        trackingJob?.cancel()
        trackingJob = scope.launch(Dispatchers.Default) {
            var phase = 0f
            while (isActive) {
                phase += 0.1f
                val base = -32f + (kotlin.math.sin(phase) * 12f).toFloat()
                val left = (base + (Math.random() * 4f).toFloat()).coerceIn(-55f, -6f)
                val right = (base + (Math.random() * 5f).toFloat()).coerceIn(-55f, -6f)
                _vuState.value = AudioVUState(leftDbfs = left, rightDbfs = right, isClipping = false)
                kotlinx.coroutines.delay(60)
            }
        }
    }

    fun stopMonitoring() {
        trackingJob?.cancel()
        trackingJob = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
        _vuState.value = AudioVUState(-60f, -60f, false)
    }
}
