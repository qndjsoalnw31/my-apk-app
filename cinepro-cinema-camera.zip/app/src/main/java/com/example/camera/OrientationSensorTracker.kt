package com.example.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.atan2
import kotlin.math.sqrt

data class HorizonLevelState(
    val rollDegrees: Float = 0f,
    val pitchDegrees: Float = 0f,
    val isLevel: Boolean = true
)

class OrientationSensorTracker(context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val rotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        ?: sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
        ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val _levelState = MutableStateFlow(HorizonLevelState())
    val levelState: StateFlow<HorizonLevelState> = _levelState

    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    fun start() {
        rotationSensor?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientationAngles)
            val pitch = Math.toDegrees(orientationAngles[1].toDouble()).toFloat()
            val roll = Math.toDegrees(orientationAngles[2].toDouble()).toFloat()

            val isLevel = kotlin.math.abs(roll) < 1.0f
            _levelState.value = HorizonLevelState(rollDegrees = roll, pitchDegrees = pitch, isLevel = isLevel)
        } else if (event.sensor.type == Sensor.TYPE_ACCELEROMETER || event.sensor.type == Sensor.TYPE_GRAVITY) {
            val ax = event.values[0]
            val ay = event.values[1]
            val az = event.values[2]

            val roll = Math.toDegrees(atan2(ax.toDouble(), sqrt(ay * ay + az * az).toDouble())).toFloat()
            val pitch = Math.toDegrees(atan2(ay.toDouble(), sqrt(ax * ax + az * az).toDouble())).toFloat()

            val isLevel = kotlin.math.abs(roll) < 1.0f
            _levelState.value = HorizonLevelState(rollDegrees = roll, pitchDegrees = pitch, isLevel = isLevel)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
