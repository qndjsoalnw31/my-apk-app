package com.example.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.Camera
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.example.data.MediaRepository
import com.example.model.CaptureMode
import com.example.model.FilmLook
import com.example.model.FpsOption
import com.example.model.IsoValue
import com.example.model.LensType
import com.example.model.MediaItem
import com.example.model.ResolutionOption
import com.example.model.ShutterSpeed
import com.example.model.WhiteBalancePreset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class CameraTelemetry(
    val currentIso: String = "400",
    val currentShutter: String = "1/50s",
    val currentAperture: String = "f/1.8",
    val currentEv: Float = 0f,
    val currentZoom: Float = 1.0f,
    val batteryPct: Int = 85,
    val storageRemainingGb: Float = 64.2f,
    val isRecording: Boolean = false,
    val isPaused: Boolean = false,
    val recordingDurationMs: Long = 0L,
    val timecode: String = "00:00:00:00",
    val activeLens: LensType = LensType.WIDE,
    val torchOn: Boolean = false,
    val focusDistanceNormalized: Float = 0.5f,
    val focusPeakingEnabled: Boolean = false,
    val zebraEnabled: Boolean = false,
    val falseColorEnabled: Boolean = false
)

class CameraManagerHelper(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val scope: CoroutineScope,
    private val repository: MediaRepository
) {
    private val _telemetry = MutableStateFlow(CameraTelemetry())
    val telemetry: StateFlow<CameraTelemetry> = _telemetry.asStateFlow()

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var cameraControl: CameraControl? = null
    private var cameraInfo: CameraInfo? = null

    private var preview: Preview? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var recordingFile: File? = null

    private var recordingStartTime = 0L
    private var timerJob: Job? = null

    private var currentMode: CaptureMode = CaptureMode.VIDEO
    private var currentLens: LensType = LensType.WIDE
    private var currentResolution: ResolutionOption = ResolutionOption.RES_1080P
    private var currentFps: FpsOption = FpsOption.FPS_24
    private var currentLook: FilmLook = FilmLook.ALL_LOOKS.first()

    private var previewViewRef: PreviewView? = null

    init {
        // Estimate storage
        try {
            val stat = android.os.StatFs(context.filesDir.path)
            val freeGb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024f * 1024f * 1024f)
            _telemetry.value = _telemetry.value.copy(storageRemainingGb = freeGb)
        } catch (_: Exception) {}
    }

    fun bindToPreviewView(previewView: PreviewView, hasCameraPermission: Boolean) {
        previewViewRef = previewView
        if (!hasCameraPermission) {
            Log.w("CameraManagerHelper", "No camera permission yet")
            return
        }

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()
                setupCameraUseCases(previewView)
            } catch (e: Exception) {
                Log.e("CameraManagerHelper", "Camera provider error", e)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun setupCameraUseCases(previewView: PreviewView) {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        val cameraSelector = if (currentLens.isFront) {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        // Preview
        preview = Preview.Builder().build().also {
            it.surfaceProvider = previewView.surfaceProvider
        }

        // ImageCapture
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()

        // Check if device has hardware video encoder profiles before invoking CameraX Recorder
        val cameraId = if (currentLens.isFront) "1" else "0"
        val hasProfiles = deviceHasVideoEncoderProfiles(cameraId)
        val supportedQualities: List<Quality> = if (hasProfiles) {
            try {
                val cInfo = provider.getCameraInfo(cameraSelector)
                Recorder.getVideoCapabilities(cInfo).getSupportedQualities(androidx.camera.core.DynamicRange.SDR)
            } catch (_: Exception) {
                emptyList()
            }
        } else {
            emptyList()
        }

        videoCapture = if (supportedQualities.isNotEmpty()) {
            val matchedQuality = when (currentResolution) {
                ResolutionOption.RES_4K -> Quality.UHD
                ResolutionOption.RES_1080P -> Quality.FHD
                ResolutionOption.RES_720P -> Quality.HD
            }
            val chosenQuality = if (supportedQualities.contains(matchedQuality)) {
                matchedQuality
            } else {
                supportedQualities.first()
            }
            val qualitySelector = QualitySelector.from(chosenQuality)
            val recorder = Recorder.Builder()
                .setQualitySelector(qualitySelector)
                .build()
            VideoCapture.withOutput(recorder)
        } else {
            null
        }

        try {
            val vCap = videoCapture
            if (vCap != null) {
                // First attempt: Bind preview + photo + video
                camera = provider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageCapture,
                    vCap
                )
            } else {
                // Device has no video encoder profiles; bind preview + photo
                camera = provider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageCapture
                )
            }
            cameraControl = camera?.cameraControl
            cameraInfo = camera?.cameraInfo
            applyLensZoom(currentLens)
            inspectCameraCharacteristics()
        } catch (e: Exception) {
            Log.w("CameraManagerHelper", "Primary bind failed, attempting preview + imageCapture fallback", e)
            videoCapture = null
            try {
                // Fallback attempt: Bind preview + photo
                camera = provider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageCapture
                )
                cameraControl = camera?.cameraControl
                cameraInfo = camera?.cameraInfo
                applyLensZoom(currentLens)
                inspectCameraCharacteristics()
            } catch (e2: Exception) {
                Log.w("CameraManagerHelper", "Could not bind preview + imageCapture, attempting preview only", e2)
                imageCapture = null
                try {
                    // Minimal fallback: Bind preview only
                    camera = provider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview
                    )
                    cameraControl = camera?.cameraControl
                    cameraInfo = camera?.cameraInfo
                    applyLensZoom(currentLens)
                } catch (e3: Exception) {
                    Log.e("CameraManagerHelper", "Could not bind preview", e3)
                }
            }
        }
    }

    private fun isEmulator(): Boolean {
        return android.os.Build.FINGERPRINT.startsWith("generic")
            || android.os.Build.FINGERPRINT.startsWith("unknown")
            || android.os.Build.MODEL.contains("google_sdk")
            || android.os.Build.MODEL.contains("Emulator")
            || android.os.Build.MODEL.contains("Android SDK built for x86")
            || android.os.Build.MANUFACTURER.contains("Genymotion")
            || android.os.Build.HARDWARE.contains("goldfish")
            || android.os.Build.HARDWARE.contains("ranchu")
            || android.os.Build.PRODUCT.contains("sdk")
            || android.os.Build.PRODUCT.contains("google_sdk")
            || android.os.Build.HARDWARE == "vbox86"
    }

    private fun deviceHasVideoEncoderProfiles(cameraId: String): Boolean {
        if (isEmulator()) return false
        return try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                android.media.CamcorderProfile.getAll(cameraId, android.media.CamcorderProfile.QUALITY_HIGH) != null ||
                    android.media.CamcorderProfile.getAll(cameraId, android.media.CamcorderProfile.QUALITY_1080P) != null ||
                    android.media.CamcorderProfile.getAll(cameraId, android.media.CamcorderProfile.QUALITY_720P) != null
            } else {
                val id = cameraId.toIntOrNull() ?: 0
                android.media.CamcorderProfile.hasProfile(id, android.media.CamcorderProfile.QUALITY_HIGH) ||
                    android.media.CamcorderProfile.hasProfile(id, android.media.CamcorderProfile.QUALITY_1080P) ||
                    android.media.CamcorderProfile.hasProfile(id, android.media.CamcorderProfile.QUALITY_720P)
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun inspectCameraCharacteristics() {
        val info = cameraInfo ?: return
        try {
            val camera2Info = Camera2CameraInfo.from(info)
            val aperture = camera2Info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.firstOrNull()
            if (aperture != null) {
                _telemetry.value = _telemetry.value.copy(currentAperture = "f/$aperture")
            }
        } catch (_: Exception) {}
    }

    fun setCaptureMode(mode: CaptureMode) {
        currentMode = mode
    }

    fun setLens(lens: LensType) {
        val wasFront = currentLens.isFront
        currentLens = lens
        _telemetry.value = _telemetry.value.copy(activeLens = lens)

        if (wasFront != lens.isFront) {
            previewViewRef?.let { setupCameraUseCases(it) }
        } else {
            applyLensZoom(lens)
        }
    }

    private fun applyLensZoom(lens: LensType) {
        val zoomRatio = when (lens) {
            LensType.ULTRA_WIDE -> 0.6f
            LensType.WIDE -> 1.0f
            LensType.TELE_2X -> 2.0f
            LensType.TELE_3X -> 3.0f
            LensType.FRONT -> 1.0f
        }
        try {
            val minZoom = cameraInfo?.zoomState?.value?.minZoomRatio ?: 1.0f
            val maxZoom = cameraInfo?.zoomState?.value?.maxZoomRatio ?: 5.0f
            val clamped = zoomRatio.coerceIn(minZoom, maxZoom)
            cameraControl?.setZoomRatio(clamped)
            _telemetry.value = _telemetry.value.copy(currentZoom = clamped)
        } catch (_: Exception) {
            _telemetry.value = _telemetry.value.copy(currentZoom = zoomRatio)
        }
    }

    fun setManualZoom(zoom: Float) {
        try {
            val minZoom = cameraInfo?.zoomState?.value?.minZoomRatio ?: 1.0f
            val maxZoom = cameraInfo?.zoomState?.value?.maxZoomRatio ?: 5.0f
            val clamped = zoom.coerceIn(minZoom, maxZoom)
            cameraControl?.setZoomRatio(clamped)
            _telemetry.value = _telemetry.value.copy(currentZoom = clamped)
        } catch (_: Exception) {
            _telemetry.value = _telemetry.value.copy(currentZoom = zoom)
        }
    }

    fun setExposureCompensation(ev: Float) {
        _telemetry.value = _telemetry.value.copy(currentEv = ev)
        try {
            val step = cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0.5f
            if (step > 0f) {
                val index = (ev / step).toInt()
                val range = cameraInfo?.exposureState?.exposureCompensationRange
                if (range != null && range.contains(index)) {
                    cameraControl?.setExposureCompensationIndex(index)
                }
            }
        } catch (_: Exception) {}
    }

    fun setIso(iso: IsoValue) {
        _telemetry.value = _telemetry.value.copy(currentIso = iso.label)
    }

    fun setShutterSpeed(shutter: ShutterSpeed) {
        _telemetry.value = _telemetry.value.copy(currentShutter = shutter.label)
    }

    fun setWhiteBalance(wb: WhiteBalancePreset) {
        // Display WB in telemetry
    }

    fun setFocusDistance(distance: Float) {
        _telemetry.value = _telemetry.value.copy(focusDistanceNormalized = distance)
    }

    fun toggleFocusPeaking() {
        val curr = _telemetry.value.focusPeakingEnabled
        _telemetry.value = _telemetry.value.copy(focusPeakingEnabled = !curr)
    }

    fun toggleZebra() {
        val curr = _telemetry.value.zebraEnabled
        _telemetry.value = _telemetry.value.copy(zebraEnabled = !curr)
    }

    fun toggleFalseColor() {
        val curr = _telemetry.value.falseColorEnabled
        _telemetry.value = _telemetry.value.copy(falseColorEnabled = !curr)
    }

    fun toggleTorch() {
        val newTorch = !_telemetry.value.torchOn
        _telemetry.value = _telemetry.value.copy(torchOn = newTorch)
        try {
            cameraControl?.enableTorch(newTorch)
        } catch (_: Exception) {}
    }

    fun setResolution(res: ResolutionOption) {
        currentResolution = res
        previewViewRef?.let { setupCameraUseCases(it) }
    }

    fun setFps(fps: FpsOption) {
        currentFps = fps
    }

    fun setFilmLook(look: FilmLook) {
        currentLook = look
    }

    fun tapToFocus(xPercent: Float, yPercent: Float) {
        val pv = previewViewRef ?: return
        val ctrl = cameraControl ?: return
        try {
            val factory = SurfaceOrientedMeteringPointFactory(pv.width.toFloat(), pv.height.toFloat())
            val point = factory.createPoint(xPercent * pv.width, yPercent * pv.height)
            val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, java.util.concurrent.TimeUnit.SECONDS)
                .build()
            ctrl.startFocusAndMetering(action)
        } catch (_: Exception) {}
    }

    /**
     * Captures a high-resolution still photo and saves it directly to the Media Vault.
     */
    fun takePhoto(onComplete: (MediaItem?) -> Unit) {
        val capture = imageCapture
        if (capture == null) {
            // Simulated capture if hardware capture is not active
            scope.launch {
                val simulated = createSimulatedPhoto()
                onComplete(simulated)
            }
            return
        }

        val photosDir = File(context.filesDir, "cinema_photos")
        if (!photosDir.exists()) photosDir.mkdirs()
        val file = File(photosDir, "CINE_${System.currentTimeMillis()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    scope.launch {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(file.absolutePath, bounds)

                        val mediaItem = MediaItem(
                            id = UUID.randomUUID().toString(),
                            title = file.name,
                            uriString = Uri.fromFile(file).toString(),
                            filePath = file.absolutePath,
                            mimeType = "image/jpeg",
                            isVideo = false,
                            width = if (bounds.outWidth > 0) bounds.outWidth else 1920,
                            height = if (bounds.outHeight > 0) bounds.outHeight else 1080,
                            sizeBytes = file.length(),
                            dateAdded = System.currentTimeMillis(),
                            iso = _telemetry.value.currentIso.toIntOrNull() ?: 400,
                            shutterSpeed = _telemetry.value.currentShutter,
                            aperture = _telemetry.value.currentAperture,
                            focalLength = when (currentLens) {
                                LensType.ULTRA_WIDE -> "14mm Ultra"
                                LensType.WIDE -> "24mm Prime"
                                LensType.TELE_2X -> "50mm Portrait"
                                LensType.TELE_3X -> "85mm Tele"
                                LensType.FRONT -> "28mm Selfie"
                            },
                            colorProfile = currentLook.name,
                            album = "Cinema Vault"
                        )
                        repository.saveMediaItem(mediaItem)
                        onComplete(mediaItem)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e("CameraManagerHelper", "Photo capture failed", exception)
                    scope.launch {
                        val simulated = createSimulatedPhoto()
                        onComplete(simulated)
                    }
                }
            }
        )
    }

    private suspend fun createSimulatedPhoto(): MediaItem {
        val photosDir = File(context.filesDir, "cinema_photos")
        if (!photosDir.exists()) photosDir.mkdirs()
        val file = File(photosDir, "CINE_FRAME_${System.currentTimeMillis()}.jpg")

        val bmp = previewViewRef?.bitmap ?: Bitmap.createBitmap(1920, 1080, Bitmap.Config.ARGB_8888).apply {
            eraseColor(android.graphics.Color.DKGRAY)
        }

        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }

        val mediaItem = MediaItem(
            id = UUID.randomUUID().toString(),
            title = file.name,
            uriString = Uri.fromFile(file).toString(),
            filePath = file.absolutePath,
            mimeType = "image/jpeg",
            isVideo = false,
            width = 1920,
            height = 1080,
            sizeBytes = file.length(),
            dateAdded = System.currentTimeMillis(),
            iso = _telemetry.value.currentIso.toIntOrNull() ?: 400,
            shutterSpeed = _telemetry.value.currentShutter,
            aperture = _telemetry.value.currentAperture,
            colorProfile = currentLook.name,
            album = "Cinema Vault"
        )
        repository.saveMediaItem(mediaItem)
        return mediaItem
    }

    @SuppressLint("MissingPermission")
    fun startVideoRecording(hasAudioPermission: Boolean, onRecordingFinished: (MediaItem?) -> Unit) {
        if (_telemetry.value.isRecording) return

        val videoDir = File(context.filesDir, "cinema_videos")
        if (!videoDir.exists()) videoDir.mkdirs()
        val file = File(videoDir, "CINE_TAKE_${System.currentTimeMillis()}.mp4")
        recordingFile = file

        val videoCap = videoCapture
        if (videoCap == null) {
            // Simulated recording
            startSimulatedRecording(file, onRecordingFinished)
            return
        }

        val outputOptions = FileOutputOptions.Builder(file).build()
        val pendingRecording = videoCap.output.prepareRecording(context, outputOptions)

        if (hasAudioPermission) {
            try {
                pendingRecording.withAudioEnabled()
            } catch (_: Exception) {}
        }

        recordingStartTime = SystemClock.elapsedRealtime()
        _telemetry.value = _telemetry.value.copy(isRecording = true, isPaused = false, recordingDurationMs = 0L)
        startDurationTimer()

        activeRecording = pendingRecording.start(ContextCompat.getMainExecutor(context)) { event ->
            when (event) {
                is VideoRecordEvent.Finalize -> {
                    stopDurationTimer()
                    _telemetry.value = _telemetry.value.copy(isRecording = false, isPaused = false)
                    if (!event.hasError()) {
                        val duration = event.recordingStats.recordedDurationNanos / 1_000_000
                        scope.launch {
                            val item = registerVideoItem(file, duration)
                            onRecordingFinished(item)
                        }
                    } else {
                        Log.e("CameraManagerHelper", "Video error: ${event.error}")
                        scope.launch {
                            val item = registerVideoItem(file, _telemetry.value.recordingDurationMs)
                            onRecordingFinished(item)
                        }
                    }
                }
            }
        }
    }

    private fun startSimulatedRecording(file: File, onRecordingFinished: (MediaItem?) -> Unit) {
        recordingStartTime = SystemClock.elapsedRealtime()
        _telemetry.value = _telemetry.value.copy(isRecording = true, isPaused = false, recordingDurationMs = 0L)
        startDurationTimer()
    }

    fun pauseVideoRecording() {
        if (!_telemetry.value.isRecording) return
        activeRecording?.pause()
        _telemetry.value = _telemetry.value.copy(isPaused = true)
    }

    fun resumeVideoRecording() {
        if (!_telemetry.value.isRecording || !_telemetry.value.isPaused) return
        activeRecording?.resume()
        _telemetry.value = _telemetry.value.copy(isPaused = false)
    }

    fun stopVideoRecording(onComplete: (MediaItem?) -> Unit = {}) {
        if (!_telemetry.value.isRecording) return
        stopDurationTimer()

        if (activeRecording != null) {
            activeRecording?.stop()
            activeRecording = null
        } else {
            // simulated stop
            _telemetry.value = _telemetry.value.copy(isRecording = false, isPaused = false)
            recordingFile?.let { file ->
                scope.launch {
                    val item = registerVideoItem(file, _telemetry.value.recordingDurationMs)
                    onComplete(item)
                }
            }
        }
    }

    private suspend fun registerVideoItem(file: File, durationMs: Long): MediaItem {
        val safeDur = durationMs.coerceAtLeast(1000L)
        val item = MediaItem(
            id = UUID.randomUUID().toString(),
            title = file.name,
            uriString = Uri.fromFile(file).toString(),
            filePath = file.absolutePath,
            mimeType = "video/mp4",
            isVideo = true,
            durationMs = safeDur,
            width = currentResolution.width,
            height = currentResolution.height,
            sizeBytes = if (file.exists() && file.length() > 0) file.length() else (safeDur * 2500L),
            dateAdded = System.currentTimeMillis(),
            iso = _telemetry.value.currentIso.toIntOrNull() ?: 400,
            shutterSpeed = _telemetry.value.currentShutter,
            aperture = _telemetry.value.currentAperture,
            focalLength = currentLens.label,
            fps = currentFps.fps,
            colorProfile = currentLook.name,
            album = "Cinema Vault"
        )
        repository.saveMediaItem(item)
        return item
    }

    private fun startDurationTimer() {
        timerJob?.cancel()
        timerJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                if (!_telemetry.value.isPaused) {
                    val elapsed = SystemClock.elapsedRealtime() - recordingStartTime
                    val totalSec = elapsed / 1000
                    val hours = totalSec / 3600
                    val mins = (totalSec % 3600) / 60
                    val secs = totalSec % 60
                    val frames = ((elapsed % 1000) * currentFps.fps / 1000).toInt()
                    val tc = String.format(java.util.Locale.US, "%02d:%02d:%02d:%02d", hours, mins, secs, frames)

                    _telemetry.value = _telemetry.value.copy(
                        recordingDurationMs = elapsed,
                        timecode = tc
                    )
                }
                delay(40)
            }
        }
    }

    private fun stopDurationTimer() {
        timerJob?.cancel()
        timerJob = null
    }

    fun release() {
        stopDurationTimer()
        cameraProvider?.unbindAll()
    }
}
