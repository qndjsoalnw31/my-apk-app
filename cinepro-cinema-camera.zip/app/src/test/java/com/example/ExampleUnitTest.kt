package com.example

import com.example.model.AspectRatioGuide
import com.example.model.CaptureMode
import com.example.model.FilmLook
import com.example.model.FpsOption
import com.example.model.GridType
import com.example.model.IsoValue
import com.example.model.LensType
import com.example.model.MediaItem
import com.example.model.ResolutionOption
import com.example.model.ShutterSpeed
import com.example.model.WhiteBalancePreset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testCameraModels() {
        assertEquals("PHOTO", CaptureMode.PHOTO.label)
        assertEquals("VIDEO", CaptureMode.VIDEO.label)
        assertTrue(CaptureMode.VIDEO.isVideo)
        assertFalse(CaptureMode.PHOTO.isVideo)

        assertEquals("0.5x", LensType.ULTRA_WIDE.label)
        assertEquals("1.0x", LensType.WIDE.label)
        assertEquals("2.0x", LensType.TELE_2X.label)
        assertEquals("FRONT", LensType.FRONT.label)
        assertTrue(LensType.FRONT.isFront)

        assertEquals(1920, ResolutionOption.RES_1080P.width)
        assertEquals(1080, ResolutionOption.RES_1080P.height)
        assertEquals(3840, ResolutionOption.RES_4K.width)

        assertEquals(24, FpsOption.FPS_24.fps)
        assertEquals(60, FpsOption.FPS_60.fps)

        assertEquals("1/50s", ShutterSpeed.S_1_50.label)
        assertEquals(50, ShutterSpeed.S_1_50.denominator)

        assertEquals("400", IsoValue.ISO_400.label)
        assertEquals(400, IsoValue.ISO_400.value)

        assertEquals("3200K (Tungsten)", WhiteBalancePreset.TUNGSTEN.label)
        assertEquals(3200, WhiteBalancePreset.TUNGSTEN.kelvin)

        assertEquals("None", GridType.NONE.label)
        assertEquals("3x3 Rule of Thirds", GridType.RULE_OF_THIRDS.label)

        assertEquals(2.39f, AspectRatioGuide.SCOPE_2_39.ratio)
    }

    @Test
    fun testFilmLooksCollection() {
        assertTrue(FilmLook.ALL_LOOKS.isNotEmpty())
        val tealOrange = FilmLook.ALL_LOOKS.find { it.id == "teal_orange" }
        assertNotNull(tealOrange)
        assertEquals("Teal & Orange", tealOrange?.name)

        val bw = FilmLook.ALL_LOOKS.find { it.id == "bw_tri_x" }
        assertNotNull(bw)
        assertTrue(bw?.isBw == true)
    }

    @Test
    fun testMediaItemFormatting() {
        val video = MediaItem(
            id = "test_vid",
            title = "A001_C001.MP4",
            uriString = "file:///tmp/vid.mp4",
            filePath = "/tmp/vid.mp4",
            mimeType = "video/mp4",
            isVideo = true,
            durationMs = 65400L,
            width = 3840,
            height = 2160,
            sizeBytes = 104857600L // 100 MB
        )

        assertEquals("01:05.40", video.formattedDuration)
        assertEquals("4K UHD", video.resolutionLabel)
        assertEquals("MP4", video.extension)
        assertTrue(video.formattedSize.contains("MB"))
    }
}
