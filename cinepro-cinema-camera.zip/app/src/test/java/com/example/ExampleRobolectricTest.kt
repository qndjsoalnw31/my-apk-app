package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleRobolectricTest {
    @Test
    fun testAppIdentifier() {
        assertEquals("CinePro", "CinePro")
    }
}
