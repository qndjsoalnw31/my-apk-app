package com.example.chess

import com.example.chess.engine.BoardState
import com.example.chess.engine.FenUtils
import com.example.chess.engine.MoveGenerator
import com.example.chess.engine.StockfishEngine
import com.example.chess.model.EngineMode
import com.example.chess.model.EngineStrength
import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import com.example.chess.state.ChessStateHolder
import com.example.chess.state.EditSubMode
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ChessAuditedFeaturesTest {

    @Before
    fun setUp() {
        ChessStateHolder.resetGame()
        if (ChessStateHolder.isEditMode.value) {
            ChessStateHolder.toggleEditMode()
        }
    }

    // 1. وضعية فيها Checkmate مباشر للملك ويجب أن يجد التطبيق الدفاع الصحيح.
    @Test
    fun test1_immediateCheckmateThreat_findsCorrectDefense() = runBlocking {
        // Scholar's Mate threat position:
        // White: e4, Bc4, Qh5
        // Black: e5, Nc6, a6 (Black ignored threat on f7)
        // White threatens Qxf7#
        val fen = "r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 3 3"
        val state = FenUtils.parseFen(fen)
        assertEquals(PieceColor.BLACK, state.activeColor)

        val result = StockfishEngine.analyzePosition(
            state = state,
            userColor = PieceColor.BLACK,
            mode = EngineMode.BALANCED,
            strength = EngineStrength.MASTER
        )

        assertNotNull(result.bestMove)
        val bestMove = result.bestMove!!.move
        val stateAfterDefense = MoveGenerator.makeMove(state, bestMove)

        // Ensure Black's chosen move prevents immediate mate in 1
        val whiteReplies = MoveGenerator.generateLegalMoves(stateAfterDefense, PieceColor.WHITE)
        val whiteHasMate = whiteReplies.any { oppM ->
            val afterWhite = MoveGenerator.makeMove(stateAfterDefense, oppM)
            MoveGenerator.isInCheck(afterWhite, PieceColor.BLACK) &&
                    MoveGenerator.generateLegalMoves(afterWhite, PieceColor.BLACK).isEmpty()
        }
        assertFalse("Best move chosen by engine must prevent immediate checkmate!", whiteHasMate)
    }

    // 2. وضعية فيها أكثر من نقلة عادية لكن نقلة واحدة فقط تمنع Checkmate.
    @Test
    fun test2_onlyOneMovePreventsCheckmate() = runBlocking {
        // Position where Black has several moves (moving pawns a6, b6, h6, etc.),
        // but White threatens Qh7# or Qg7#, and only 1 move stops it.
        // Setup:
        // White: King on g1, Queen on d3, Bishop on c2 (battery on b1-h7)
        // Black: King on g8, pawns on f7, g7, h7, pawn on a7, pawn on b7, pawn on c7
        // White Queen + Bishop battery threatens Qxh7#
        // If Black plays g6, it blocks the battery! All other pawn moves (a6, b6, etc.) allow Qxh7#
        val fen = "r1bq1rk1/ppp2ppp/2n5/8/8/3Q4/PPB2PPP/RNB1K2R b KQ - 0 1"
        val state = FenUtils.parseFen(fen)

        val result = StockfishEngine.analyzePosition(
            state = state,
            userColor = PieceColor.BLACK,
            mode = EngineMode.BALANCED,
            strength = EngineStrength.MASTER
        )

        assertNotNull(result.bestMove)
        val bestMove = result.bestMove!!.move
        val stateAfter = MoveGenerator.makeMove(state, bestMove)

        // Verify that after Black's move, White CANNOT mate in 1
        val whiteReplies = MoveGenerator.generateLegalMoves(stateAfter, PieceColor.WHITE)
        val whiteCanMate = whiteReplies.any { wM ->
            val afterW = MoveGenerator.makeMove(stateAfter, wM)
            MoveGenerator.isInCheck(afterW, PieceColor.BLACK) &&
                    MoveGenerator.generateLegalMoves(afterW, PieceColor.BLACK).isEmpty()
        }
        assertFalse("Engine must pick the defense that avoids immediate checkmate", whiteCanMate)
    }

    // 3. وضعية لا يوجد فيها أي تهديد مباشر، ويجب أن يعمل المحرك الحالي بشكل طبيعي.
    @Test
    fun test3_noDirectThreat_normalEngineEvaluation() = runBlocking {
        val initialBoard = FenUtils.parseFen(FenUtils.INITIAL_FEN)
        val result = StockfishEngine.analyzePosition(
            state = initialBoard,
            userColor = PieceColor.WHITE,
            mode = EngineMode.BALANCED,
            strength = EngineStrength.MASTER
        )

        assertNotNull(result.bestMove)
        assertFalse(result.isCheck)
        assertFalse(result.isCheckmate)
        assertFalse(result.isStalemate)
        assertTrue(result.topLines.isNotEmpty())
    }

    // 4. وضعية فيها Check ويجب التعامل معها قانونيًا.
    @Test
    fun test4_positionInCheck_mustHandleLegally() = runBlocking {
        // Position where Black Queen gives check to White King on e1
        // White can block with Be2, Qe2, Ne2, etc.
        val fen = "rnb1kbnr/pppp1ppp/8/8/4q3/8/PPPPBPPP/RNBQK1NR w KQkq - 2 4"
        val state = FenUtils.parseFen(fen)
        // Let's create an explicit check: Queen on e7 checks King on e1 with e-file open
        val checkFen = "rnb1kbnr/ppppqppp/8/8/8/8/PPPP1PPP/RNBQKBNR w KQkq - 1 3"
        val checkState = FenUtils.parseFen(checkFen)
        assertTrue("White must be in check", MoveGenerator.isInCheck(checkState, PieceColor.WHITE))

        val result = StockfishEngine.analyzePosition(
            state = checkState,
            userColor = PieceColor.WHITE,
            mode = EngineMode.BALANCED,
            strength = EngineStrength.MASTER
        )

        assertNotNull(result.bestMove)
        assertTrue(result.isCheck)
        val stateAfter = MoveGenerator.makeMove(checkState, result.bestMove!!.move)
        assertFalse("After legal defense, King must NOT be in check", MoveGenerator.isInCheck(stateAfter, PieceColor.WHITE))
    }

    // 5. تحريك الملك في Edit Mode والتأكد من عدم بقاء Castling Rights القديمة.
    @Test
    fun test5_editMode_moveKing_clearsCastlingRights() {
        ChessStateHolder.toggleEditMode()
        assertTrue(ChessStateHolder.isEditMode.value)

        // White King is on e1 (4, 0). Move to e2 (4, 1)
        ChessStateHolder.movePieceDirectly(Square(4, 0), Square(4, 1))

        val board = ChessStateHolder.boardState.value
        assertNull(board.getPiece(Square(4, 0)))
        assertEquals(PieceType.KING, board.getPiece(Square(4, 1))?.type)
        assertFalse("White kingside castling must be false when King moves", board.whiteCanCastleKingside)
        assertFalse("White queenside castling must be false when King moves", board.whiteCanCastleQueenside)
    }

    // 6. تحريك أو حذف الرخ والتأكد من تحديث Castling Rights.
    @Test
    fun test6_editMode_moveOrDeleteRook_updatesCastlingRights() {
        ChessStateHolder.toggleEditMode()

        // Remove White kingside rook on h1 (7, 0)
        ChessStateHolder.removePiece(Square(7, 0))
        var board = ChessStateHolder.boardState.value
        assertFalse("White kingside castling must be false after h1 rook removed", board.whiteCanCastleKingside)
        assertTrue("White queenside castling remains true if a1 rook untouched", board.whiteCanCastleQueenside)

        // Move White queenside rook from a1 (0, 0) to a2 (0, 1)
        ChessStateHolder.movePieceDirectly(Square(0, 0), Square(0, 1))
        board = ChessStateHolder.boardState.value
        assertFalse("White queenside castling must be false after a1 rook moved", board.whiteCanCastleQueenside)
    }

    // 7. تعديل بيدق والتأكد من عدم بقاء En Passant قديم.
    @Test
    fun test7_editMode_modifyPawn_clearsEnPassant() {
        // Create state with active en passant
        val fenWithEp = "rnbqkbnr/ppp1pppp/8/3pP3/8/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 3"
        ChessStateHolder.loadFen(fenWithEp)
        assertEquals(Square(3, 5), ChessStateHolder.boardState.value.enPassantSquare)

        ChessStateHolder.toggleEditMode()
        // Move a piece in edit mode
        ChessStateHolder.movePieceDirectly(Square(0, 1), Square(0, 2))

        val board = ChessStateHolder.boardState.value
        assertNull("En passant must be cleared after edit operation", board.enPassantSquare)
    }

    // 8. حذف قطعة.
    @Test
    fun test8_editMode_deletePiece() {
        ChessStateHolder.toggleEditMode()
        assertNotNull(ChessStateHolder.boardState.value.getPiece(Square(3, 1))) // d2 pawn

        ChessStateHolder.removePiece(Square(3, 1))
        assertNull("Piece at d2 must be removed", ChessStateHolder.boardState.value.getPiece(Square(3, 1)))
        assertTrue("Captured white list should contain the removed pawn", ChessStateHolder.capturedPiecesWhite.value.any { it.type == PieceType.PAWN })
    }

    // 9. إضافة قطعة.
    @Test
    fun test9_editMode_addPiece() {
        ChessStateHolder.toggleEditMode()
        assertNull(ChessStateHolder.boardState.value.getPiece(Square(4, 4))) // e5 empty

        val queen = Piece(PieceType.QUEEN, PieceColor.WHITE)
        ChessStateHolder.addPieceDirectly(Square(4, 4), queen)

        val placed = ChessStateHolder.boardState.value.getPiece(Square(4, 4))
        assertNotNull(placed)
        assertEquals(PieceType.QUEEN, placed?.type)
        assertEquals(PieceColor.WHITE, placed?.color)
    }

    // 10. تحريك قطعة إلى مربع فارغ.
    @Test
    fun test10_editMode_movePieceToEmptySquare() {
        ChessStateHolder.toggleEditMode()
        val e2Pawn = ChessStateHolder.boardState.value.getPiece(Square(4, 1))
        assertNotNull(e2Pawn)

        ChessStateHolder.movePieceDirectly(Square(4, 1), Square(4, 3)) // e2 to e4
        assertNull("e2 must be null after move", ChessStateHolder.boardState.value.getPiece(Square(4, 1)))
        assertEquals(e2Pawn, ChessStateHolder.boardState.value.getPiece(Square(4, 3)))
    }

    // 11. تحريك قطعة إلى مربع مشغول (استبدال وليس تبديل).
    @Test
    fun test11_editMode_movePieceToOccupiedSquare_replacesNotSwaps() {
        ChessStateHolder.toggleEditMode()
        // White Queen on d1 (3, 0), Black Pawn on d7 (3, 6)
        val queen = ChessStateHolder.boardState.value.getPiece(Square(3, 0))
        val blackPawn = ChessStateHolder.boardState.value.getPiece(Square(3, 6))
        assertNotNull(queen)
        assertNotNull(blackPawn)

        ChessStateHolder.movePieceDirectly(Square(3, 0), Square(3, 6))

        val origin = ChessStateHolder.boardState.value.getPiece(Square(3, 0))
        val target = ChessStateHolder.boardState.value.getPiece(Square(3, 6))

        assertNull("Origin square d1 must be empty!", origin)
        assertNotEquals("Origin square must NOT receive the target piece (no accidental swap)!", blackPawn, origin)
        assertEquals("Target square d7 must now hold the White Queen", queen, target)
    }

    // 12. عدة تعديلات متتالية ثم Undo.
    @Test
    fun test12_editMode_multipleEditsThenUndo() {
        ChessStateHolder.toggleEditMode()
        val initialFen = FenUtils.toFen(ChessStateHolder.boardState.value)

        // Edit 1: delete e2
        ChessStateHolder.removePiece(Square(4, 1))
        // Edit 2: add Queen to e4
        ChessStateHolder.addPieceDirectly(Square(4, 3), Piece(PieceType.QUEEN, PieceColor.WHITE))
        // Edit 3: delete a7
        ChessStateHolder.removePiece(Square(0, 6))

        assertTrue(ChessStateHolder.canUndoEdit.value)

        // Undo edit 3
        ChessStateHolder.undoEdit()
        assertNotNull("a7 pawn should be restored after undoing edit 3", ChessStateHolder.boardState.value.getPiece(Square(0, 6)))

        // Undo edit 2
        ChessStateHolder.undoEdit()
        assertNull("e4 queen should be removed after undoing edit 2", ChessStateHolder.boardState.value.getPiece(Square(4, 3)))

        // Undo edit 1
        ChessStateHolder.undoEdit()
        val restoredFen = FenUtils.toFen(ChessStateHolder.boardState.value)
        assertEquals("Board must match initial FEN after undoing all edits", initialFen, restoredFen)
    }

    // 13. Undo ثم Redo.
    @Test
    fun test13_editMode_undoThenRedo() {
        ChessStateHolder.toggleEditMode()
        // Delete d2 pawn
        ChessStateHolder.removePiece(Square(3, 1))
        assertNull(ChessStateHolder.boardState.value.getPiece(Square(3, 1)))

        // Undo
        ChessStateHolder.undoEdit()
        assertNotNull("Pawn on d2 restored", ChessStateHolder.boardState.value.getPiece(Square(3, 1)))
        assertTrue("canRedoEdit should be true after undo", ChessStateHolder.canRedoEdit.value)

        // Redo
        ChessStateHolder.redoEdit()
        assertNull("Pawn on d2 removed again after redo", ChessStateHolder.boardState.value.getPiece(Square(3, 1)))
    }

    // 14. إنشاء وضعية جديدة بالكامل ثم الخروج من Edit Mode وتشغيل التحليل.
    @Test
    fun test14_createCustomPosition_exitEditMode_runsAnalysisSuccessfully() = runBlocking {
        ChessStateHolder.toggleEditMode()

        // Create endgame: White King on e1, Rook on a1; Black King on e8
        for (r in 0..7) {
            for (f in 0..7) {
                ChessStateHolder.boardState.value.setPiece(Square(f, r), null)
            }
        }
        ChessStateHolder.addPieceDirectly(Square(4, 0), Piece(PieceType.KING, PieceColor.WHITE))
        ChessStateHolder.addPieceDirectly(Square(0, 0), Piece(PieceType.ROOK, PieceColor.WHITE))
        ChessStateHolder.addPieceDirectly(Square(4, 7), Piece(PieceType.KING, PieceColor.BLACK))

        // Exit edit mode
        ChessStateHolder.toggleEditMode()
        assertFalse(ChessStateHolder.isEditMode.value)

        // Trigger and check analysis
        val result = StockfishEngine.analyzePosition(
            state = ChessStateHolder.boardState.value,
            userColor = PieceColor.WHITE,
            mode = EngineMode.BALANCED,
            strength = EngineStrength.MASTER
        )

        assertNotNull(result.bestMove)
        assertTrue(result.topLines.isNotEmpty())
    }

    // 15. التأكد أن Move History القديمة لا تجعل الوضعية الجديدة غير متناسقة.
    @Test
    fun test15_oldMoveHistoryDisconnectedFromNewPosition() {
        // Play e4 in standard mode
        val e2 = Square(4, 1)
        val e4 = Square(4, 3)
        val e2Piece = ChessStateHolder.boardState.value.getPiece(e2)!!
        ChessStateHolder.makeMove(com.example.chess.model.Move(from = e2, to = e4, piece = e2Piece))
        assertEquals(1, ChessStateHolder.moveHistory.value.size)

        // Enter and exit edit mode to establish new position
        ChessStateHolder.toggleEditMode()
        ChessStateHolder.removePiece(Square(0, 6)) // modify board
        ChessStateHolder.toggleEditMode()

        // Assert old history is disconnected
        assertTrue("Move history must be empty after exiting edit mode", ChessStateHolder.moveHistory.value.isEmpty())
        assertTrue("Quality log must be empty after exiting edit mode", ChessStateHolder.qualityLog.value.isEmpty())
    }

    // 16. التأكد أن التطبيق لا يعطي نقلة غير قانونية بعد التعديل.
    @Test
    fun test16_noIllegalMovesGeneratedAfterModification() {
        ChessStateHolder.toggleEditMode()
        // Move White King to e2
        ChessStateHolder.movePieceDirectly(Square(4, 0), Square(4, 1))
        // Put Black Rook on e8 checking King on e2
        ChessStateHolder.addPieceDirectly(Square(4, 7), Piece(PieceType.ROOK, PieceColor.BLACK))
        ChessStateHolder.toggleEditMode()

        val board = ChessStateHolder.boardState.value
        val legalMoves = MoveGenerator.generateLegalMoves(board, PieceColor.WHITE)

        // Every legal move must leave White King not in check
        for (m in legalMoves) {
            val nextSt = MoveGenerator.makeMove(board, m)
            assertFalse("Move $m must not leave king in check", MoveGenerator.isInCheck(nextSt, PieceColor.WHITE))
        }
    }
}
