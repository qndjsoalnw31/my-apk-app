package com.example.chess.engine

import com.example.chess.model.EngineMode
import com.example.chess.model.EngineStrength
import com.example.chess.model.PieceColor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TacticalSafetyTest {

    /**
     * اختبار 1:
     * المستخدم = WHITE
     * يوجد Check على BLACK
     * يجب ألا يظهر تحذير دفاعي للمستخدم.
     */
    @Test
    fun testUserWhite_OpponentBlackInCheck_NoDefensiveWarningForUser() = runBlocking {
        // Black King on e8 is in check by White Queen on e2.
        // It is Black's turn (b). User is WHITE.
        val fen = "4k3/8/8/8/8/8/4Q3/4K3 b - - 0 1"
        val state = FenUtils.parseFen(fen)

        // Verify that Black is in check and White is NOT in check
        assertTrue("Black should be in check", MoveGenerator.isInCheck(state, PieceColor.BLACK))
        assertFalse("White should NOT be in check", MoveGenerator.isInCheck(state, PieceColor.WHITE))

        val result = StockfishEngine.analyzePosition(
            state = state,
            userColor = PieceColor.WHITE,
            mode = EngineMode.QUICK,
            strength = EngineStrength.BEGINNER
        )

        // isCheck in AnalysisResult represents whether the USER is in check
        assertFalse("User (WHITE) must NOT have isCheck = true", result.isCheck)
        assertFalse("User (WHITE) is not in check", result.isUserInCheck)
        assertTrue("Opponent (BLACK) is in check", result.isOpponentInCheck)

        // Must NOT contain defensive warning words directed at the user
        val alert = result.tacticAlertAr ?: ""
        val desc = result.threatDescriptionAr

        assertFalse("Alert must not contain defensive warning 'الدفاع الإجباري'", alert.contains("الدفاع الإجباري"))
        assertFalse("Alert must not contain 'ملكك في كش'", alert.contains("ملكك في كش"))
        assertFalse("Alert must not contain 'كش مات ضدك'", alert.contains("كش مات ضدك"))

        assertFalse("Description must not demand user defense 'يجب الدفاع'", desc.contains("يجب الدفاع"))
        assertFalse("Description must not claim user king is under threat 'ملكك تحت التهديد'", desc.contains("ملكك تحت التهديد"))
        assertTrue("Description or alert should recognize offensive opportunity or opponent turn",
            desc.contains("فرصة هجومية") || desc.contains("المنافس") || alert.contains("فرصة هجومية"))
    }

    /**
     * اختبار 2:
     * المستخدم = BLACK
     * يوجد Check على WHITE
     * يجب ألا يظهر تحذير دفاعي للمستخدم.
     */
    @Test
    fun testUserBlack_OpponentWhiteInCheck_NoDefensiveWarningForUser() = runBlocking {
        // White King on e1 is in check by Black Queen on e2.
        // It is White's turn (w). User is BLACK.
        val fen = "4k3/8/8/8/8/8/4q3/4K3 w - - 0 1"
        val state = FenUtils.parseFen(fen)

        // Verify that White is in check and Black is NOT in check
        assertTrue("White should be in check", MoveGenerator.isInCheck(state, PieceColor.WHITE))
        assertFalse("Black should NOT be in check", MoveGenerator.isInCheck(state, PieceColor.BLACK))

        val result = StockfishEngine.analyzePosition(
            state = state,
            userColor = PieceColor.BLACK,
            mode = EngineMode.QUICK,
            strength = EngineStrength.BEGINNER
        )

        // isCheck in AnalysisResult represents whether the USER is in check
        assertFalse("User (BLACK) must NOT have isCheck = true", result.isCheck)
        assertFalse("User (BLACK) is not in check", result.isUserInCheck)
        assertTrue("Opponent (WHITE) is in check", result.isOpponentInCheck)

        // Must NOT contain defensive warning words directed at the user
        val alert = result.tacticAlertAr ?: ""
        val desc = result.threatDescriptionAr

        assertFalse("Alert must not contain defensive warning 'الدفاع الإجباري'", alert.contains("الدفاع الإجباري"))
        assertFalse("Alert must not contain 'ملكك في كش'", alert.contains("ملكك في كش"))
        assertFalse("Alert must not contain 'كش مات ضدك'", alert.contains("كش مات ضدك"))

        assertFalse("Description must not demand user defense 'يجب الدفاع'", desc.contains("يجب الدفاع"))
        assertFalse("Description must not claim user king is under threat 'ملكك تحت التهديد'", desc.contains("ملكك تحت التهديد"))
        assertTrue("Description or alert should recognize offensive opportunity or opponent turn",
            desc.contains("فرصة هجومية") || desc.contains("المنافس") || alert.contains("فرصة هجومية"))
    }

    /**
     * اختبار إضافي:
     * المستخدم = WHITE وهو في Check
     * يجب أن يظهر تحذير دفاعي للمستخدم.
     */
    @Test
    fun testUserWhite_InCheck_ShowsDefensiveWarning() = runBlocking {
        val fen = "4k3/8/8/8/8/8/4q3/4K3 w - - 0 1"
        val state = FenUtils.parseFen(fen)

        val result = StockfishEngine.analyzePosition(
            state = state,
            userColor = PieceColor.WHITE,
            mode = EngineMode.QUICK,
            strength = EngineStrength.BEGINNER
        )

        assertTrue("User (WHITE) must have isCheck = true", result.isCheck)
        assertTrue("User (WHITE) is in check", result.isUserInCheck)
        assertFalse("Opponent (BLACK) is NOT in check", result.isOpponentInCheck)
    }

    /**
     * اختبار إضافي:
     * المستخدم = BLACK وهو في Check
     * يجب أن يظهر تحذير دفاعي للمستخدم.
     */
    @Test
    fun testUserBlack_InCheck_ShowsDefensiveWarning() = runBlocking {
        val fen = "4k3/8/8/8/8/8/4Q3/4K3 b - - 0 1"
        val state = FenUtils.parseFen(fen)

        val result = StockfishEngine.analyzePosition(
            state = state,
            userColor = PieceColor.BLACK,
            mode = EngineMode.QUICK,
            strength = EngineStrength.BEGINNER
        )

        assertTrue("User (BLACK) must have isCheck = true", result.isCheck)
        assertTrue("User (BLACK) is in check", result.isUserInCheck)
        assertFalse("Opponent (WHITE) is NOT in check", result.isOpponentInCheck)
    }
}
