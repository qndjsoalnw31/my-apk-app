package com.example.chess.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.chessassistant.rqxptz.R
import com.example.chess.engine.FenUtils
import com.example.chess.model.PieceColor
import com.example.chess.ui.components.AnalysisGaugeCard
import com.example.chess.ui.components.CapturedPiecesBar
import com.example.chess.ui.components.ChessBoardView
import com.example.chess.ui.components.MoveHistoryPanel
import com.example.chess.ui.components.OpeningBadgeCard
import com.example.chess.ui.dialogs.AiCoachDialog
import com.example.chess.ui.dialogs.EngineSettingsDialog
import com.example.chess.ui.dialogs.GameReviewDialog
import com.example.chess.ui.dialogs.SavedGamesDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChessAssistantScreen(viewModel: ChessViewModel) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val boardState by viewModel.boardState.collectAsState()
    val isEditMode by viewModel.isEditMode.collectAsState()
    val editSubMode by viewModel.editSubMode.collectAsState()
    val canUndoEdit by viewModel.canUndoEdit.collectAsState()
    val canRedoEdit by viewModel.canRedoEdit.collectAsState()
    val editHintMessage by viewModel.editHintMessage.collectAsState()
    val userColor by viewModel.userColor.collectAsState()
    val isFlipped by viewModel.isFlipped.collectAsState()
    val moveHistory by viewModel.moveHistory.collectAsState()
    val analysisResult by viewModel.analysisResult.collectAsState()
    val isAnalyzing by viewModel.isAnalyzing.collectAsState()
    val selectedSquare by viewModel.selectedSquare.collectAsState()
    val legalMoves by viewModel.legalMoves.collectAsState()
    val engineMode by viewModel.engineMode.collectAsState()
    val engineStrength by viewModel.engineStrength.collectAsState()
    val topLinesCount by viewModel.topLinesCount.collectAsState()
    val qualityLog by viewModel.qualityLog.collectAsState()
    val capturedWhite by viewModel.capturedWhite.collectAsState()
    val capturedBlack by viewModel.capturedBlack.collectAsState()
    val savedGames by viewModel.savedGames.collectAsState()

    val openingInfo by viewModel.openingInfo.collectAsState()
    val aiCoachAdvice by viewModel.aiCoachAdvice.collectAsState()
    val isAskingCoach by viewModel.isAskingCoach.collectAsState()
    val appMode by viewModel.appMode.collectAsState()
    val currentPuzzle by viewModel.currentPuzzle.collectAsState()
    val puzzleFeedback by viewModel.puzzleFeedback.collectAsState()
    val puzzleSolved by viewModel.puzzleSolved.collectAsState()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showReviewDialog by remember { mutableStateOf(false) }
    var showSavedGamesDialog by remember { mutableStateOf(false) }
    var showCoachDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (appMode == AppMode.ANALYSIS) "مساعد الشطرنج الذكي" else "تمارين التكتيك واللغز",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Text(
                            text = "${engineMode.labelAr} • Stockfish & Gemini AI",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            showCoachDialog = true
                            if (aiCoachAdvice == null) {
                                viewModel.askAiCoach()
                            }
                        },
                        modifier = Modifier.testTag("top_ai_coach_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "مدرب الذكاء الاصطناعي",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleFloatingOverlay(context) },
                        modifier = Modifier.testTag("floating_overlay_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureInPictureAlt,
                            contentDescription = "النافذة العائمة",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleEditMode() },
                        modifier = Modifier.testTag("edit_mode_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isEditMode) Icons.Default.Check else Icons.Default.Edit,
                            contentDescription = if (isEditMode) "إنهاء وضع التعديل" else "تعديل الرقعة",
                            tint = if (isEditMode) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(
                        onClick = { showSavedGamesDialog = true },
                        modifier = Modifier.testTag("saved_games_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "المباريات المحفوظة"
                        )
                    }

                    IconButton(
                        onClick = { showReviewDialog = true },
                        modifier = Modifier.testTag("game_review_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = "تحليل المباراة"
                        )
                    }

                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier.testTag("engine_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "الإعدادات"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            val isWide = maxWidth > maxHeight && maxHeight > 250.dp

            Column(modifier = Modifier.fillMaxSize()) {
                // Main App Mode Switcher (Analysis vs Puzzle)
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    SegmentedButton(
                        selected = (appMode == AppMode.ANALYSIS),
                        onClick = { viewModel.setAppMode(AppMode.ANALYSIS) },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Analytics, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مساعد المباراة والتحليل", fontSize = 12.sp)
                        }
                    }

                    SegmentedButton(
                        selected = (appMode == AppMode.PUZZLE),
                        onClick = { viewModel.setAppMode(AppMode.PUZZLE) },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Extension, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تمارين التكتيك", fontSize = 12.sp)
                        }
                    }
                }

                if (isWide) {
                    // Wide / Landscape Layout
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            ChessBoardView(
                                boardState = boardState,
                                isFlipped = isFlipped,
                                selectedSquare = selectedSquare,
                                legalMoves = legalMoves,
                                analysisResult = analysisResult,
                                userColor = userColor,
                                isEditMode = isEditMode,
                                onSquareClick = { sq -> viewModel.selectSquare(sq) },
                                onMoveAttempt = { _, _ -> },
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Column(
                            modifier = Modifier
                                .weight(1.1f)
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (appMode == AppMode.PUZZLE) {
                                // Puzzle Feedback & Controls
                                currentPuzzle?.let { puz ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text(text = puz.titleAr, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text(text = "الفئة: ${puz.categoryAr}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(text = puzzleFeedback ?: "", fontSize = 12.sp)

                                            Spacer(modifier = Modifier.height(8.dp))
                                            Button(
                                                onClick = { viewModel.nextPuzzle() },
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(imageVector = Icons.AutoMirrored.Filled.NavigateNext, contentDescription = null)
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("اللغز التالي 🎯")
                                            }
                                        }
                                    }
                                }
                            } else {
                                // Opening Book Recognized Badge
                                OpeningBadgeCard(openingInfo = openingInfo)

                                // Side Selector Bar
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "جانب اللعب:",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )

                                        SingleChoiceSegmentedButtonRow {
                                            SegmentedButton(
                                                selected = (userColor == PieceColor.WHITE),
                                                onClick = { viewModel.selectUserColor(PieceColor.WHITE) },
                                                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                                            ) {
                                                Text("الأبيض ♔", fontSize = 11.sp)
                                            }

                                            SegmentedButton(
                                                selected = (userColor == PieceColor.BLACK),
                                                onClick = { viewModel.selectUserColor(PieceColor.BLACK) },
                                                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                                            ) {
                                                Text("الأسود ♚", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }

                                CapturedPiecesBar(
                                    capturedWhite = capturedWhite,
                                    capturedBlack = capturedBlack
                                )

                                // Controls Toolbar
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { viewModel.undoMove() },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(imageVector = Icons.AutoMirrored.Filled.Undo, contentDescription = "تراجع", modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text("تراجع", fontSize = 10.sp)
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.resetGame() },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "إعادة", modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text("إعادة", fontSize = 10.sp)
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.flipBoard() },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Flip, contentDescription = "قلب", modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text("قلب", fontSize = 10.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val currentFen = FenUtils.toFen(boardState)
                                            clipboardManager.setText(AnnotatedString(currentFen))
                                            Toast.makeText(context, "تم نسخ FEN الحالية", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "نسخ FEN", modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text("FEN", fontSize = 10.sp)
                                    }
                                }

                                AnalysisGaugeCard(
                                    analysisResult = analysisResult,
                                    isAnalyzing = isAnalyzing,
                                    userColor = userColor,
                                    activeColor = boardState.activeColor,
                                    onAskCoachClick = {
                                        showCoachDialog = true
                                        if (aiCoachAdvice == null) {
                                            viewModel.askAiCoach()
                                        }
                                    }
                                )

                                MoveHistoryPanel(moves = moveHistory)
                            }
                        }
                    }
                } else {
                    // Portrait / Single Column Layout
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (appMode == AppMode.ANALYSIS) {
                            // Hero Graphic Banner Header
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(72.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_chess_banner_1785189329343),
                                    contentDescription = "Chess AI Banner",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }

                            // Opening Book Badge
                            OpeningBadgeCard(openingInfo = openingInfo)

                            // Side Selector Bar
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "جانب اللعب الخاص بك:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    SingleChoiceSegmentedButtonRow {
                                        SegmentedButton(
                                            selected = (userColor == PieceColor.WHITE),
                                            onClick = { viewModel.selectUserColor(PieceColor.WHITE) },
                                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                                        ) {
                                            Text("الأبيض ♔", fontSize = 12.sp)
                                        }

                                        SegmentedButton(
                                            selected = (userColor == PieceColor.BLACK),
                                            onClick = { viewModel.selectUserColor(PieceColor.BLACK) },
                                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                                        ) {
                                            Text("الأسود ♚", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        } else {
                            // Puzzle Banner Mode
                            currentPuzzle?.let { puz ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(text = puz.titleAr, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Surface(
                                                color = MaterialTheme.colorScheme.primary,
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = puz.categoryAr,
                                                    color = Color.White,
                                                    fontSize = 10.sp,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = puzzleFeedback ?: "", fontSize = 12.sp)

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Button(
                                            onClick = { viewModel.nextPuzzle() },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(imageVector = Icons.AutoMirrored.Filled.NavigateNext, contentDescription = null)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("التدريب التالي 🎯")
                                        }
                                    }
                                }
                            }
                        }

                        CapturedPiecesBar(
                            capturedWhite = capturedWhite,
                            capturedBlack = capturedBlack
                        )

                        AnimatedVisibility(visible = isEditMode) {
                            EditControlsBanner(
                                editSubMode = editSubMode,
                                activeColor = boardState.activeColor,
                                canUndoEdit = canUndoEdit,
                                canRedoEdit = canRedoEdit,
                                editHintMessage = editHintMessage,
                                selectedSquare = selectedSquare,
                                onSetSubMode = { mode -> viewModel.setEditSubMode(mode) },
                                onToggleActiveColor = { viewModel.toggleActiveColorInEditMode() },
                                onUndoEdit = { viewModel.undoEdit() },
                                onRedoEdit = { viewModel.redoEdit() },
                                onAddPiece = { sq, piece -> com.example.chess.state.ChessStateHolder.addPieceDirectly(sq, piece) }
                            )
                        }

                        ChessBoardView(
                            boardState = boardState,
                            isFlipped = isFlipped,
                            selectedSquare = selectedSquare,
                            legalMoves = legalMoves,
                            analysisResult = analysisResult,
                            userColor = userColor,
                            isEditMode = isEditMode,
                            onSquareClick = { sq -> viewModel.selectSquare(sq) },
                            onMoveAttempt = { _, _ -> },
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (appMode == AppMode.ANALYSIS) {
                            // Controls Toolbar
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { viewModel.undoMove() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(imageVector = Icons.AutoMirrored.Filled.Undo, contentDescription = "تراجع", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تراجع", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.resetGame() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "إعادة", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إعادة", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.flipBoard() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Flip, contentDescription = "قلب", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("قلب", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        val currentFen = FenUtils.toFen(boardState)
                                        clipboardManager.setText(AnnotatedString(currentFen))
                                        Toast.makeText(context, "تم نسخ FEN الحالية", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "نسخ FEN", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("FEN", fontSize = 11.sp)
                                }
                            }

                            AnalysisGaugeCard(
                                analysisResult = analysisResult,
                                isAnalyzing = isAnalyzing,
                                userColor = userColor,
                                activeColor = boardState.activeColor,
                                onAskCoachClick = {
                                    showCoachDialog = true
                                    if (aiCoachAdvice == null) {
                                        viewModel.askAiCoach()
                                    }
                                }
                            )

                            MoveHistoryPanel(moves = moveHistory)
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }

    // Dialogs
    if (showCoachDialog) {
        AiCoachDialog(
            aiAdvice = aiCoachAdvice,
            isLoading = isAskingCoach,
            onAskCoach = { topic -> viewModel.askAiCoach(topic) },
            onDismiss = { showCoachDialog = false }
        )
    }

    if (showSettingsDialog) {
        EngineSettingsDialog(
            currentMode = engineMode,
            currentStrength = engineStrength,
            currentTopLines = topLinesCount,
            onDismiss = { showSettingsDialog = false },
            onApply = { mode, strength, topCount ->
                viewModel.updateEngineSettings(mode, strength, topCount)
            }
        )
    }

    if (showReviewDialog) {
        GameReviewDialog(
            qualityLog = qualityLog,
            onDismiss = { showReviewDialog = false },
            onSaveGame = {
                viewModel.saveCurrentGame("مباراة شطرنج")
                Toast.makeText(context, "تم حفظ المباراة في قاعدة البيانات", Toast.LENGTH_SHORT).show()
                showReviewDialog = false
            },
            onSharePgn = {
                val pgn = com.example.chess.engine.PgnUtils.exportPgn(moveHistory = moveHistory)
                clipboardManager.setText(AnnotatedString(pgn))
                Toast.makeText(context, "تم نسخ صيغة PGN إلى الحافظة", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showSavedGamesDialog) {
        SavedGamesDialog(
            games = savedGames,
            onDismiss = { showSavedGamesDialog = false },
            onLoadGame = { game ->
                viewModel.loadFen(game.fen)
                Toast.makeText(context, "تم تحميل الوضعية بنجاح", Toast.LENGTH_SHORT).show()
            },
            onDeleteGame = { id -> viewModel.deleteGame(id) },
            onImportFen = { fen -> viewModel.loadFen(fen) }
        )
    }
}

@Composable
private fun EditControlsBanner(
    editSubMode: com.example.chess.state.EditSubMode,
    activeColor: PieceColor,
    canUndoEdit: Boolean,
    canRedoEdit: Boolean,
    editHintMessage: String?,
    selectedSquare: com.example.chess.model.Square?,
    onSetSubMode: (com.example.chess.state.EditSubMode) -> Unit,
    onToggleActiveColor: () -> Unit,
    onUndoEdit: () -> Unit,
    onRedoEdit: () -> Unit,
    onAddPiece: (com.example.chess.model.Square, com.example.chess.model.Piece) -> Unit
) {
    Surface(
        color = Color(0xFF1E293B),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Move button
                    Surface(
                        color = if (editSubMode == com.example.chess.state.EditSubMode.MOVE) Color(0xFFF59E0B) else Color(0xFF334155),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.clickable { onSetSubMode(com.example.chess.state.EditSubMode.MOVE) }
                    ) {
                        Text(
                            text = "↔️ نقل",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (editSubMode == com.example.chess.state.EditSubMode.MOVE) Color.Black else Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }

                    // Eat button
                    Surface(
                        color = if (editSubMode == com.example.chess.state.EditSubMode.EAT_REMOVE) Color(0xFFEF4444) else Color(0xFF334155),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.clickable { onSetSubMode(com.example.chess.state.EditSubMode.EAT_REMOVE) }
                    ) {
                        Text(
                            text = "🗡️ أكل",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }

                    // Undo
                    Surface(
                        color = if (canUndoEdit) Color(0xFF2563EB) else Color(0xFF334155),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.clickable(enabled = canUndoEdit) { onUndoEdit() }
                    ) {
                        Text(
                            text = "↶ تراجع",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (canUndoEdit) Color.White else Color.Gray,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }

                    // Redo
                    Surface(
                        color = if (canRedoEdit) Color(0xFF2563EB) else Color(0xFF334155),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.clickable(enabled = canRedoEdit) { onRedoEdit() }
                    ) {
                        Text(
                            text = "↷ إعادة",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (canRedoEdit) Color.White else Color.Gray,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }

                // Turn switch
                Surface(
                    color = Color(0xFF059669),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.clickable { onToggleActiveColor() }
                ) {
                    Text(
                        text = if (activeColor == PieceColor.WHITE) "الدور: أبيض ♔" else "الدور: أسود ♚",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                }
            }

            // Piece palette when square selected
            if (selectedSquare != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "إضافة إلى ${selectedSquare.name}:",
                        fontSize = 10.sp,
                        color = Color.LightGray,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        val pieceSymbols = listOf(
                            com.example.chess.model.PieceType.QUEEN to if (activeColor == PieceColor.WHITE) "♕" else "♛",
                            com.example.chess.model.PieceType.ROOK to if (activeColor == PieceColor.WHITE) "♖" else "♜",
                            com.example.chess.model.PieceType.BISHOP to if (activeColor == PieceColor.WHITE) "♗" else "♝",
                            com.example.chess.model.PieceType.KNIGHT to if (activeColor == PieceColor.WHITE) "♘" else "♞",
                            com.example.chess.model.PieceType.PAWN to if (activeColor == PieceColor.WHITE) "♙" else "♟"
                        )
                        for ((type, sym) in pieceSymbols) {
                            Surface(
                                color = Color(0xFF334155),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.clickable {
                                    onAddPiece(selectedSquare, com.example.chess.model.Piece(type, activeColor))
                                }
                            ) {
                                Text(
                                    text = sym,
                                    fontSize = 16.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (editHintMessage != null) {
                Text(
                    text = editHintMessage,
                    fontSize = 10.sp,
                    color = Color(0xFFFBBF24),
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

