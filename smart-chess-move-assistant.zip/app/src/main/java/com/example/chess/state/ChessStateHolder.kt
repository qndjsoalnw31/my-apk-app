package com.example.chess.state

import android.content.Context
import com.example.chess.engine.BoardState
import com.example.chess.engine.FenUtils
import com.example.chess.engine.MoveGenerator
import com.example.chess.engine.StockfishEngine
import com.example.chess.model.AnalysisResult
import com.example.chess.model.EngineMode
import com.example.chess.model.EngineStrength
import com.example.chess.model.Move
import com.example.chess.model.MoveQuality
import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.Square
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class EditSubMode {
    MOVE,       // نقل القطع
    EAT_REMOVE  // أكل / إزالة القطع
}

data class EditSnapshot(
    val boardState: BoardState,
    val capturedWhite: List<Piece>,
    val capturedBlack: List<Piece>
)

object ChessStateHolder {

    private val scope = CoroutineScope(Dispatchers.Default)
    private var analysisJob: Job? = null
    private var appContext: Context? = null

    // User's chosen playing color (White or Black)
    val userColor = MutableStateFlow(PieceColor.WHITE)

    // Current board state
    val boardState = MutableStateFlow(FenUtils.parseFen(FenUtils.INITIAL_FEN))

    // Move history and fast state stack history for instant O(1) Undo
    val moveHistory = MutableStateFlow<List<Move>>(emptyList())
    private val boardStateHistory = mutableListOf<BoardState>()
    private val capturedWhiteHistory = mutableListOf<List<Piece>>()
    private val capturedBlackHistory = mutableListOf<List<Piece>>()

    // Analysis Result
    val analysisResult = MutableStateFlow<AnalysisResult?>(null)

    // Is Analyzing
    val isAnalyzing = MutableStateFlow(false)

    // Board Flipped
    val isBoardFlipped = MutableStateFlow(false)

    // Board Edit Mode (وضع تعديل الرقعة)
    val isEditMode = MutableStateFlow(false)
    val editSubMode = MutableStateFlow(EditSubMode.MOVE)

    // Edit History for Undo (↶) and Redo (↷) with complete state snapshots
    private val editUndoStack = mutableListOf<EditSnapshot>()
    private val editRedoStack = mutableListOf<EditSnapshot>()
    val canUndoEdit = MutableStateFlow(false)
    val canRedoEdit = MutableStateFlow(false)
    val editHintMessage = MutableStateFlow<String?>(null)

    val showCoordinates = MutableStateFlow(true)

    // Selected Square
    val selectedSquare = MutableStateFlow<Square?> (null)

    // Available Legal Moves for Selected Square
    val legalMovesForSelected = MutableStateFlow<List<Move>>(emptyList())

    // Engine Configurations
    val engineMode = MutableStateFlow(EngineMode.BALANCED)
    val engineStrength = MutableStateFlow(EngineStrength.MASTER)
    val topLinesCount = MutableStateFlow(3)

    // Move quality ratings log for full game review
    val qualityLog = MutableStateFlow<List<Pair<Move, MoveQuality>>>(emptyList())

    // Captured Pieces
    val capturedPiecesWhite = MutableStateFlow<List<Piece>>(emptyList())
    val capturedPiecesBlack = MutableStateFlow<List<Piece>>(emptyList())

    fun init(context: Context) {
        appContext = context.applicationContext
        val prefs = appContext?.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE)
        val savedColorName = prefs?.getString("user_color", PieceColor.WHITE.name)
        val color = try {
            PieceColor.valueOf(savedColorName ?: PieceColor.WHITE.name)
        } catch (e: Exception) {
            PieceColor.WHITE
        }
        userColor.value = color
        isBoardFlipped.value = (color == PieceColor.BLACK)
        if (boardStateHistory.isEmpty()) {
            resetGame()
        }
    }

    fun selectUserColor(color: PieceColor, context: Context? = null) {
        val ctx = context?.applicationContext ?: appContext
        userColor.value = color
        isBoardFlipped.value = (color == PieceColor.BLACK)

        ctx?.let {
            it.getSharedPreferences("chess_prefs", Context.MODE_PRIVATE)
                .edit()
                .putString("user_color", color.name)
                .apply()
        }
        triggerAnalysis()
    }

    fun isInitialPosition(board: BoardState): Boolean {
        val fen = FenUtils.toFen(board).trim()
        return fen.startsWith("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR")
    }

    fun updateBoardState(newBoard: BoardState) {
        if (isInitialPosition(newBoard)) {
            resetGame()
        } else {
            boardState.value = newBoard
            triggerAnalysis()
        }
    }

    fun makeMove(move: Move): Boolean {
        val currentBoard = boardState.value
        val nextBoard = MoveGenerator.makeMove(currentBoard, move)

        // Track captured piece
        val newCapWhite = capturedPiecesWhite.value.toMutableList()
        val newCapBlack = capturedPiecesBlack.value.toMutableList()
        if (move.capturedPiece != null) {
            if (move.capturedPiece.color == PieceColor.WHITE) {
                newCapWhite.add(move.capturedPiece)
            } else {
                newCapBlack.add(move.capturedPiece)
            }
        }
        capturedPiecesWhite.value = newCapWhite
        capturedPiecesBlack.value = newCapBlack

        // Calculate move quality rating compared to previous analysis
        val prevEval = analysisResult.value?.evalScore ?: 0.0
        boardState.value = nextBoard
        moveHistory.value = moveHistory.value + move

        // Record state snapshot for instant O(1) undo
        boardStateHistory.add(nextBoard.copy())
        capturedWhiteHistory.add(newCapWhite)
        capturedBlackHistory.add(newCapBlack)

        selectedSquare.value = null
        legalMovesForSelected.value = emptyList()

        triggerAnalysis(evalBefore = prevEval, movedMove = move)
        return true
    }

    private fun recordEditState() {
        val snapshot = EditSnapshot(
            boardState = boardState.value.copy(),
            capturedWhite = capturedPiecesWhite.value.toList(),
            capturedBlack = capturedPiecesBlack.value.toList()
        )
        editUndoStack.add(snapshot)
        if (editUndoStack.size > 50) {
            editUndoStack.removeAt(0)
        }
        editRedoStack.clear()
        canUndoEdit.value = true
        canRedoEdit.value = false
    }

    fun undoEdit() {
        if (editUndoStack.isEmpty()) return
        val currentSnapshot = EditSnapshot(
            boardState = boardState.value.copy(),
            capturedWhite = capturedPiecesWhite.value.toList(),
            capturedBlack = capturedPiecesBlack.value.toList()
        )
        editRedoStack.add(currentSnapshot)
        if (editRedoStack.size > 50) {
            editRedoStack.removeAt(0)
        }

        val previousSnapshot = editUndoStack.removeAt(editUndoStack.size - 1)
        boardState.value = previousSnapshot.boardState.copy()
        capturedPiecesWhite.value = previousSnapshot.capturedWhite
        capturedPiecesBlack.value = previousSnapshot.capturedBlack

        canUndoEdit.value = editUndoStack.isNotEmpty()
        canRedoEdit.value = true
        selectedSquare.value = null
        legalMovesForSelected.value = emptyList()
        editHintMessage.value = "تم التراجع ↶"
    }

    fun redoEdit() {
        if (editRedoStack.isEmpty()) return
        val currentSnapshot = EditSnapshot(
            boardState = boardState.value.copy(),
            capturedWhite = capturedPiecesWhite.value.toList(),
            capturedBlack = capturedPiecesBlack.value.toList()
        )
        editUndoStack.add(currentSnapshot)
        if (editUndoStack.size > 50) {
            editUndoStack.removeAt(0)
        }

        val nextSnapshot = editRedoStack.removeAt(editRedoStack.size - 1)
        boardState.value = nextSnapshot.boardState.copy()
        capturedPiecesWhite.value = nextSnapshot.capturedWhite
        capturedPiecesBlack.value = nextSnapshot.capturedBlack

        canUndoEdit.value = true
        canRedoEdit.value = editRedoStack.isNotEmpty()
        selectedSquare.value = null
        legalMovesForSelected.value = emptyList()
        editHintMessage.value = "تم الإعادة ↷"
    }

    fun toggleEditMode() {
        val nextMode = !isEditMode.value
        isEditMode.value = nextMode
        editSubMode.value = EditSubMode.MOVE // Default to MOVE when entering edit mode
        selectedSquare.value = null
        legalMovesForSelected.value = emptyList()

        if (nextMode) {
            analysisJob?.cancel()
            isAnalyzing.value = false
            analysisResult.value = null
            editUndoStack.clear()
            editRedoStack.clear()
            canUndoEdit.value = false
            canRedoEdit.value = false
            editHintMessage.value = "وضع تعديل الرقعة مفعل"
        } else {
            // Exiting edit mode: establish a pristine, fully-validated chess position
            val finalBoard = boardState.value.copy()
            finalBoard.enPassantSquare = null
            finalBoard.halfmoveClock = 0
            finalBoard.sanitizeCastlingRights()
            boardState.value = finalBoard

            // Fully disconnect old match history so old moves don't corrupt the new position
            moveHistory.value = emptyList()
            qualityLog.value = emptyList()

            val (cW, cB) = FenUtils.computeCapturedPieces(finalBoard)
            capturedPiecesWhite.value = cW
            capturedPiecesBlack.value = cB

            boardStateHistory.clear()
            boardStateHistory.add(finalBoard.copy())
            capturedWhiteHistory.clear()
            capturedWhiteHistory.add(cW)
            capturedBlackHistory.clear()
            capturedBlackHistory.add(cB)

            editUndoStack.clear()
            editRedoStack.clear()
            canUndoEdit.value = false
            canRedoEdit.value = false
            editHintMessage.value = null

            triggerAnalysis()
        }
    }

    fun setEditSubMode(mode: EditSubMode) {
        editSubMode.value = mode
        selectedSquare.value = null
    }

    fun toggleShowCoordinates() {
        showCoordinates.value = !showCoordinates.value
    }

    fun removePiece(sq: Square) {
        val current = boardState.value
        if (current.getPiece(sq) != null) {
            recordEditState()
            val newBoard = current.copy()
            newBoard.setPiece(sq, null)
            newBoard.enPassantSquare = null
            newBoard.halfmoveClock = 0
            newBoard.sanitizeCastlingRights()

            val (cW, cB) = FenUtils.computeCapturedPieces(newBoard)
            capturedPiecesWhite.value = cW
            capturedPiecesBlack.value = cB

            boardState.value = newBoard
            selectedSquare.value = null
            legalMovesForSelected.value = emptyList()
            editHintMessage.value = "حذف قطعة من ${sq.name} 🗑️"
        }
    }

    fun addPieceDirectly(sq: Square, piece: Piece) {
        recordEditState()
        val current = boardState.value
        val newBoard = current.copy()
        newBoard.setPiece(sq, piece)
        newBoard.enPassantSquare = null
        newBoard.halfmoveClock = 0
        newBoard.sanitizeCastlingRights()

        val (cW, cB) = FenUtils.computeCapturedPieces(newBoard)
        capturedPiecesWhite.value = cW
        capturedPiecesBlack.value = cB

        boardState.value = newBoard
        selectedSquare.value = null
        legalMovesForSelected.value = emptyList()
        editHintMessage.value = "إضافة قطعة في ${sq.name} ♟️"
    }

    fun toggleActiveColorInEditMode() {
        recordEditState()
        val current = boardState.value
        val newColor = if (current.activeColor == PieceColor.WHITE) PieceColor.BLACK else PieceColor.WHITE
        val newBoard = current.copy()
        newBoard.activeColor = newColor
        newBoard.enPassantSquare = null
        boardState.value = newBoard
        editHintMessage.value = if (newColor == PieceColor.WHITE) "الدور الآن للأبيض ♔" else "الدور الآن للأسود ♚"
    }

    fun movePieceDirectly(from: Square, to: Square) {
        if (from == to) {
            selectedSquare.value = null
            return
        }
        val current = boardState.value
        val pieceToMove = current.getPiece(from) ?: return
        val targetPiece = current.getPiece(to)

        recordEditState()

        val newBoard = current.copy()
        newBoard.setPiece(from, null)
        newBoard.setPiece(to, pieceToMove)
        newBoard.enPassantSquare = null
        newBoard.halfmoveClock = 0
        newBoard.sanitizeCastlingRights()

        val (cW, cB) = FenUtils.computeCapturedPieces(newBoard)
        capturedPiecesWhite.value = cW
        capturedPiecesBlack.value = cB

        boardState.value = newBoard
        selectedSquare.value = null
        legalMovesForSelected.value = emptyList()
        editHintMessage.value = if (targetPiece != null) "استبدال: ${from.name} → ${to.name}" else "نقل: ${from.name} → ${to.name}"
    }

    fun selectSquare(sq: Square) {
        if (isEditMode.value) {
            if (editSubMode.value == EditSubMode.EAT_REMOVE) {
                // Eat/Remove mode: tap piece/square removes piece immediately
                removePiece(sq)
                return
            }

            // MOVE mode:
            val activeSelected = selectedSquare.value
            if (activeSelected == null) {
                val p = boardState.value.getPiece(sq)
                if (p != null) {
                    selectedSquare.value = sq
                    editHintMessage.value = "محدد: ${sq.name}"
                }
            } else if (activeSelected == sq) {
                selectedSquare.value = null
                editHintMessage.value = null
            } else {
                movePieceDirectly(activeSelected, sq)
            }
            return
        }

        val current = boardState.value
        val p = current.getPiece(sq)

        val activeSelected = selectedSquare.value
        if (activeSelected != null) {
            // Attempt to move to 'sq'
            val targetMove = legalMovesForSelected.value.firstOrNull { it.to == sq }
            if (targetMove != null) {
                makeMove(targetMove)
                return
            }
        }

        if (p != null && p.color == current.activeColor) {
            selectedSquare.value = sq
            val allLegal = MoveGenerator.generateLegalMoves(current, current.activeColor)
            legalMovesForSelected.value = allLegal.filter { it.from == sq }
        } else {
            selectedSquare.value = null
            legalMovesForSelected.value = emptyList()
        }
    }

    fun undoMove() {
        if (moveHistory.value.isEmpty() || boardStateHistory.size <= 1) return

        // Instant O(1) state restoration directly from memory stack
        boardStateHistory.removeAt(boardStateHistory.size - 1)
        capturedWhiteHistory.removeAt(capturedWhiteHistory.size - 1)
        capturedBlackHistory.removeAt(capturedBlackHistory.size - 1)

        val history = moveHistory.value.dropLast(1)
        moveHistory.value = history

        val restoredBoard = boardStateHistory.last().copy()
        boardState.value = restoredBoard
        capturedPiecesWhite.value = capturedWhiteHistory.last()
        capturedPiecesBlack.value = capturedBlackHistory.last()
        selectedSquare.value = null
        legalMovesForSelected.value = emptyList()

        triggerAnalysis()
    }

    fun resetGame() {
        val initialBoard = FenUtils.parseFen(FenUtils.INITIAL_FEN)
        moveHistory.value = emptyList()
        boardState.value = initialBoard
        capturedPiecesWhite.value = emptyList()
        capturedPiecesBlack.value = emptyList()
        qualityLog.value = emptyList()
        selectedSquare.value = null
        legalMovesForSelected.value = emptyList()

        boardStateHistory.clear()
        boardStateHistory.add(initialBoard.copy())
        capturedWhiteHistory.clear()
        capturedWhiteHistory.add(emptyList())
        capturedBlackHistory.clear()
        capturedBlackHistory.add(emptyList())

        editUndoStack.clear()
        editRedoStack.clear()
        canUndoEdit.value = false
        canRedoEdit.value = false
        editHintMessage.value = null

        triggerAnalysis()
    }

    fun loadFen(fenStr: String) {
        try {
            val state = FenUtils.parseFen(fenStr)
            state.sanitizeCastlingRights()
            if (isInitialPosition(state)) {
                resetGame()
            } else {
                boardState.value = state
                moveHistory.value = emptyList()
                qualityLog.value = emptyList()
                val (cW, cB) = FenUtils.computeCapturedPieces(state)
                capturedPiecesWhite.value = cW
                capturedPiecesBlack.value = cB
                selectedSquare.value = null
                legalMovesForSelected.value = emptyList()

                boardStateHistory.clear()
                boardStateHistory.add(state.copy())
                capturedWhiteHistory.clear()
                capturedWhiteHistory.add(cW)
                capturedBlackHistory.clear()
                capturedBlackHistory.add(cB)

                editUndoStack.clear()
                editRedoStack.clear()
                canUndoEdit.value = false
                canRedoEdit.value = false
                editHintMessage.value = null

                triggerAnalysis()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun triggerAnalysis(evalBefore: Double = 0.0, movedMove: Move? = null) {
        if (isEditMode.value) return
        analysisJob?.cancel()
        isAnalyzing.value = true

        analysisJob = scope.launch {
            val historyHashes = boardStateHistory.map { StockfishEngine.computeZobristHash(it) }
            val res = StockfishEngine.analyzePosition(
                state = boardState.value,
                userColor = userColor.value,
                mode = engineMode.value,
                strength = engineStrength.value,
                topCount = topLinesCount.value,
                historyHashes = historyHashes
            )
            analysisResult.value = res
            isAnalyzing.value = false

            if (movedMove != null) {
                val quality = StockfishEngine.classifyMoveQuality(
                    evalBefore = evalBefore,
                    evalAfter = res.evalScore,
                    isUserTurn = (boardState.value.activeColor == userColor.value),
                    color = boardState.value.activeColor.opposite()
                )
                qualityLog.value = qualityLog.value + (movedMove to quality)
            }
        }
    }
}
