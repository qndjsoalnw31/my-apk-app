package com.example.chess.engine

import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square

class BoardState(
    val grid: Array<Array<Piece?>> = Array(8) { Array(8) { null } },
    var activeColor: PieceColor = PieceColor.WHITE,
    var whiteCanCastleKingside: Boolean = true,
    var whiteCanCastleQueenside: Boolean = true,
    var blackCanCastleKingside: Boolean = true,
    var blackCanCastleQueenside: Boolean = true,
    var enPassantSquare: Square? = null,
    var halfmoveClock: Int = 0,
    var fullmoveNumber: Int = 1
) {
    fun copy(): BoardState {
        val newGrid = Array(8) { rank ->
            Array(8) { file -> grid[rank][file] }
        }
        return BoardState(
            grid = newGrid,
            activeColor = activeColor,
            whiteCanCastleKingside = whiteCanCastleKingside,
            whiteCanCastleQueenside = whiteCanCastleQueenside,
            blackCanCastleKingside = blackCanCastleKingside,
            blackCanCastleQueenside = blackCanCastleQueenside,
            enPassantSquare = enPassantSquare,
            halfmoveClock = halfmoveClock,
            fullmoveNumber = fullmoveNumber
        )
    }

    fun getPiece(file: Int, rank: Int): Piece? {
        if (file !in 0..7 || rank !in 0..7) return null
        return grid[rank][file]
    }

    fun getPiece(square: Square): Piece? {
        return getPiece(square.file, square.rank)
    }

    fun setPiece(square: Square, piece: Piece?) {
        if (square.file in 0..7 && square.rank in 0..7) {
            grid[square.rank][square.file] = piece
        }
    }

    fun sanitizeCastlingRights() {
        val wKing = getPiece(4, 0)
        if (wKing?.type != PieceType.KING || wKing.color != PieceColor.WHITE) {
            whiteCanCastleKingside = false
            whiteCanCastleQueenside = false
        } else {
            val h1 = getPiece(7, 0)
            if (h1?.type != PieceType.ROOK || h1.color != PieceColor.WHITE) {
                whiteCanCastleKingside = false
            }
            val a1 = getPiece(0, 0)
            if (a1?.type != PieceType.ROOK || a1.color != PieceColor.WHITE) {
                whiteCanCastleQueenside = false
            }
        }

        val bKing = getPiece(4, 7)
        if (bKing?.type != PieceType.KING || bKing.color != PieceColor.BLACK) {
            blackCanCastleKingside = false
            blackCanCastleQueenside = false
        } else {
            val h8 = getPiece(7, 7)
            if (h8?.type != PieceType.ROOK || h8.color != PieceColor.BLACK) {
                blackCanCastleKingside = false
            }
            val a8 = getPiece(0, 7)
            if (a8?.type != PieceType.ROOK || a8.color != PieceColor.BLACK) {
                blackCanCastleQueenside = false
            }
        }
    }
}

object FenUtils {
    const val INITIAL_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    fun parseFen(fen: String): BoardState {
        val tokens = fen.trim().split("\\s+".toRegex())
        val boardState = BoardState()

        if (tokens.isEmpty()) return boardState

        // 1. Piece Placement
        val rows = tokens[0].split("/")
        if (rows.size == 8) {
            for (r in 0..7) {
                val rank = 7 - r // FEN starts from 8th rank down to 1st
                var file = 0
                for (char in rows[r]) {
                    if (char.isDigit()) {
                        file += char.toString().toInt()
                    } else {
                        val color = if (char.isUpperCase()) PieceColor.WHITE else PieceColor.BLACK
                        val type = when (char.lowercaseChar()) {
                            'p' -> PieceType.PAWN
                            'n' -> PieceType.KNIGHT
                            'b' -> PieceType.BISHOP
                            'r' -> PieceType.ROOK
                            'q' -> PieceType.QUEEN
                            'k' -> PieceType.KING
                            else -> PieceType.PAWN
                        }
                        if (file in 0..7 && rank in 0..7) {
                            boardState.grid[rank][file] = Piece(type, color)
                        }
                        file++
                    }
                }
            }
        }

        // 2. Active Color
        if (tokens.size > 1) {
            boardState.activeColor = if (tokens[1] == "b") PieceColor.BLACK else PieceColor.WHITE
        }

        // 3. Castling Rights
        if (tokens.size > 2) {
            val castling = tokens[2]
            boardState.whiteCanCastleKingside = castling.contains("K")
            boardState.whiteCanCastleQueenside = castling.contains("Q")
            boardState.blackCanCastleKingside = castling.contains("k")
            boardState.blackCanCastleQueenside = castling.contains("q")
        }

        // 4. En Passant
        if (tokens.size > 3 && tokens[3] != "-") {
            boardState.enPassantSquare = Square.fromName(tokens[3])
        }

        // 5. Halfmove clock
        if (tokens.size > 4) {
            boardState.halfmoveClock = tokens[4].toIntOrNull() ?: 0
        }

        // 6. Fullmove number
        if (tokens.size > 5) {
            boardState.fullmoveNumber = tokens[5].toIntOrNull() ?: 1
        }

        boardState.sanitizeCastlingRights()
        return boardState
    }

    fun computeCapturedPieces(board: BoardState): Pair<List<Piece>, List<Piece>> {
        val whiteCounts = mutableMapOf<PieceType, Int>()
        val blackCounts = mutableMapOf<PieceType, Int>()
        for (r in 0..7) {
            for (f in 0..7) {
                val p = board.getPiece(f, r) ?: continue
                val map = if (p.color == PieceColor.WHITE) whiteCounts else blackCounts
                map[p.type] = (map[p.type] ?: 0) + 1
            }
        }

        val standardSet = listOf(
            PieceType.QUEEN to 1,
            PieceType.ROOK to 2,
            PieceType.BISHOP to 2,
            PieceType.KNIGHT to 2,
            PieceType.PAWN to 8
        )

        val capturedWhite = mutableListOf<Piece>()
        val capturedBlack = mutableListOf<Piece>()

        for ((type, standardCount) in standardSet) {
            val wCount = whiteCounts[type] ?: 0
            if (wCount < standardCount) {
                repeat(standardCount - wCount) {
                    capturedWhite.add(Piece(type, PieceColor.WHITE))
                }
            }
            val bCount = blackCounts[type] ?: 0
            if (bCount < standardCount) {
                repeat(standardCount - bCount) {
                    capturedBlack.add(Piece(type, PieceColor.BLACK))
                }
            }
        }
        return Pair(capturedWhite, capturedBlack)
    }

    fun toFen(state: BoardState): String {
        val sb = StringBuilder()

        // 1. Piece Placement
        for (r in 7 downTo 0) {
            var emptyCount = 0
            for (f in 0..7) {
                val piece = state.grid[r][f]
                if (piece == null) {
                    emptyCount++
                } else {
                    if (emptyCount > 0) {
                        sb.append(emptyCount)
                        emptyCount = 0
                    }
                    sb.append(piece.fenChar)
                }
            }
            if (emptyCount > 0) {
                sb.append(emptyCount)
            }
            if (r > 0) sb.append("/")
        }

        // 2. Active Color
        sb.append(" ").append(if (state.activeColor == PieceColor.WHITE) "w" else "b")

        // 3. Castling Rights
        val castling = StringBuilder()
        if (state.whiteCanCastleKingside) castling.append("K")
        if (state.whiteCanCastleQueenside) castling.append("Q")
        if (state.blackCanCastleKingside) castling.append("k")
        if (state.blackCanCastleQueenside) castling.append("q")
        sb.append(" ").append(if (castling.isEmpty()) "-" else castling.toString())

        // 4. En Passant
        sb.append(" ").append(state.enPassantSquare?.name ?: "-")

        // 5. Halfmove & Fullmove
        sb.append(" ").append(state.halfmoveClock)
        sb.append(" ").append(state.fullmoveNumber)

        return sb.toString()
    }
}
