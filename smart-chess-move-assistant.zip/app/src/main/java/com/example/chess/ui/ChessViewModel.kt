package com.example.chess.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.chess.data.AppDatabase
import com.example.chess.data.ChessPuzzle
import com.example.chess.data.ChessRepository
import com.example.chess.data.PuzzleRepository
import com.example.chess.data.SavedGame
import com.example.chess.engine.FenUtils
import com.example.chess.engine.OpeningBook
import com.example.chess.engine.OpeningInfo
import com.example.chess.engine.PgnUtils
import com.example.chess.model.EngineMode
import com.example.chess.model.EngineStrength
import com.example.chess.model.MoveQuality
import com.example.chess.model.PieceColor
import com.example.chess.model.Square
import com.example.chess.service.FloatingChessOverlayService
import com.example.chess.service.GeminiChessCoachService
import com.example.chess.state.ChessStateHolder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppMode {
    ANALYSIS,
    PUZZLE
}

data class GameReviewReport(
    val accuracyPercentage: Int,
    val bestMovesCount: Int,
    val goodMovesCount: Int,
    val inaccuracyCount: Int,
    val mistakeCount: Int,
    val blunderCount: Int
)

class ChessViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ChessRepository(AppDatabase.getInstance(application).chessDao())

    val savedGames: StateFlow<List<SavedGame>> = repository.savedGames.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val isEditMode = ChessStateHolder.isEditMode
    val editSubMode = ChessStateHolder.editSubMode
    val canUndoEdit = ChessStateHolder.canUndoEdit
    val canRedoEdit = ChessStateHolder.canRedoEdit
    val editHintMessage = ChessStateHolder.editHintMessage
    val showCoordinates = ChessStateHolder.showCoordinates
    val boardState = ChessStateHolder.boardState
    val userColor = ChessStateHolder.userColor
    val isFlipped = ChessStateHolder.isBoardFlipped
    val moveHistory = ChessStateHolder.moveHistory
    val analysisResult = ChessStateHolder.analysisResult
    val isAnalyzing = ChessStateHolder.isAnalyzing
    val selectedSquare = ChessStateHolder.selectedSquare
    val legalMoves = ChessStateHolder.legalMovesForSelected
    val engineMode = ChessStateHolder.engineMode
    val engineStrength = ChessStateHolder.engineStrength
    val topLinesCount = ChessStateHolder.topLinesCount
    val qualityLog = ChessStateHolder.qualityLog
    val capturedWhite = ChessStateHolder.capturedPiecesWhite
    val capturedBlack = ChessStateHolder.capturedPiecesBlack

    // Opening Book Detector State
    val openingInfo: StateFlow<OpeningInfo?> = moveHistory.combine(boardState) { history, _ ->
        OpeningBook.detectOpening(history)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    // AI Coach State
    private val _aiCoachAdvice = MutableStateFlow<String?>(null)
    val aiCoachAdvice: StateFlow<String?> = _aiCoachAdvice.asStateFlow()

    private val _isAskingCoach = MutableStateFlow(false)
    val isAskingCoach: StateFlow<Boolean> = _isAskingCoach.asStateFlow()

    // App Mode (Analysis vs Puzzle)
    private val _appMode = MutableStateFlow(AppMode.ANALYSIS)
    val appMode: StateFlow<AppMode> = _appMode.asStateFlow()

    // Current Puzzle State
    private val _currentPuzzleIndex = MutableStateFlow(0)
    val currentPuzzleIndex: StateFlow<Int> = _currentPuzzleIndex.asStateFlow()

    val currentPuzzle: StateFlow<ChessPuzzle?> = combine(_appMode, _currentPuzzleIndex) { mode, idx ->
        if (mode == AppMode.PUZZLE && idx in PuzzleRepository.puzzles.indices) {
            PuzzleRepository.puzzles[idx]
        } else null
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    private val _puzzleFeedback = MutableStateFlow<String?>(null)
    val puzzleFeedback: StateFlow<String?> = _puzzleFeedback.asStateFlow()

    private val _puzzleSolved = MutableStateFlow(false)
    val puzzleSolved: StateFlow<Boolean> = _puzzleSolved.asStateFlow()

    init {
        ChessStateHolder.triggerAnalysis()
    }

    fun setAppMode(mode: AppMode) {
        _appMode.value = mode
        if (mode == AppMode.PUZZLE) {
            loadPuzzle(PuzzleRepository.puzzles[_currentPuzzleIndex.value])
        } else {
            ChessStateHolder.resetGame()
        }
    }

    fun askAiCoach(topic: String? = null) {
        viewModelScope.launch {
            _isAskingCoach.value = true
            val advice = GeminiChessCoachService.askAiCoach(
                boardState = boardState.value,
                userColor = userColor.value,
                analysisResult = analysisResult.value,
                questionTopic = topic
            )
            _aiCoachAdvice.value = advice
            _isAskingCoach.value = false
        }
    }

    fun clearCoachAdvice() {
        _aiCoachAdvice.value = null
    }

    fun selectUserColor(color: PieceColor) {
        ChessStateHolder.selectUserColor(color, getApplication())
    }

    fun selectSquare(sq: Square) {
        val mode = _appMode.value
        val puz = currentPuzzle.value

        if (mode == AppMode.PUZZLE && puz != null && !_puzzleSolved.value) {
            val prevHistorySize = moveHistory.value.size
            ChessStateHolder.selectSquare(sq)
            val newHistory = moveHistory.value

            if (newHistory.size > prevHistorySize) {
                val lastPlayedMove = newHistory.last()
                if (lastPlayedMove.san == puz.targetMoveSan || lastPlayedMove.san.startsWith(puz.targetMoveSan.replace("#", "").replace("+", ""))) {
                    _puzzleSolved.value = true
                    _puzzleFeedback.value = "🎉 أحسنت! حركتك المتميزة (${lastPlayedMove.san}) صحيحة تماماً!\n${puz.solutionExplanationAr}"
                } else {
                    _puzzleFeedback.value = "❌ حركة غير دقيقة. جرب مرة أخرى!\n💡 تلميح: ${puz.hintAr}"
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(1200)
                        ChessStateHolder.undoMove()
                    }
                }
            }
            return
        }

        ChessStateHolder.selectSquare(sq)
    }

    fun nextPuzzle() {
        val nextIdx = (_currentPuzzleIndex.value + 1) % PuzzleRepository.puzzles.size
        _currentPuzzleIndex.value = nextIdx
        loadPuzzle(PuzzleRepository.puzzles[nextIdx])
    }

    fun loadPuzzle(puzzle: ChessPuzzle) {
        _puzzleSolved.value = false
        _puzzleFeedback.value = "🎯 الهدف: أوجد أفضل حركة للطرف ${if (puzzle.userColor == PieceColor.WHITE) "الأبيض" else "الأسود"}.\n💡 ${puzzle.hintAr}"
        ChessStateHolder.selectUserColor(puzzle.userColor)
        ChessStateHolder.loadFen(puzzle.fen)
    }

    fun generateGameReview(): GameReviewReport {
        val log = qualityLog.value
        if (log.isEmpty()) {
            return GameReviewReport(
                accuracyPercentage = 100,
                bestMovesCount = 0,
                goodMovesCount = 0,
                inaccuracyCount = 0,
                mistakeCount = 0,
                blunderCount = 0
            )
        }

        var best = 0
        var good = 0
        var inaccuracy = 0
        var mistake = 0
        var blunder = 0

        for ((_, q) in log) {
            when (q) {
                MoveQuality.EXCELLENT, MoveQuality.BEST -> best++
                MoveQuality.GOOD -> good++
                MoveQuality.INACCURACY -> inaccuracy++
                MoveQuality.MISTAKE -> mistake++
                MoveQuality.BLUNDER -> blunder++
            }
        }

        val total = log.size
        val score = (best * 100 + good * 80 + inaccuracy * 50 + mistake * 20 + blunder * 0) / total
        val accuracyPct = score.coerceIn(10, 100)

        return GameReviewReport(
            accuracyPercentage = accuracyPct,
            bestMovesCount = best,
            goodMovesCount = good,
            inaccuracyCount = inaccuracy,
            mistakeCount = mistake,
            blunderCount = blunder
        )
    }

    fun flipBoard() {
        ChessStateHolder.isBoardFlipped.value = !ChessStateHolder.isBoardFlipped.value
    }

    fun toggleEditMode() {
        ChessStateHolder.toggleEditMode()
    }

    fun setEditSubMode(mode: com.example.chess.state.EditSubMode) {
        ChessStateHolder.setEditSubMode(mode)
    }

    fun undoEdit() {
        ChessStateHolder.undoEdit()
    }

    fun redoEdit() {
        ChessStateHolder.redoEdit()
    }

    fun toggleActiveColorInEditMode() {
        ChessStateHolder.toggleActiveColorInEditMode()
    }

    fun undoMove() {
        ChessStateHolder.undoMove()
    }

    fun resetGame() {
        ChessStateHolder.resetGame()
        _aiCoachAdvice.value = null
    }

    fun loadFen(fen: String) {
        ChessStateHolder.loadFen(fen)
        _aiCoachAdvice.value = null
    }

    fun updateEngineSettings(mode: EngineMode, strength: EngineStrength, topCount: Int) {
        ChessStateHolder.engineMode.value = mode
        ChessStateHolder.engineStrength.value = strength
        ChessStateHolder.topLinesCount.value = topCount
        ChessStateHolder.triggerAnalysis()
    }

    fun saveCurrentGame(title: String = "مباراة محفوظة") {
        viewModelScope.launch {
            val fen = FenUtils.toFen(boardState.value)
            val pgn = PgnUtils.exportPgn(moveHistory = moveHistory.value)
            val game = SavedGame(
                title = "$title (${moveHistory.value.size} نقلة)",
                fen = fen,
                pgn = pgn,
                playerColor = userColor.value.name,
                totalMoves = moveHistory.value.size
            )
            repository.saveGame(game)
        }
    }

    fun deleteGame(id: Long) {
        viewModelScope.launch {
            repository.deleteGame(id)
        }
    }

    fun toggleFloatingOverlay(context: Context) {
        if (FloatingChessOverlayService.isRunning) {
            val serviceIntent = Intent(context, FloatingChessOverlayService::class.java)
            context.stopService(serviceIntent)
            Toast.makeText(context, "تم إغلاق النافذة العائمة", Toast.LENGTH_SHORT).show()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            Toast.makeText(context, "يرجى تفعيل إذن العرض فوق التطبيقات لتشغيل النافذة العائمة", Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } else {
            val serviceIntent = Intent(context, FloatingChessOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
            Toast.makeText(context, "تم تفعيل النافذة العائمة فوق التطبيقات", Toast.LENGTH_SHORT).show()
        }
    }
}

