package com.example.chess.service

import com.aistudio.chessassistant.rqxptz.BuildConfig
import com.example.chess.engine.BoardState
import com.example.chess.engine.FenUtils
import com.example.chess.engine.MoveGenerator
import com.example.chess.model.AnalysisResult
import com.example.chess.model.PieceColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiChessCoachService {

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(12, TimeUnit.SECONDS)
            .build()
    }

    suspend fun askAiCoach(
        boardState: BoardState,
        userColor: PieceColor,
        analysisResult: AnalysisResult?,
        questionTopic: String? = null
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val currentFen = FenUtils.toFen(boardState)
        val bestMoveSan = analysisResult?.bestMove?.san ?: "غير محدد"
        val evalScore = analysisResult?.evalScore ?: 0.0
        val isUserInCheck = analysisResult?.isUserInCheck ?: MoveGenerator.isInCheck(boardState, userColor)
        val isOpponentInCheck = analysisResult?.isOpponentInCheck ?: MoveGenerator.isInCheck(boardState, userColor.opposite())
        val isUserCheckmated = analysisResult?.isUserCheckmated ?: (isUserInCheck && MoveGenerator.generateLegalMoves(boardState, userColor).isEmpty())
        val isOpponentCheckmated = analysisResult?.isOpponentCheckmated ?: (isOpponentInCheck && MoveGenerator.generateLegalMoves(boardState, userColor.opposite()).isEmpty())

        val colorNameAr = if (userColor == PieceColor.WHITE) "الأبيض (White)" else "الأسود (Black)"

        val promptText = StringBuilder().apply {
            append("أنت مدرب شطرنج محترف واستراتيجي خبير بلقب غراند ماستر (Grandmaster Chess Coach).\n")
            append("مهمتك تقديم نصيحة استراتيجية وتحليل تكتيكي دقيق باللغة العربية الواضحة والشديدة الفائدة للاعب.\n\n")
            append("معطيات الوضعية الحالية:\n")
            append("- FEN: $currentFen\n")
            append("- لون اللاعب المحلل: $colorNameAr\n")
            append("- التقييم الحالي: $evalScore بيدق\n")
            append("- أفضل نقلة مقترحة من المحرك: $bestMoveSan\n")
            if (isUserInCheck) append("- تحذير دفاعي: ملكك تحت التهديد المباشر (كش - Check)!\n")
            if (isOpponentInCheck) append("- فرصة هجومية: ملك الخصم تحت التهديد المباشر (كش - Check)!\n")
            if (isUserCheckmated) append("- تحذير حاسم: لقد تعرضت لكش مات (Checkmate) وانتهت المباراة بالخسارة!\n")
            if (isOpponentCheckmated) append("- إنجاز رائع: لقد حققت كش مات (Checkmate) ضد الخصم وفزت بالمباراة!\n")
            
            if (!questionTopic.isNullOrBlank()) {
                append("\nسؤال/طلب اللاعب المحدد: \"$questionTopic\"\n")
            } else {
                append("\nيرجى تقديم شرح مختصر ومباشر (3-4 أسطر مركزة):\n")
                append("1. الخطورة أو التهديد الأبرز في هذه الوضعية.\n")
                append("2. الخطة الاستراتيجية الموصى بها ولماذا تعتبر النقلة المقترحة $bestMoveSan هي الأفضل.\n")
                append("3. نصيحة عملية سريعة للاعب.\n")
            }
        }.toString()

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "null") {
            return@withContext fallbackLocalExplanation(analysisResult, bestMoveSan, evalScore, isUserInCheck, isOpponentInCheck, userColor)
        }

        try {
            val jsonBody = JSONObject().apply {
                val contents = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().put("text", promptText))
                        }
                        put("parts", parts)
                    }
                    put(contentObj)
                }
                put("contents", contents)
                
                val genConfig = JSONObject().apply {
                    put("temperature", 0.4)
                    put("maxOutputTokens", 450)
                }
                put("generationConfig", genConfig)
            }

            val requestUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(requestUrl)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val responseStr = response.body?.string() ?: ""
                val responseJson = JSONObject(responseStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val aiText = parts.getJSONObject(0).optString("text", "")
                        if (aiText.isNotBlank()) {
                            return@withContext aiText.trim()
                        }
                    }
                }
            }
            return@withContext fallbackLocalExplanation(analysisResult, bestMoveSan, evalScore, isUserInCheck, isOpponentInCheck, userColor)
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext fallbackLocalExplanation(analysisResult, bestMoveSan, evalScore, isUserInCheck, isOpponentInCheck, userColor)
        }
    }

    private fun fallbackLocalExplanation(
        analysisResult: AnalysisResult?,
        bestMoveSan: String,
        evalScore: Double,
        isUserInCheck: Boolean,
        isOpponentInCheck: Boolean,
        userColor: PieceColor
    ): String {
        val bestLine = analysisResult?.bestMove
        val exp = bestLine?.explanationAr

        return StringBuilder().apply {
            append("💡 **تحليل مدرب الشطرنج الذكي:**\n")
            if (isUserInCheck) {
                append("⚠️ **تنبيه دفاعي:** ملكك تحت التهديد المباشر (كش)! الأولوية القصوى لحماية الملك والدفاع.\n\n")
            } else if (isOpponentInCheck) {
                append("⚔️ **فرصة هجومية:** ملك الخصم تحت الكش المباشر! حافظ على الضغط الهجومي لاستغلال الموقف.\n\n")
            }
            if (!exp.isNullOrBlank()) {
                append("$exp\n\n")
            } else {
                append("النقلة الموصى بها هي **$bestMoveSan** لتعزيز مركز الرقعة وتطوير القطع الهجومية.\n\n")
            }
            
            val userAdvantage = if (userColor == PieceColor.WHITE) evalScore else -evalScore
            when {
                userAdvantage > 2.0 -> append("📈 **نصيحة:** لديك تفوق مادي واستراتيجي ملموس (+${String.format("%.1f", Math.abs(userAdvantage))}). حافظ على الضغط وتبادل القطع للوصول لنهاية رابحة.")
                userAdvantage < -2.0 -> append("🛡️ **نصيحة:** المنافس يملك تفوقاً. تجنب التبادل غير المحسوب وركز على غلق الثغرات والدفاع المتين حول الملك.")
                else -> append("⚖️ **نصيحة:** الوضعية متكافئة تقريباً. حافظ على سلامة البيادق وسيطر على العامود المفتوح.")
            }
        }.toString()
    }
}
