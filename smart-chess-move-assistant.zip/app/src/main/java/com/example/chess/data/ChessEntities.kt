package com.example.chess.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_games")
data class SavedGame(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val fen: String,
    val pgn: String,
    val playerColor: String, // "WHITE" or "BLACK"
    val totalMoves: Int,
    val result: String = "*",
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "analysis_records")
data class AnalysisRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gameId: Long = 0,
    val moveIndex: Int,
    val fen: String,
    val moveSan: String,
    val evalScore: Double,
    val qualityLabel: String,
    val timestamp: Long = System.currentTimeMillis()
)
