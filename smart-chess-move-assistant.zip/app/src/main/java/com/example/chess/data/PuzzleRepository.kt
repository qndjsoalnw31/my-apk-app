package com.example.chess.data

import com.example.chess.model.PieceColor

data class ChessPuzzle(
    val id: String,
    val titleAr: String,
    val categoryAr: String,
    val fen: String,
    val userColor: PieceColor,
    val targetMoveSan: String,
    val hintAr: String,
    val solutionExplanationAr: String
)

object PuzzleRepository {

    val puzzles = listOf(
        ChessPuzzle(
            id = "p1",
            titleAr = "كش مات الصف الخلفي (Back Rank Mate)",
            categoryAr = "كش مات في نقلة واحدة",
            fen = "6k1/5ppp/8/8/8/8/8/1R4K1 w - - 0 1",
            userColor = PieceColor.WHITE,
            targetMoveSan = "Rb8#",
            hintAr = "استغل عدم وجود حماية لصف الملك الخلفي وهاجم بواسطة الرخ.",
            solutionExplanationAr = "النقلة Rb8# تحقق كش مات فوري لأن بيادق الملك تحاصره ولا يستطيع الهروب إلى الصف السابع!"
        ),
        ChessPuzzle(
            id = "p2",
            titleAr = "شوكة الحصان القاتلة (Knight Fork)",
            categoryAr = "تكتيك الشوكة",
            fen = "r1bqkb1r/pppp1ppp/2n2n2/4p3/4P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 4 4",
            userColor = PieceColor.WHITE,
            targetMoveSan = "Nxe5",
            hintAr = "ابحث عن أخذ بيدق مع فتح ثغرة تكتيكية.",
            solutionExplanationAr = "النقلة Nxe5 تهدد بفرصة كسب تفوق مادي واستدراج قطع الأسود إلى مربعات مكشوفة."
        ),
        ChessPuzzle(
            id = "p3",
            titleAr = "مات بالوزير المباشر (Queen Mate)",
            categoryAr = "كش مات في نقلة واحدة",
            fen = "r1bqk2r/pppp1ppp/2n5/2b1p3/2B1P3/5Q2/PPPP1PPP/RNB1K2R w KQkq - 0 5",
            userColor = PieceColor.WHITE,
            targetMoveSan = "Qxf7#",
            hintAr = "المربع f7 هو أضعف مربع في معسكر الأسود! هاجمه بالوزير بدعم من الفيل.",
            solutionExplanationAr = "النقلة Qxf7# تسمى (مات الشاب / Scholar's Mate) وهي كش مات مباشر بمساندة الفيل c4!"
        ),
        ChessPuzzle(
            id = "p4",
            titleAr = "تكتيك الربط بالفيل (Pin Tactical)",
            categoryAr = "الربط التكتيكي",
            fen = "r1bqk2r/pp3ppp/2p2n2/2bpP3/4P3/2PB4/PP1P1PPP/RNBQK2R w KQkq - 0 7",
            userColor = PieceColor.WHITE,
            targetMoveSan = "exf6",
            hintAr = "استغل غياب حماية الحصان واكسب قطعة صافية.",
            solutionExplanationAr = "أخذ الحصان exf6 يمنحك تفوقاً مادياً كبيراً بحصان كامل!"
        ),
        ChessPuzzle(
            id = "p5",
            titleAr = "مات الرخ على العامود المفتوح",
            categoryAr = "نهاية دور وتكتيك",
            fen = "3r2k1/p4ppp/8/8/8/8/P4PPP/2R3K1 w - - 0 1",
            userColor = PieceColor.WHITE,
            targetMoveSan = "Rc8",
            hintAr = "هاجم رخ الأسود على العامود c المفتوح.",
            solutionExplanationAr = "السيطرة على الصف والرخ تهدد بكش مات مباشر على الصف الثامن!"
        )
    )
}
