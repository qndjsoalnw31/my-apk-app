package com.example.chess.engine

import com.example.chess.model.Move

object PgnUtils {

    fun exportPgn(
        event: String = "مباراة شطرنج",
        site: String = "مساعد الشطرنج الذكي",
        date: String = "2026.07.27",
        whitePlayer: String = "لاعب 1",
        blackPlayer: String = "لاعب 2",
        result: String = "*",
        moveHistory: List<Move>
    ): String {
        val sb = StringBuilder()
        sb.append("[Event \"$event\"]\n")
        sb.append("[Site \"$site\"]\n")
        sb.append("[Date \"$date\"]\n")
        sb.append("[White \"$whitePlayer\"]\n")
        sb.append("[Black \"$blackPlayer\"]\n")
        sb.append("[Result \"$result\"]\n\n")

        for (i in moveHistory.indices) {
            if (i % 2 == 0) {
                val moveNum = (i / 2) + 1
                sb.append("$moveNum. ")
            }
            sb.append(moveHistory[i].san).append(" ")
        }
        sb.append(result)
        return sb.toString()
    }

    fun parsePgnMoves(pgnText: String): List<String> {
        val cleanPgn = pgnText.replace("\\[.*?\\]".toRegex(), "").trim()
        val moveTokens = cleanPgn.split("\\s+".toRegex())
        val moves = mutableListOf<String>()

        for (token in moveTokens) {
            if (token.contains(".") || token == "1-0" || token == "0-1" || token == "1/2-1/2" || token == "*") {
                continue
            }
            if (token.isNotBlank()) {
                moves.add(token)
            }
        }
        return moves
    }
}
