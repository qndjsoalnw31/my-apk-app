package com.example.chess.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import com.example.chess.state.ChessStateHolder
import com.example.chess.state.EditSubMode
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry

class FloatingChessOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var overlayLifecycleOwner: OverlayLifecycleOwner? = null

    private var baseWidthDp = 320
    private var baseHeightDp = 380
    private var currentScale by mutableStateOf(1.0f)

    private var isMinimized by mutableStateOf(false)
    private var isPositionLocked by mutableStateOf(false)
    private var savedWidthPx = 0
    private var savedHeightPx = 0
    private var currentAlpha by mutableStateOf(0.95f)

    private var dragStartX = 0
    private var dragStartY = 0
    private var dragAccX = 0f
    private var dragAccY = 0f

    private var resizeStartW = 0
    private var resizeStartH = 0
    private var resizeAccX = 0f
    private var resizeAccY = 0f

    private var moveAnimator: android.animation.ValueAnimator? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        ChessStateHolder.init(this)
        startForegroundServiceNotification()
        setupOverlayWindow()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun startForegroundServiceNotification() {
        val channelId = "floating_chess_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "مساعد الشطرنج العائم",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingChessOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            0,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("مساعد الشطرنج الذكي")
            .setContentText("النافذة العائمة نشطة وتعمل فوق التطبيقات")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إغلاق النافذة", stopPendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1001, notification)
        }
    }

    private fun setupOverlayWindow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            (baseWidthDp * currentScale).toInt().dpToPx(this),
            (baseHeightDp * currentScale).toInt().dpToPx(this),
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                    WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,
            PixelFormat.RGBA_8888
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }

        val lifecycleOwner = OverlayLifecycleOwner()
        lifecycleOwner.onCreate()
        overlayLifecycleOwner = lifecycleOwner

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            setContent {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    FloatingOverlayContent(
                        currentScale = currentScale,
                        isMinimized = isMinimized,
                        isPositionLocked = isPositionLocked,
                        currentAlpha = currentAlpha,
                        onClose = { stopSelf() },
                        onToggleMinimize = { toggleMinimize() },
                        onTogglePositionLock = { togglePositionLock() },
                        onCycleOpacity = { cycleOpacity() },
                        onDragStart = { onDragStart() },
                        onDragMove = { dx, dy -> onDragMove(dx, dy) },
                        onResizeStart = { onResizeStart() },
                        onResizeMove = { dx, dy -> onResizeMove(dx, dy) },
                        onZoomChange = { deltaScale -> updateScale(deltaScale) },
                        onResetScale = { resetScale() },
                        onExpandToApp = {
                            val intent = Intent(this@FloatingChessOverlayService, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                            }
                            startActivity(intent)
                        }
                    )
                }
            }
        }

        overlayView = composeView
        try {
            windowManager.addView(overlayView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun togglePositionLock() {
        isPositionLocked = !isPositionLocked
    }

    private fun onDragStart() {
        if (isPositionLocked) return
        params?.let {
            dragStartX = it.x
            dragStartY = it.y
            dragAccX = 0f
            dragAccY = 0f
        }
    }

    private fun onDragMove(dx: Float, dy: Float) {
        if (isPositionLocked) return
        params?.let { p ->
            dragAccX += dx
            dragAccY += dy
            val displayMetrics = resources.displayMetrics
            val maxX = (displayMetrics.widthPixels - p.width).coerceAtLeast(0)
            val maxY = (displayMetrics.heightPixels - p.height).coerceAtLeast(0)
            p.x = (dragStartX + dragAccX.toInt()).coerceIn(0, maxX)
            p.y = (dragStartY + dragAccY.toInt()).coerceIn(0, maxY)
            try {
                windowManager.updateViewLayout(overlayView, p)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun onResizeStart() {
        if (isPositionLocked) return
        params?.let {
            resizeStartW = it.width
            resizeStartH = it.height
            resizeAccX = 0f
            resizeAccY = 0f
        }
    }

    private fun onResizeMove(dx: Float, dy: Float) {
        if (isPositionLocked) return
        params?.let { p ->
            resizeAccX += dx
            resizeAccY += dy
            val minW = 200.dpToPx(this)
            val minH = 240.dpToPx(this)
            val maxW = (resources.displayMetrics.widthPixels * 0.95f).toInt()
            val maxH = (resources.displayMetrics.heightPixels * 0.85f).toInt()

            p.width = (resizeStartW + resizeAccX.toInt()).coerceIn(minW, maxW)
            p.height = (resizeStartH + resizeAccY.toInt()).coerceIn(minH, maxH)
            currentScale = p.width.toFloat() / baseWidthDp.dpToPx(this)
            try {
                windowManager.updateViewLayout(overlayView, p)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun updateScale(deltaScale: Float) {
        if (isMinimized) return
        currentScale = (currentScale + deltaScale).coerceIn(0.5f, 2.5f)
        params?.let { p ->
            p.width = (baseWidthDp.dpToPx(this) * currentScale).toInt()
            p.height = (baseHeightDp.dpToPx(this) * currentScale).toInt()
            windowManager.updateViewLayout(overlayView, p)
        }
    }

    private fun resetScale() {
        if (isMinimized) return
        currentScale = 1.0f
        params?.let { p ->
            p.width = baseWidthDp.dpToPx(this)
            p.height = baseHeightDp.dpToPx(this)
            windowManager.updateViewLayout(overlayView, p)
        }
    }

    private fun toggleMinimize() {
        params?.let { p ->
            if (!isMinimized) {
                savedWidthPx = p.width
                savedHeightPx = p.height
                p.width = 140.dpToPx(this)
                p.height = 140.dpToPx(this)
                isMinimized = true
            } else {
                p.width = if (savedWidthPx > 0) savedWidthPx else baseWidthDp.dpToPx(this)
                p.height = if (savedHeightPx > 0) savedHeightPx else baseHeightDp.dpToPx(this)
                isMinimized = false
            }
            windowManager.updateViewLayout(overlayView, p)
        }
    }

    private fun cycleOpacity() {
        val nextAlpha = when {
            currentAlpha >= 0.9f -> 0.7f
            currentAlpha >= 0.65f -> 0.45f
            currentAlpha >= 0.4f -> 0.25f
            else -> 0.95f
        }
        currentAlpha = nextAlpha
        params?.let { p ->
            p.alpha = currentAlpha
            windowManager.updateViewLayout(overlayView, p)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        overlayLifecycleOwner?.onDestroy()
        overlayLifecycleOwner = null
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun Int.dpToPx(context: Context): Int {
        return (this * context.resources.displayMetrics.density).toInt()
    }

    companion object {
        const val ACTION_STOP = "com.example.chess.ACTION_STOP"
        var isRunning: Boolean = false
            private set
    }
}

private class OverlayLifecycleOwner : androidx.lifecycle.LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val lifecycleRegistry = androidx.lifecycle.LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle
        get() = lifecycleRegistry

    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    override val viewModelStore: ViewModelStore
        get() = store

    fun onCreate() {
        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    fun onDestroy() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }
}

@Composable
fun FloatingOverlayContent(
    currentScale: Float,
    isMinimized: Boolean,
    isPositionLocked: Boolean,
    currentAlpha: Float,
    onClose: () -> Unit,
    onToggleMinimize: () -> Unit,
    onTogglePositionLock: () -> Unit,
    onCycleOpacity: () -> Unit,
    onDragStart: () -> Unit,
    onDragMove: (Float, Float) -> Unit,
    onResizeStart: () -> Unit,
    onResizeMove: (Float, Float) -> Unit,
    onZoomChange: (Float) -> Unit,
    onResetScale: () -> Unit,
    onExpandToApp: () -> Unit
) {
    val context = LocalContext.current
    val boardState by ChessStateHolder.boardState.collectAsState()
    val userColor by ChessStateHolder.userColor.collectAsState()
    val isFlipped by ChessStateHolder.isBoardFlipped.collectAsState()
    val analysis by ChessStateHolder.analysisResult.collectAsState()
    val isAnalyzing by ChessStateHolder.isAnalyzing.collectAsState()
    val isEditMode by ChessStateHolder.isEditMode.collectAsState()
    val editSubMode by ChessStateHolder.editSubMode.collectAsState()
    val selectedSquare by ChessStateHolder.selectedSquare.collectAsState()
    val legalMoves by ChessStateHolder.legalMovesForSelected.collectAsState()
    val canUndoEdit by ChessStateHolder.canUndoEdit.collectAsState()
    val canRedoEdit by ChessStateHolder.canRedoEdit.collectAsState()
    val editHintMessage by ChessStateHolder.editHintMessage.collectAsState()
    val showCoordinates by ChessStateHolder.showCoordinates.collectAsState()
    val haptic = LocalHapticFeedback.current

    val selectedScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (selectedSquare != null) 1.09f else 1.0f,
        animationSpec = androidx.compose.animation.core.tween(durationMillis = 200),
        label = "selectedScale"
    )

    if (isMinimized) {
        // Draggable Floating Mini Chessboard View (all pieces visible)
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(12.dp))
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { onDragStart() },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            onDragMove(dragAmount.x, dragAmount.y)
                        }
                    )
                },
            color = Color(0xFF0F172A),
            tonalElevation = 8.dp,
            shadowElevation = 12.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(3.dp)
            ) {
                // Mini 8x8 Chessboard Canvas showing all pieces
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(8.dp))
                        .pointerInput(isFlipped) {
                            detectTapGestures { offset ->
                                val boardSize = min(size.width, size.height)
                                val offsetX = (size.width - boardSize) / 2f
                                val offsetY = (size.height - boardSize) / 2f
                                val tileSize = boardSize / 8f

                                if (offset.x in offsetX..(offsetX + boardSize) &&
                                    offset.y in offsetY..(offsetY + boardSize)
                                ) {
                                    val file = ((offset.x - offsetX) / tileSize).toInt().coerceIn(0, 7)
                                    val rankIndex = ((offset.y - offsetY) / tileSize).toInt().coerceIn(0, 7)
                                    val actualFile = if (isFlipped) 7 - file else file
                                    val actualRank = if (isFlipped) rankIndex else 7 - rankIndex
                                    ChessStateHolder.selectSquare(Square(actualFile, actualRank))
                                }
                            }
                        }
                ) {
                    val boardSize = min(size.width, size.height)
                    if (boardSize <= 0f) return@Canvas

                    val offsetX = (size.width - boardSize) / 2f
                    val offsetY = (size.height - boardSize) / 2f
                    val tileSize = boardSize / 8f

                    // 1. Draw Squares & Highlights
                    for (r in 0..7) {
                        for (f in 0..7) {
                            val isLight = (r + f) % 2 == 0
                            val sqColor = if (isLight) Color(0xFFF0D9B5) else Color(0xFFB58863)
                            val drawX = offsetX + (if (isFlipped) 7 - f else f) * tileSize
                            val drawY = offsetY + (if (isFlipped) r else 7 - r) * tileSize

                            drawRect(
                                color = sqColor,
                                topLeft = Offset(drawX, drawY),
                                size = Size(tileSize, tileSize)
                            )

                            val actualFile = if (isFlipped) 7 - f else f
                            val actualRank = if (isFlipped) r else 7 - r
                            if (selectedSquare?.file == actualFile && selectedSquare?.rank == actualRank) {
                                drawRect(
                                    color = Color(0x883B82F6),
                                    topLeft = Offset(drawX, drawY),
                                    size = Size(tileSize, tileSize)
                                )
                            }
                        }
                    }

                    // 2. Render all pieces clearly
                    val textSizePx = (tileSize * 0.76f).coerceAtLeast(8f)
                    val pieceTypeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)

                    val fillWhitePaint = android.graphics.Paint().apply {
                        textSize = textSizePx
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        typeface = pieceTypeface
                        color = android.graphics.Color.WHITE
                        style = android.graphics.Paint.Style.FILL
                    }
                    val strokeWhitePaint = android.graphics.Paint().apply {
                        textSize = textSizePx
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        typeface = pieceTypeface
                        color = android.graphics.Color.parseColor("#090D16")
                        style = android.graphics.Paint.Style.STROKE
                        strokeWidth = (tileSize * 0.055f).coerceAtLeast(1.5f)
                    }
                    val fillBlackPaint = android.graphics.Paint().apply {
                        textSize = textSizePx
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        typeface = pieceTypeface
                        color = android.graphics.Color.parseColor("#0F172A")
                        style = android.graphics.Paint.Style.FILL
                    }
                    val strokeBlackPaint = android.graphics.Paint().apply {
                        textSize = textSizePx
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        typeface = pieceTypeface
                        color = android.graphics.Color.parseColor("#F8FAFC")
                        style = android.graphics.Paint.Style.STROKE
                        strokeWidth = (tileSize * 0.04f).coerceAtLeast(1.2f)
                    }

                    val fontMetrics = fillWhitePaint.fontMetrics
                    val baselineOffset = (fontMetrics.descent + fontMetrics.ascent) / 2f

                    for (r in 0..7) {
                        for (f in 0..7) {
                            val piece = boardState.grid[r][f] ?: continue
                            val drawX = offsetX + (if (isFlipped) 7 - f else f) * tileSize
                            val drawY = offsetY + (if (isFlipped) r else 7 - r) * tileSize

                            val centerX = drawX + tileSize / 2f
                            val centerY = drawY + tileSize / 2f
                            val baselineY = centerY - baselineOffset
                            val symbolToDraw = piece.solidSymbol

                            if (piece.color == PieceColor.WHITE) {
                                drawContext.canvas.nativeCanvas.drawText(symbolToDraw, centerX, baselineY, strokeWhitePaint)
                                drawContext.canvas.nativeCanvas.drawText(symbolToDraw, centerX, baselineY, fillWhitePaint)
                            } else {
                                drawContext.canvas.nativeCanvas.drawText(symbolToDraw, centerX, baselineY, strokeBlackPaint)
                                drawContext.canvas.nativeCanvas.drawText(symbolToDraw, centerX, baselineY, fillBlackPaint)
                            }
                        }
                    }
                }

                // Mini Overlay Expand Button
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp)
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(Color(0xDD0F172A))
                        .clickable { onToggleMinimize() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInFull,
                        contentDescription = "تكبير",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
        return
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp)),
        color = Color(0xFF0F172A),
        tonalElevation = 8.dp,
        shadowElevation = 12.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp)
        ) {
            // Drag Header & Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { onDragStart() },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    onDragMove(dragAmount.x, dragAmount.y)
                                }
                            )
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.DragHandle,
                        contentDescription = "سحب النافذة",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier
                            .size(18.dp)
                            .padding(end = 2.dp)
                    )
                    Text(
                        text = "مساعد الشطرنج",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    if (isEditMode) {
                        Surface(
                            color = Color(0xFFF59E0B),
                            shape = CircleShape
                        ) {
                            Text(
                                text = "تعديل الرقعة (+)",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    } else if (isAnalyzing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(12.dp),
                            color = Color(0xFF3B82F6),
                            strokeWidth = 1.5.dp
                        )
                    } else if (boardState.activeColor == userColor && analysis?.bestMove != null) {
                        Surface(
                            color = Color(0xFF10B981),
                            shape = CircleShape
                        ) {
                            Text(
                                text = analysis?.bestMove?.san ?: "",
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    } else if (boardState.activeColor != userColor) {
                        Surface(
                            color = Color(0xFFF59E0B),
                            shape = CircleShape
                        ) {
                            Text(
                                text = "دور المنافس",
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Board Edit Mode Toggle Button (+)
                    Surface(
                        color = if (isEditMode) Color(0xFFF59E0B) else Color(0xFF334155),
                        shape = CircleShape,
                        modifier = Modifier
                            .padding(horizontal = 2.dp)
                            .size(24.dp)
                            .clickable { ChessStateHolder.toggleEditMode() }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = if (isEditMode) "إنهاء وضع التعديل" else "وضع تعديل الرقعة (+)",
                                tint = if (isEditMode) Color.Black else Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Coordinates Toggle Button (🏷️)
                    Surface(
                        color = if (showCoordinates) Color(0xFF10B981) else Color(0xFF334155),
                        shape = CircleShape,
                        modifier = Modifier
                            .padding(horizontal = 2.dp)
                            .size(24.dp)
                            .clickable {
                                try { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (_: Exception) {}
                                ChessStateHolder.toggleShowCoordinates()
                            }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "🏷️",
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Opacity Cycle Button
                    Surface(
                        color = Color(0xFF334155),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .padding(horizontal = 2.dp)
                            .clickable { onCycleOpacity() }
                    ) {
                        Text(
                            text = "${(currentAlpha * 100).toInt()}%",
                            color = Color(0xFFF59E0B),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }

                    // Lock Position Button
                    IconButton(
                        onClick = onTogglePositionLock,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = if (isPositionLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = if (isPositionLocked) "إلغاء قفل الموقع" else "قفل الموقع",
                            tint = if (isPositionLocked) Color(0xFFEF4444) else Color.LightGray,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    // Zoom Out
                    IconButton(
                        onClick = { onZoomChange(-0.15f) },
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "تصغير",
                            tint = Color.LightGray,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    Surface(
                        color = Color(0xFF334155),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.padding(horizontal = 2.dp)
                    ) {
                        Text(
                            text = "${(currentScale * 100).toInt()}%",
                            color = Color(0xFF38BDF8),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                .clickable { onResetScale() }
                        )
                    }

                    // Zoom In
                    IconButton(
                        onClick = { onZoomChange(0.15f) },
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "تكبير",
                            tint = Color.LightGray,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    // Minimize to Bubble
                    IconButton(
                        onClick = onToggleMinimize,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "تصغير للفقاعة",
                            tint = Color.LightGray,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    IconButton(
                        onClick = onExpandToApp,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInFull,
                            contentDescription = "فتح التطبيق",
                            tint = Color.LightGray,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Dedicated Edit Mode Controls Banner (Move / Eat-Remove / Turn Switch / Undo / Redo)
            AnimatedVisibility(visible = isEditMode) {
                Surface(
                    color = Color(0xFF0F172A),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 3.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                // Sub-mode 1: Move (نقل)
                                Surface(
                                    color = if (editSubMode == EditSubMode.MOVE) Color(0xFFF59E0B) else Color(0xFF334155),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.clickable {
                                        try { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (_: Exception) {}
                                        ChessStateHolder.setEditSubMode(EditSubMode.MOVE)
                                    }
                                ) {
                                    Text(
                                        text = "↔️ نقل",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (editSubMode == EditSubMode.MOVE) Color.Black else Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                // Sub-mode 2: Eat / Remove (أكل / إزالة)
                                Surface(
                                    color = if (editSubMode == EditSubMode.EAT_REMOVE) Color(0xFFEF4444) else Color(0xFF334155),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.clickable {
                                        try { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (_: Exception) {}
                                        ChessStateHolder.setEditSubMode(EditSubMode.EAT_REMOVE)
                                    }
                                ) {
                                    Text(
                                        text = "🗡️ أكل",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                // Undo Button (↶)
                                Surface(
                                    color = if (canUndoEdit) Color(0xFF2563EB) else Color(0xFF1E293B),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.clickable(enabled = canUndoEdit) {
                                        try { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (_: Exception) {}
                                        ChessStateHolder.undoEdit()
                                    }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Undo,
                                            contentDescription = "تراجع",
                                            tint = if (canUndoEdit) Color.White else Color.DarkGray,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = " تراجع",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (canUndoEdit) Color.White else Color.DarkGray
                                        )
                                    }
                                }

                                // Redo Button (↷)
                                Surface(
                                    color = if (canRedoEdit) Color(0xFF2563EB) else Color(0xFF1E293B),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.clickable(enabled = canRedoEdit) {
                                        try { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (_: Exception) {}
                                        ChessStateHolder.redoEdit()
                                    }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Redo,
                                            contentDescription = "إعادة",
                                            tint = if (canRedoEdit) Color.White else Color.DarkGray,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = " إعادة",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (canRedoEdit) Color.White else Color.DarkGray
                                        )
                                    }
                                }
                            }

                            // Turn switch: White / Black
                            Surface(
                                color = Color(0xFF059669),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.clickable {
                                    try { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (_: Exception) {}
                                    ChessStateHolder.toggleActiveColorInEditMode()
                                }
                            ) {
                                Text(
                                    text = if (boardState.activeColor == PieceColor.WHITE) "الدور: أبيض ♔" else "الدور: أسود ♚",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        // Piece placement palette if square selected or to edit
                        if (selectedSquare != null) {
                            val activeSq = selectedSquare!!
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "إضافة / تغيير قطعة في ${activeSq.name}:",
                                    fontSize = 10.sp,
                                    color = Color.LightGray,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    val currentColor = boardState.activeColor
                                    val pieces = listOf(
                                        PieceType.QUEEN to if (currentColor == PieceColor.WHITE) "♕" else "♛",
                                        PieceType.ROOK to if (currentColor == PieceColor.WHITE) "♖" else "♜",
                                        PieceType.BISHOP to if (currentColor == PieceColor.WHITE) "♗" else "♝",
                                        PieceType.KNIGHT to if (currentColor == PieceColor.WHITE) "♘" else "♞",
                                        PieceType.PAWN to if (currentColor == PieceColor.WHITE) "♙" else "♟"
                                    )
                                    for ((type, sym) in pieces) {
                                        Surface(
                                            color = Color(0xFF334155),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.clickable {
                                                try { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (_: Exception) {}
                                                ChessStateHolder.addPieceDirectly(activeSq, com.example.chess.model.Piece(type, currentColor))
                                            }
                                        ) {
                                            Text(
                                                text = sym,
                                                fontSize = 13.sp,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }

                                    // Delete selected piece
                                    if (boardState.getPiece(activeSq) != null) {
                                        Surface(
                                            color = Color(0xFFDC2626),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.clickable {
                                                try { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (_: Exception) {}
                                                ChessStateHolder.removePiece(activeSq)
                                            }
                                        ) {
                                            Text(
                                                text = "🗑️",
                                                fontSize = 11.sp,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Hint toast message banner
                        if (!editHintMessage.isNullOrEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Surface(
                                    color = Color(0xBB1E293B),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = editHintMessage!!,
                                        fontSize = 10.sp,
                                        color = Color(0xFFF59E0B),
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Mini Board Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
            ) {
                var dragStartSquare by remember { mutableStateOf<Square?>(null) }
                var dragCurrentSquare by remember { mutableStateOf<Square?>(null) }
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(isFlipped, isEditMode, editSubMode) {
                            detectTapGestures { offset ->
                                val boardSize = min(size.width, size.height)
                                val offsetX = (size.width - boardSize) / 2f
                                val offsetY = (size.height - boardSize) / 2f
                                val tileSize = boardSize / 8f

                                if (offset.x in offsetX..(offsetX + boardSize) &&
                                    offset.y in offsetY..(offsetY + boardSize)
                                ) {
                                    val file = ((offset.x - offsetX) / tileSize).toInt().coerceIn(0, 7)
                                    val rankIndex = ((offset.y - offsetY) / tileSize).toInt().coerceIn(0, 7)

                                    val actualFile = if (isFlipped) 7 - file else file
                                    val actualRank = if (isFlipped) rankIndex else 7 - rankIndex

                                    ChessStateHolder.selectSquare(Square(actualFile, actualRank))
                                }
                            }
                        }
                        .pointerInput(isFlipped, isEditMode, editSubMode) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    val boardSize = min(size.width, size.height)
                                    val offsetX = (size.width - boardSize) / 2f
                                    val offsetY = (size.height - boardSize) / 2f
                                    val tileSize = boardSize / 8f

                                    if (offset.x in offsetX..(offsetX + boardSize) &&
                                        offset.y in offsetY..(offsetY + boardSize)
                                    ) {
                                        val file = ((offset.x - offsetX) / tileSize).toInt().coerceIn(0, 7)
                                        val rankIndex = ((offset.y - offsetY) / tileSize).toInt().coerceIn(0, 7)
                                        val actualFile = if (isFlipped) 7 - file else file
                                        val actualRank = if (isFlipped) rankIndex else 7 - rankIndex
                                        val sq = Square(actualFile, actualRank)
                                        if (boardState.getPiece(sq) != null) {
                                            dragStartSquare = sq
                                            dragCurrentSquare = sq
                                            if (isEditMode) {
                                                if (editSubMode == EditSubMode.EAT_REMOVE) {
                                                    ChessStateHolder.removePiece(sq)
                                                } else {
                                                    ChessStateHolder.selectedSquare.value = sq
                                                }
                                            }
                                        }
                                    }
                                },
                                onDragEnd = {
                                    val start = dragStartSquare
                                    val end = dragCurrentSquare
                                    if (isEditMode && editSubMode == EditSubMode.MOVE && start != null && end != null && start != end) {
                                        ChessStateHolder.movePieceDirectly(start, end)
                                    }
                                    dragStartSquare = null
                                    dragCurrentSquare = null
                                },
                                onDragCancel = {
                                    val start = dragStartSquare
                                    val end = dragCurrentSquare
                                    if (isEditMode && editSubMode == EditSubMode.MOVE && start != null && end != null && start != end) {
                                        ChessStateHolder.movePieceDirectly(start, end)
                                    }
                                    dragStartSquare = null
                                    dragCurrentSquare = null
                                },
                                onDrag = { change, _ ->
                                    if (isEditMode) {
                                        change.consume()
                                        if (editSubMode == EditSubMode.MOVE) {
                                            val offset = change.position
                                            val boardSize = min(size.width, size.height)
                                            val offsetX = (size.width - boardSize) / 2f
                                            val offsetY = (size.height - boardSize) / 2f
                                            val tileSize = boardSize / 8f

                                            val startSq = dragStartSquare
                                            if (startSq != null &&
                                                offset.x in offsetX..(offsetX + boardSize) &&
                                                offset.y in offsetY..(offsetY + boardSize)
                                            ) {
                                                val file = ((offset.x - offsetX) / tileSize).toInt().coerceIn(0, 7)
                                                val rankIndex = ((offset.y - offsetY) / tileSize).toInt().coerceIn(0, 7)
                                                val actualFile = if (isFlipped) 7 - file else file
                                                val actualRank = if (isFlipped) rankIndex else 7 - rankIndex
                                                val targetSq = Square(actualFile, actualRank)

                                                dragCurrentSquare = targetSq
                                                ChessStateHolder.selectedSquare.value = targetSq
                                                ChessStateHolder.editHintMessage.value = "سحب إلى: ${targetSq.name}"
                                            }
                                        }
                                    }
                                }
                            )
                        }
                        .pointerInput(Unit) {
                            detectTransformGestures { _, _, zoom, _ ->
                                if (zoom != 1f) {
                                    onZoomChange((zoom - 1f) * 0.4f)
                                }
                            }
                        }
                ) {
                    val boardSize = min(size.width, size.height)
                    if (boardSize <= 0f) return@Canvas

                    val offsetX = (size.width - boardSize) / 2f
                    val offsetY = (size.height - boardSize) / 2f
                    val tileSize = boardSize / 8f

                    // 1. Draw Squares & Highlights
                    for (r in 0..7) {
                        for (f in 0..7) {
                            val isLight = (r + f) % 2 == 0
                            val sqColor = if (isLight) Color(0xFFF0D9B5) else Color(0xFFB58863)

                            val drawX = offsetX + (if (isFlipped) 7 - f else f) * tileSize
                            val drawY = offsetY + (if (isFlipped) r else 7 - r) * tileSize

                            drawRect(
                                color = sqColor,
                                topLeft = Offset(drawX, drawY),
                                size = Size(tileSize, tileSize)
                            )

                            // Draw Rank & File Coordinates
                            if (showCoordinates) {
                                if (f == 0) {
                                    val rankLabel = if (isFlipped) (r + 1).toString() else (8 - r).toString()
                                    val rankPaint = android.graphics.Paint().apply {
                                        textSize = (tileSize * 0.18f).coerceAtLeast(8f)
                                        color = if (isLight) android.graphics.Color.DKGRAY else android.graphics.Color.WHITE
                                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                                        isAntiAlias = true
                                    }
                                    drawContext.canvas.nativeCanvas.drawText(
                                        rankLabel,
                                        drawX + tileSize * 0.08f,
                                        drawY + tileSize * 0.28f,
                                        rankPaint
                                    )
                                }

                                if (r == 7) {
                                    val fileLabel = if (isFlipped) ('h' - f).toString() else ('a' + f).toString()
                                    val filePaint = android.graphics.Paint().apply {
                                        textSize = (tileSize * 0.18f).coerceAtLeast(8f)
                                        color = if (isLight) android.graphics.Color.DKGRAY else android.graphics.Color.WHITE
                                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                                        isAntiAlias = true
                                    }
                                    drawContext.canvas.nativeCanvas.drawText(
                                        fileLabel,
                                        drawX + tileSize * 0.80f,
                                        drawY + tileSize * 0.90f,
                                        filePaint
                                    )
                                }
                            }

                            // Highlight Selected
                            val actualFile = if (isFlipped) 7 - f else f
                            val actualRank = if (isFlipped) r else 7 - r
                            if (selectedSquare?.file == actualFile && selectedSquare?.rank == actualRank) {
                                // Semi-transparent square fill
                                drawRect(
                                    color = if (isEditMode) Color(0x99F59E0B) else Color(0x883B82F6),
                                    topLeft = Offset(drawX, drawY),
                                    size = Size(tileSize, tileSize)
                                )

                                // Vibrant outline border & outer glow
                                val strokeColor = if (isEditMode) Color(0xFFF59E0B) else Color(0xFF60A5FA)
                                val glowColor = if (isEditMode) Color(0x66F59E0B) else Color(0x663B82F6)

                                drawRect(
                                    color = glowColor,
                                    topLeft = Offset(drawX - 2.dp.toPx(), drawY - 2.dp.toPx()),
                                    size = Size(tileSize + 4.dp.toPx(), tileSize + 4.dp.toPx()),
                                    style = Stroke(width = 3.dp.toPx())
                                )
                                drawRect(
                                    color = strokeColor,
                                    topLeft = Offset(drawX + 1.dp.toPx(), drawY + 1.dp.toPx()),
                                    size = Size(tileSize - 2.dp.toPx(), tileSize - 2.dp.toPx()),
                                    style = Stroke(width = 2.5f.dp.toPx())
                                )
                            }

                            // Highlight King in Check
                            val piece = boardState.getPiece(actualFile, actualRank)
                            if (!isEditMode && piece?.type == PieceType.KING && (analysis?.isCheck == true || analysis?.isOpponentInCheck == true) && piece.color == boardState.activeColor) {
                                drawRect(
                                    color = Color(0xAAEF4444),
                                    topLeft = Offset(drawX, drawY),
                                    size = Size(tileSize, tileSize)
                                )
                            }
                        }
                    }

                    // 2. Legal Move Indicators (only when not in Edit Mode)
                    if (!isEditMode) {
                        for (move in legalMoves) {
                            val drawX = offsetX + (if (isFlipped) 7 - move.to.file else move.to.file) * tileSize + tileSize / 2f
                            val drawY = offsetY + (if (isFlipped) move.to.rank else 7 - move.to.rank) * tileSize + tileSize / 2f

                            if (move.capturedPiece != null) {
                                drawCircle(
                                    color = Color(0xAAEF4444),
                                    radius = tileSize * 0.38f,
                                    center = Offset(drawX, drawY)
                                )
                            } else {
                                drawCircle(
                                    color = Color(0xAA10B981),
                                    radius = tileSize * 0.18f,
                                    center = Offset(drawX, drawY)
                                )
                            }
                        }
                    }

                    // 3. Best Move Arrow Overlay (ONLY when not in Edit Mode & on user turn)
                    if (!isEditMode && boardState.activeColor == userColor) {
                        analysis?.bestMove?.move?.let { move ->
                            val fromX = offsetX + (if (isFlipped) 7 - move.from.file else move.from.file) * tileSize + tileSize / 2f
                            val fromY = offsetY + (if (isFlipped) move.from.rank else 7 - move.from.rank) * tileSize + tileSize / 2f
                            val toX = offsetX + (if (isFlipped) 7 - move.to.file else move.to.file) * tileSize + tileSize / 2f
                            val toY = offsetY + (if (isFlipped) move.to.rank else 7 - move.to.rank) * tileSize + tileSize / 2f

                            // Draw Arrow Line
                            drawLine(
                                color = Color(0xFF0284C7),
                                start = Offset(fromX, fromY),
                                end = Offset(toX, toY),
                                strokeWidth = tileSize * 0.14f
                            )

                            // Draw Arrowhead
                            val angle = atan2((toY - fromY).toDouble(), (toX - fromX).toDouble())
                            val arrowLength = tileSize * 0.35f
                            val arrowAngle = Math.toRadians(32.0)

                            val x1 = toX - arrowLength * cos(angle - arrowAngle).toFloat()
                            val y1 = toY - arrowLength * sin(angle - arrowAngle).toFloat()
                            val x2 = toX - arrowLength * cos(angle + arrowAngle).toFloat()
                            val y2 = toY - arrowLength * sin(angle + arrowAngle).toFloat()

                            val arrowPath = Path().apply {
                                moveTo(toX, toY)
                                lineTo(x1, y1)
                                lineTo(x2, y2)
                                close()
                            }
                            drawPath(arrowPath, color = Color(0xFF0284C7))
                        }
                    }

                    // 4. Render Chess Pieces with Crisp Dual-Layer Paint & Bold Sans-Serif Typeface
                    val textSizePx = (tileSize * 0.76f).coerceAtLeast(10f)
                    val pieceTypeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)

                    val fillWhitePaint = android.graphics.Paint().apply {
                        textSize = textSizePx
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        isSubpixelText = true
                        isFilterBitmap = true
                        typeface = pieceTypeface
                        color = android.graphics.Color.WHITE
                        style = android.graphics.Paint.Style.FILL
                    }

                    val strokeWhitePaint = android.graphics.Paint().apply {
                        textSize = textSizePx
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        isSubpixelText = true
                        isFilterBitmap = true
                        typeface = pieceTypeface
                        color = android.graphics.Color.parseColor("#090D16")
                        style = android.graphics.Paint.Style.STROKE
                        strokeWidth = (tileSize * 0.055f).coerceAtLeast(2f)
                    }

                    val fillBlackPaint = android.graphics.Paint().apply {
                        textSize = textSizePx
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        isSubpixelText = true
                        isFilterBitmap = true
                        typeface = pieceTypeface
                        color = android.graphics.Color.parseColor("#0F172A")
                        style = android.graphics.Paint.Style.FILL
                    }

                    val strokeBlackPaint = android.graphics.Paint().apply {
                        textSize = textSizePx
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        isSubpixelText = true
                        isFilterBitmap = true
                        typeface = pieceTypeface
                        color = android.graphics.Color.parseColor("#F8FAFC")
                        style = android.graphics.Paint.Style.STROKE
                        strokeWidth = (tileSize * 0.04f).coerceAtLeast(1.5f)
                    }

                    val shadowPaint = android.graphics.Paint().apply {
                        textSize = textSizePx
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        isSubpixelText = true
                        isFilterBitmap = true
                        typeface = pieceTypeface
                        color = android.graphics.Color.parseColor("#44000000")
                        style = android.graphics.Paint.Style.FILL
                    }

                    val fontMetrics = fillWhitePaint.fontMetrics
                    val baselineOffset = (fontMetrics.descent + fontMetrics.ascent) / 2f

                    for (r in 0..7) {
                        for (f in 0..7) {
                            val piece = boardState.grid[r][f] ?: continue
                            val actualFile = f
                            val actualRank = r
                            val drawX = offsetX + (if (isFlipped) 7 - f else f) * tileSize
                            val drawY = offsetY + (if (isFlipped) r else 7 - r) * tileSize

                            val centerX = drawX + tileSize / 2f
                            val centerY = drawY + tileSize / 2f
                            val baselineY = centerY - baselineOffset

                            val isSelected = (selectedSquare?.file == actualFile && selectedSquare?.rank == actualRank)

                            if (isSelected) {
                                // Subtle glowing halo circle behind selected piece
                                val haloColor = if (isEditMode) Color(0x66F59E0B) else Color(0x663B82F6)
                                drawCircle(
                                    color = haloColor,
                                    radius = tileSize * 0.44f * selectedScale,
                                    center = Offset(centerX, centerY)
                                )

                                drawContext.canvas.nativeCanvas.save()
                                drawContext.canvas.nativeCanvas.scale(selectedScale, selectedScale, centerX, centerY)
                            }

                            val symbolToDraw = piece.solidSymbol

                            // Soft piece drop shadow for 3D depth
                            drawContext.canvas.nativeCanvas.drawText(
                                symbolToDraw,
                                centerX + 1.5.dp.toPx(),
                                baselineY + 2.5.dp.toPx(),
                                shadowPaint
                            )

                            if (piece.color == PieceColor.WHITE) {
                                drawContext.canvas.nativeCanvas.drawText(
                                    symbolToDraw,
                                    centerX,
                                    baselineY,
                                    strokeWhitePaint
                                )
                                drawContext.canvas.nativeCanvas.drawText(
                                    symbolToDraw,
                                    centerX,
                                    baselineY,
                                    fillWhitePaint
                                )
                            } else {
                                drawContext.canvas.nativeCanvas.drawText(
                                    symbolToDraw,
                                    centerX,
                                    baselineY,
                                    strokeBlackPaint
                                )
                                drawContext.canvas.nativeCanvas.drawText(
                                    symbolToDraw,
                                    centerX,
                                    baselineY,
                                    fillBlackPaint
                                )
                            }

                            if (isSelected) {
                                drawContext.canvas.nativeCanvas.restore()
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Bottom Quick Actions Bar with Drag and Resize Handles
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { onDragStart() },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        onDragMove(dragAmount.x, dragAmount.y)
                                    }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DragHandle,
                            contentDescription = "سحب النافذة",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(2.dp))

                    Text(
                        text = "التقييم: ${String.format("%.2f", analysis?.evalScore ?: 0.0)}",
                        color = Color(0xFF38BDF8),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Board Edit Mode (+) Button
                    Surface(
                        color = if (isEditMode) Color(0xFFF59E0B) else Color(0xFF334155),
                        shape = CircleShape,
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .size(24.dp)
                            .clickable { ChessStateHolder.toggleEditMode() }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = if (isEditMode) "إنهاء وضع التعديل" else "وضع تعديل الرقعة (+)",
                                tint = if (isEditMode) Color.Black else Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Quick Side Toggle Button (White / Black)
                    Surface(
                        color = Color(0xFF334155),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .clickable {
                                val nextColor = if (userColor == PieceColor.WHITE) PieceColor.BLACK else PieceColor.WHITE
                                ChessStateHolder.selectUserColor(nextColor, context)
                            }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = "تبديل اللون",
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (userColor == PieceColor.WHITE) "أبيض" else "أسود",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(
                        onClick = { ChessStateHolder.isBoardFlipped.value = !ChessStateHolder.isBoardFlipped.value },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = "قلب الرقعة",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    IconButton(
                        onClick = { ChessStateHolder.undoMove() },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "تراجع",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    IconButton(
                        onClick = { ChessStateHolder.resetGame() },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "إعادة",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    // Resize Drag Handle
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .background(Color(0xFF0284C7), RoundedCornerShape(6.dp))
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { onResizeStart() },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        onResizeMove(dragAmount.x, dragAmount.y)
                                    }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AspectRatio,
                            contentDescription = "سحب لتغيير الحجم",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}
