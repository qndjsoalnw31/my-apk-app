package com.example.chess.model

import androidx.compose.ui.geometry.Offset

enum class PieceType(val symbol: String, val valInPawns: Int) {
    PAWN("P", 1),
    KNIGHT("N", 3),
    BISHOP("B", 3),
    ROOK("R", 5),
    QUEEN("Q", 9),
    KING("K", 100)
}

enum class PieceColor {
    WHITE, BLACK;

    fun opposite(): PieceColor = if (this == WHITE) BLACK else WHITE
}

data class Piece(
    val type: PieceType,
    val color: PieceColor
) {
    val fenChar: Char
        get() {
            val c = when (type) {
                PieceType.PAWN -> 'p'
                PieceType.KNIGHT -> 'n'
                PieceType.BISHOP -> 'b'
                PieceType.ROOK -> 'r'
                PieceType.QUEEN -> 'q'
                PieceType.KING -> 'k'
            }
            return if (color == PieceColor.WHITE) c.uppercaseChar() else c
        }

    val solidSymbol: String
        get() = when (type) {
            PieceType.KING -> "♚"
            PieceType.QUEEN -> "♛"
            PieceType.ROOK -> "♜"
            PieceType.BISHOP -> "♝"
            PieceType.KNIGHT -> "♞"
            PieceType.PAWN -> "♟"
        }

    val unicodeSymbol: String
        get() = when (color) {
            PieceColor.WHITE -> when (type) {
                PieceType.KING -> "♔"
                PieceType.QUEEN -> "♕"
                PieceType.ROOK -> "♖"
                PieceType.BISHOP -> "♗"
                PieceType.KNIGHT -> "♘"
                PieceType.PAWN -> "♙"
            }
            PieceColor.BLACK -> solidSymbol
        }
}

data class Square(
    val file: Int, // 0..7 (a..h)
    val rank: Int  // 0..7 (1..8)
) {
    val name: String
        get() = "${('a' + file)}${rank + 1}"

    val isLight: Boolean
        get() = (file + rank) % 2 != 0

    companion object {
        fun fromName(name: String): Square? {
            if (name.length != 2) return null
            val file = name[0] - 'a'
            val rank = name[1] - '1'
            if (file in 0..7 && rank in 0..7) {
                return Square(file, rank)
            }
            return null
        }
    }
}

data class Move(
    val from: Square,
    val to: Square,
    val piece: Piece,
    val capturedPiece: Piece? = null,
    val promotion: PieceType? = null,
    val isCastling: Boolean = false,
    val isEnPassant: Boolean = false,
    val san: String = "",
    val evalAfter: Double = 0.0
)

enum class MoveQuality(val labelAr: String, val colorHex: Long) {
    EXCELLENT("نقلة ممتازة ✨", 0xFF10B981),
    BEST("الأفضل 🎯", 0xFF3B82F6),
    GOOD("جيدة 👍", 0xFF10B981),
    INACCURACY("غير دقيقة ⚠️", 0xFFF59E0B),
    MISTAKE("خطأ ❌", 0xFFEF4444),
    BLUNDER("خطأ فادح 💥", 0xFFDC2626)
}

data class EngineLine(
    val move: Move,
    val san: String,
    val evalScore: Double, // +1.5 means White is +1.5 pawns
    val mateIn: Int? = null,
    val strengthPercentage: Int, // 0 to 100
    val pv: List<String> = emptyList(), // Principal variation (next suggested moves)
    val explanationAr: String = ""
)

data class AnalysisResult(
    val bestMove: EngineLine?,
    val topLines: List<EngineLine>,
    val evalScore: Double,
    val mateIn: Int? = null,
    val depthReached: Int,
    val isCheck: Boolean = false,
    val isCheckmate: Boolean = false,
    val isStalemate: Boolean = false,
    val threatDescriptionAr: String = "",
    val tacticAlertAr: String? = null,
    val isUserInCheck: Boolean = false,
    val isOpponentInCheck: Boolean = false,
    val isUserCheckmated: Boolean = false,
    val isOpponentCheckmated: Boolean = false
)

enum class EngineMode(val labelAr: String, val defaultDepth: Int) {
    QUICK("تحليل سريع ⚡", 8),
    BALANCED("تحليل متوازن ⚖️", 12),
    DEEP("تحليل عميق 🔍", 16)
}

enum class EngineStrength(val labelAr: String, val level: Int) {
    BEGINNER("مبتدئ (800)", 1),
    INTERMEDIATE("متوسط (1500)", 2),
    ADVANCED("متقدم (2000)", 3),
    MASTER("ماستر / Stockfish (2800+)", 4)
}

data class GameStats(
    val totalMoves: Int,
    val excellentCount: Int,
    val goodCount: Int,
    val inaccuracyCount: Int,
    val blunderCount: Int,
    val accuracyPercentage: Int,
    val evalHistory: List<Double>
)
