package com.example.chess.engine

import com.example.chess.model.Move
import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import kotlin.math.abs

object MoveGenerator {

    fun generateLegalMoves(state: BoardState, color: PieceColor = state.activeColor): List<Move> {
        val pseudoMoves = generatePseudoMoves(state, color)
        val legalMoves = mutableListOf<Move>()

        for (move in pseudoMoves) {
            val nextState = makeMove(state, move)
            if (!isInCheck(nextState, color)) {
                legalMoves.add(move)
            }
        }
        return legalMoves
    }

    fun generateLegalCapturesAndPromotions(state: BoardState, color: PieceColor = state.activeColor): List<Move> {
        val pseudoMoves = generatePseudoMoves(state, color)
        val legalCaptures = mutableListOf<Move>()

        for (move in pseudoMoves) {
            if (move.capturedPiece != null || move.promotion != null) {
                val nextState = makeMove(state, move)
                if (!isInCheck(nextState, color)) {
                    legalCaptures.add(move)
                }
            }
        }
        return legalCaptures
    }

    fun makeMove(state: BoardState, move: Move): BoardState {
        val next = state.copy()
        val piece = move.piece
        val color = piece.color

        // Remove piece from origin
        next.setPiece(move.from, null)

        // Handle Castling
        if (move.isCastling) {
            val rank = move.from.rank
            if (move.to.file == 6) { // Kingside
                next.setPiece(Square(6, rank), piece)
                val rook = next.getPiece(Square(7, rank))
                next.setPiece(Square(7, rank), null)
                next.setPiece(Square(5, rank), rook)
            } else if (move.to.file == 2) { // Queenside
                next.setPiece(Square(2, rank), piece)
                val rook = next.getPiece(Square(0, rank))
                next.setPiece(Square(0, rank), null)
                next.setPiece(Square(3, rank), rook)
            }
        } else if (move.isEnPassant) {
            next.setPiece(move.to, piece)
            val captureRank = if (color == PieceColor.WHITE) move.to.rank - 1 else move.to.rank + 1
            next.setPiece(Square(move.to.file, captureRank), null)
        } else if (move.promotion != null) {
            next.setPiece(move.to, Piece(move.promotion, color))
        } else {
            next.setPiece(move.to, piece)
        }

        // Reset En Passant Target
        next.enPassantSquare = null
        if (piece.type == PieceType.PAWN && abs(move.to.rank - move.from.rank) == 2) {
            val epRank = (move.from.rank + move.to.rank) / 2
            next.enPassantSquare = Square(move.from.file, epRank)
        }

        // Update Castling Rights
        if (piece.type == PieceType.KING) {
            if (color == PieceColor.WHITE) {
                next.whiteCanCastleKingside = false
                next.whiteCanCastleQueenside = false
            } else {
                next.blackCanCastleKingside = false
                next.blackCanCastleQueenside = false
            }
        }
        if (piece.type == PieceType.ROOK) {
            if (move.from.file == 0 && move.from.rank == 0) next.whiteCanCastleQueenside = false
            if (move.from.file == 7 && move.from.rank == 0) next.whiteCanCastleKingside = false
            if (move.from.file == 0 && move.from.rank == 7) next.blackCanCastleQueenside = false
            if (move.from.file == 7 && move.from.rank == 7) next.blackCanCastleKingside = false
        }
        if (move.to.file == 0 && move.to.rank == 0) next.whiteCanCastleQueenside = false
        if (move.to.file == 7 && move.to.rank == 0) next.whiteCanCastleKingside = false
        if (move.to.file == 0 && move.to.rank == 7) next.blackCanCastleQueenside = false
        if (move.to.file == 7 && move.to.rank == 7) next.blackCanCastleKingside = false
        next.sanitizeCastlingRights()

        // Halfmove & Fullmove update
        if (piece.type == PieceType.PAWN || move.capturedPiece != null) {
            next.halfmoveClock = 0
        } else {
            next.halfmoveClock++
        }

        if (color == PieceColor.BLACK) {
            next.fullmoveNumber++
        }

        next.activeColor = color.opposite()
        return next
    }

    fun isInCheck(state: BoardState, color: PieceColor): Boolean {
        // Find king square
        var kingSquare: Square? = null
        for (r in 0..7) {
            for (f in 0..7) {
                val p = state.getPiece(f, r)
                if (p != null && p.color == color && p.type == PieceType.KING) {
                    kingSquare = Square(f, r)
                    break
                }
            }
            if (kingSquare != null) break
        }
        if (kingSquare == null) return false

        return isSquareAttacked(state, kingSquare, color.opposite())
    }

    fun isSquareAttacked(state: BoardState, square: Square, attackerColor: PieceColor): Boolean {
        val f = square.file
        val r = square.rank

        // 1. Pawn attacks
        val pawnDir = if (attackerColor == PieceColor.WHITE) -1 else 1
        val pawnRank = r + pawnDir
        if (pawnRank in 0..7) {
            if (f - 1 >= 0) {
                val p = state.getPiece(f - 1, pawnRank)
                if (p != null && p.color == attackerColor && p.type == PieceType.PAWN) return true
            }
            if (f + 1 <= 7) {
                val p = state.getPiece(f + 1, pawnRank)
                if (p != null && p.color == attackerColor && p.type == PieceType.PAWN) return true
            }
        }

        // 2. Knight attacks
        val knightDx = intArrayOf(-2, -2, -1, -1, 1, 1, 2, 2)
        val knightDy = intArrayOf(-1, 1, -2, 2, -2, 2, -1, 1)
        for (i in 0..7) {
            val nf = f + knightDx[i]
            val nr = r + knightDy[i]
            if (nf in 0..7 && nr in 0..7) {
                val p = state.getPiece(nf, nr)
                if (p != null && p.color == attackerColor && p.type == PieceType.KNIGHT) return true
            }
        }

        // 3. King attacks
        for (dx in -1..1) {
            for (dy in -1..1) {
                if (dx == 0 && dy == 0) continue
                val kf = f + dx
                val kr = r + dy
                if (kf in 0..7 && kr in 0..7) {
                    val p = state.getPiece(kf, kr)
                    if (p != null && p.color == attackerColor && p.type == PieceType.KING) return true
                }
            }
        }

        // 4. Straight rays (Rook / Queen)
        val straightDx = intArrayOf(1, -1, 0, 0)
        val straightDy = intArrayOf(0, 0, 1, -1)
        for (i in 0..3) {
            var tf = f + straightDx[i]
            var tr = r + straightDy[i]
            while (tf in 0..7 && tr in 0..7) {
                val p = state.getPiece(tf, tr)
                if (p != null) {
                    if (p.color == attackerColor && (p.type == PieceType.ROOK || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                tf += straightDx[i]
                tr += straightDy[i]
            }
        }

        // 5. Diagonal rays (Bishop / Queen)
        val diagDx = intArrayOf(1, 1, -1, -1)
        val diagDy = intArrayOf(1, -1, 1, -1)
        for (i in 0..3) {
            var tf = f + diagDx[i]
            var tr = r + diagDy[i]
            while (tf in 0..7 && tr in 0..7) {
                val p = state.getPiece(tf, tr)
                if (p != null) {
                    if (p.color == attackerColor && (p.type == PieceType.BISHOP || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                tf += diagDx[i]
                tr += diagDy[i]
            }
        }

        return false
    }

    private fun generatePseudoMoves(
        state: BoardState,
        color: PieceColor,
        includeCastling: Boolean = true
    ): List<Move> {
        val moves = mutableListOf<Move>()
        for (r in 0..7) {
            for (f in 0..7) {
                val piece = state.getPiece(f, r) ?: continue
                if (piece.color != color) continue
                val from = Square(f, r)

                when (piece.type) {
                    PieceType.PAWN -> generatePawnMoves(state, from, piece, moves)
                    PieceType.KNIGHT -> generateKnightMoves(state, from, piece, moves)
                    PieceType.BISHOP -> generateSlidingMoves(state, from, piece, moves, BISHOP_DIRECTIONS)
                    PieceType.ROOK -> generateSlidingMoves(state, from, piece, moves, ROOK_DIRECTIONS)
                    PieceType.QUEEN -> generateSlidingMoves(state, from, piece, moves, QUEEN_DIRECTIONS)
                    PieceType.KING -> generateKingMoves(state, from, piece, moves, includeCastling)
                }
            }
        }
        return moves
    }

    private fun generatePawnMoves(state: BoardState, from: Square, piece: Piece, moves: MutableList<Move>) {
        val dir = if (piece.color == PieceColor.WHITE) 1 else -1
        val startRank = if (piece.color == PieceColor.WHITE) 1 else 6
        val promoRank = if (piece.color == PieceColor.WHITE) 7 else 0

        // Forward 1 square
        val targetRank = from.rank + dir
        if (targetRank in 0..7) {
            if (state.getPiece(from.file, targetRank) == null) {
                val to = Square(from.file, targetRank)
                if (targetRank == promoRank) {
                    listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT).forEach { promo ->
                        moves.add(Move(from, to, piece, promotion = promo))
                    }
                } else {
                    moves.add(Move(from, to, piece))
                }

                // Forward 2 squares from initial rank
                if (from.rank == startRank) {
                    val doubleRank = from.rank + 2 * dir
                    if (state.getPiece(from.file, doubleRank) == null) {
                        moves.add(Move(from, Square(from.file, doubleRank), piece))
                    }
                }
            }
        }

        // Captures
        for (fOffset in listOf(-1, 1)) {
            val targetFile = from.file + fOffset
            if (targetFile in 0..7 && targetRank in 0..7) {
                val targetPiece = state.getPiece(targetFile, targetRank)
                val targetSq = Square(targetFile, targetRank)

                if (targetPiece != null && targetPiece.color != piece.color) {
                    if (targetRank == promoRank) {
                        listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT).forEach { promo ->
                            moves.add(Move(from, targetSq, piece, capturedPiece = targetPiece, promotion = promo))
                        }
                    } else {
                        moves.add(Move(from, targetSq, piece, capturedPiece = targetPiece))
                    }
                } else if (state.enPassantSquare == targetSq) {
                    // En Passant capture
                    val epPiece = state.getPiece(targetFile, from.rank)
                    moves.add(Move(from, targetSq, piece, capturedPiece = epPiece, isEnPassant = true))
                }
            }
        }
    }

    private fun generateKnightMoves(state: BoardState, from: Square, piece: Piece, moves: MutableList<Move>) {
        val offsets = listOf(-2, -1, 1, 2)
        for (dx in offsets) {
            for (dy in offsets) {
                if (abs(dx) != abs(dy)) {
                    val tf = from.file + dx
                    val tr = from.rank + dy
                    if (tf in 0..7 && tr in 0..7) {
                        val targetPiece = state.getPiece(tf, tr)
                        if (targetPiece == null || targetPiece.color != piece.color) {
                            moves.add(Move(from, Square(tf, tr), piece, capturedPiece = targetPiece))
                        }
                    }
                }
            }
        }
    }

    private fun generateSlidingMoves(
        state: BoardState,
        from: Square,
        piece: Piece,
        moves: MutableList<Move>,
        directions: List<Pair<Int, Int>>
    ) {
        for ((dx, dy) in directions) {
            var tf = from.file + dx
            var tr = from.rank + dy
            while (tf in 0..7 && tr in 0..7) {
                val targetPiece = state.getPiece(tf, tr)
                val to = Square(tf, tr)
                if (targetPiece == null) {
                    moves.add(Move(from, to, piece))
                } else {
                    if (targetPiece.color != piece.color) {
                        moves.add(Move(from, to, piece, capturedPiece = targetPiece))
                    }
                    break
                }
                tf += dx
                tr += dy
            }
        }
    }

    private fun generateKingMoves(
        state: BoardState,
        from: Square,
        piece: Piece,
        moves: MutableList<Move>,
        includeCastling: Boolean
    ) {
        for (dx in -1..1) {
            for (dy in -1..1) {
                if (dx == 0 && dy == 0) continue
                val tf = from.file + dx
                val tr = from.rank + dy
                if (tf in 0..7 && tr in 0..7) {
                    val targetPiece = state.getPiece(tf, tr)
                    if (targetPiece == null || targetPiece.color != piece.color) {
                        moves.add(Move(from, Square(tf, tr), piece, capturedPiece = targetPiece))
                    }
                }
            }
        }

        if (includeCastling && !isInCheck(state, piece.color)) {
            val rank = if (piece.color == PieceColor.WHITE) 0 else 7
            if (from.rank == rank && from.file == 4) {
                val canKingside = if (piece.color == PieceColor.WHITE) state.whiteCanCastleKingside else state.blackCanCastleKingside
                val canQueenside = if (piece.color == PieceColor.WHITE) state.whiteCanCastleQueenside else state.blackCanCastleQueenside

                // Kingside
                if (canKingside && state.getPiece(5, rank) == null && state.getPiece(6, rank) == null) {
                    // Check path squares
                    val passState = state.copy()
                    passState.setPiece(Square(4, rank), null)
                    passState.setPiece(Square(5, rank), piece)
                    if (!isInCheck(passState, piece.color)) {
                        moves.add(Move(from, Square(6, rank), piece, isCastling = true))
                    }
                }

                // Queenside
                if (canQueenside && state.getPiece(1, rank) == null && state.getPiece(2, rank) == null && state.getPiece(3, rank) == null) {
                    val passState = state.copy()
                    passState.setPiece(Square(4, rank), null)
                    passState.setPiece(Square(3, rank), piece)
                    if (!isInCheck(passState, piece.color)) {
                        moves.add(Move(from, Square(2, rank), piece, isCastling = true))
                    }
                }
            }
        }
    }

    fun toSan(state: BoardState, move: Move): String {
        if (move.isCastling) {
            return if (move.to.file == 6) "O-O" else "O-O-O"
        }

        val piece = move.piece
        val sb = StringBuilder()

        if (piece.type != PieceType.PAWN) {
            sb.append(piece.type.symbol)

            // Disambiguation if needed
            val sameTypeMoves = generateLegalMoves(state, piece.color).filter {
                it.piece.type == piece.type && it.to == move.to && it.from != move.from
            }
            if (sameTypeMoves.isNotEmpty()) {
                val sameFile = sameTypeMoves.any { it.from.file == move.from.file }
                val sameRank = sameTypeMoves.any { it.from.rank == move.from.rank }
                if (!sameFile) {
                    sb.append('a' + move.from.file)
                } else if (!sameRank) {
                    sb.append(move.from.rank + 1)
                } else {
                    sb.append('a' + move.from.file).append(move.from.rank + 1)
                }
            }
        } else {
            if (move.capturedPiece != null || move.isEnPassant) {
                sb.append('a' + move.from.file)
            }
        }

        if (move.capturedPiece != null || move.isEnPassant) {
            sb.append("x")
        }

        sb.append(move.to.name)

        if (move.promotion != null) {
            sb.append("=").append(move.promotion.symbol)
        }

        val nextState = makeMove(state, move)
        val opponentColor = piece.color.opposite()
        if (isInCheck(nextState, opponentColor)) {
            val opponentLegalMoves = generateLegalMoves(nextState, opponentColor)
            if (opponentLegalMoves.isEmpty()) {
                sb.append("#")
            } else {
                sb.append("+")
            }
        }

        return sb.toString()
    }

    private val BISHOP_DIRECTIONS = listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1)
    private val ROOK_DIRECTIONS = listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)
    private val QUEEN_DIRECTIONS = BISHOP_DIRECTIONS + ROOK_DIRECTIONS
}
