package com.example.chess.data

import kotlinx.coroutines.flow.Flow

class ChessRepository(private val dao: ChessDao) {

    val savedGames: Flow<List<SavedGame>> = dao.getAllSavedGames()

    suspend fun saveGame(game: SavedGame): Long {
        return dao.insertGame(game)
    }

    suspend fun deleteGame(id: Long) {
        dao.deleteGame(id)
    }

    suspend fun recordAnalysis(record: AnalysisRecord) {
        dao.insertAnalysisRecord(record)
    }

    fun getRecordsForGame(gameId: Long): Flow<List<AnalysisRecord>> {
        return dao.getAnalysisRecords(gameId)
    }
}
