package com.example.chess.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChessDao {

    @Query("SELECT * FROM saved_games ORDER BY createdAt DESC")
    fun getAllSavedGames(): Flow<List<SavedGame>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: SavedGame): Long

    @Query("DELETE FROM saved_games WHERE id = :id")
    suspend fun deleteGame(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalysisRecord(record: AnalysisRecord)

    @Query("SELECT * FROM analysis_records WHERE gameId = :gameId ORDER BY moveIndex ASC")
    fun getAnalysisRecords(gameId: Long): Flow<List<AnalysisRecord>>
}
