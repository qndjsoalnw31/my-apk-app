package com.example.chess.engine

import com.example.chess.model.Move

data class OpeningInfo(
    val nameAr: String,
    val nameEn: String,
    val ecoCode: String,
    val descriptionAr: String,
    val keyPlanAr: String
)

object OpeningBook {

    fun detectOpening(moveHistory: List<Move>): OpeningInfo? {
        if (moveHistory.isEmpty()) return null

        val sans = moveHistory.map { it.san.replace("+", "").replace("#", "") }
        val movesStr = sans.joinToString(" ")

        return when {
            movesStr.startsWith("e4 e5 Nf3 Nc6 Bb5") -> OpeningInfo(
                nameAr = "افتتاح روي لوبيز (الإسباني)",
                nameEn = "Ruy Lopez / Spanish Opening",
                ecoCode = "C60-C99",
                descriptionAr = "من أعرق وأقوى الافتتاحيات في التاريخ.",
                keyPlanAr = "الضغط على حصان c6 وتأمين التبيت السريع والسيطرة على مربعات d4 وe4."
            )
            movesStr.startsWith("e4 c5") -> OpeningInfo(
                nameAr = "الدفاع الصقلي",
                nameEn = "Sicilian Defense",
                ecoCode = "B20-B99",
                descriptionAr = "الدفاع الأكثر ديناميكية وهجوماً ضد 1.e4.",
                keyPlanAr = "خلق اختلال في مركز الرقعة واستغلال عامود c المفتوح مع هجوم حاد على جناح الوزير."
            )
            movesStr.startsWith("e4 e6") -> OpeningInfo(
                nameAr = "الدفاع الفرنسي",
                nameEn = "French Defense",
                ecoCode = "C00-C19",
                descriptionAr = "افتتاح صلب ومتين يهدف لتأسيس سلاسل بيادق قوية.",
                keyPlanAr = "دعم النقلة d5 والضغط على مركز بيادق الأبيض في c5 وd4."
            )
            movesStr.startsWith("e4 c6") -> OpeningInfo(
                nameAr = "دفاع كارو-كان",
                nameEn = "Caro-Kann Defense",
                ecoCode = "B10-B19",
                descriptionAr = "دفاع آمن جداً يمتاز بهيكل بيادق سليم ودون إغلاق فيل المربعات الفاتحة.",
                keyPlanAr = "تجهيز النقلة d5 ثم تطوير فيل c8 بحرية قبل غلق السلسلة البيدقية."
            )
            movesStr.startsWith("d4 d5 c4") -> OpeningInfo(
                nameAr = "جامبيت الوزير",
                nameEn = "Queen's Gambit",
                ecoCode = "D06-D69",
                descriptionAr = "التضحية بالبيدق الجانبي للسيطرة الشاملة على الوسط.",
                keyPlanAr = "استبدال بيدق الجناح c4 بمركز أقوى للسيطرة على d5 وe4."
            )
            movesStr.startsWith("e4 e5 Nf3 Nc6 Bc4") -> OpeningInfo(
                nameAr = "الافتتاح الإيطالي",
                nameEn = "Italian Game",
                ecoCode = "C50-C59",
                descriptionAr = "افتتاح كلاسيكي يركز على التطوير السريع للقطع والسيطرة على المركز.",
                keyPlanAr = "توجيه فيل c4 نحو المربع الضعيف f7 والتجهيز للسيطرة على مربعات d4."
            )
            movesStr.startsWith("e4 e5 Nf3 Nc6 Nc3 Nf6") -> OpeningInfo(
                nameAr = "افتتاح الفرسان الأربعة",
                nameEn = "Four Knights Game",
                ecoCode = "C48-C49",
                descriptionAr = "افتتاح هادئ ومتكافئ يعتمد على الانتشار السليم والآمن.",
                keyPlanAr = "تطوير كافة القطع الصغرى بسرعة والتبيت المبكر لمباراة متكافئة."
            )
            movesStr.startsWith("d4 Nf6 c4 g6") -> OpeningInfo(
                nameAr = "دفاع الهندي الملكي",
                nameEn = "King's Indian Defense",
                ecoCode = "E60-E99",
                descriptionAr = "دفاع فرنسي هجومي يمنح الأبيض المركز ليشن الأسود هجوماً مضاداً على ملكه.",
                keyPlanAr = "فيانشيتو الفيل g7 ثم اختراق مركز الأبيض بالنقلات e5 أو f5."
            )
            movesStr.startsWith("d4 d5 Nf3 Nf6 Bf4") || movesStr.startsWith("d4 Nf6 Nf3 d5 Bf4") -> OpeningInfo(
                nameAr = "نظام لندن",
                nameEn = "London System",
                ecoCode = "D02",
                descriptionAr = "نظام حديث وصلب جداً يمنح الأبيض وضعية آمنة دون حظر قطع معينة.",
                keyPlanAr = "تثبيت الفيل في f4 وبناء هرم بيدقي صلب (c3-d4-e3) والتثبيت في e5."
            )
            movesStr.startsWith("c4") -> OpeningInfo(
                nameAr = "الافتتاح الإنجليزي",
                nameEn = "English Opening",
                ecoCode = "A10-A39",
                descriptionAr = "افتتاح مرن يسيطر على المربع d5 من الجناح.",
                keyPlanAr = "التحكم بالمربع d5 وبناء هجوم تدريجي على جناح الوزير."
            )
            movesStr.startsWith("Nf3") -> OpeningInfo(
                nameAr = "افتتاح ريتي",
                nameEn = "Réti Opening",
                ecoCode = "A04-A09",
                descriptionAr = "افتتاح فرنسي غير مباشر يؤجل تحريك بيادق المركز.",
                keyPlanAr = "السيطرة البعيدة على بيادق الوسط وإرغام الخصم على التقدم المبكر."
            )
            movesStr.startsWith("e4 d5") -> OpeningInfo(
                nameAr = "الدفاع الاسكندنافي",
                nameEn = "Scandinavian Defense",
                ecoCode = "B01",
                descriptionAr = "التحدي المباشر لبيدق e4 من النقلة الأولى.",
                keyPlanAr = "تكسير بيدق e4 سريعاً وفتح خطوط لوزير وفيلة الأسود."
            )
            movesStr.startsWith("e4 e5 Nf3 Nf6") -> OpeningInfo(
                nameAr = "دفاع بيتروف (الروسي)",
                nameEn = "Petrov's Defense",
                ecoCode = "C42-C43",
                descriptionAr = "دفاع صلب وند بند يهاجم بيدق e4 مباشرة.",
                keyPlanAr = "استرداد البيدق وتحقيق التعادل والصلابة البيدقية بسرعة."
            )
            movesStr.startsWith("e4 e5") -> OpeningInfo(
                nameAr = "افتتاح بيدق الملك المزدوَج",
                nameEn = "Open Game (1.e4 e5)",
                ecoCode = "C20",
                descriptionAr = "المواجهة التقليدية المفتوحة للسيطرة المباشرة على الوسط.",
                keyPlanAr = "الانتشار السريع للفرسان والفيلة والتطلع نحو التبيت المريح."
            )
            movesStr.startsWith("d4 d5") -> OpeningInfo(
                nameAr = "افتتاح بيدق الوزير",
                nameEn = "Closed Game (1.d4 d5)",
                ecoCode = "D00",
                descriptionAr = "المواجهة المغلقة الصارمة للتحكم بمربعات d4 وd5.",
                keyPlanAr = "تطوير القطع وتجهيز اختراقات الجناح أو بناء قلعة صلبة."
            )
            else -> null
        }
    }
}
