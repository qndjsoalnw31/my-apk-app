package com.example.chess.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.model.Piece

@Composable
fun CapturedPiecesBar(
    capturedWhite: List<Piece>,
    capturedBlack: List<Piece>,
    modifier: Modifier = Modifier
) {
    val whiteVal = capturedWhite.sumOf { it.type.valInPawns }
    val blackVal = capturedBlack.sumOf { it.type.valInPawns }
    val diff = whiteVal - blackVal

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Captured White pieces (captured by Black)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "المأخوذ:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(4.dp))
            capturedWhite.forEach { piece ->
                Text(
                    text = piece.solidSymbol,
                    fontSize = 16.sp,
                    color = Color.White
                )
            }
            if (diff < 0) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "+${-diff}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF10B981)
                )
            }
        }

        // Captured Black pieces (captured by White)
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (diff > 0) {
                Text(
                    text = "+$diff",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF10B981)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            capturedBlack.forEach { piece ->
                Text(
                    text = piece.solidSymbol,
                    fontSize = 16.sp,
                    color = Color(0xFF0F172A)
                )
            }
        }
    }
}
