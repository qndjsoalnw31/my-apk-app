package com.example.chess.engine

import com.example.chess.model.AnalysisResult
import com.example.chess.model.EngineLine
import com.example.chess.model.EngineMode
import com.example.chess.model.EngineStrength
import com.example.chess.model.Move
import com.example.chess.model.MoveQuality
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.util.Random
import kotlin.coroutines.coroutineContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object StockfishEngine {

    // Piece Value Weights in Centipawns
    private const val PAWN_VAL = 100
    private const val KNIGHT_VAL = 320
    private const val BISHOP_VAL = 330
    private const val ROOK_VAL = 500
    private const val QUEEN_VAL = 950
    private const val KING_VAL = 20000

    private const val INF_SCORE = 200000
    private const val MATE_SCORE = 100000

    // Transposition Table Entry Flag
    private const val TT_EXACT = 0
    private const val TT_LOWERBOUND = 1
    private const val TT_UPPERBOUND = 2

    private data class TTEntry(
        var hash: Long = 0L,
        var depth: Int = 0,
        var score: Int = 0,
        var flag: Int = TT_EXACT,
        var bestMove: Move? = null
    )

    private const val TT_SIZE = 65536
    private const val TT_MASK = TT_SIZE - 1
    private val transpositionTable = Array(TT_SIZE) { TTEntry() }

    // Killer Moves & History Heuristics
    private const val MAX_PLY = 32
    private val killerMoves = Array(MAX_PLY) { Array<Move?>(2) { null } }
    private val historyTable = Array(2) { Array(64) { IntArray(64) } }

    // Zobrist Hashing Random Keys
    private val zobristPieces = Array(8) { Array(8) { LongArray(12) } }
    private var zobristColor = 0L
    private val zobristCastling = LongArray(16)
    private val zobristEnPassant = LongArray(9)

    init {
        val rng = Random(1070377L)
        for (r in 0..7) {
            for (f in 0..7) {
                for (p in 0..11) {
                    zobristPieces[r][f][p] = rng.nextLong()
                }
            }
        }
        zobristColor = rng.nextLong()
        for (i in 0..15) zobristCastling[i] = rng.nextLong()
        for (i in 0..8) zobristEnPassant[i] = rng.nextLong()
    }

    private fun pieceIndex(type: PieceType, color: PieceColor): Int {
        val base = when (type) {
            PieceType.PAWN -> 0
            PieceType.KNIGHT -> 1
            PieceType.BISHOP -> 2
            PieceType.ROOK -> 3
            PieceType.QUEEN -> 4
            PieceType.KING -> 5
        }
        return if (color == PieceColor.WHITE) base else base + 6
    }

    fun computeZobristHash(state: BoardState): Long {
        var hash = 0L
        for (r in 0..7) {
            for (f in 0..7) {
                val piece = state.grid[r][f] ?: continue
                val idx = pieceIndex(piece.type, piece.color)
                hash = hash xor zobristPieces[r][f][idx]
            }
        }
        if (state.activeColor == PieceColor.BLACK) {
            hash = hash xor zobristColor
        }
        var cIdx = 0
        if (state.whiteCanCastleKingside) cIdx = cIdx or 1
        if (state.whiteCanCastleQueenside) cIdx = cIdx or 2
        if (state.blackCanCastleKingside) cIdx = cIdx or 4
        if (state.blackCanCastleQueenside) cIdx = cIdx or 8
        hash = hash xor zobristCastling[cIdx]

        val epFile = state.enPassantSquare?.file ?: 8
        hash = hash xor zobristEnPassant[epFile]

        return hash
    }

    // PeSTO Middlegame & Endgame Piece Square Tables
    private val PAWN_MG = intArrayOf(
          0,   0,   0,   0,   0,   0,   0,   0,
         98, 134,  61,  95,  68, 126,  34, -11,
         -6,   7,  26,  31,  65,  56,  25, -20,
        -14,  13,   6,  21,  23,  12,  17, -23,
        -27,  -2,  -5,  12,  17,   6,  10, -25,
        -26,  -4,  -4, -10,   3,   3,  33, -12,
        -35,  -1, -20, -23, -15,  24,  38, -22,
          0,   0,   0,   0,   0,   0,   0,   0
    )

    private val PAWN_EG = intArrayOf(
          0,   0,   0,   0,   0,   0,   0,   0,
        178, 173, 158, 134, 147, 132, 165, 187,
         94, 100,  98,  67,  67,  73,  82,  82,
         32,  33,  29,  17,   9,   8,  20,  23,
         13,   9,   8,  -7,  -3,  -3,   9,   8,
          4,   7,  -6,   1,   0,  -5,  -1,  -8,
         13,   8,   8,  10,  13,   0,   2,  -7,
          0,   0,   0,   0,   0,   0,   0,   0
    )

    private val KNIGHT_MG = intArrayOf(
       -167, -89, -34, -49,  61, -97, -15,-107,
        -73, -41,  72,  36,  23,  62,   7, -17,
        -47,  60,  37,  65,  84, 129,  73,  44,
         -9,  17,  19,  53,  37,  41,  18,   1,
        -13,   4,  16,  13,  28,  19,  21,  -8,
        -23,  -9,  12,  10,  19,  17,  25, -16,
        -29, -53, -12,  -3,  -1,  18, -14, -19,
       -105, -21,  -6,  -8, -11, -14, -19, -33
    )

    private val KNIGHT_EG = intArrayOf(
        -58, -38, -13, -28, -31, -27, -63, -99,
        -25,  -8, -25,  -2,  -9, -25, -24, -52,
        -24, -20,  10,   9,  -1,  -9, -19, -41,
        -17,   3,  22,  22,  22,  11,   8, -18,
        -18,  -6,  16,  25,  16,  17,   4, -18,
        -23,  -3,  -1,  15,  10,  -3, -20, -22,
        -42, -20, -10,  -5,  -2, -20, -23, -44,
        -29, -51, -23, -15, -22, -18, -50, -64
    )

    private val BISHOP_MG = intArrayOf(
        -29,   4, -82, -37, -25, -42,   7,  -8,
        -26,  16, -18, -13,  30,  59,  18, -47,
        -16,  37,  43,  40,  35,  50,  37,  -2,
         -4,   5,  19,  50,  37,  37,   7,  -2,
         -6,  13,  13,  26,  34,  12,  10,   4,
          0,  15,  15,  15,  14,  27,  18,  10,
          4,  15,  16,   0,   7,  21,  33,   1,
        -33,  -3, -14, -21, -13, -12, -39, -21
    )

    private val BISHOP_EG = intArrayOf(
        -14, -21,  -9,  -8,  -7,  -9, -17, -24,
         -8,  -4,   7, -12,  -3, -13,  -4, -14,
          2,  -8,   0,  -1,  -2,   6,   0,   4,
         -3,   9,  12,   9,  14,  10,   3,   2,
         -6,   3,  13,  19,   7,  10,  -3,  -9,
        -12,  -3,   8,  10,  13,   3,  -7, -15,
        -14, -18,  -7,  -1,   4,  -9, -15, -27,
        -23,  -9, -23,  -5,  -9, -16,  -5, -17
    )

    private val ROOK_MG = intArrayOf(
         32,  42,  32,  51,  63,   9,  31,  43,
         27,  32,  58,  62,  80,  67,  26,  44,
         -5,  19,  26,  36,  17,  45,  61,  16,
        -24, -11,   7,  26,  24,  35,  -8, -20,
        -36, -26, -12,  -1,   9,  -7,   6, -23,
        -45, -25, -16, -17,   3,   0,  -5, -33,
        -44, -16, -20,  -9,  -1,  11,  -6, -71,
        -19, -13,   1,  17,  16,   7, -37, -26
    )

    private val ROOK_EG = intArrayOf(
         13,  10,  18,  15,  12,  12,   8,   5,
         11,  13,  13,  11,  -3,   3,   8,   3,
          7,   7,   7,   5,   4,  -3,  -5,  -3,
          4,   3,  13,   1,   2,   1,  -1,   2,
          3,   5,   8,   4,  -5,  -6,  -8, -11,
         -4,   0,  -5,  -1,  -7, -12,  -8, -16,
         -6,  -6,   0,   2,  -9,  -9, -11,  -3,
         -9,   2,   3,  -1,  -5, -13,   4, -20
    )

    private val QUEEN_MG = intArrayOf(
        -28,   0,  29,  12,  59,  44,  43,  45,
        -24, -39,  -5,   1, -16,  57,  28,  54,
        -13, -17,   7,   8,  29,  56,  47,  57,
        -27, -27, -16, -16,  -1,  17,  -2,   1,
         -9, -26,  -9, -10,  -2,  -4,   3,  -3,
        -14,   2, -11,  -2,  -5,   2,  14,   5,
        -35,  -8,  11,   2,   8,  15,  -3,   1,
         -1, -18,  -9,  10, -15, -25, -31, -50
    )

    private val QUEEN_EG = intArrayOf(
         -9,  22,  22,  27,  27,  19,  10,  20,
        -17,  20,  32,  41,  58,  25,  30,   0,
        -20,   6,   9,  49,  47,  35,  19,   9,
          3,  22,  24,  45,  57,  40,  57,  36,
        -18,  28,  19,  47,  31,  34,  39,  23,
        -16, -27,  15,   6,   9,  17,  10,   5,
        -22, -23, -30, -16, -16, -23, -36, -32,
        -33, -28, -22, -43,  -5, -32, -20, -41
    )

    private val KING_MG = intArrayOf(
        -65,  23,  16, -15, -56, -34,   2,  13,
         29,  -1, -20,  -7,  -8,  -4, -38, -29,
         -9,  24,   2, -16, -20,   6,  22, -22,
        -17, -20, -12, -27, -30, -25, -14, -36,
        -49,  -1, -27, -39, -46, -44, -33, -51,
        -14, -14, -22, -46, -44, -30, -15, -27,
          1,   7,  -8, -64, -43, -16,   9,   8,
        -15,  36,  12, -54,   8, -28,  24,  14
    )

    private val KING_EG = intArrayOf(
        -74, -35, -18, -18, -11,  15,   4, -17,
        -12,  17,  14,  17,  17,  38,  23,  11,
         10,  17,  23,  15,  20,  45,  44,  13,
         -8,  22,  24,  27,  26,  33,  26,   3,
        -18,  -4,  21,  24,  27,  23,   9, -11,
        -19,  -3,  11,  21,  23,  16,   7,  -9,
        -27, -11,   4,  13,  14,   4,  -5, -17,
        -53, -34, -21, -11, -28, -14, -24, -43
    )

    suspend fun analyzePosition(
        state: BoardState,
        userColor: PieceColor,
        mode: EngineMode = EngineMode.BALANCED,
        strength: EngineStrength = EngineStrength.MASTER,
        topCount: Int = 3,
        historyHashes: List<Long> = emptyList()
    ): AnalysisResult = withContext(Dispatchers.Default) {
        coroutineContext.ensureActive()

        val opponentColor = userColor.opposite()
        val isUserTurn = (state.activeColor == userColor)
        val isUserInCheck = MoveGenerator.isInCheck(state, userColor)
        val isOpponentInCheck = MoveGenerator.isInCheck(state, opponentColor)

        val userColorNameAr = if (userColor == PieceColor.WHITE) "الأبيض" else "الأسود"
        val oppColorNameAr = if (userColor == PieceColor.WHITE) "الأسود" else "الأبيض"

        // ==========================================
        // 1. OPPONENT'S TURN
        // ==========================================
        if (!isUserTurn) {
            val oppLegalMoves = MoveGenerator.generateLegalMoves(state, opponentColor)
            val currentEvalCentipawns = evaluateBoard(state)
            val evalPawns = currentEvalCentipawns / 100.0

            if (oppLegalMoves.isEmpty()) {
                return@withContext if (isOpponentInCheck) {
                    // Checkmate against Opponent -> User Won!
                    AnalysisResult(
                        bestMove = null,
                        topLines = emptyList(),
                        evalScore = if (userColor == PieceColor.WHITE) 99.0 else -99.0,
                        mateIn = 0,
                        depthReached = 0,
                        isCheck = false,
                        isCheckmate = true,
                        isUserInCheck = false,
                        isOpponentInCheck = true,
                        isUserCheckmated = false,
                        isOpponentCheckmated = true,
                        threatDescriptionAr = "كش مات! لقد فزت بالمباراة وحققت المات ضد الخصم.",
                        tacticAlertAr = "كش مات حاسم! فوز مستحق للمستخدم."
                    )
                } else {
                    AnalysisResult(
                        bestMove = null,
                        topLines = emptyList(),
                        evalScore = 0.0,
                        depthReached = 0,
                        isCheck = false,
                        isCheckmate = false,
                        isStalemate = true,
                        isUserInCheck = false,
                        isOpponentInCheck = false,
                        threatDescriptionAr = "تعادل بسبب خنق ملك الخصم (Stalemate).",
                        tacticAlertAr = null
                    )
                }
            }

            // Opponent has legal moves
            val threatDesc = if (isOpponentInCheck) {
                "دور المنافس ($oppColorNameAr) - ملك الخصم تحت الكش المباشر وفرصة هجومية مواتية لك."
            } else {
                "دور المنافس ($oppColorNameAr) - المحرك بانتظار إدخال نقلة المنافس."
            }

            val tacticAlert = if (isOpponentInCheck) {
                "فرصة هجومية: ملك الخصم تحت الكش المباشر! المنافس مجبر على الدفاع."
            } else {
                null
            }

            return@withContext AnalysisResult(
                bestMove = null,
                topLines = emptyList(),
                evalScore = evalPawns,
                mateIn = null,
                depthReached = 0,
                isCheck = false, // User is NOT in check
                isCheckmate = false,
                isUserInCheck = false,
                isOpponentInCheck = isOpponentInCheck,
                threatDescriptionAr = threatDesc,
                tacticAlertAr = tacticAlert
            )
        }

        // ==========================================
        // 2. USER'S TURN
        // ==========================================
        val legalMoves = MoveGenerator.generateLegalMoves(state, userColor)

        if (legalMoves.isEmpty()) {
            return@withContext if (isUserInCheck) {
                // Checkmate against User -> User Lost!
                AnalysisResult(
                    bestMove = null,
                    topLines = emptyList(),
                    evalScore = if (userColor == PieceColor.WHITE) -99.0 else 99.0,
                    mateIn = 0,
                    depthReached = 0,
                    isCheck = true,
                    isCheckmate = true,
                    isUserInCheck = true,
                    isOpponentInCheck = false,
                    isUserCheckmated = true,
                    isOpponentCheckmated = false,
                    threatDescriptionAr = "كش مات! لقد خسر الملك المعركة.",
                    tacticAlertAr = "كش مات ضدك! انتهت المباراة."
                )
            } else {
                AnalysisResult(
                    bestMove = null,
                    topLines = emptyList(),
                    evalScore = 0.0,
                    depthReached = 0,
                    isCheck = false,
                    isCheckmate = false,
                    isStalemate = true,
                    isUserInCheck = false,
                    isOpponentInCheck = false,
                    threatDescriptionAr = "تعادل بسبب الخنق (Stalemate)."
                )
            }
        }

        val historySet = historyHashes.toSet()
        val searchPath = LongArray(MAX_PLY + 16)
        searchPath[0] = computeZobristHash(state)

        // ==========================================
        // TACTICAL SAFETY & KING PROTECTION LAYER
        // ==========================================
        // 1. Immediate Checkmate by User (Mate in 1 win against opponent)
        val playerWinningMateMove = legalMoves.firstOrNull { m ->
            val nextSt = MoveGenerator.makeMove(state, m)
            MoveGenerator.isInCheck(nextSt, opponentColor) && MoveGenerator.generateLegalMoves(nextSt, opponentColor).isEmpty()
        }

        // 2. Direct Opponent Mate Threat against User's King (if user passes or is in check)
        val opponentDirectThreats = if (!isUserInCheck) {
            val nullState = state.copy().apply {
                activeColor = opponentColor
                enPassantSquare = null
            }
            MoveGenerator.generateLegalMoves(nullState, opponentColor)
        } else {
            emptyList()
        }

        val hasImmediateMateThreat = (!isUserInCheck && opponentDirectThreats.any { oppM ->
            val nullState = state.copy().apply {
                activeColor = opponentColor
                enPassantSquare = null
            }
            val stAfter = MoveGenerator.makeMove(nullState, oppM)
            MoveGenerator.isInCheck(stAfter, userColor) && MoveGenerator.generateLegalMoves(stAfter, userColor).isEmpty()
        }) || (isUserInCheck && legalMoves.any { allowsImmediateOpponentMate(state, it, userColor) })

        // 3. Mandatory Defense: filter moves to analyze only safe moves that prevent immediate checkmate on user's king
        val movesToAnalyze = if (hasImmediateMateThreat) {
            val safeMoves = legalMoves.filter { m -> !allowsImmediateOpponentMate(state, m, userColor) }
            if (safeMoves.isNotEmpty()) safeMoves else legalMoves
        } else {
            legalMoves
        }

        val targetMaxDepth = when (strength) {
            EngineStrength.BEGINNER -> 3
            EngineStrength.INTERMEDIATE -> 5
            EngineStrength.ADVANCED -> 7
            EngineStrength.MASTER -> max(mode.defaultDepth, 9)
        }

        // Cache SAN strings so toSan is evaluated once per move
        val moveSanMap = movesToAnalyze.associateWith { MoveGenerator.toSan(state, it) }

        val ratedMovesMap = mutableMapOf<Move, Pair<Int, String>>()
        val startTime = System.currentTimeMillis()
        val timeLimitMs = when (strength) {
            EngineStrength.BEGINNER -> 150L
            EngineStrength.INTERMEDIATE -> 300L
            EngineStrength.ADVANCED -> 500L
            EngineStrength.MASTER -> 750L
        }

        var ttBestMove: Move? = null

        // Iterative Deepening with Time Control & High Precision Move Ordering
        for (depth in 1..targetMaxDepth) {
            coroutineContext.ensureActive()

            val sortedMoves = movesToAnalyze.sortedByDescending { m ->
                val prevScore = ratedMovesMap[m]?.first ?: -INF_SCORE
                val isWinBonus = if (m == playerWinningMateMove) 2_000_000 else 0
                val isTT = if (m == ttBestMove) 1_000_000 else 0
                val captureBonus = if (m.capturedPiece != null) {
                    100000 + getPieceValue(m.capturedPiece.type) * 10 - getPieceValue(m.piece.type)
                } else 0
                val promoBonus = if (m.promotion != null) 90000 else 0
                prevScore + isWinBonus + isTT + captureBonus + promoBonus
            }

            var bestDepthScore = -INF_SCORE
            var bestDepthMove: Move? = null

            for (move in sortedMoves) {
                coroutineContext.ensureActive()
                val nextState = MoveGenerator.makeMove(state, move)
                val moveSan = moveSanMap[move] ?: MoveGenerator.toSan(state, move)

                searchPath[1] = computeZobristHash(nextState)

                val evalCentipawns = -alphaBeta(
                    state = nextState,
                    depth = depth - 1,
                    alpha = -INF_SCORE,
                    beta = INF_SCORE,
                    color = state.activeColor.opposite(),
                    ply = 1,
                    historySet = historySet,
                    searchPath = searchPath
                )

                ratedMovesMap[move] = Pair(evalCentipawns, moveSan)

                if (evalCentipawns > bestDepthScore) {
                    bestDepthScore = evalCentipawns
                    bestDepthMove = move
                }
            }

            if (bestDepthMove != null) {
                ttBestMove = bestDepthMove
            }

            if (abs(bestDepthScore) > MATE_SCORE - 1000) {
                break
            }

            if (System.currentTimeMillis() - startTime >= timeLimitMs && depth >= 2) {
                break
            }
        }

        // Tactical Blunder Check & Output Line Formatting
        val safeRatedLines = ratedMovesMap.map { (move, pair) ->
            var (evalCentipawns, moveSan) = pair

            // Apply Tactical Safety Overrides
            if (move == playerWinningMateMove) {
                evalCentipawns = MATE_SCORE - 1
            }

            val evalPawns = evalCentipawns / 100.0
            val normalizedEval = if (state.activeColor == PieceColor.WHITE) evalPawns else -evalPawns

            // Short Principal Variation (PV)
            val pvList = mutableListOf(moveSan)
            var pvState = MoveGenerator.makeMove(state, move)
            var pvColor = state.activeColor.opposite()
            val pvMoves = MoveGenerator.generateLegalMoves(pvState, pvColor)
            if (pvMoves.isNotEmpty()) {
                val bestPv = pvMoves.maxByOrNull { m ->
                    val st = MoveGenerator.makeMove(pvState, m)
                    evaluateBoard(st) * (if (pvColor == PieceColor.WHITE) 1 else -1)
                }
                if (bestPv != null) {
                    pvList.add(MoveGenerator.toSan(pvState, bestPv))
                }
            }

            val explanation = generateArabicExplanation(move, state, evalPawns)

            val isMate = abs(evalCentipawns) > MATE_SCORE - 1000
            val mateInSteps = if (isMate) {
                val remPly = MATE_SCORE - abs(evalCentipawns) + 1
                val movesCount = max(1, (remPly + 1) / 2)
                if (evalCentipawns > 0) movesCount else -movesCount
            } else null

            EngineLine(
                move = move.copy(san = moveSan, evalAfter = normalizedEval),
                san = moveSan,
                evalScore = normalizedEval,
                mateIn = mateInSteps,
                strengthPercentage = 0,
                pv = pvList,
                explanationAr = explanation
            )
        }.toMutableList()

        safeRatedLines.sortByDescending {
            if (state.activeColor == PieceColor.WHITE) it.evalScore else -it.evalScore
        }

        val bestScore = safeRatedLines.firstOrNull()?.evalScore ?: 0.0
        val processedTopLines = safeRatedLines.take(topCount).mapIndexed { idx, line ->
            val scoreDiff = abs(bestScore - line.evalScore)
            val pct = max(10, 100 - (scoreDiff * 25 + idx * 5).toInt())
            line.copy(strengthPercentage = pct)
        }

        val best = processedTopLines.firstOrNull()
        val currentEval = best?.evalScore ?: (evaluateBoard(state) / 100.0)

        val threatDesc = when {
            playerWinningMateMove != null -> "فرصة كش مات حاسمة وفورية في نقلة واحدة!"
            hasImmediateMateThreat && isUserInCheck -> "ملكك في كش مباشر وتحت تهديد كش مات! تم حصر التحليل في الدفاع الإجباري."
            hasImmediateMateThreat -> "تحذير: الخصم يهدد بكش مات مباشر لملكك! تم حصر التحليل في الدفاع الإجباري."
            best?.mateIn != null && best.mateIn > 0 -> "فرصة كش مات حاسمة متتالية في ${best.mateIn} نقلات لصالحك!"
            best?.mateIn != null && best.mateIn < 0 -> "تحذير: الخصم يملك خطة كش مات في ${abs(best.mateIn)} نقلات، يجب الدفاع فوراً!"
            isUserInCheck -> "ملكك تحت التهديد المباشر (كش!)! يجب الدفاع فوراً."
            isOpponentInCheck -> "ملك الخصم تحت الكش المباشر! فرصة هجومية لمواصلة الضغط."
            best?.move?.capturedPiece != null -> "تكتيك أخذ قطعة (${best.move.capturedPiece.type.name}) وتوسيع الفارق المادي."
            (userColor == PieceColor.WHITE && currentEval > 1.5) || (userColor == PieceColor.BLACK && currentEval < -1.5) ->
                "تفوق وسيطرة ممتازة لك ($userColorNameAr) على الرقعة والمركز."
            (userColor == PieceColor.WHITE && currentEval < -1.5) || (userColor == PieceColor.BLACK && currentEval > 1.5) ->
                "المنافس ($oppColorNameAr) يملك أفضلية وضغطاً، ركز على تأمين الدفاع."
            else -> "الوضعية متكافئة ودقيقة بين الطرفين."
        }

        val tacticAlert = when {
            playerWinningMateMove != null -> "كش مات فوري في نقلة واحدة! نقلة الفوز الحاسمة."
            hasImmediateMateThreat -> "تحذير تكتيكي: الخصم يهدد بكش مات مباشر! تم اعتماد الدفاع الإجباري."
            best?.mateIn != null && best.mateIn > 0 -> "مسار كش مات حتمي في ${best.mateIn} نقلات لصالحك!"
            best?.move?.isCastling == true -> "تبيت استراتيجي لحماية الملك وتأمين الروك."
            best?.move?.promotion != null -> "ترقية البيدق والحصول على ملكة جديدة!"
            best?.move?.capturedPiece?.type == PieceType.QUEEN -> "اقتناص ملكة الخصم بالحسابات الدقيقة!"
            isUserInCheck -> "تحذير: ملكك في كش مباشر! يجب حمايته فوراً."
            isOpponentInCheck -> "فرصة هجومية: ملك الخصم تحت الكش المباشر!"
            else -> null
        }

        AnalysisResult(
            bestMove = best,
            topLines = processedTopLines,
            evalScore = currentEval,
            mateIn = best?.mateIn,
            depthReached = targetMaxDepth,
            isCheck = isUserInCheck,
            isCheckmate = false,
            threatDescriptionAr = threatDesc,
            tacticAlertAr = tacticAlert,
            isUserInCheck = isUserInCheck,
            isOpponentInCheck = isOpponentInCheck,
            isUserCheckmated = false,
            isOpponentCheckmated = false
        )
    }

    private fun alphaBeta(
        state: BoardState,
        depth: Int,
        alpha: Int,
        beta: Int,
        color: PieceColor,
        ply: Int,
        historySet: Set<Long>,
        searchPath: LongArray
    ): Int {
        val hash = computeZobristHash(state)
        if (ply < searchPath.size) {
            searchPath[ply] = hash
        }

        // Repetition Detection & Draw Avoidance
        if (ply > 0) {
            val isRepeatedInHistory = hash in historySet
            var isRepeatedInPath = false
            val limit = min(ply, searchPath.size)
            for (i in 0 until limit - 1) {
                if (searchPath[i] == hash) {
                    isRepeatedInPath = true
                    break
                }
            }

            if (isRepeatedInHistory || isRepeatedInPath) {
                val staticEval = evaluateBoard(state) * (if (color == PieceColor.WHITE) 1 else -1)
                return when {
                    staticEval > 50 -> -2500 // Penalize repetition heavily when winning
                    staticEval < -200 -> 0    // Accept draw by repetition when losing
                    else -> -150               // Prefer active play over unnecessary draw when position is equal
                }
            }
        }

        if (depth <= 0) {
            return quiescenceSearch(state, alpha, beta, color, 4, ply)
        }

        val ttIdx = (hash and TT_MASK.toLong()).toInt()
        val ttEntry = transpositionTable[ttIdx]

        if (ttEntry.hash == hash && ttEntry.depth >= depth) {
            var ttScore = ttEntry.score
            if (ttScore > MATE_SCORE - 1000) ttScore -= ply
            else if (ttScore < -MATE_SCORE + 1000) ttScore += ply

            if (ttEntry.flag == TT_EXACT) return ttScore
            if (ttEntry.flag == TT_LOWERBOUND && ttScore >= beta) return ttScore
            if (ttEntry.flag == TT_UPPERBOUND && ttScore <= alpha) return ttScore
        }

        val inCheck = MoveGenerator.isInCheck(state, color)

        // Null Move Pruning (for depth >= 3)
        if (depth >= 3 && !inCheck && hasNonPawnMaterial(state, color)) {
            val nullState = state.copy()
            nullState.activeColor = color.opposite()
            nullState.enPassantSquare = null
            val nullEval = -alphaBeta(
                state = nullState,
                depth = depth - 1 - 2,
                alpha = -beta,
                beta = -beta + 1,
                color = color.opposite(),
                ply = ply + 1,
                historySet = historySet,
                searchPath = searchPath
            )
            if (nullEval >= beta) {
                return beta
            }
        }

        val moves = MoveGenerator.generateLegalMoves(state, color)
        if (moves.isEmpty()) {
            return if (inCheck) {
                -MATE_SCORE + ply
            } else {
                0
            }
        }

        // Advanced Move Ordering with TT, Captures, Promotions, Killers & History
        val ttMove = if (ttEntry.hash == hash) ttEntry.bestMove else null
        val sortedMoves = moves.sortedByDescending { m ->
            when {
                m == ttMove -> 1_000_000
                m.capturedPiece != null -> 100_000 + getPieceValue(m.capturedPiece.type) * 10 - getPieceValue(m.piece.type)
                m.promotion != null -> 90_000
                ply < MAX_PLY && m == killerMoves[ply][0] -> 50_000
                ply < MAX_PLY && m == killerMoves[ply][1] -> 45_000
                else -> 10_000 + historyTable[if (color == PieceColor.WHITE) 0 else 1][m.from.rank * 8 + m.from.file][m.to.rank * 8 + m.to.file]
            }
        }

        var curAlpha = alpha
        var bestVal = -INF_SCORE
        var bestMove: Move? = null

        for (move in sortedMoves) {
            val nextState = MoveGenerator.makeMove(state, move)
            val score = -alphaBeta(
                state = nextState,
                depth = depth - 1,
                alpha = -beta,
                beta = -curAlpha,
                color = color.opposite(),
                ply = ply + 1,
                historySet = historySet,
                searchPath = searchPath
            )

            if (score > bestVal) {
                bestVal = score
                bestMove = move
            }

            if (score > curAlpha) {
                curAlpha = score
            }

            if (curAlpha >= beta) {
                if (move.capturedPiece == null && ply < MAX_PLY) {
                    killerMoves[ply][1] = killerMoves[ply][0]
                    killerMoves[ply][0] = move
                    val cIdx = if (color == PieceColor.WHITE) 0 else 1
                    val fromIdx = move.from.rank * 8 + move.from.file
                    val toIdx = move.to.rank * 8 + move.to.file
                    historyTable[cIdx][fromIdx][toIdx] += depth * depth
                }
                break
            }
        }

        val flag = when {
            bestVal <= alpha -> TT_UPPERBOUND
            bestVal >= beta -> TT_LOWERBOUND
            else -> TT_EXACT
        }

        var storedScore = bestVal
        if (storedScore > MATE_SCORE - 1000) storedScore += ply
        else if (storedScore < -MATE_SCORE + 1000) storedScore -= ply

        ttEntry.hash = hash
        ttEntry.depth = depth
        ttEntry.score = storedScore
        ttEntry.flag = flag
        ttEntry.bestMove = bestMove

        return bestVal
    }

    private fun quiescenceSearch(
        state: BoardState,
        alpha: Int,
        beta: Int,
        color: PieceColor,
        qDepth: Int,
        ply: Int
    ): Int {
        val inCheck = MoveGenerator.isInCheck(state, color)

        if (inCheck) {
            val evasions = MoveGenerator.generateLegalMoves(state, color)
            if (evasions.isEmpty()) {
                return -MATE_SCORE + ply
            }
            if (qDepth <= 0) return evaluateBoard(state) * (if (color == PieceColor.WHITE) 1 else -1)

            var curAlpha = alpha
            for (move in evasions) {
                val nextState = MoveGenerator.makeMove(state, move)
                val score = -quiescenceSearch(nextState, -beta, -curAlpha, color.opposite(), qDepth - 1, ply + 1)
                if (score >= beta) return beta
                if (score > curAlpha) curAlpha = score
            }
            return curAlpha
        }

        val standPat = evaluateBoard(state) * (if (color == PieceColor.WHITE) 1 else -1)
        if (qDepth <= 0 || standPat >= beta) return standPat

        var curAlpha = max(alpha, standPat)

        val captures = MoveGenerator.generateLegalCapturesAndPromotions(state, color)
            .sortedByDescending { m ->
                val victimVal = if (m.capturedPiece != null) getPieceValue(m.capturedPiece.type) else 800
                val attackerVal = getPieceValue(m.piece.type)
                victimVal * 10 - attackerVal
            }

        for (move in captures) {
            val victimVal = if (move.capturedPiece != null) getPieceValue(move.capturedPiece.type) else 800
            if (standPat + victimVal + 200 < curAlpha && !move.isCastling && move.promotion == null) {
                continue
            }

            val nextState = MoveGenerator.makeMove(state, move)
            val score = -quiescenceSearch(nextState, -beta, -curAlpha, color.opposite(), qDepth - 1, ply + 1)

            if (score >= beta) return beta
            if (score > curAlpha) curAlpha = score
        }

        return curAlpha
    }

    private fun hasNonPawnMaterial(state: BoardState, color: PieceColor): Boolean {
        for (r in 0..7) {
            for (f in 0..7) {
                val p = state.grid[r][f] ?: continue
                if (p.color == color && p.type != PieceType.PAWN && p.type != PieceType.KING) {
                    return true
                }
            }
        }
        return false
    }

    private fun getPieceValue(type: PieceType): Int {
        return when (type) {
            PieceType.PAWN -> PAWN_VAL
            PieceType.KNIGHT -> KNIGHT_VAL
            PieceType.BISHOP -> BISHOP_VAL
            PieceType.ROOK -> ROOK_VAL
            PieceType.QUEEN -> QUEEN_VAL
            PieceType.KING -> KING_VAL
        }
    }

    fun evaluateBoard(state: BoardState): Int {
        var mgScore = 0
        var egScore = 0
        var gamePhase = 0

        var whiteBishops = 0
        var blackBishops = 0

        for (r in 0..7) {
            for (f in 0..7) {
                val piece = state.grid[r][f] ?: continue
                val isWhite = piece.color == PieceColor.WHITE
                val multiplier = if (isWhite) 1 else -1

                val sqIdx = if (isWhite) (7 - r) * 8 + f else r * 8 + f

                val baseVal = getPieceValue(piece.type)

                val (mgPst, egPst) = when (piece.type) {
                    PieceType.PAWN -> Pair(PAWN_MG[sqIdx], PAWN_EG[sqIdx])
                    PieceType.KNIGHT -> {
                        gamePhase += 1
                        Pair(KNIGHT_MG[sqIdx], KNIGHT_EG[sqIdx])
                    }
                    PieceType.BISHOP -> {
                        gamePhase += 1
                        if (isWhite) whiteBishops++ else blackBishops++
                        Pair(BISHOP_MG[sqIdx], BISHOP_EG[sqIdx])
                    }
                    PieceType.ROOK -> {
                        gamePhase += 2
                        Pair(ROOK_MG[sqIdx], ROOK_EG[sqIdx])
                    }
                    PieceType.QUEEN -> {
                        gamePhase += 4
                        Pair(QUEEN_MG[sqIdx], QUEEN_EG[sqIdx])
                    }
                    PieceType.KING -> Pair(KING_MG[sqIdx], KING_EG[sqIdx])
                }

                mgScore += multiplier * (baseVal + mgPst)
                egScore += multiplier * (baseVal + egPst)
            }
        }

        // Bishop Pair Bonus
        if (whiteBishops >= 2) {
            mgScore += 35
            egScore += 45
        }
        if (blackBishops >= 2) {
            mgScore -= 35
            egScore -= 45
        }

        // King Safety & Pawn Structure Positional Bonuses
        val kingSafetyBonus = evaluateKingSafetyAndStructure(state)
        mgScore += kingSafetyBonus

        // Tapered Evaluation (Phase interpolation max 24)
        val phase = min(24, gamePhase)
        return (mgScore * phase + egScore * (24 - phase)) / 24
    }

    private fun evaluateKingSafetyAndStructure(state: BoardState): Int {
        var score = 0

        var wKingFile = 4; var wKingRank = 0
        var bKingFile = 4; var bKingRank = 7

        for (r in 0..7) {
            for (f in 0..7) {
                val p = state.grid[r][f] ?: continue
                if (p.type == PieceType.KING) {
                    if (p.color == PieceColor.WHITE) {
                        wKingFile = f; wKingRank = r
                    } else {
                        bKingFile = f; bKingRank = r
                    }
                }
            }
        }

        // White King Pawn Shield
        if (wKingRank <= 1) {
            for (df in -1..1) {
                val f = wKingFile + df
                if (f in 0..7) {
                    val shieldPawn = state.grid[wKingRank + 1][f]
                    if (shieldPawn?.type == PieceType.PAWN && shieldPawn.color == PieceColor.WHITE) {
                        score += 15
                    }
                }
            }
        }

        // Black King Pawn Shield
        if (bKingRank >= 6) {
            for (df in -1..1) {
                val f = bKingFile + df
                if (f in 0..7) {
                    val shieldPawn = state.grid[bKingRank - 1][f]
                    if (shieldPawn?.type == PieceType.PAWN && shieldPawn.color == PieceColor.BLACK) {
                        score -= 15
                    }
                }
            }
        }

        return score
    }

    fun classifyMoveQuality(evalBefore: Double, evalAfter: Double, isUserTurn: Boolean, color: PieceColor): MoveQuality {
        val evalDiff = if (color == PieceColor.WHITE) (evalAfter - evalBefore) else (evalBefore - evalAfter)
        return when {
            evalDiff >= 0.8 -> MoveQuality.EXCELLENT
            evalDiff >= -0.2 -> MoveQuality.BEST
            evalDiff >= -0.7 -> MoveQuality.GOOD
            evalDiff >= -1.5 -> MoveQuality.INACCURACY
            evalDiff >= -3.0 -> MoveQuality.MISTAKE
            else -> MoveQuality.BLUNDER
        }
    }

    private fun generateArabicExplanation(move: Move, state: BoardState, evalPawns: Double): String {
        val pieceName = when (move.piece.type) {
            PieceType.PAWN -> "البيدق"
            PieceType.KNIGHT -> "الحصان"
            PieceType.BISHOP -> "الفيل"
            PieceType.ROOK -> "الرخ"
            PieceType.QUEEN -> "الوزير"
            PieceType.KING -> "الملك"
        }

        val pieceSymbol = move.piece.unicodeSymbol
        val fromSquare = move.from.name
        val toSquare = move.to.name

        val reason = when {
            move.isCastling -> "تبيت استراتيجي لحماية الملك وتأمين الجناح."
            move.promotion != null -> "ترقية البيدق والحصول على قطعة إضافية قوية."
            move.capturedPiece != null -> {
                val capName = when (move.capturedPiece.type) {
                    PieceType.PAWN -> "البيدق"
                    PieceType.KNIGHT -> "الحصان"
                    PieceType.BISHOP -> "الفيل"
                    PieceType.ROOK -> "الرخ"
                    PieceType.QUEEN -> "الوزير"
                    PieceType.KING -> "الملك"
                }
                "أخذ $capName المنافس وزيادة الفارق المادي."
            }
            move.to.file in 3..4 && move.to.rank in 3..4 -> "السيطرة المحكمة على مربعات الوسط الهامة."
            else -> "تطوير قطعة $pieceName وإحكام السيطرة التكتيكية."
        }

        return "القطعة: $pieceName ($pieceSymbol) • تحريك من $fromSquare إلى $toSquare.\nالسبب: $reason"
    }

    fun allowsImmediateOpponentMate(state: BoardState, playerMove: Move, playerColor: PieceColor): Boolean {
        val nextSt = MoveGenerator.makeMove(state, playerMove)
        val oppReplies = MoveGenerator.generateLegalMoves(nextSt, playerColor.opposite())
        for (oppM in oppReplies) {
            val afterOpp = MoveGenerator.makeMove(nextSt, oppM)
            if (MoveGenerator.isInCheck(afterOpp, playerColor)) {
                if (MoveGenerator.generateLegalMoves(afterOpp, playerColor).isEmpty()) {
                    return true
                }
            }
        }
        return false
    }
}
