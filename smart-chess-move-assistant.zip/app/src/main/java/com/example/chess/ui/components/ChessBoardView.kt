package com.example.chess.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.chess.engine.BoardState
import com.example.chess.model.AnalysisResult
import com.example.chess.model.Move
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun ChessBoardView(
    boardState: BoardState,
    isFlipped: Boolean,
    selectedSquare: Square?,
    legalMoves: List<Move>,
    analysisResult: AnalysisResult?,
    userColor: PieceColor = PieceColor.WHITE,
    isEditMode: Boolean = false,
    showCoordinates: Boolean = true,
    onSquareClick: (Square) -> Unit,
    onMoveAttempt: (Square, Square) -> Unit,
    modifier: Modifier = Modifier
) {
    val lightSquareColor = Color(0xFFF0D9B5)
    val darkSquareColor = Color(0xFFB58863)
    val selectedColor = Color(0x883B82F6)
    val editSelectedColor = Color(0xAAF59E0B)
    val legalMoveDotColor = Color(0xAA10B981)
    val arrowColor = Color(0xFF0284C7)

    val selectedScale by animateFloatAsState(
        targetValue = if (selectedSquare != null) 1.09f else 1.0f,
        animationSpec = tween(durationMillis = 200),
        label = "selectedScale"
    )

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .padding(2.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(3.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
            .testTag("chess_board_canvas")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isFlipped, selectedSquare, legalMoves, isEditMode) {
                    detectTapGestures { offset ->
                        val boardSize = min(size.width, size.height)
                        val offsetX = (size.width - boardSize) / 2f
                        val offsetY = (size.height - boardSize) / 2f
                        val tileSize = boardSize / 8f

                        if (offset.x in offsetX..(offsetX + boardSize) &&
                            offset.y in offsetY..(offsetY + boardSize)
                        ) {
                            val file = ((offset.x - offsetX) / tileSize).toInt().coerceIn(0, 7)
                            val rankIndex = ((offset.y - offsetY) / tileSize).toInt().coerceIn(0, 7)

                            val actualFile = if (isFlipped) 7 - file else file
                            val actualRank = if (isFlipped) rankIndex else 7 - rankIndex

                            onSquareClick(Square(actualFile, actualRank))
                        }
                    }
                }
        ) {
            val boardSize = min(size.width, size.height)
            if (boardSize <= 0f) return@Canvas

            val offsetX = (size.width - boardSize) / 2f
            val offsetY = (size.height - boardSize) / 2f
            val tileSize = boardSize / 8f

            // 1. Draw Board Grid & Coordinates
            for (r in 0..7) {
                for (f in 0..7) {
                    val isLight = (r + f) % 2 == 0
                    val squareBgColor = if (isLight) lightSquareColor else darkSquareColor

                    val drawX = offsetX + (if (isFlipped) 7 - f else f) * tileSize
                    val drawY = offsetY + (if (isFlipped) r else 7 - r) * tileSize

                    drawRect(
                        color = squareBgColor,
                        topLeft = Offset(drawX, drawY),
                        size = Size(tileSize, tileSize)
                    )

                    // Draw Rank & File Coordinates
                    if (showCoordinates) {
                        if (f == 0) {
                            val rankLabel = if (isFlipped) (r + 1).toString() else (8 - r).toString()
                            val rankPaint = android.graphics.Paint().apply {
                                textSize = (tileSize * 0.18f).coerceAtLeast(8f)
                                color = if (isLight) android.graphics.Color.DKGRAY else android.graphics.Color.WHITE
                                typeface = android.graphics.Typeface.DEFAULT_BOLD
                                isAntiAlias = true
                            }
                            drawContext.canvas.nativeCanvas.drawText(
                                rankLabel,
                                drawX + tileSize * 0.08f,
                                drawY + tileSize * 0.28f,
                                rankPaint
                            )
                        }

                        if (r == 7) {
                            val fileLabel = if (isFlipped) ('h' - f).toString() else ('a' + f).toString()
                            val filePaint = android.graphics.Paint().apply {
                                textSize = (tileSize * 0.18f).coerceAtLeast(8f)
                                color = if (isLight) android.graphics.Color.DKGRAY else android.graphics.Color.WHITE
                                typeface = android.graphics.Typeface.DEFAULT_BOLD
                                isAntiAlias = true
                            }
                            drawContext.canvas.nativeCanvas.drawText(
                                fileLabel,
                                drawX + tileSize * 0.80f,
                                drawY + tileSize * 0.90f,
                                filePaint
                            )
                        }
                    }

                    // Highlight Selected Square
                    val actualFile = if (isFlipped) 7 - f else f
                    val actualRank = if (isFlipped) r else 7 - r
                    if (selectedSquare?.file == actualFile && selectedSquare?.rank == actualRank) {
                        drawRect(
                            color = if (isEditMode) editSelectedColor else selectedColor,
                            topLeft = Offset(drawX, drawY),
                            size = Size(tileSize, tileSize)
                        )

                        // Vibrant outline border & outer glow
                        val strokeColor = if (isEditMode) Color(0xFFF59E0B) else Color(0xFF60A5FA)
                        val glowColor = if (isEditMode) Color(0x66F59E0B) else Color(0x663B82F6)

                        drawRect(
                            color = glowColor,
                            topLeft = Offset(drawX - 2.dp.toPx(), drawY - 2.dp.toPx()),
                            size = Size(tileSize + 4.dp.toPx(), tileSize + 4.dp.toPx()),
                            style = Stroke(width = 3.dp.toPx())
                        )
                        drawRect(
                            color = strokeColor,
                            topLeft = Offset(drawX + 1.dp.toPx(), drawY + 1.dp.toPx()),
                            size = Size(tileSize - 2.dp.toPx(), tileSize - 2.dp.toPx()),
                            style = Stroke(width = 2.5f.dp.toPx())
                        )
                    }

                    // Highlight King in Check
                    val piece = boardState.getPiece(actualFile, actualRank)
                    if (!isEditMode && piece?.type == PieceType.KING && (analysisResult?.isCheck == true || analysisResult?.isOpponentInCheck == true) && piece.color == boardState.activeColor) {
                        drawRect(
                            color = Color(0xAAEF4444),
                            topLeft = Offset(drawX, drawY),
                            size = Size(tileSize, tileSize)
                        )
                    }
                }
            }

            // 2. Legal Move Indicators
            if (!isEditMode) {
                for (move in legalMoves) {
                    val drawX = offsetX + (if (isFlipped) 7 - move.to.file else move.to.file) * tileSize + tileSize / 2f
                    val drawY = offsetY + (if (isFlipped) move.to.rank else 7 - move.to.rank) * tileSize + tileSize / 2f

                    if (move.capturedPiece != null) {
                        drawCircle(
                            color = Color(0xAAEF4444),
                            radius = tileSize * 0.38f,
                            center = Offset(drawX, drawY)
                        )
                    } else {
                        drawCircle(
                            color = legalMoveDotColor,
                            radius = tileSize * 0.18f,
                            center = Offset(drawX, drawY)
                        )
                    }
                }
            }

            // 3. Recommended Best Move Arrow (User's Turn)
            if (!isEditMode && boardState.activeColor == userColor) {
                analysisResult?.bestMove?.move?.let { move ->
                    val fromX = offsetX + (if (isFlipped) 7 - move.from.file else move.from.file) * tileSize + tileSize / 2f
                    val fromY = offsetY + (if (isFlipped) move.from.rank else 7 - move.from.rank) * tileSize + tileSize / 2f
                    val toX = offsetX + (if (isFlipped) 7 - move.to.file else move.to.file) * tileSize + tileSize / 2f
                    val toY = offsetY + (if (isFlipped) move.to.rank else 7 - move.to.rank) * tileSize + tileSize / 2f

                    drawLine(
                        color = arrowColor,
                        start = Offset(fromX, fromY),
                        end = Offset(toX, toY),
                        strokeWidth = tileSize * 0.14f
                    )

                    val angle = atan2((toY - fromY).toDouble(), (toX - fromX).toDouble())
                    val arrowLength = tileSize * 0.35f
                    val arrowAngle = Math.toRadians(32.0)

                    val x1 = toX - arrowLength * cos(angle - arrowAngle).toFloat()
                    val y1 = toY - arrowLength * sin(angle - arrowAngle).toFloat()
                    val x2 = toX - arrowLength * cos(angle + arrowAngle).toFloat()
                    val y2 = toY - arrowLength * sin(angle + arrowAngle).toFloat()

                    val path = Path().apply {
                        moveTo(toX, toY)
                        lineTo(x1, y1)
                        lineTo(x2, y2)
                        close()
                    }
                    drawPath(path, color = arrowColor)
                }
            }

            // 4. Render Chess Pieces with Crisp Dual-Layer Paint & Bold Sans-Serif Typeface
            val textSizePx = (tileSize * 0.76f).coerceAtLeast(10f)
            val pieceTypeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)

            val fillWhitePaint = android.graphics.Paint().apply {
                textSize = textSizePx
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
                isSubpixelText = true
                isFilterBitmap = true
                typeface = pieceTypeface
                color = android.graphics.Color.WHITE
                style = android.graphics.Paint.Style.FILL
            }

            val strokeWhitePaint = android.graphics.Paint().apply {
                textSize = textSizePx
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
                isSubpixelText = true
                isFilterBitmap = true
                typeface = pieceTypeface
                color = android.graphics.Color.parseColor("#090D16")
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = (tileSize * 0.055f).coerceAtLeast(2f)
            }

            val fillBlackPaint = android.graphics.Paint().apply {
                textSize = textSizePx
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
                isSubpixelText = true
                isFilterBitmap = true
                typeface = pieceTypeface
                color = android.graphics.Color.parseColor("#0F172A")
                style = android.graphics.Paint.Style.FILL
            }

            val strokeBlackPaint = android.graphics.Paint().apply {
                textSize = textSizePx
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
                isSubpixelText = true
                isFilterBitmap = true
                typeface = pieceTypeface
                color = android.graphics.Color.parseColor("#F8FAFC")
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = (tileSize * 0.04f).coerceAtLeast(1.5f)
            }

            val shadowPaint = android.graphics.Paint().apply {
                textSize = textSizePx
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
                isSubpixelText = true
                isFilterBitmap = true
                typeface = pieceTypeface
                color = android.graphics.Color.parseColor("#44000000")
                style = android.graphics.Paint.Style.FILL
            }

            val fontMetrics = fillWhitePaint.fontMetrics
            val baselineOffset = (fontMetrics.descent + fontMetrics.ascent) / 2f

            for (r in 0..7) {
                for (f in 0..7) {
                    val piece = boardState.grid[r][f] ?: continue
                    val actualFile = f
                    val actualRank = r
                    val drawX = offsetX + (if (isFlipped) 7 - f else f) * tileSize
                    val drawY = offsetY + (if (isFlipped) r else 7 - r) * tileSize

                    val centerX = drawX + tileSize / 2f
                    val centerY = drawY + tileSize / 2f
                    val baselineY = centerY - baselineOffset

                    val isSelected = (selectedSquare?.file == actualFile && selectedSquare?.rank == actualRank)

                    if (isSelected) {
                        // Subtle glowing halo circle behind selected piece
                        val haloColor = if (isEditMode) Color(0x66F59E0B) else Color(0x663B82F6)
                        drawCircle(
                            color = haloColor,
                            radius = tileSize * 0.44f * selectedScale,
                            center = Offset(centerX, centerY)
                        )

                        drawContext.canvas.nativeCanvas.save()
                        drawContext.canvas.nativeCanvas.scale(selectedScale, selectedScale, centerX, centerY)
                    }

                    val symbolToDraw = piece.solidSymbol

                    // Soft piece drop shadow for 3D depth
                    drawContext.canvas.nativeCanvas.drawText(
                        symbolToDraw,
                        centerX + 1.5.dp.toPx(),
                        baselineY + 2.5.dp.toPx(),
                        shadowPaint
                    )

                    if (piece.color == PieceColor.WHITE) {
                        drawContext.canvas.nativeCanvas.drawText(
                            symbolToDraw,
                            centerX,
                            baselineY,
                            strokeWhitePaint
                        )
                        drawContext.canvas.nativeCanvas.drawText(
                            symbolToDraw,
                            centerX,
                            baselineY,
                            fillWhitePaint
                        )
                    } else {
                        drawContext.canvas.nativeCanvas.drawText(
                            symbolToDraw,
                            centerX,
                            baselineY,
                            strokeBlackPaint
                        )
                        drawContext.canvas.nativeCanvas.drawText(
                            symbolToDraw,
                            centerX,
                            baselineY,
                            fillBlackPaint
                        )
                    }

                    if (isSelected) {
                        drawContext.canvas.nativeCanvas.restore()
                    }
                }
            }
        }
    }
}

