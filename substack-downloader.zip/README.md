# Substack Downloader

تطبيق أندرويد أصيل (Native Android) مبني بلغة **Kotlin** وواجهة **Jetpack Compose (Material Design 3)** لتنزيل الفيديوهات، المقاطع الصوتية (Podcasts / MP3)، والصور من منصتي **Substack** و **TikTok** بجودة عالية وبدون علامة مائية، مع مشغل وسائط مدمج وإدارة متكاملة للتنزيلات في الخلفية.

---

## المميزات الأساسية (Key Features)

- **دعم مزدوج للمنصات (Substack & TikTok)**:
  - استخراج وتنزيل فيديوهات وملاحظات ومقالات وبودكاست **Substack** مع تحليل قوائم التشغيل المباشرة **HLS (`.m3u8`)** ودمج المقاطع تلقائيًا.
  - استخراج وتنزيل فيديوهات **TikTok** بجودة **1080p HD** بدون علامة مائية، وتنزيل الصوتيات (**MP3**)، وألبومات الصور (**Photo Carousels**) مع فك تلقائي للروابط المختصرة (`vt.tiktok.com` / `vm.tiktok.com`).
- **معاينة ذكية ومشغل مدمج**:
  - معاينة فورية للمنشور قبل التنزيل بإطار متناسق (1:1) يدعم تصفح ألبومات الصور واختيار الدقة أو الصيغة المطلوبة.
  - مشغل فيديو وصوت مدمج داخل التطبيق مع التحكم بالسرعة، التقديم/التأخير، وكتم الصوت.
- **إدارة تنزيلات متقدمة في الخلفية**:
  - خدمة أمامية (`DownloadForegroundService`) تدعم التنزيل المتزامن المحدود (`Semaphore`)، الإيقاف المؤقت، الاستئناف (`HTTP Range`)، وإعادة المحاولة التلقائية.
  - حفظ السجل محليًا في قاعدة بيانات **Room** مع البحث، الفلترة، الترتيب، المشاركة، والتصدير المباشر إلى معرض الهاتف (`MediaStore`).
- **حماية وأمان مدمج (`SecurityGuard`)**:
  - التحقق الصارم من الروابط (HTTPS فقط)، منع هجمات **SSRF** عبر `SafeDns`، منع اختراق المسارات (**Path Traversal**)، وفحص البصمة الثنائية للملفات المنزلة (**Magic Bytes Integrity**).
- **دعم كامل للغتين العربية والإنجليزية**:
  - واجهة ليلية احترافية تدعم اتجاهي **RTL** و **LTR** وتفضيلات المستخدم المخزنة عبر **Jetpack DataStore**.

---

## البنية التقنية والمعمارية (Tech Stack & Architecture)

- **اللغة**: Kotlin (JDK 21)
- **واجهة المستخدم**: Jetpack Compose + Material Design 3
- **النمط المعماري**: MVVM (`UI` -> `DownloadViewModel` -> `DownloadRepository` -> `DAO / Network Parsers`)
- **الشبكات والاستخراج**: OkHttp 4 + Custom `SubstackParser`, `TikTokParser`, & `HlsDownloader`
- **التخزين المحلي**:
  - **Room Database** (`AppDatabase`, `DownloadDao`) لسجل التنزيلات وحالاتها.
  - **DataStore Preferences** (`SettingsRepository`) لحفظ إعدادات المستخدم.
- **الصور**: Coil Compose (`AsyncImage`)
- **الاختبارات**: JUnit 4 + Robolectric + Coroutines Test

### هيكل المجلدات (Project Structure)

```text
app/src/main/java/com/example/
├── MainActivity.kt                  # نقطة الدخول الرئيسية ومعالجة روابط المشاركة (Intent Filters)
├── data/
│   ├── db/                          # قاعدة بيانات Room (AppDatabase, DownloadDao)
│   ├── model/                       # نماذج البيانات (DownloadItem, NoteDetails)
│   └── settings/                    # إعدادات التطبيق عبر DataStore (SettingsRepository)
├── network/
│   ├── SubstackParser.kt            # محلل صفحات وملاحظات وفيديوهات Substack
│   ├── TikTokParser.kt              # محلل روابط وفيديوهات وألبومات صور TikTok
│   └── hls/                         # محرك تحليل وتنزيل قوائم HLS (HlsParser, HlsDownloader)
├── repository/
│   └── DownloadRepository.kt        # إدارة طوابير التحميل، الاستئناف، وربط قاعدة البيانات
├── security/
│   └── SecurityGuard.kt             # فلاتر الحماية (SSRF, DNS, Path Sanitization, File Integrity)
├── service/
│   └── DownloadForegroundService.kt # الخدمة الأمامية لإشعارات واستمرارية التنزيل بالخلفية
└── ui/
    ├── DownloadViewModel.kt         # إدارة حالة الواجهة والتفاعل مع المستودع
    ├── MainScreen.kt                # الهيكل الرئيسي وشريط التنقل السفلي
    ├── components/                  # المشغل المدمج ومعاينة الوسائط (InAppVideoPlayer, SquareMediaPreview)
    ├── screens/                     # الشاشات (HomeScreen, DownloadsScreen, SettingsScreen)
    ├── theme/                       # الألوان والخطوط والسمات (Color, Theme, Type, Shape)
    └── util/                        # الترجمة وتصدير الوسائط (Localization, MediaExportHelper)
```

---

## طريقة التثبيت والتشغيل (Setup & Build Instructions)

### المتطلبات المسبقة (Prerequisites)
- **JDK 21**
- **Android SDK** (`compileSdk = 36`, `minSdk = 24`)
- **Gradle 9.x** (أو عبر Android Studio)

### خطوات التشغيل
1. استنساخ المستودع:
   ```bash
   git clone <repository-url>
   cd substack-downloader
   ```
2. إعداد ملف البيئة (اختياري):
   - يحتوي المشروع على ملف `.env.example` كقالب قياسي. لا يتطلب التطبيق أي مفاتيح API خارجية لتشغيل ميزات التنزيل الأساسية.
3. بناء نسخة التطوير (Debug APK):
   ```bash
   gradle :app:assembleDebug
   ```
4. تشغيل الاختبارات المحلية (Unit & Robolectric Tests):
   ```bash
   gradle :app:testDebugUnitTest
   ```

---

## الأمان والخصوصية (Security & Privacy)

- لا يتم تضمين أي مفاتيح سرية أو كلمات مرور داخل الكود المصدري.
- ملفات `.env` ومفاتيح التوقيع الخاصة (`*.jks`, `*.keystore`) مستبعدة تلقائيًا عبر `.gitignore`.
- جميع عمليات المعالجة والتخزين تتم محليًا على جهاز المستخدم دون إرسال بيانات الاستخدام إلى خوادم طرف ثالث.
