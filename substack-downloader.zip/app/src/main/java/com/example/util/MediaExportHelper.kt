package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.security.SecurityGuard
import com.example.security.SecurityLogger
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object MediaExportHelper {

    private const val TAG = "MediaExportHelper"

    /**
     * Share downloaded file via Android system share sheet (WhatsApp, Telegram, Drive, etc.)
     * Uses strict FileProvider scoping and permission flags.
     */
    fun shareFile(context: Context, filePath: String, isAudio: Boolean, title: String? = null) {
        try {
            val file = File(filePath)
            if (!file.exists() || file.length() == 0L) {
                Toast.makeText(context, "الملف غير موجود أو لم يكتمل تحميله بعد.", Toast.LENGTH_SHORT).show()
                return
            }

            // Verify file integrity before sharing
            if (!SecurityGuard.verifyMediaFileIntegrity(file, isAudio)) {
                Toast.makeText(context, "تعذر مشاركة الملف لعدم تطابق توقيع الوسائط الآمن.", Toast.LENGTH_SHORT).show()
                return
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (isAudio) "audio/mpeg" else "video/mp4"
            val safeSubject = SecurityGuard.sanitizeText(title ?: file.name, maxLength = 60)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, safeSubject)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, "مشاركة الملف عبر:")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            SecurityLogger.e("Error sharing file safely", e)
            val msg = SecurityGuard.sanitizeErrorMessage(e)
            Toast.makeText(context, "تعذر مشاركة الملف: $msg", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Open file in external system player (e.g. VLC, MX Player, Google Photos)
     */
    fun openFileWithExternalApp(context: Context, filePath: String, isAudio: Boolean) {
        try {
            val file = File(filePath)
            if (!file.exists() || file.length() == 0L) {
                Toast.makeText(context, "الملف غير موجود في الجهاز.", Toast.LENGTH_SHORT).show()
                return
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (isAudio) "audio/*" else "video/*"

            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(Intent.createChooser(viewIntent, "تشغيل بواسطة:"))
        } catch (e: Exception) {
            SecurityLogger.e("Error opening file safely", e)
            val msg = SecurityGuard.sanitizeErrorMessage(e)
            Toast.makeText(context, "تعذر فتح الملف بمشغل خارجي: $msg", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Exports internal downloaded file to public phone storage (Gallery / Movies / Music)
     * using MediaStore on Android 10+ (Q+) or direct copy on older versions with canonical validation.
     */
    fun exportToPublicGallery(context: Context, filePath: String, isAudio: Boolean, fileName: String): Boolean {
        val sourceFile = File(filePath)
        if (!sourceFile.exists() || sourceFile.length() == 0L) {
            Toast.makeText(context, "الملف الأصلي غير متوفر للتصدير.", Toast.LENGTH_SHORT).show()
            return false
        }

        // Clean filename to prevent directory traversal in MediaStore display name
        val safeName = SecurityGuard.sanitizeFileName(fileName, isAudio = isAudio)

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val collection = if (isAudio) {
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }

                val mimeType = if (isAudio) "audio/mpeg" else "video/mp4"
                val relativeFolder = if (isAudio) "${Environment.DIRECTORY_MUSIC}/SubstackDownloads" else "${Environment.DIRECTORY_MOVIES}/SubstackDownloads"

                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativeFolder)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val itemUri = resolver.insert(collection, values)
                    ?: throw IllegalStateException("فشل إنشاء مدخل في وسائط الهاتف.")

                resolver.openOutputStream(itemUri)?.use { outStream ->
                    FileInputStream(sourceFile).use { inStream ->
                        inStream.copyTo(outStream)
                    }
                }

                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)

                Toast.makeText(context, "تم تصدير وحفظ الملف في معرض الهاتف بنجاح!", Toast.LENGTH_LONG).show()
                true
            } else {
                val targetDir = File(
                    Environment.getExternalStoragePublicDirectory(
                        if (isAudio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
                    ),
                    "SubstackDownloads"
                )
                if (!targetDir.exists()) {
                    targetDir.mkdirs()
                }
                val destFile = File(targetDir, safeName)
                if (!SecurityGuard.isPathStrictlyInsideDirectory(destFile, targetDir)) {
                    throw SecurityException("مسار الحفظ غير مصرح به.")
                }

                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }

                android.media.MediaScannerConnection.scanFile(
                    context,
                    arrayOf(destFile.absolutePath),
                    arrayOf(if (isAudio) "audio/mpeg" else "video/mp4"),
                    null
                )

                Toast.makeText(context, "تم تصدير وحفظ الملف في ذاكرة الهاتف بنجاح!", Toast.LENGTH_LONG).show()
                true
            }
        } catch (e: Exception) {
            SecurityLogger.e("Error exporting file to gallery", e)
            val msg = SecurityGuard.sanitizeErrorMessage(e)
            Toast.makeText(context, "تعذر التصدير: $msg", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
