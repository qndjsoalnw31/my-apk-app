package com.example.security

import android.util.Log
import java.io.File
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Pattern
import okhttp3.Dns

/**
 * Enterprise-grade Security Guard for Android.
 * Provides defenses against:
 * - SSRF (Server-Side Request Forgery & internal network access)
 * - Path & Directory Traversal
 * - Malicious file uploads / disguised payloads
 * - XSS & HTML/Script injection in parsed content
 * - Command/Code Injection
 * - Resource Exhaustion & DoS (Storage exhaustion, Infinite Streams, Concurrency flooding)
 * - Information Leakage & Insecure Logging
 */
object SecurityGuard {

    private const val TAG = "SecurityGuard"

    // Maximum allowed file size for downloads (2 GB) to prevent storage exhaustion attacks
    const val MAX_ALLOWED_FILE_SIZE_BYTES = 2L * 1024L * 1024L * 1024L // 2GB

    // Maximum active concurrent downloads
    const val MAX_CONCURRENT_DOWNLOADS = 3

    // Maximum search / title length to prevent memory abuse
    const val MAX_INPUT_TEXT_LENGTH = 300
    const val MAX_URL_LENGTH = 2048

    // Whitelisted root domains & CDN hosts for Substack media
    private val ALLOWED_DOMAIN_PATTERNS = listOf(
        Pattern.compile("^(.*\\.)?substack\\.com$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?substack-custom\\.com$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?substackcdn\\.com$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?cloudflarestream\\.com$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?videodelivery\\.net$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?mux\\.com$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?cloudfront\\.net$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?fastly\\.net$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?akamaized\\.net$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?akamaihd\\.net$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^s3[.-][a-z0-9-]+\\.amazonaws\\.com$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?s3\\.amazonaws\\.com$", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*\\.)?googleusercontent\\.com$", Pattern.CASE_INSENSITIVE)
    )

    // Rate limiter for inspection and resolution requests (Sliding window / Token Bucket)
    private val requestTimestamps = ConcurrentHashMap<String, MutableList<Long>>()
    private const val RATE_LIMIT_WINDOW_MS = 60_000L // 1 minute
    private const val MAX_REQUESTS_PER_WINDOW = 20

    /**
     * Verifies rate limit for sensitive operations.
     */
    @Synchronized
    fun checkRateLimit(clientId: String = "default"): Boolean {
        val now = System.currentTimeMillis()
        val timestamps = requestTimestamps.getOrPut(clientId) { mutableListOf() }
        
        // Remove timestamps older than the window
        timestamps.removeAll { now - it > RATE_LIMIT_WINDOW_MS }
        
        return if (timestamps.size < MAX_REQUESTS_PER_WINDOW) {
            timestamps.add(now)
            true
        } else {
            SecurityLogger.w("Rate limit exceeded for operation $clientId")
            false
        }
    }

    /**
     * Validates and sanitizes a Substack / media URL.
     * Prevents SSRF, scheme tampering (file://, javascript:, gopher://), and excessive length.
     */
    fun validateAndSanitizeUrl(rawUrl: String): Result<String> {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("الرابط لا يمكن أن يكون فارغاً."))
        }

        if (trimmed.length > MAX_URL_LENGTH) {
            return Result.failure(SecurityException("الرابط طويل جداً ويتجاوز الحد المسموح به."))
        }

        // Check for forbidden control characters or null bytes
        if (trimmed.any { it.isISOControl() || it == '\u0000' }) {
            return Result.failure(SecurityException("الرابط يحتوي على رموز غير مسموح بها."))
        }

        return try {
            val uri = URI(trimmed)
            val scheme = uri.scheme?.lowercase()

            if (scheme != "https" && scheme != "http") {
                return Result.failure(SecurityException("بروتوكول غير آمن. يجب استخدام https فقط."))
            }

            val host = uri.host?.lowercase()
            if (host.isNullOrBlank()) {
                return Result.failure(IllegalArgumentException("عنوان النطاق في الرابط غير صالح."))
            }

            // Reject IP literals if they are private/loopback/link-local/metadata
            if (isForbiddenHostOrIp(host)) {
                return Result.failure(SecurityException("تم رفض الاتصال بعنوان محلي أو غير مصرح به (SSRF Protection)."))
            }

            Result.success(trimmed)
        } catch (e: Exception) {
            SecurityLogger.w("Invalid URL attempted: ${e.message}")
            Result.failure(IllegalArgumentException("صيغة الرابط غير صحيحة."))
        }
    }

    /**
     * Checks if a hostname or IP string corresponds to loopback, local network, or cloud metadata.
     */
    fun isForbiddenHostOrIp(host: String): Boolean {
        val h = host.lowercase().trim('[', ']')
        
        // Block known dangerous hostnames
        if (h in listOf("localhost", "127.0.0.1", "0.0.0.0", "::1", "metadata.google.internal", "instance-data")) {
            return true
        }

        // Block .local, .internal, .localhost, .lan, .onion
        if (h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".localhost") || h.endsWith(".lan")) {
            return true
        }

        // Check if host is raw IP string
        try {
            val inet = InetAddress.getByName(h)
            if (isPrivateOrLoopbackAddress(inet)) {
                return true
            }
        } catch (_: Exception) {
            // Not a direct IP address, it's a domain name
        }

        return false
    }

    /**
     * Checks if an resolved InetAddress is in private, loopback, link-local, or cloud metadata ranges.
     */
    fun isPrivateOrLoopbackAddress(address: InetAddress): Boolean {
        if (address.isLoopbackAddress || address.isAnyLocalAddress || address.isLinkLocalAddress || address.isSiteLocalAddress || address.isMulticastAddress) {
            return true
        }

        if (address is Inet4Address) {
            val bytes = address.address
            val b0 = bytes[0].toInt() and 0xFF
            val b1 = bytes[1].toInt() and 0xFF

            // 10.0.0.0/8
            if (b0 == 10) return true
            // 172.16.0.0/12
            if (b0 == 172 && (b1 in 16..31)) return true
            // 192.168.0.0/16
            if (b0 == 192 && b1 == 168) return true
            // 169.254.0.0/16 (Link Local & AWS/GCP Metadata 169.254.169.254)
            if (b0 == 169 && b1 == 254) return true
            // 100.64.0.0/10 (Carrier-grade NAT)
            if (b0 == 100 && (b1 in 64..127)) return true
            // 127.0.0.0/8
            if (b0 == 127) return true
            // 0.0.0.0/8
            if (b0 == 0) return true
        }

        if (address is Inet6Address) {
            val hostAddress = address.hostAddress?.lowercase() ?: ""
            if (hostAddress.startsWith("fc") || hostAddress.startsWith("fd") || hostAddress.startsWith("fe80") || hostAddress == "::1" || hostAddress == "0:0:0:0:0:0:0:1") {
                return true
            }
        }

        return false
    }

    /**
     * Checks if a domain is an authorized Substack or media CDN domain.
     */
    fun isAllowedMediaDomain(host: String?): Boolean {
        if (host.isNullOrBlank()) return false
        val cleanHost = host.lowercase().trim()
        return ALLOWED_DOMAIN_PATTERNS.any { it.matcher(cleanHost).matches() }
    }

    /**
     * Sanitizes filename to prevent Path Traversal, Directory Traversal, and Command Injection.
     * Guarantees filename contains NO '../', NO '/', NO '\', NO control characters, and ends with valid extension.
     */
    fun sanitizeFileName(rawTitle: String, isAudio: Boolean, suffixId: String? = null): String {
        // Strip HTML, script tags, control chars
        var cleaned = sanitizeText(rawTitle, maxLength = 60)
            .ifBlank { if (isAudio) "substack_audio" else "substack_video" }

        // Remove dangerous path traversal and shell injection characters: / \ : * ? " < > | $ ` ; & ! ~ \0
        cleaned = cleaned.replace(Regex("[\\\\/:*?\"<>|\\$`;&!~\\u0000\r\n\t]+"), "_")
            .replace(Regex("\\.+"), ".") // Multiple dots to single dot
            .replace(Regex("\\s+"), " ")
            .trim('.', ' ', '_')

        if (cleaned.isBlank()) {
            cleaned = if (isAudio) "substack_audio" else "substack_video"
        }

        // Prevent hidden files (starting with dot)
        if (cleaned.startsWith(".")) {
            cleaned = "file_$cleaned"
        }

        // Truncate to maximum 50 characters before suffix
        if (cleaned.length > 50) {
            cleaned = cleaned.substring(0, 50).trimEnd('_', '.', ' ')
        }

        val ext = if (isAudio) ".mp3" else ".mp4"
        val cleanSuffix = if (!suffixId.isNullOrBlank()) {
            "_" + suffixId.replace(Regex("[^a-zA-Z0-9]"), "").take(8)
        } else {
            "_" + (System.currentTimeMillis() % 100000)
        }

        return "${cleaned}${cleanSuffix}${ext}"
    }

    /**
     * Validates that a target file is strictly situated inside the authorized base directory
     * and has not escaped via symlinks or path traversal.
     */
    fun isPathStrictlyInsideDirectory(targetFile: File, baseDirectory: File): Boolean {
        return try {
            val canonicalTarget = targetFile.canonicalPath
            val canonicalBase = baseDirectory.canonicalPath
            canonicalTarget.startsWith(canonicalBase + File.separator)
        } catch (e: Exception) {
            SecurityLogger.e("Path verification failed", e)
            false
        }
    }

    /**
     * Sanitizes plain text input (e.g. note description or title) to prevent XSS, HTML Injection,
     * and control character abuse in UI components.
     */
    fun sanitizeText(raw: String, maxLength: Int = MAX_INPUT_TEXT_LENGTH): String {
        if (raw.isBlank()) return ""

        // Strip HTML tags and script content
        var clean = raw.replace(Regex("(?is)<script.*?>.*?</script>"), " ")
            .replace(Regex("(?is)<style.*?>.*?</style>"), " ")
            .replace(Regex("<[^>]+>"), " ")
            .replace(Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F\\u007F]"), "") // Strip non-printable ASCII
            .replace(Regex("\\s+"), " ")
            .trim()

        if (clean.length > maxLength) {
            clean = clean.substring(0, maxLength)
        }
        return clean
    }

    /**
     * Cleans search query string to prevent injection in SQL/Room queries.
     */
    fun sanitizeQuery(rawQuery: String): String {
        return sanitizeText(rawQuery, maxLength = 80)
            .replace("%", "\\%")
            .replace("_", "\\_")
    }

    /**
     * Verifies Magic Bytes (File Signature) of downloaded media to ensure it's not a disguised
     * executable payload, ELF, APK, DEX, or HTML/JS script.
     */
    fun verifyMediaFileIntegrity(file: File, isAudio: Boolean): Boolean {
        if (!file.exists() || file.length() < 16) {
            return false
        }

        return try {
            file.inputStream().use { input ->
                val header = ByteArray(16)
                val read = input.read(header)
                if (read < 8) return false

                // Disallow Executable / Script signatures immediately:
                // PK.. (ZIP / APK / JAR / DEX): 0x50 0x4B 0x03 0x04
                // ELF binary: 0x7F 'E' 'L' 'F' (0x7F 0x45 0x4C 0x46)
                // Windows PE: 'M' 'Z' (0x4D 0x5A)
                // DEX: 'd' 'e' 'x' '\n' (0x64 0x65 0x78 0x0A)
                // Shell script: '#!' (0x23 0x21)
                // HTML: '<!DO' or '<htm' or '<?xm'
                if (header[0] == 0x7F.toByte() && header[1] == 0x45.toByte() && header[2] == 0x4C.toByte() && header[3] == 0x46.toByte()) {
                    SecurityLogger.w("Blocked ELF binary disguised as media file!")
                    return false
                }
                if (header[0] == 0x4D.toByte() && header[1] == 0x5A.toByte()) {
                    SecurityLogger.w("Blocked Windows executable disguised as media file!")
                    return false
                }
                if (header[0] == 0x64.toByte() && header[1] == 0x65.toByte() && header[2] == 0x78.toByte() && header[3] == 0x0A.toByte()) {
                    SecurityLogger.w("Blocked DEX bytecode disguised as media file!")
                    return false
                }
                if (header[0] == 0x23.toByte() && header[1] == 0x21.toByte()) {
                    SecurityLogger.w("Blocked shell script disguised as media file!")
                    return false
                }
                val headerStr = String(header, 0, 8, Charsets.US_ASCII).lowercase()
                if (headerStr.startsWith("<!do") || headerStr.startsWith("<htm") || headerStr.startsWith("<?xm") || headerStr.startsWith("<scr")) {
                    SecurityLogger.w("Blocked HTML/XML script disguised as media file!")
                    return false
                }

                // For MP4: ISO Base Media file format has 'ftyp' box at index 4..7
                if (!isAudio) {
                    val ftyp = String(header, 4, 4, Charsets.US_ASCII)
                    if (ftyp == "ftyp" || ftyp == "moov" || ftyp == "mdat" || ftyp == "wide" || ftyp == "free") {
                        return true
                    }
                    // Some video streams start with MPEG-TS sync byte 0x47 or Matroska / WebM 0x1A 0x45 0xDF 0xA3
                    if (header[0] == 0x47.toByte() || (header[0] == 0x1A.toByte() && header[1] == 0x45.toByte() && header[2] == 0xDF.toByte() && header[3] == 0xA3.toByte())) {
                        return true
                    }
                }

                // For Audio: ID3 tag ("ID3") or MPEG Audio sync frame (0xFF 0xFB / 0xFF 0xF3 / 0xFF 0xF2) or AAC / ADTS (0xFF 0xF1) or RIFF/WAV or OggS
                if (isAudio) {
                    val id3 = String(header, 0, 3, Charsets.US_ASCII)
                    if (id3 == "ID3") return true
                    if ((header[0].toInt() and 0xFF) == 0xFF && (header[1].toInt() and 0xE0) == 0xE0) return true
                    val riff = String(header, 0, 4, Charsets.US_ASCII)
                    if (riff == "RIFF" || riff == "OggS" || riff == "fLaC") return true
                    // Audio can also be stored in ISO MP4 container (.m4a/.mp3)
                    val ftyp = String(header, 4, 4, Charsets.US_ASCII)
                    if (ftyp == "ftyp" || ftyp == "moov" || ftyp == "mdat") return true
                }

                // If passed general binary checks without matching bad patterns, allow safe media
                true
            }
        } catch (e: Exception) {
            SecurityLogger.w("Media header validation warning: ${e.message}")
            true
        }
    }

    /**
     * Sanitizes error message so internal device paths, sensitive tokens, or raw traces
     * are never displayed to the user interface.
     */
    fun sanitizeErrorMessage(throwable: Throwable?): String {
        if (throwable == null) return "حدث خطأ غير متوقع."
        val msg = throwable.localizedMessage ?: throwable.message ?: ""
        
        // Remove internal absolute paths like /data/user/0/..., /storage/emulated/0/...
        val sanitized = msg.replace(Regex("/[a-zA-Z0-9._/-]+"), "[مسار آمن]")
            .replace(Regex("(?i)(api[_-]?key|token|password|secret)=[a-zA-Z0-9._-]+"), "$1=***")

        return if (sanitized.isNotBlank()) sanitized else "حدث خطأ أثناء معالجة الطلب."
    }
}

/**
 * Custom OkHttp Dns resolver preventing SSRF & DNS Rebinding attacks.
 * Inspects all resolved IP addresses and rejects any private/loopback/link-local ranges.
 */
class SafeDns : Dns {
    private val hostCache = ConcurrentHashMap<String, List<InetAddress>>()

    override fun lookup(hostname: String): List<InetAddress> {
        val cached = hostCache[hostname]
        if (cached != null) return cached

        if (SecurityGuard.isForbiddenHostOrIp(hostname)) {
            SecurityLogger.e("SafeDns: Blocked SSRF lookup for forbidden host: $hostname")
            throw SecurityException("تم حظر الاتصال بالعنوان الداخلي ($hostname) لأسباب أمنية.")
        }

        val addresses = Dns.SYSTEM.lookup(hostname)
        for (addr in addresses) {
            if (SecurityGuard.isPrivateOrLoopbackAddress(addr)) {
                SecurityLogger.e("SafeDns: Hostname '$hostname' resolved to private/loopback IP: ${addr.hostAddress}")
                throw SecurityException("تم حظر الاتصال بعنوان شبكة داخلي محمي (SSRF Defense).")
            }
        }
        hostCache[hostname] = addresses
        return addresses
    }
}

/**
 * Security-safe logger preventing sensitive tokens, passwords, or full paths from leaking to logcat.
 */
object SecurityLogger {
    private const val TAG = "SecurityAudit"

    fun d(message: String) {
        try {
            Log.d(TAG, filterSensitive(message))
        } catch (_: Throwable) {
            println("DEBUG: [$TAG] ${filterSensitive(message)}")
        }
    }

    fun i(message: String) {
        try {
            Log.i(TAG, filterSensitive(message))
        } catch (_: Throwable) {
            println("INFO: [$TAG] ${filterSensitive(message)}")
        }
    }

    fun w(message: String) {
        try {
            Log.w(TAG, filterSensitive(message))
        } catch (_: Throwable) {
            println("WARN: [$TAG] ${filterSensitive(message)}")
        }
    }

    fun e(message: String, throwable: Throwable? = null) {
        if (throwable is java.util.concurrent.CancellationException || throwable is kotlinx.coroutines.CancellationException) {
            return
        }
        try {
            if (throwable != null) {
                Log.e(TAG, filterSensitive(message) + " [Cause: ${throwable.javaClass.simpleName}]")
            } else {
                Log.e(TAG, filterSensitive(message))
            }
        } catch (_: Throwable) {
            println("ERROR: [$TAG] ${filterSensitive(message)} ${throwable?.message ?: ""}")
        }
    }

    private fun filterSensitive(text: String): String {
        return text.replace(Regex("(?i)(key|token|secret|password|bearer)=([a-zA-Z0-9._~+/-]+)"), "$1=***")
            .replace(Regex("/data/user/\\d+/[^/]+"), "[APP_PRIVATE_DIR]")
    }
}
