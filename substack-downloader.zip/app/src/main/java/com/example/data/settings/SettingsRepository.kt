package com.example.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "substack_settings")

data class AppSettings(
    val themeMode: String = "system", // "system", "dark", "light"
    val language: String = "ar", // "ar", "en", "system" - Default to Arabic
    val defaultQuality: String = "auto", // "auto", "1080p", "720p", "480p", "360p", "audio"
    val concurrentDownloads: Int = 2, // 1, 2, 3
    val autoRetry: Boolean = true,
    val autoClipboard: Boolean = true,
    val wifiOnly: Boolean = false,
    val notificationsEnabled: Boolean = true
)

class SettingsRepository(private val context: Context) {

    private object PreferencesKeys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val DEFAULT_QUALITY = stringPreferencesKey("default_quality")
        val CONCURRENT_DOWNLOADS = intPreferencesKey("concurrent_downloads")
        val AUTO_RETRY = booleanPreferencesKey("auto_retry")
        val AUTO_CLIPBOARD = booleanPreferencesKey("auto_clipboard")
        val WIFI_ONLY = booleanPreferencesKey("wifi_only")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { preferences ->
        AppSettings(
            themeMode = preferences[PreferencesKeys.THEME_MODE] ?: "system",
            language = preferences[PreferencesKeys.LANGUAGE] ?: "ar",
            defaultQuality = preferences[PreferencesKeys.DEFAULT_QUALITY] ?: "auto",
            concurrentDownloads = preferences[PreferencesKeys.CONCURRENT_DOWNLOADS] ?: 2,
            autoRetry = preferences[PreferencesKeys.AUTO_RETRY] ?: true,
            autoClipboard = preferences[PreferencesKeys.AUTO_CLIPBOARD] ?: true,
            wifiOnly = preferences[PreferencesKeys.WIFI_ONLY] ?: false,
            notificationsEnabled = preferences[PreferencesKeys.NOTIFICATIONS_ENABLED] ?: true
        )
    }

    suspend fun updateThemeMode(themeMode: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.THEME_MODE] = themeMode
        }
    }

    suspend fun updateLanguage(language: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.LANGUAGE] = language
        }
    }

    suspend fun updateDefaultQuality(quality: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.DEFAULT_QUALITY] = quality
        }
    }

    suspend fun updateConcurrentDownloads(limit: Int) {
        val safeLimit = limit.coerceIn(1, 3)
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.CONCURRENT_DOWNLOADS] = safeLimit
        }
    }

    suspend fun updateAutoRetry(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.AUTO_RETRY] = enabled
        }
    }

    suspend fun updateAutoClipboard(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.AUTO_CLIPBOARD] = enabled
        }
    }

    suspend fun updateWifiOnly(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.WIFI_ONLY] = enabled
        }
    }

    suspend fun updateNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.NOTIFICATIONS_ENABLED] = enabled
        }
    }
}
