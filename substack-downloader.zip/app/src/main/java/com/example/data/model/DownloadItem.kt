package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "downloads",
    indices = [
        Index(value = ["status"]),
        Index(value = ["createdAt"]),
        Index(value = ["formatType"])
    ]
)
data class DownloadItem(
    @PrimaryKey val id: String,
    val noteId: String? = null,
    val url: String,
    val title: String,
    val description: String = "",
    val author: String = "Substack",
    val imageUrl: String? = null,
    val filename: String,
    val filePath: String = "",
    val size: Long = 0L,
    val downloadedSize: Long = 0L,
    val status: String = STATUS_QUEUED,
    val formatType: String = FORMAT_VIDEO,
    val qualityLabel: String = "1080p HD",
    val resolution: String? = null,
    val bitrate: Long? = null,
    val durationSeconds: Double? = null,
    val mimeType: String = "video/mp4",
    val sourceUrl: String = "",
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
) {
    companion object {
        const val STATUS_QUEUED = "QUEUED"
        const val STATUS_RESOLVING = "RESOLVING"
        const val STATUS_DOWNLOADING = "DOWNLOADING"
        const val STATUS_PAUSED = "PAUSED"
        const val STATUS_DONE = "DONE"
        const val STATUS_ERROR = "ERROR"
        const val STATUS_CANCELLED = "CANCELLED"

        const val FORMAT_VIDEO = "VIDEO"
        const val FORMAT_AUDIO = "AUDIO"
    }

    val isFinished: Boolean
        get() = status == STATUS_DONE || status == STATUS_ERROR || status == STATUS_CANCELLED

    val isActive: Boolean
        get() = status == STATUS_DOWNLOADING || status == STATUS_RESOLVING || status == STATUS_QUEUED
}

data class NoteDetails(
    val noteId: String,
    val title: String,
    val description: String,
    val author: String = "Substack",
    val imageUrl: String?,
    val durationSeconds: Double? = null,
    val mediaIds: List<String> = emptyList(),
    val videoSources: List<VideoSource> = emptyList()
)

data class VideoSource(
    val type: String, // "hls", "mp4", "webm", "audio", "direct"
    val quality: String = "1080p HD",
    val resolution: String? = null,
    val bitrate: Long? = null,
    val sizeBytes: Long? = null,
    val url: String,
    val mimeType: String = "video/mp4",
    val isHls: Boolean = false
)

data class DownloadProgress(
    val downloadedBytes: Long,
    val totalBytes: Long,
    val bytesPerSec: Double,
    val etaSeconds: Long,
    val isPaused: Boolean = false,
    val isHls: Boolean = false,
    val currentSegment: Int = 0,
    val totalSegments: Int = 0
) {
    val percentage: Float
        get() = when {
            totalBytes > 0 -> ((downloadedBytes.toFloat() / totalBytes.toFloat()) * 100f).coerceIn(0f, 100f)
            totalSegments > 0 -> ((currentSegment.toFloat() / totalSegments.toFloat()) * 100f).coerceIn(0f, 100f)
            else -> 0f
        }
}
