package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey val id: String,
    val noteId: String? = null,
    val url: String,
    val title: String,
    val description: String = "",
    val imageUrl: String? = null,
    val filename: String,
    val filePath: String = "",
    val size: Long = 0L,
    val downloadedSize: Long = 0L,
    val status: String = STATUS_QUEUED, // QUEUED, RESOLVING, DOWNLOADING, PAUSED, DONE, ERROR, CANCELLED
    val formatType: String = FORMAT_VIDEO, // FORMAT_VIDEO or FORMAT_AUDIO
    val qualityLabel: String = "1080p", // "1080p", "720p", "480p", "Audio"
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
) {
    companion object {
        const val STATUS_QUEUED = "QUEUED"
        const val STATUS_RESOLVING = "RESOLVING"
        const val STATUS_DOWNLOADING = "DOWNLOADING"
        const val STATUS_PAUSED = "PAUSED"
        const val STATUS_DONE = "DONE"
        const val STATUS_ERROR = "ERROR"
        const val STATUS_CANCELLED = "CANCELLED"

        const val FORMAT_VIDEO = "VIDEO"
        const val FORMAT_AUDIO = "AUDIO"
    }
}

data class NoteDetails(
    val noteId: String,
    val title: String,
    val description: String,
    val imageUrl: String?,
    val mediaIds: List<String>,
    val videoSources: List<VideoSource>
)

data class VideoSource(
    val type: String, // "mp4", "hls", "direct", "cdn"
    val quality: String = "1080p HD", // "1080p HD", "720p SD", "480p", "Audio MP3"
    val url: String
)

data class DownloadProgress(
    val downloadedBytes: Long,
    val totalBytes: Long,
    val bytesPerSec: Double,
    val etaSeconds: Long,
    val isPaused: Boolean = false
) {
    val percentage: Float
        get() = if (totalBytes > 0) (downloadedBytes.toFloat() / totalBytes.toFloat()) * 100f else 0f
}

