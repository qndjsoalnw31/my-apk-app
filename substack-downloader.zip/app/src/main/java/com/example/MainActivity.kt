package com.example

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.core.content.ContextCompat
import com.example.security.SecurityGuard
import com.example.ui.DownloadViewModel
import com.example.ui.MainScreen
import com.example.ui.theme.SubstackDownloaderTheme
import com.example.ui.util.LocalAppStrings
import com.example.ui.util.getAppLayoutDirection
import com.example.ui.util.getAppStrings
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val viewModel: DownloadViewModel by viewModels()

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        Log.d("MainActivity", "Notification permission granted: $isGranted")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            enableEdgeToEdge()
        } catch (e: Exception) {
            Log.w("MainActivity", "EdgeToEdge non-critical fallback: ${e.message}")
        }

        // Request notification permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        handleIncomingIntent(intent)

        setContent {
            val settings by viewModel.appSettings.collectAsState()
            val isDarkTheme = when (settings.themeMode) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }
            val strings = getAppStrings(settings.language)
            val layoutDirection = getAppLayoutDirection(settings.language)

            // Dynamically synchronize Activity Locale and Configuration
            LaunchedEffect(settings.language) {
                try {
                    val targetLocale = if (settings.language.equals("en", ignoreCase = true)) Locale.ENGLISH else Locale("ar")
                    Locale.setDefault(targetLocale)
                    val resources = this@MainActivity.resources
                    val config = resources.configuration
                    config.setLocale(targetLocale)
                    config.setLayoutDirection(targetLocale)
                    @Suppress("DEPRECATION")
                    resources.updateConfiguration(config, resources.displayMetrics)
                } catch (e: Exception) {
                    Log.w("MainActivity", "Locale configuration sync warning: ${e.message}")
                }
            }

            CompositionLocalProvider(
                LocalAppStrings provides strings,
                LocalLayoutDirection provides layoutDirection
            ) {
                SubstackDownloaderTheme(darkTheme = isDarkTheme) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        MainScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        checkClipboardForSubstackUrl()
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return

        val action = intent.action
        val type = intent.type

        if (Intent.ACTION_SEND == action && type != null) {
            if ("text/plain" == type) {
                val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (!sharedText.isNullOrBlank()) {
                    extractAndSetUrl(sharedText)
                }
            }
        } else if (Intent.ACTION_VIEW == action) {
            val dataUri = intent.data
            if (dataUri != null) {
                val urlString = dataUri.toString()
                extractAndSetUrl(urlString)
            }
        }
    }

    private fun extractAndSetUrl(text: String) {
        val urlRegex = Regex("https?://[^\\s<>\"'{}|\\\\^`]+", RegexOption.IGNORE_CASE)
        val match = urlRegex.find(text)
        val extractedUrl = match?.value ?: text.trim()

        if (SecurityGuard.validateAndSanitizeUrl(extractedUrl).isSuccess) {
            viewModel.onUrlChanged(extractedUrl)
            if (com.example.network.TikTokParser.isTikTokUrl(extractedUrl)) {
                viewModel.setPlatformMode(com.example.ui.PlatformMode.TIKTOK)
            } else {
                viewModel.setPlatformMode(com.example.ui.PlatformMode.SUBSTACK)
            }
            viewModel.setCurrentTab(0)
        }
    }

    private fun checkClipboardForSubstackUrl() {
        try {
            if (!viewModel.appSettings.value.autoClipboard) return

            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            if (clipboard?.hasPrimaryClip() == true) {
                val item = clipboard.primaryClip?.getItemAt(0)
                val rawText = item?.text?.toString()?.trim() ?: ""
                val urlRegex = Regex("https?://[^\\s<>\"'{}|\\\\^`]+", RegexOption.IGNORE_CASE)
                val match = urlRegex.find(rawText)
                val text = match?.value ?: rawText

                if (text.startsWith("http", ignoreCase = true) &&
                    (text.contains("substack.com") || text.contains("open.substack.com") || com.example.network.TikTokParser.isTikTokUrl(text)) &&
                    SecurityGuard.validateAndSanitizeUrl(text).isSuccess
                ) {
                    viewModel.onClipboardDetected(text)
                }
            }
        } catch (e: Exception) {
            Log.w("MainActivity", "Clipboard check warning: ${e.message}")
        }
    }
}
