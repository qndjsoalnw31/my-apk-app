package com.example.network.hls

import com.example.security.SafeDns
import com.example.security.SecurityGuard
import com.example.security.SecurityLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URI
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class HlsParser(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .dns(SafeDns())
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {

    suspend fun fetchAndParseMaster(masterUrl: String): HlsMasterPlaylist = withContext(Dispatchers.IO) {
        val safeUrl = SecurityGuard.validateAndSanitizeUrl(masterUrl).getOrThrow()
        val content = fetchText(safeUrl)
        parseMasterContent(safeUrl, content)
    }

    suspend fun fetchAndParseMedia(mediaUrl: String): HlsMediaPlaylist = withContext(Dispatchers.IO) {
        val safeUrl = SecurityGuard.validateAndSanitizeUrl(mediaUrl).getOrThrow()
        val content = fetchText(safeUrl)
        parseMediaContent(safeUrl, content)
    }

    fun parseMasterContent(baseUrl: String, content: String): HlsMasterPlaylist {
        val variants = mutableListOf<HlsVariant>()
        val audioTracks = mutableListOf<HlsAudioTrack>()

        val lines = content.lines().map { it.trim() }.filter { it.isNotEmpty() }
        var currentBandwidth: Long = 0
        var currentResolution: String? = null
        var currentWidth: Int? = null
        var currentHeight: Int? = null
        var currentCodecs: String? = null
        var currentFrameRate: Float? = null

        val resolutionPattern = Pattern.compile("RESOLUTION=(\\d+)x(\\d+)", Pattern.CASE_INSENSITIVE)
        val bandwidthPattern = Pattern.compile("BANDWIDTH=(\\d+)", Pattern.CASE_INSENSITIVE)
        val codecsPattern = Pattern.compile("CODECS=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE)
        val frameRatePattern = Pattern.compile("FRAME-RATE=([\\d.]+)", Pattern.CASE_INSENSITIVE)

        for (i in lines.indices) {
            val line = lines[i]

            if (line.startsWith("#EXT-X-STREAM-INF:")) {
                // Parse attributes
                val bwMatcher = bandwidthPattern.matcher(line)
                if (bwMatcher.find()) {
                    currentBandwidth = bwMatcher.group(1)?.toLongOrNull() ?: 0L
                }

                val resMatcher = resolutionPattern.matcher(line)
                if (resMatcher.find()) {
                    val w = resMatcher.group(1)?.toIntOrNull()
                    val h = resMatcher.group(2)?.toIntOrNull()
                    currentWidth = w
                    currentHeight = h
                    if (w != null && h != null) {
                        currentResolution = "${w}x${h}"
                    }
                }

                val codecsMatcher = codecsPattern.matcher(line)
                if (codecsMatcher.find()) {
                    currentCodecs = codecsMatcher.group(1)
                }

                val frMatcher = frameRatePattern.matcher(line)
                if (frMatcher.find()) {
                    currentFrameRate = frMatcher.group(1)?.toFloatOrNull()
                }
            } else if (line.startsWith("#EXT-X-MEDIA:TYPE=AUDIO")) {
                val uriPattern = Pattern.compile("URI=\"([^\"]+)\"")
                val namePattern = Pattern.compile("NAME=\"([^\"]+)\"")
                val langPattern = Pattern.compile("LANGUAGE=\"([^\"]+)\"")

                val uriMatcher = uriPattern.matcher(line)
                val nameMatcher = namePattern.matcher(line)
                val langMatcher = langPattern.matcher(line)

                if (uriMatcher.find()) {
                    val trackUri = resolveUrl(baseUrl, uriMatcher.group(1) ?: "")
                    val name = if (nameMatcher.find()) nameMatcher.group(1) ?: "Audio" else "Audio"
                    val lang = if (langMatcher.find()) langMatcher.group(1) else null
                    audioTracks.add(HlsAudioTrack(url = trackUri, name = name, language = lang))
                }
            } else if (!line.startsWith("#")) {
                // This is the variant URI following #EXT-X-STREAM-INF
                val resolvedVariantUrl = resolveUrl(baseUrl, line)
                val label = buildQualityLabel(currentHeight, currentBandwidth)

                variants.add(
                    HlsVariant(
                        url = resolvedVariantUrl,
                        bandwidth = currentBandwidth,
                        resolution = currentResolution,
                        width = currentWidth,
                        height = currentHeight,
                        codecs = currentCodecs,
                        frameRate = currentFrameRate,
                        qualityLabel = label
                    )
                )

                // Reset temporary fields
                currentBandwidth = 0L
                currentResolution = null
                currentWidth = null
                currentHeight = null
                currentCodecs = null
                currentFrameRate = null
            }
        }

        // Sort variants from highest resolution/bandwidth to lowest
        variants.sortByDescending { it.height ?: (it.bandwidth / 1000).toInt() }

        return HlsMasterPlaylist(uri = baseUrl, variants = variants, audioTracks = audioTracks)
    }

    fun parseMediaContent(baseUrl: String, content: String): HlsMediaPlaylist {
        val segments = mutableListOf<HlsSegment>()
        var targetDuration = 0.0
        var totalDuration = 0.0
        var isEndList = false
        var currentDuration = 0.0
        var sequenceCounter: Long = 0

        val lines = content.lines().map { it.trim() }.filter { it.isNotEmpty() }

        val targetPattern = Pattern.compile("#EXT-X-TARGETDURATION:([\\d.]+)")
        val extinfPattern = Pattern.compile("#EXTINF:([\\d.]+)")
        val seqPattern = Pattern.compile("#EXT-X-MEDIA-SEQUENCE:(\\d+)")

        for (line in lines) {
            if (line.startsWith("#EXT-X-TARGETDURATION:")) {
                val matcher = targetPattern.matcher(line)
                if (matcher.find()) {
                    targetDuration = matcher.group(1)?.toDoubleOrNull() ?: 0.0
                }
            } else if (line.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
                val matcher = seqPattern.matcher(line)
                if (matcher.find()) {
                    sequenceCounter = matcher.group(1)?.toLongOrNull() ?: 0L
                }
            } else if (line.startsWith("#EXTINF:")) {
                val matcher = extinfPattern.matcher(line)
                if (matcher.find()) {
                    currentDuration = matcher.group(1)?.toDoubleOrNull() ?: 0.0
                }
            } else if (line == "#EXT-X-ENDLIST") {
                isEndList = true
            } else if (!line.startsWith("#")) {
                val segmentUrl = resolveUrl(baseUrl, line)
                segments.add(
                    HlsSegment(
                        url = segmentUrl,
                        duration = currentDuration,
                        sequenceNumber = sequenceCounter++
                    )
                )
                totalDuration += currentDuration
                currentDuration = 0.0
            }
        }

        return HlsMediaPlaylist(
            uri = baseUrl,
            targetDuration = targetDuration,
            totalDuration = totalDuration,
            isEndList = isEndList,
            segments = segments
        )
    }

    private fun buildQualityLabel(height: Int?, bandwidth: Long): String {
        return when {
            height != null && height >= 1080 -> "1080p Full HD"
            height != null && height >= 720 -> "720p HD"
            height != null && height >= 480 -> "480p SD"
            height != null && height >= 360 -> "360p"
            height != null && height >= 240 -> "240p"
            bandwidth > 3_000_000 -> "1080p Full HD"
            bandwidth > 1_500_000 -> "720p HD"
            bandwidth > 800_000 -> "480p SD"
            bandwidth > 400_000 -> "360p"
            else -> "جودة تلقائية (${bandwidth / 1000} kbps)"
        }
    }

    fun resolveUrl(baseUrl: String, relativeOrAbsolute: String): String {
        return try {
            if (relativeOrAbsolute.startsWith("http://") || relativeOrAbsolute.startsWith("https://")) {
                relativeOrAbsolute
            } else {
                val baseUri = URI(baseUrl)
                baseUri.resolve(relativeOrAbsolute).toString()
            }
        } catch (e: Exception) {
            SecurityLogger.w("Failed to resolve relative URL $relativeOrAbsolute against $baseUrl: ${e.message}")
            if (baseUrl.contains("/")) {
                val prefix = baseUrl.substringBeforeLast("/") + "/"
                prefix + relativeOrAbsolute.removePrefix("/")
            } else {
                relativeOrAbsolute
            }
        }
    }

    private suspend fun fetchText(url: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) Chrome/131.0.0.0 Mobile Safari/537.36")
            .header("Referer", "https://substack.com/")
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val code = response.code
            response.close()
            throw IllegalStateException("Failed to load playlist: HTTP $code")
        }
        val text = response.body?.string() ?: ""
        response.close()
        text
    }
}
