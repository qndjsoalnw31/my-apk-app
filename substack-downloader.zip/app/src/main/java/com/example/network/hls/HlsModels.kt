package com.example.network.hls

data class HlsMasterPlaylist(
    val uri: String,
    val variants: List<HlsVariant>,
    val audioTracks: List<HlsAudioTrack> = emptyList()
)

data class HlsVariant(
    val url: String,
    val bandwidth: Long,
    val resolution: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val codecs: String? = null,
    val frameRate: Float? = null,
    val qualityLabel: String = ""
)

data class HlsAudioTrack(
    val url: String,
    val name: String,
    val language: String? = null,
    val groupId: String? = null,
    val isDefault: Boolean = false
)

data class HlsMediaPlaylist(
    val uri: String,
    val targetDuration: Double,
    val totalDuration: Double,
    val isEndList: Boolean,
    val segments: List<HlsSegment>
)

data class HlsSegment(
    val url: String,
    val duration: Double,
    val sequenceNumber: Long,
    val keyUrl: String? = null,
    val keyIv: ByteArray? = null
)
