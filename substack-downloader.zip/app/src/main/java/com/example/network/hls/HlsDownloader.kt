package com.example.network.hls

import com.example.security.SafeDns
import com.example.security.SecurityGuard
import com.example.security.SecurityLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class HlsDownloader(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .dns(SafeDns())
        .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {

    suspend fun downloadHlsStream(
        streamUrl: String,
        outputPartFile: File,
        destFile: File,
        isAudio: Boolean,
        onProgress: (downloadedBytes: Long, estimatedTotalBytes: Long, bytesPerSec: Double, etaSec: Long, currentSegment: Int, totalSegments: Int) -> Unit,
        isCancelledOrPaused: () -> Boolean
    ): Unit = withContext(Dispatchers.IO) {
        val parser = HlsParser(client)

        // 1. Fetch and parse the playlist
        val playlist = parser.fetchAndParseMedia(streamUrl)
        if (playlist.segments.isEmpty()) {
            throw IllegalStateException("قائمة تشغيل HLS لا تحتوي على مقاطع (Segments).")
        }

        outputPartFile.parentFile?.let { if (!it.exists()) it.mkdirs() }

        var downloadedBytes = if (outputPartFile.exists()) outputPartFile.length() else 0L
        val totalSegments = playlist.segments.size
        var currentSegmentIndex = 0

        val startTime = System.currentTimeMillis()
        var lastReportTime = System.currentTimeMillis()

        // High-speed parallel batch downloading (4 segments at a time, strictly ordered write)
        val concurrencyBatchSize = 4

        FileOutputStream(outputPartFile, true).use { out ->
            val chunks = playlist.segments.chunked(concurrencyBatchSize)
            for (chunk in chunks) {
                if (isCancelledOrPaused() || Thread.currentThread().isInterrupted) {
                    throw CancellationException("HLS Download paused or cancelled")
                }

                // Download chunk segments in parallel
                val results = chunk.map { segment ->
                    async(Dispatchers.IO) {
                        downloadSingleSegment(segment.url, isCancelledOrPaused)
                    }
                }.awaitAll()

                // Write downloaded bytes strictly in order to preserve stream continuity
                for (segmentBytes in results) {
                    if (isCancelledOrPaused()) {
                        throw CancellationException("HLS Download cancelled during stream")
                    }

                    if (downloadedBytes + segmentBytes.size > SecurityGuard.MAX_ALLOWED_FILE_SIZE_BYTES) {
                        throw SecurityException("تم تجاوز حد حجم الملف الأقصى المسموح به (2 جيجابايت).")
                    }

                    out.write(segmentBytes)
                    downloadedBytes += segmentBytes.size
                    currentSegmentIndex++
                }

                // Periodic progress report
                val now = System.currentTimeMillis()
                if (now - lastReportTime >= 200 || currentSegmentIndex >= totalSegments) {
                    val elapsedSec = ((now - startTime) / 1000.0).coerceAtLeast(0.001)
                    val speed = downloadedBytes / elapsedSec
                    val avgSegmentSize = downloadedBytes / currentSegmentIndex.coerceAtLeast(1)
                    val estimatedTotal = avgSegmentSize * totalSegments
                    val remainingBytes = (estimatedTotal - downloadedBytes).coerceAtLeast(0)
                    val eta = if (speed > 0) (remainingBytes / speed).toLong() else 0L

                    onProgress(downloadedBytes, estimatedTotal, speed, eta, currentSegmentIndex, totalSegments)
                    lastReportTime = now
                }
            }
        }

        // Verify magic bytes and complete atomic rename
        if (outputPartFile.exists() && outputPartFile.length() > 0) {
            val isVerified = SecurityGuard.verifyMediaFileIntegrity(outputPartFile, isAudio)
            if (!isVerified) {
                outputPartFile.delete()
                throw SecurityException("فشل التحقق الأمني: الملف الناتج لا يحتوي على توقيع وسائط صالح.")
            }

            if (destFile.exists()) destFile.delete()
            val renamed = outputPartFile.renameTo(destFile)
            if (!renamed) {
                outputPartFile.copyTo(destFile, overwrite = true)
                outputPartFile.delete()
            }
        } else {
            throw IllegalStateException("الملف الناتج فارغ بعد تجميع المقاطع.")
        }
    }

    private fun downloadSingleSegment(rawUrl: String, isCancelledOrPaused: () -> Boolean): ByteArray {
        val safeUrl = SecurityGuard.validateAndSanitizeUrl(rawUrl).getOrThrow()
        var attempts = 0
        var lastEx: Exception? = null

        while (attempts < 3) {
            if (isCancelledOrPaused()) throw CancellationException("HLS Download cancelled")
            attempts++
            try {
                val req = Request.Builder()
                    .url(safeUrl)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) Chrome/131.0.0.0 Mobile Safari/537.36")
                    .header("Referer", "https://substack.com/")
                    .build()

                val res = client.newCall(req).execute()
                if (!res.isSuccessful) {
                    val code = res.code
                    res.close()
                    throw IllegalStateException("Segment HTTP error: $code")
                }

                val body = res.body ?: throw IllegalStateException("Empty segment body")
                val bytes = body.bytes()
                res.close()
                return bytes
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastEx = e
                SecurityLogger.w("Retrying segment (attempt $attempts): ${e.message}")
            }
        }

        throw lastEx ?: IllegalStateException("Failed to download segment after 3 attempts")
    }
}
