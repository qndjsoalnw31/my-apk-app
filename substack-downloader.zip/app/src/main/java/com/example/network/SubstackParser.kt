package com.example.network

import com.example.data.model.NoteDetails
import com.example.data.model.VideoSource
import com.example.network.hls.HlsParser
import com.example.security.SafeDns
import com.example.security.SecurityGuard
import com.example.security.SecurityLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class SubstackParser(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .dns(SafeDns())
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {

    private val hlsParser = HlsParser(client)

    companion object {
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

        fun extractNoteId(url: String): String? {
            val patterns = listOf(
                Pattern.compile("/note/c-(\\d{1,20})", Pattern.CASE_INSENSITIVE),
                Pattern.compile("/notes/c-(\\d{1,20})", Pattern.CASE_INSENSITIVE),
                Pattern.compile("\\bc-(\\d{1,20})\\b", Pattern.CASE_INSENSITIVE),
                Pattern.compile("c-(\\d{1,20})", Pattern.CASE_INSENSITIVE),
                Pattern.compile("/comment/(\\d{1,20})", Pattern.CASE_INSENSITIVE)
            )
            for (p in patterns) {
                val matcher = p.matcher(url)
                if (matcher.find()) {
                    val id = matcher.group(1)
                    if (id != null && id.all { it.isDigit() }) {
                        return id
                    }
                }
            }
            return null
        }

        fun extractPostSlug(url: String): Pair<String?, String?> {
            // Returns Pair(subdomain/domain, slug)
            try {
                val uri = URI(url)
                val host = uri.host ?: ""
                val path = uri.path ?: ""
                val postPattern = Pattern.compile("/p/([a-zA-Z0-9_-]+)", Pattern.CASE_INSENSITIVE)
                val matcher = postPattern.matcher(path)
                if (matcher.find()) {
                    val slug = matcher.group(1)
                    return Pair(host, slug)
                }
            } catch (_: Exception) {}
            return Pair(null, null)
        }

        fun cleanHtmlText(text: String): String {
            return SecurityGuard.sanitizeText(text, maxLength = 250)
        }

        fun safeFilename(rawName: String, downloadId: String? = null, isAudio: Boolean = false): String {
            return SecurityGuard.sanitizeFileName(rawName, isAudio = isAudio, suffixId = downloadId)
        }
    }

    /**
     * Resolves Substack Note, Post, or Media URL and extracts genuine media streams rapidly.
     */
    suspend fun resolveNote(noteUrl: String): NoteDetails = withContext(Dispatchers.IO) {
        if (!SecurityGuard.checkRateLimit("resolve_note")) {
            throw SecurityException("تم تجاوز حد الطلبات المتكررة، يرجى الانتظار بضع ثوانٍ.")
        }

        val sanitizedUrl = SecurityGuard.validateAndSanitizeUrl(noteUrl).getOrThrow()

        // Fast-path: Check note ID or post slug immediately without network redirect roundtrip
        val directNoteId = extractNoteId(sanitizedUrl)
        if (directNoteId != null) {
            return@withContext resolveCommentNote(directNoteId, sanitizedUrl)
        }

        val (directHost, directSlug) = extractPostSlug(sanitizedUrl)
        if (directSlug != null && directHost != null && !directHost.contains("open.substack.com")) {
            return@withContext resolvePostArticle(directHost, directSlug, sanitizedUrl)
        }

        // Only resolve redirect if fast-path did not match
        val finalUrl = resolveRedirects(sanitizedUrl)
        val noteId = extractNoteId(finalUrl)
        val (host, postSlug) = extractPostSlug(finalUrl)

        if (noteId != null) {
            return@withContext resolveCommentNote(noteId, finalUrl)
        } else if (postSlug != null && host != null) {
            return@withContext resolvePostArticle(host, postSlug, finalUrl)
        } else {
            // Direct video or direct link
            return@withContext resolveGenericPageOrDirect(finalUrl)
        }
    }

    private suspend fun resolveCommentNote(noteId: String, pageUrl: String): NoteDetails = withContext(Dispatchers.IO) {
        val apiUrl = "https://substack.com/api/v1/reader/comment/$noteId"

        val request = Request.Builder()
            .url(apiUrl)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "application/json, text/plain, */*")
            .header("Referer", "https://substack.com/")
            .get()
            .build()

        SecurityLogger.i("Resolving Substack Note ID: $noteId")

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val code = response.code
            response.close()
            throw IllegalStateException("خادم Substack رفض الطلب (HTTP $code)")
        }

        val jsonString = response.body?.string() ?: ""
        response.close()

        if (jsonString.isBlank()) {
            throw IllegalStateException("استجابة خادم Substack فارغة.")
        }

        val jsonObject = JSONObject(jsonString)
        val extracted = ExtractedData()
        extractEverything(jsonObject, extracted)

        val sources = discoverRealSources(extracted)

        val rawTitle = extracted.titles.firstOrNull()?.ifBlank { null }
            ?: extracted.texts.maxByOrNull { it.length }?.take(60)
            ?: "Substack Note $noteId"
        val title = cleanHtmlText(rawTitle)

        val rawDesc = extracted.texts.maxByOrNull { it.length } ?: ""
        val description = cleanHtmlText(rawDesc)

        val rawAuthor = extracted.authors.firstOrNull() ?: "Substack Note"
        val author = cleanHtmlText(rawAuthor)

        val rawImage = extracted.images.firstOrNull()
        val imageUrl = if (!rawImage.isNullOrBlank() && SecurityGuard.validateAndSanitizeUrl(rawImage).isSuccess) {
            rawImage
        } else null

        return@withContext NoteDetails(
            noteId = noteId,
            title = title,
            description = description,
            author = author,
            imageUrl = imageUrl,
            durationSeconds = extracted.durationSeconds,
            mediaIds = extracted.mediaIds.distinct(),
            videoSources = sources
        )
    }

    private suspend fun resolvePostArticle(host: String, slug: String, pageUrl: String): NoteDetails = withContext(Dispatchers.IO) {
        val apiUrl = "https://$host/api/v1/posts/$slug"

        val request = Request.Builder()
            .url(apiUrl)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "application/json, text/plain, */*")
            .header("Referer", "https://$host/")
            .get()
            .build()

        val response = client.newCall(request).execute()
        if (response.isSuccessful) {
            val jsonString = response.body?.string() ?: ""
            response.close()
            if (jsonString.isNotBlank()) {
                val jsonObject = JSONObject(jsonString)
                val extracted = ExtractedData()
                extractEverything(jsonObject, extracted)

                val sources = discoverRealSources(extracted)

                val title = cleanHtmlText(jsonObject.optString("title", slug))
                val description = cleanHtmlText(jsonObject.optString("description", jsonObject.optString("subtitle", "")))
                val author = cleanHtmlText(jsonObject.optJSONObject("published_by")?.optString("name") ?: jsonObject.optString("post_date", host))
                val coverImage = jsonObject.optString("cover_image").ifBlank { extracted.images.firstOrNull() }

                return@withContext NoteDetails(
                    noteId = slug,
                    title = title,
                    description = description,
                    author = author,
                    imageUrl = if (!coverImage.isNullOrBlank()) coverImage else null,
                    durationSeconds = extracted.durationSeconds,
                    mediaIds = extracted.mediaIds.distinct(),
                    videoSources = sources
                )
            }
        } else {
            response.close()
        }

        // Fallback to HTML scraping of page
        return@withContext resolveGenericPageOrDirect(pageUrl)
    }

    private suspend fun resolveGenericPageOrDirect(pageUrl: String): NoteDetails = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(pageUrl)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "*/*")
            .get()
            .build()

        val response = client.newCall(request).execute()
        val contentType = response.header("Content-Type", "")?.lowercase() ?: ""
        val bodyText = response.body?.string() ?: ""
        response.close()

        val extracted = ExtractedData()

        if (contentType.contains("application/json")) {
            try {
                val json = JSONObject(bodyText)
                extractEverything(json, extracted)
            } catch (_: Exception) {}
        } else {
            // HTML search for video sources and scripts
            val mp4Matcher = Pattern.compile("https?://[^\"'\\s]+\\.mp4[^\"'\\s]*", Pattern.CASE_INSENSITIVE).matcher(bodyText)
            while (mp4Matcher.find()) {
                extracted.videos.add(mp4Matcher.group(0) ?: "")
            }
            val m3u8Matcher = Pattern.compile("https?://[^\"'\\s]+\\.m3u8[^\"'\\s]*", Pattern.CASE_INSENSITIVE).matcher(bodyText)
            while (m3u8Matcher.find()) {
                extracted.videos.add(m3u8Matcher.group(0) ?: "")
            }
            val titleMatcher = Pattern.compile("<title>(.*?)</title>", Pattern.CASE_INSENSITIVE).matcher(bodyText)
            if (titleMatcher.find()) {
                extracted.titles.add(cleanHtmlText(titleMatcher.group(1) ?: ""))
            }
            val ogImageMatcher = Pattern.compile("<meta property=\"og:image\" content=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE).matcher(bodyText)
            if (ogImageMatcher.find()) {
                extracted.images.add(ogImageMatcher.group(1) ?: "")
            }
        }

        val sources = discoverRealSources(extracted)
        val title = extracted.titles.firstOrNull() ?: "Substack Media"

        return@withContext NoteDetails(
            noteId = "media_" + (System.currentTimeMillis() % 10000),
            title = title,
            description = extracted.texts.firstOrNull() ?: "",
            author = "Substack",
            imageUrl = extracted.images.firstOrNull(),
            durationSeconds = extracted.durationSeconds,
            mediaIds = extracted.mediaIds.distinct(),
            videoSources = sources
        )
    }

    /**
     * Inspects discovered video and audio candidate URLs to extract real qualities and variants.
     */
    private suspend fun discoverRealSources(extracted: ExtractedData): List<VideoSource> {
        val sources = mutableListOf<VideoSource>()

        // 1. Process HLS (.m3u8) streams by parsing Master Playlist for true resolutions
        for (vUrl in extracted.videos) {
            val valid = SecurityGuard.validateAndSanitizeUrl(vUrl).getOrNull() ?: continue
            if (valid.contains(".m3u8")) {
                try {
                    val master = hlsParser.fetchAndParseMaster(valid)
                    if (master.variants.isNotEmpty()) {
                        for (variant in master.variants) {
                            sources.add(
                                VideoSource(
                                    type = "hls",
                                    quality = variant.qualityLabel,
                                    resolution = variant.resolution,
                                    bitrate = variant.bandwidth,
                                    url = variant.url,
                                    mimeType = "application/x-mpegURL",
                                    isHls = true
                                )
                            )
                        }
                    } else {
                        sources.add(
                            VideoSource(
                                type = "hls",
                                quality = "HLS Stream",
                                url = valid,
                                mimeType = "application/x-mpegURL",
                                isHls = true
                            )
                        )
                    }

                    // Add Audio only option from HLS if available
                    if (master.audioTracks.isNotEmpty()) {
                        for (track in master.audioTracks) {
                            sources.add(
                                VideoSource(
                                    type = "audio",
                                    quality = "صوت فقط (Audio MP3/AAC)",
                                    url = track.url,
                                    mimeType = "audio/mp4",
                                    isHls = true
                                )
                            )
                        }
                    }
                } catch (e: Exception) {
                    SecurityLogger.w("Master playlist parsing fallback: ${e.message}")
                    sources.add(
                        VideoSource(
                            type = "hls",
                            quality = "HLS Stream",
                            url = valid,
                            mimeType = "application/x-mpegURL",
                            isHls = true
                        )
                    )
                }
            } else if (valid.contains(".mp4") || valid.contains(".webm")) {
                val quality = when {
                    valid.contains("1080") -> "1080p Full HD"
                    valid.contains("720") -> "720p HD"
                    valid.contains("480") -> "480p SD"
                    valid.contains("360") -> "360p"
                    else -> "MP4 مباشر"
                }
                sources.add(
                    VideoSource(
                        type = if (valid.contains(".webm")) "webm" else "mp4",
                        quality = quality,
                        url = valid,
                        mimeType = if (valid.contains(".webm")) "video/webm" else "video/mp4",
                        isHls = false
                    )
                )
            }
        }

        // 2. Add CDN URLs
        for (cdn in extracted.cdnUrls) {
            val valid = SecurityGuard.validateAndSanitizeUrl(cdn).getOrNull() ?: continue
            if (sources.none { it.url == valid }) {
                sources.add(
                    VideoSource(
                        type = "cdn",
                        quality = "720p HD (CDN)",
                        url = valid,
                        mimeType = "video/mp4",
                        isHls = false
                    )
                )
            }
        }

        // 3. Add Media Upload IDs endpoints
        for (mId in extracted.mediaIds) {
            val sanitizedMid = mId.replace(Regex("[^a-zA-Z0-9_-]"), "")
            if (sanitizedMid.isNotBlank()) {
                val mp4Url = "https://substack.com/api/v1/video/upload/$sanitizedMid/src?type=mp4"
                if (sources.none { it.url == mp4Url }) {
                    sources.add(
                        VideoSource(
                            type = "mp4",
                            quality = "1080p Full HD",
                            url = mp4Url,
                            mimeType = "video/mp4",
                            isHls = false
                        )
                    )
                    sources.add(
                        VideoSource(
                            type = "mp4",
                            quality = "720p HD",
                            url = mp4Url,
                            mimeType = "video/mp4",
                            isHls = false
                        )
                    )
                }
            }
        }

        // 4. Always provide an Audio Only source extraction option
        if (sources.isNotEmpty() && sources.none { it.type == "audio" }) {
            val bestSource = sources.first()
            sources.add(
                VideoSource(
                    type = "audio",
                    quality = "صوت فقط (Audio MP3)",
                    url = bestSource.url,
                    mimeType = "audio/mpeg",
                    isHls = bestSource.isHls
                )
            )
        }

        return sources.distinctBy { it.url + it.quality }
    }

    suspend fun resolveDirectStreamUrl(sourceUrl: String): String = withContext(Dispatchers.IO) {
        val safeSourceUrl = SecurityGuard.validateAndSanitizeUrl(sourceUrl).getOrThrow()

        val request = Request.Builder()
            .url(safeSourceUrl)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "*/*")
            .header("Referer", "https://substack.com/")
            .get()
            .build()

        val response = client.newCall(request).execute()
        val finalUrl = response.request.url.toString()
        val contentType = response.header("Content-Type", "")?.lowercase() ?: ""

        val safeFinalResult = SecurityGuard.validateAndSanitizeUrl(finalUrl)
        if (safeFinalResult.isFailure) {
            response.close()
            throw SecurityException("تم حظر رابط إعادة التوجيه لعدم استيفائه معايير الأمان.")
        }

        if (contentType.contains("application/json")) {
            val bodyString = response.body?.string() ?: ""
            response.close()
            if (bodyString.isNotBlank()) {
                val json = JSONObject(bodyString)
                val extracted = ExtractedData()
                extractEverything(json, extracted)
                val candidate = extracted.videos.firstOrNull() ?: extracted.cdnUrls.firstOrNull()
                if (!candidate.isNullOrBlank()) {
                    val safeCandidate = SecurityGuard.validateAndSanitizeUrl(candidate).getOrNull()
                    if (safeCandidate != null) {
                        return@withContext safeCandidate
                    }
                }
            }
        } else {
            response.close()
        }

        return@withContext safeFinalResult.getOrThrow()
    }

    private suspend fun resolveRedirects(url: String): String = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .head()
                .build()

            val response = client.newCall(request).execute()
            val finalUrl = response.request.url.toString()
            response.close()
            finalUrl
        } catch (e: Exception) {
            url
        }
    }

    private class ExtractedData {
        val videos = mutableListOf<String>()
        val mediaIds = mutableListOf<String>()
        val cdnUrls = mutableListOf<String>()
        val images = mutableListOf<String>()
        val titles = mutableListOf<String>()
        val authors = mutableListOf<String>()
        val texts = mutableListOf<String>()
        var durationSeconds: Double? = null
    }

    private fun extractEverything(obj: Any?, data: ExtractedData) {
        when (obj) {
            is JSONObject -> {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val keyLower = key.lowercase()
                    val valObj = obj.get(key)

                    if (keyLower in listOf("mediaupload", "media_upload")) {
                        if (valObj is JSONObject) {
                            val id = valObj.optString("id").ifBlank {
                                valObj.optString("uuid").ifBlank {
                                    valObj.optString("mediaUploadId")
                                }
                            }
                            if (id.isNotBlank()) data.mediaIds.add(id)

                            for (cdnKey in listOf("cdn_url", "cdnUrl", "url", "source", "src")) {
                                val cdn = valObj.optString(cdnKey)
                                if (cdn.startsWith("http://") || cdn.startsWith("https://")) {
                                    data.cdnUrls.add(cdn)
                                }
                            }
                        } else if (valObj is String && valObj.isNotBlank()) {
                            data.mediaIds.add(valObj)
                        }
                    }

                    if (keyLower in listOf("duration", "duration_seconds", "durationseconds")) {
                        if (valObj is Number) {
                            data.durationSeconds = valObj.toDouble()
                        }
                    }

                    if (valObj is String) {
                        val strVal = valObj.trim()
                        val lowerVal = strVal.lowercase()

                        if (lowerVal.contains(".mp4") || lowerVal.contains(".m3u8") || lowerVal.contains(".webm")) {
                            data.videos.add(strVal)
                        }
                        if (keyLower in listOf("cdn_url", "cdnurl") && strVal.startsWith("http")) {
                            data.cdnUrls.add(strVal)
                        }
                        if (strVal.startsWith("http://") || strVal.startsWith("https://")) {
                            if (listOf(".jpg", ".jpeg", ".png", ".webp").any { lowerVal.contains(it) }) {
                                data.images.add(strVal)
                            }
                        }
                        if (keyLower in listOf("title", "headline", "name") && strVal.isNotBlank()) {
                            data.titles.add(cleanHtmlText(strVal))
                        }
                        if (keyLower in listOf("author_name", "author", "published_by", "username") && strVal.isNotBlank()) {
                            data.authors.add(cleanHtmlText(strVal))
                        }
                        if (keyLower in listOf("body", "text", "content", "description")) {
                            val txt = cleanHtmlText(strVal)
                            if (txt.isNotBlank()) data.texts.add(txt)
                        }
                    }

                    extractEverything(valObj, data)
                }
            }
            is JSONArray -> {
                for (i in 0 until obj.length()) {
                    extractEverything(obj.get(i), data)
                }
            }
            is String -> {
                val strVal = obj.trim()
                val lowerVal = strVal.lowercase()
                if (lowerVal.contains(".mp4") || lowerVal.contains(".m3u8") || lowerVal.contains(".webm")) {
                    data.videos.add(strVal)
                }
            }
        }
    }
}
