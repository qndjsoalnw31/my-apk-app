package com.example.network

import com.example.data.model.NoteDetails
import com.example.data.model.VideoSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class SubstackParser(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {

    companion object {
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

        fun extractNoteId(url: String): String? {
            val patterns = listOf(
                Pattern.compile("/note/c-(\\d+)", Pattern.CASE_INSENSITIVE),
                Pattern.compile("\\bc-(\\d+)\\b", Pattern.CASE_INSENSITIVE),
                Pattern.compile("c-(\\d+)", Pattern.CASE_INSENSITIVE)
            )
            for (p in patterns) {
                val matcher = p.matcher(url)
                if (matcher.find()) {
                    return matcher.group(1)
                }
            }
            return null
        }

        fun cleanHtmlText(text: String): String {
            return text.replace(Regex("<[^>]+>"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        fun safeFilename(rawName: String, downloadId: String? = null, isAudio: Boolean = false): String {
            var name = cleanHtmlText(rawName.ifBlank { if (isAudio) "substack_audio" else "substack_video" })
            name = name.replace(Regex("[\\\\/:*?\"<>|]+"), "_")
                .replace(Regex("\\s+"), " ")
                .trim('.', ' ')
            if (name.isBlank()) name = if (isAudio) "substack_audio" else "substack_video"
            if (name.length > 80) name = name.substring(0, 80)

            // Remove any trailing extensions
            name = name.replace(Regex("(?i)\\.(mp4|mp3|m4a|m3u8)$"), "")

            val ext = if (isAudio) ".mp3" else ".mp4"
            val idSuffix = if (!downloadId.isNullOrBlank()) "_${downloadId.take(8)}" else "_${System.currentTimeMillis() % 10000}"

            return "${name}${idSuffix}${ext}"
        }
    }

    suspend fun resolveNote(noteUrl: String): NoteDetails = withContext(Dispatchers.IO) {
        val noteId = extractNoteId(noteUrl)
            ?: throw IllegalArgumentException("لم يتم العثور على معرّف الملاحظة (Note ID) في الرابط.")

        val apiUrl = "https://substack.com/api/v1/reader/comment/$noteId"

        val request = Request.Builder()
            .url(apiUrl)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "application/json, text/plain, */*")
            .header("Referer", "https://substack.com/")
            .header("Origin", "https://substack.com")
            .get()
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val code = response.code
            response.close()
            throw IllegalStateException("Substack رفض الطلب (HTTP $code)")
        }

        val jsonString = response.body?.string() ?: ""
        response.close()

        if (jsonString.isBlank()) {
            throw IllegalStateException("استجابة Substack فارغة.")
        }

        val jsonObject = JSONObject(jsonString)

        val extracted = ExtractedData()
        extractEverything(jsonObject, extracted)

        val sources = mutableListOf<VideoSource>()

        // Add direct video URLs found
        for (vUrl in extracted.videos) {
            val quality = if (vUrl.contains("1080") || vUrl.contains("hd")) "1080p HD"
            else if (vUrl.contains("720")) "720p SD"
            else if (vUrl.contains(".m3u8")) "HLS Stream"
            else "1080p HD"

            sources.add(VideoSource(type = if (vUrl.contains(".m3u8")) "hls" else "mp4", quality = quality, url = vUrl))
        }

        // Add CDN URLs
        for (cdn in extracted.cdnUrls) {
            sources.add(VideoSource(type = "cdn", quality = "720p SD", url = cdn))
        }

        // Add mediaUpload URLs
        for (mId in extracted.mediaIds) {
            sources.add(
                VideoSource(
                    type = "mp4",
                    quality = "1080p HD (عالية)",
                    url = "https://substack.com/api/v1/video/upload/$mId/src?type=mp4"
                )
            )
            sources.add(
                VideoSource(
                    type = "mp4",
                    quality = "720p SD (متوسطة)",
                    url = "https://substack.com/api/v1/video/upload/$mId/src?type=mp4"
                )
            )
        }

        val distinctSources = sources.distinctBy { it.url }

        val title = extracted.titles.firstOrNull()?.ifBlank { null }
            ?: extracted.texts.maxByOrNull { it.length }?.take(80)
            ?: "فيديو Substack Note"

        val description = extracted.texts.maxByOrNull { it.length } ?: ""
        val imageUrl = extracted.images.firstOrNull()

        return@withContext NoteDetails(
            noteId = noteId,
            title = title,
            description = description,
            imageUrl = imageUrl,
            mediaIds = extracted.mediaIds.distinct(),
            videoSources = distinctSources
        )
    }

    /**
     * Resolves Substack source endpoint to direct video stream URL
     * (Handles HTTP 302 redirects & JSON payload with cdn_url)
     */
    suspend fun resolveDirectStreamUrl(sourceUrl: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(sourceUrl)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "*/*")
            .header("Referer", "https://substack.com/")
            .get()
            .build()

        val response = client.newCall(request).execute()
        val finalUrl = response.request.url.toString()
        val contentType = response.header("Content-Type", "")?.lowercase() ?: ""

        if (contentType.contains("application/json")) {
            val bodyString = response.body?.string() ?: ""
            response.close()
            if (bodyString.isNotBlank()) {
                val json = JSONObject(bodyString)
                val extracted = ExtractedData()
                extractEverything(json, extracted)
                val candidate = extracted.videos.firstOrNull() ?: extracted.cdnUrls.firstOrNull()
                if (!candidate.isNullOrBlank()) {
                    return@withContext candidate
                }
            }
        }

        response.close()
        return@withContext finalUrl
    }

    private class ExtractedData {
        val videos = mutableListOf<String>()
        val mediaIds = mutableListOf<String>()
        val cdnUrls = mutableListOf<String>()
        val images = mutableListOf<String>()
        val titles = mutableListOf<String>()
        val texts = mutableListOf<String>()
    }

    private fun extractEverything(obj: Any?, data: ExtractedData) {
        when (obj) {
            is JSONObject -> {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val keyLower = key.lowercase()
                    val valObj = obj.get(key)

                    if (keyLower in listOf("mediaupload", "media_upload")) {
                        if (valObj is JSONObject) {
                            val id = valObj.optString("id").ifBlank {
                                valObj.optString("uuid").ifBlank {
                                    valObj.optString("mediaUploadId")
                                }
                            }
                            if (id.isNotBlank()) data.mediaIds.add(id)

                            for (cdnKey in listOf("cdn_url", "cdnUrl", "url", "source", "src")) {
                                val cdn = valObj.optString(cdnKey)
                                if (cdn.startsWith("http://") || cdn.startsWith("https://")) {
                                    data.cdnUrls.add(cdn)
                                }
                            }
                        } else if (valObj is String && valObj.isNotBlank()) {
                            data.mediaIds.add(valObj)
                        }
                    }

                    if (valObj is String) {
                        val strVal = valObj.trim()
                        val lowerVal = strVal.lowercase()

                        if (lowerVal.contains(".mp4") || lowerVal.contains(".m3u8")) {
                            data.videos.add(strVal)
                        }
                        if (keyLower in listOf("cdn_url", "cdnurl") && strVal.startsWith("http")) {
                            data.cdnUrls.add(strVal)
                        }
                        if (strVal.startsWith("http://") || strVal.startsWith("https://")) {
                            if (listOf(".jpg", ".jpeg", ".png", ".webp").any { lowerVal.contains(it) }) {
                                data.images.add(strVal)
                            }
                        }
                        if (keyLower in listOf("title", "headline", "name") && strVal.isNotBlank()) {
                            data.titles.add(cleanHtmlText(strVal))
                        }
                        if (keyLower in listOf("body", "text", "content", "description")) {
                            val txt = cleanHtmlText(strVal)
                            if (txt.isNotBlank()) data.texts.add(txt)
                        }
                    }

                    extractEverything(valObj, data)
                }
            }
            is JSONArray -> {
                for (i in 0 until obj.length()) {
                    extractEverything(obj.get(i), data)
                }
            }
            is String -> {
                val strVal = obj.trim()
                val lowerVal = strVal.lowercase()
                if (lowerVal.contains(".mp4") || lowerVal.contains(".m3u8")) {
                    data.videos.add(strVal)
                }
            }
        }
    }
}
