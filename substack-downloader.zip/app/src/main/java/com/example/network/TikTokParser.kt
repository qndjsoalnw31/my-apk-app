package com.example.network

import com.example.data.model.NoteDetails
import com.example.data.model.VideoSource
import com.example.security.SecurityGuard
import com.example.security.SecurityLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class TikTokParser(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {

    companion object {
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Mobile Safari/537.36"

        fun isTikTokUrl(url: String?): Boolean {
            if (url.isNullOrBlank()) return false
            return try {
                val uri = URI(url.trim())
                var host = uri.host?.lowercase() ?: return false
                if (host.startsWith("www.")) {
                    host = host.removePrefix("www.")
                }
                val allowed = listOf(
                    "tiktok.com",
                    "vt.tiktok.com",
                    "vm.tiktok.com",
                    "m.tiktok.com",
                    "v16-webapp-prime.tiktok.com"
                )
                allowed.any { host == it || host.endsWith(".$it") }
            } catch (_: Exception) {
                false
            }
        }
    }

    /**
     * Resolves short URLs (e.g. vt.tiktok.com, vm.tiktok.com) to the canonical target URL.
     */
    suspend fun resolveRedirectUrl(rawUrl: String): String = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(rawUrl)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "*/*")
                .header("Accept-Language", "ar,en;q=0.9")
                .build()

            client.newCall(request).execute().use { response ->
                val finalUrl = response.request.url.toString()
                if (isTikTokUrl(finalUrl)) {
                    finalUrl
                } else {
                    rawUrl
                }
            }
        } catch (e: Exception) {
            SecurityLogger.w("Could not resolve TikTok short URL: ${e.message}")
            rawUrl
        }
    }

    /**
     * Resolves TikTok media with dual-engine fallback (TikWM + SSSTik + OEmbed metadata).
     */
    suspend fun resolveTikTok(inputUrl: String): NoteDetails = withContext(Dispatchers.IO) {
        val sanitized = SecurityGuard.validateAndSanitizeUrl(inputUrl).getOrThrow()
        val canonicalUrl = resolveRedirectUrl(sanitized)

        val cleanSanitized = cleanTikTokUrl(sanitized)
        val cleanCanonical = cleanTikTokUrl(canonicalUrl)

        // Try clean canonical first, then original clean, then raw
        val candidateUrls = listOf(cleanCanonical, cleanSanitized, sanitized).distinct()

        var lastErrorMsg: String? = null
        for (candidate in candidateUrls) {
            try {
                val res = fetchFromTikWm(candidate)
                if (res != null && (res.videoSources.isNotEmpty() || res.imageUrls.isNotEmpty())) {
                    return@withContext res
                }
            } catch (e: Exception) {
                lastErrorMsg = e.message
                SecurityLogger.w("TikWM engine attempt failed for $candidate: ${e.message}")
            }
        }

        // Engine 2: SSSTik fallback
        for (candidate in candidateUrls) {
            try {
                val sssResult = fetchFromSssTik(candidate)
                if (sssResult != null && (sssResult.videoSources.isNotEmpty() || sssResult.imageUrls.isNotEmpty())) {
                    return@withContext sssResult
                }
            } catch (e: Exception) {
                lastErrorMsg = e.message
                SecurityLogger.w("SSSTik engine failed for $candidate: ${e.message}")
            }
        }

        val finalError = if (lastErrorMsg != null && (lastErrorMsg.contains("خاص") || lastErrorMsg.contains("محذوف") || lastErrorMsg.contains("private"))) {
            lastErrorMsg
        } else {
            "تعذر استخراج الوسائط من الرابط. يرجى التأكد من أن المنشور عام وصالح والمحاولة مجدداً."
        }
        throw IllegalStateException(finalError)
    }

    private fun cleanTikTokUrl(url: String): String {
        return try {
            val uri = URI(url.trim())
            val host = uri.host ?: return url
            val path = uri.path ?: return url
            "${uri.scheme ?: "https"}://$host$path"
        } catch (_: Exception) {
            url
        }
    }

    /**
     * Engine 1: TikWM Extractor with POST and GET mirrors
     */
    private suspend fun fetchFromTikWm(targetUrl: String): NoteDetails? = withContext(Dispatchers.IO) {
        val mirrors = listOf(
            "https://www.tikwm.com/api/",
            "https://tikwm.com/api/"
        )

        for (apiUrl in mirrors) {
            // Attempt 1: POST request
            val postBody = FormBody.Builder()
                .add("url", targetUrl)
                .add("hd", "1")
                .build()

            val postReq = Request.Builder()
                .url(apiUrl)
                .post(postBody)
                .header("User-Agent", USER_AGENT)
                .header("Referer", "https://www.tikwm.com/")
                .header("Accept", "application/json, text/javascript, */*; q=0.01")
                .build()

            try {
                client.newCall(postReq).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        if (body.contains("\"code\":0") || body.contains("\"code\": 0")) {
                            val root = JSONObject(body)
                            val dataObj = root.optJSONObject("data")
                            if (dataObj != null) {
                                return@withContext parseTikWmData(dataObj, targetUrl)
                            }
                        } else if (body.contains("1 request/second") || body.contains("Limit")) {
                            // Hit free rate limit, pause briefly and retry once
                            delay(1200)
                            client.newCall(postReq).execute().use { retryResponse ->
                                if (retryResponse.isSuccessful) {
                                    val retryBody = retryResponse.body?.string() ?: ""
                                    if (retryBody.contains("\"code\":0") || retryBody.contains("\"code\": 0")) {
                                        val root = JSONObject(retryBody)
                                        val dataObj = root.optJSONObject("data")
                                        if (dataObj != null) {
                                            return@withContext parseTikWmData(dataObj, targetUrl)
                                        }
                                    }
                                }
                            }
                        } else {
                            try {
                                val root = JSONObject(body)
                                val msg = root.optString("msg", "")
                                if (msg.contains("private", ignoreCase = true) || 
                                    msg.contains("not exist", ignoreCase = true) || 
                                    msg.contains("deleted", ignoreCase = true) ||
                                    msg.contains("removed", ignoreCase = true)) {
                                    throw IllegalStateException("المنشور خاص أو تم حذفه أو يتعذر الوصول إليه. يرجى التأكد من الرابط.")
                                }
                            } catch (e: IllegalStateException) {
                                throw e
                            } catch (_: Exception) {}
                        }
                    }
                }
            } catch (e: Exception) {
                SecurityLogger.w("TikWM POST mirror $apiUrl error: ${e.message}")
            }

            // Attempt 2: GET request
            try {
                val getUrl = "$apiUrl?url=${URLEncoder.encode(targetUrl, "UTF-8")}&hd=1"
                val getReq = Request.Builder()
                    .url(getUrl)
                    .get()
                    .header("User-Agent", USER_AGENT)
                    .header("Referer", "https://www.tikwm.com/")
                    .header("Accept", "application/json, text/javascript, */*; q=0.01")
                    .build()

                client.newCall(getReq).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        if (body.contains("\"code\":0") || body.contains("\"code\": 0")) {
                            val root = JSONObject(body)
                            val dataObj = root.optJSONObject("data")
                            if (dataObj != null) {
                                return@withContext parseTikWmData(dataObj, targetUrl)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                SecurityLogger.w("TikWM GET mirror $apiUrl error: ${e.message}")
            }
        }
        null
    }

    internal fun parseTikWmData(data: JSONObject, originalUrl: String): NoteDetails {
        val id = data.optString("id", UUID.randomUUID().toString().take(10))
        val rawTitle = data.optString("title").ifBlank {
            data.optString("desc").ifBlank { "TikTok Video" }
        }
        val title = SecurityGuard.sanitizeText(rawTitle, maxLength = 80)
        val authorName = data.optJSONObject("author")?.optString("unique_id")
            ?: data.optJSONObject("author")?.optString("nickname")
            ?: "TikTok"
        val author = SecurityGuard.sanitizeText("@$authorName", maxLength = 50)
        val coverUrl = data.optString("cover").ifBlank { null }
        val duration = data.optDouble("duration", 0.0)

        var hdUrl = data.optString("hdplay")
        var playUrl = data.optString("play")
        val wmUrl = data.optString("wmplay")
        var musicUrl = data.optString("music")

        fun normalizeUrl(u: String): String {
            if (u.startsWith("//")) return "https:$u"
            if (u.startsWith("/")) return "https://www.tikwm.com$u"
            return u
        }

        if (hdUrl.isNotBlank()) hdUrl = normalizeUrl(hdUrl)
        if (playUrl.isNotBlank()) playUrl = normalizeUrl(playUrl)
        if (musicUrl.isNotBlank()) musicUrl = normalizeUrl(musicUrl)

        val sources = mutableListOf<VideoSource>()

        // 1. HD Watermark-free stream
        if (hdUrl.isNotBlank()) {
            sources.add(
                VideoSource(
                    type = "mp4",
                    quality = "1080p HD بدون علامة مائية",
                    resolution = "HD",
                    url = hdUrl,
                    mimeType = "video/mp4",
                    isHls = false
                )
            )
        }

        // 2. Standard Watermark-free stream
        if (playUrl.isNotBlank() && playUrl != hdUrl) {
            sources.add(
                VideoSource(
                    type = "mp4",
                    quality = "720p بدون علامة مائية",
                    resolution = "SD",
                    url = playUrl,
                    mimeType = "video/mp4",
                    isHls = false
                )
            )
        } else if (sources.isEmpty() && wmUrl.isNotBlank()) {
            val normalWm = normalizeUrl(wmUrl)
            sources.add(
                VideoSource(
                    type = "mp4",
                    quality = "فيديو قياسي",
                    resolution = "SD",
                    url = normalWm,
                    mimeType = "video/mp4",
                    isHls = false
                )
            )
        }

        // 3. Audio stream
        if (musicUrl.isNotBlank()) {
            sources.add(
                VideoSource(
                    type = "audio",
                    quality = "صوت عالي الجودة MP3",
                    url = musicUrl,
                    mimeType = "audio/mpeg",
                    isHls = false
                )
            )
        }

        // 4. Photo Mode / Image Carousel extraction
        val imagesArray = data.optJSONArray("images")
        val imageUrls = mutableListOf<String>()
        if (imagesArray != null) {
            for (i in 0 until imagesArray.length()) {
                val img = imagesArray.optString(i)
                if (img.isNotBlank()) {
                    imageUrls.add(normalizeUrl(img))
                }
            }
        }

        val isPhotoPost = imageUrls.isNotEmpty()
        val finalSources = if (isPhotoPost) {
            // Keep only audio source if background music exists; never convert photo slides into video
            sources.filter { it.type == "audio" }
        } else {
            sources
        }

        val contentType = when {
            imageUrls.size > 1 -> com.example.data.model.ContentType.IMAGE_CAROUSEL
            imageUrls.size == 1 -> com.example.data.model.ContentType.IMAGE
            finalSources.any { it.type == "mp4" } -> com.example.data.model.ContentType.VIDEO
            else -> com.example.data.model.ContentType.UNSUPPORTED
        }

        val displayImage = imageUrls.firstOrNull() ?: coverUrl

        return NoteDetails(
            noteId = "tiktok_$id",
            title = title,
            description = SecurityGuard.sanitizeText(data.optString("title"), maxLength = 250),
            author = author,
            imageUrl = displayImage,
            durationSeconds = if (duration > 0) duration else null,
            videoSources = finalSources,
            contentType = contentType,
            imageUrls = imageUrls
        )
    }

    /**
     * Engine 2: SSSTik Extractor
     */
    private suspend fun fetchFromSssTik(targetUrl: String): NoteDetails? = withContext(Dispatchers.IO) {
        val formBody = FormBody.Builder()
            .add("id", targetUrl)
            .add("locale", "en")
            .add("tt", "d1JucXQ_")
            .build()

        val request = Request.Builder()
            .url("https://ssstik.io/abc?url=dl")
            .post(formBody)
            .header("User-Agent", USER_AGENT)
            .header("HX-Request", "true")
            .header("HX-Current-URL", "https://ssstik.io/en")
            .header("Accept", "*/*")
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val html = response.body?.string() ?: return@withContext null

                // Extract download URLs from response HTML
                val linkMatcher = Pattern.compile("href=\"(https://[^\"]+)\"").matcher(html)
                val foundLinks = mutableListOf<String>()
                while (linkMatcher.find()) {
                    val link = linkMatcher.group(1) ?: continue
                    if (link.contains("tikcdn.io") || link.contains("tiktok") || link.contains("/ssstik/")) {
                        foundLinks.add(link)
                    }
                }

                if (foundLinks.isEmpty()) return@withContext null

                // Extract title
                val titleMatcher = Pattern.compile("class=\"maintext\"[^>]*>([^<]+)<").matcher(html)
                val rawTitle = if (titleMatcher.find()) titleMatcher.group(1)?.trim() else null
                val title = SecurityGuard.sanitizeText(rawTitle ?: "TikTok Video", maxLength = 80)

                // Extract avatar / thumbnail
                val thumbMatcher = Pattern.compile("src=\"(https://[^\"]+)\"").matcher(html)
                val thumbUrl = if (thumbMatcher.find()) thumbMatcher.group(1) else null

                val sources = mutableListOf<VideoSource>()
                // Video source (first link)
                val videoUrl = foundLinks.firstOrNull { !it.contains("/m/") } ?: foundLinks.first()
                sources.add(
                    VideoSource(
                        type = "mp4",
                        quality = "1080p HD بدون علامة مائية",
                        resolution = "HD",
                        url = videoUrl,
                        mimeType = "video/mp4",
                        isHls = false
                    )
                )

                // Audio source (link with /m/)
                val audioUrl = foundLinks.firstOrNull { it.contains("/m/") }
                if (audioUrl != null) {
                    sources.add(
                        VideoSource(
                            type = "audio",
                            quality = "صوت عالي الجودة MP3",
                            url = audioUrl,
                            mimeType = "audio/mpeg",
                            isHls = false
                        )
                    )
                }

                val imgSlideMatcher = Pattern.compile("<img[^>]+src=\"(https://[^\"]+)\"").matcher(html)
                val slideImages = mutableListOf<String>()
                while (imgSlideMatcher.find()) {
                    val src = imgSlideMatcher.group(1) ?: continue
                    if ((src.contains("tiktokcdn") || src.contains("tikcdn")) && src != thumbUrl) {
                        slideImages.add(src)
                    }
                }

                val isPhotoPost = slideImages.isNotEmpty()
                val finalSources = if (isPhotoPost) {
                    sources.filter { it.type == "audio" }
                } else {
                    sources
                }

                val contentType = when {
                    slideImages.size > 1 -> com.example.data.model.ContentType.IMAGE_CAROUSEL
                    slideImages.size == 1 -> com.example.data.model.ContentType.IMAGE
                    finalSources.any { it.type == "mp4" } -> com.example.data.model.ContentType.VIDEO
                    else -> com.example.data.model.ContentType.UNSUPPORTED
                }

                return@withContext NoteDetails(
                    noteId = "tiktok_${UUID.randomUUID().toString().take(10)}",
                    title = title,
                    description = title,
                    author = "TikTok",
                    imageUrl = slideImages.firstOrNull() ?: thumbUrl,
                    durationSeconds = null,
                    videoSources = finalSources,
                    contentType = contentType,
                    imageUrls = slideImages
                )
            }
        } catch (e: Exception) {
            SecurityLogger.w("SSSTik execution failed: ${e.message}")
            null
        }
    }
}
