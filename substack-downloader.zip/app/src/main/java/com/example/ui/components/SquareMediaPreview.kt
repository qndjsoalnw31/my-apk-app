package com.example.ui.components

import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImagePainter
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import com.example.security.SecurityLogger
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.SubstackBorder
import kotlinx.coroutines.delay
import java.util.Locale

/**
 * 1:1 Square Video Preview Player.
 * - Displays in a strict 1:1 aspect ratio square container.
 * - Uses ContentScale.Fit equivalent logic: maintains original video aspect ratio inside.
 * - Portrait (vertical) videos fit full height with pillarbox on sides.
 * - Landscape (horizontal) videos fit full width with letterbox on top/bottom.
 * - Shows cover thumbnail until video starts, eliminating black screens.
 * - Controls: Play/pause, seek timeline, duration, mute/unmute.
 * - Clean lifecycle management with no resource leaks.
 */
@Composable
fun SquareVideoPlayer(
    videoUrl: String,
    coverUrl: String? = null,
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .aspectRatio(1f)
) {
    val context = LocalContext.current
    var isPrepared by remember(videoUrl) { mutableStateOf(false) }
    var isPlaying by remember(videoUrl) { mutableStateOf(false) }
    var isBuffering by remember(videoUrl) { mutableStateOf(false) }
    var hasStartedPlaying by remember(videoUrl) { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(false) }
    var isControlsVisible by remember { mutableStateOf(true) }
    var videoWidth by remember(videoUrl) { mutableIntStateOf(0) }
    var videoHeight by remember(videoUrl) { mutableIntStateOf(0) }
    var currentPosition by remember(videoUrl) { mutableIntStateOf(0) }
    var duration by remember(videoUrl) { mutableIntStateOf(0) }
    var errorMessage by remember(videoUrl) { mutableStateOf<String?>(null) }

    val mediaPlayer = remember(videoUrl) { MediaPlayer() }
    var surfaceRef by remember(videoUrl) { mutableStateOf<Surface?>(null) }

    // Position tracking coroutine
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            try {
                if (mediaPlayer.isPlaying) {
                    currentPosition = mediaPlayer.currentPosition
                }
            } catch (_: Exception) {}
            delay(250)
        }
    }

    // Auto-hide controls
    LaunchedEffect(isControlsVisible, isPlaying) {
        if (isControlsVisible && isPlaying) {
            delay(3500)
            isControlsVisible = false
        }
    }

    DisposableEffect(videoUrl) {
        try {
            mediaPlayer.reset()
            mediaPlayer.setDataSource(context, Uri.parse(videoUrl))
            mediaPlayer.setOnVideoSizeChangedListener { _, w, h ->
                if (w > 0 && h > 0) {
                    videoWidth = w
                    videoHeight = h
                }
            }
            mediaPlayer.setOnPreparedListener { mp ->
                isPrepared = true
                isBuffering = false
                duration = mp.duration
                if (mp.videoWidth > 0 && mp.videoHeight > 0) {
                    videoWidth = mp.videoWidth
                    videoHeight = mp.videoHeight
                }
            }
            mediaPlayer.setOnCompletionListener {
                isPlaying = false
                currentPosition = duration
                isControlsVisible = true
            }
            mediaPlayer.setOnErrorListener { _, what, extra ->
                SecurityLogger.w("MediaPlayer error in preview: what=$what, extra=$extra")
                isBuffering = false
                isPlaying = false
                errorMessage = "تعذر تشغيل المعاينة المباشرة"
                true
            }
            isBuffering = true
            mediaPlayer.prepareAsync()
        } catch (e: Exception) {
            SecurityLogger.w("SquareVideoPlayer setup error: ${e.message}")
            isBuffering = false
            errorMessage = e.localizedMessage
        }

        onDispose {
            try {
                if (mediaPlayer.isPlaying) {
                    mediaPlayer.stop()
                }
                mediaPlayer.reset()
                mediaPlayer.release()
            } catch (_: Exception) {}
            surfaceRef?.release()
        }
    }

    val videoAspect = if (videoWidth > 0 && videoHeight > 0) {
        videoWidth.toFloat() / videoHeight.toFloat()
    } else {
        16f / 9f
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black)
            .border(1.dp, SubstackBorder, RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                isControlsVisible = !isControlsVisible
            },
        contentAlignment = Alignment.Center
    ) {
        // Video View: TextureView scaled with ContentScale.Fit logic
        val videoDisplayModifier = if (videoAspect >= 1f) {
            // Horizontal / Landscape: Fill width, pillarbox top & bottom
            Modifier
                .fillMaxWidth()
                .aspectRatio(videoAspect)
        } else {
            // Vertical / Portrait: Fill height, pillarbox left & right
            Modifier
                .fillMaxHeight()
                .aspectRatio(videoAspect)
        }

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx ->
                    TextureView(ctx).apply {
                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                                val s = Surface(st)
                                surfaceRef = s
                                try {
                                    mediaPlayer.setSurface(s)
                                } catch (_: Exception) {}
                            }

                            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

                            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                                try {
                                    mediaPlayer.setSurface(null)
                                } catch (_: Exception) {}
                                surfaceRef?.release()
                                surfaceRef = null
                                return true
                            }

                            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                        }
                    }
                },
                modifier = videoDisplayModifier
            )
        }

        // Thumbnail fallback while loading or before user starts playback
        if (!hasStartedPlaying && !coverUrl.isNullOrBlank()) {
            SubcomposeAsyncImage(
                model = coverUrl,
                contentDescription = "Video Poster",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Buffering indicator
        if (isBuffering) {
            CircularProgressIndicator(
                color = BrandBlue,
                modifier = Modifier.size(36.dp),
                strokeWidth = 3.dp
            )
        }

        // Error banner if any
        if (errorMessage != null && !hasStartedPlaying) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color.Black.copy(alpha = 0.75f),
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = errorMessage ?: "",
                    color = Color.White,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        // Video Overlay Controls
        AnimatedVisibility(
            visible = isControlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
            ) {
                // Top controls: Mute Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            isMuted = !isMuted
                            val vol = if (isMuted) 0f else 1f
                            try {
                                mediaPlayer.setVolume(vol, vol)
                            } catch (_: Exception) {}
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.6f))
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            contentDescription = if (isMuted) "Unmute" else "Mute",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Center: Big Play / Pause Button
                IconButton(
                    onClick = {
                        if (!isPrepared) return@IconButton
                        if (isPlaying) {
                            try {
                                mediaPlayer.pause()
                            } catch (_: Exception) {}
                            isPlaying = false
                        } else {
                            try {
                                if (currentPosition >= duration && duration > 0) {
                                    mediaPlayer.seekTo(0)
                                    currentPosition = 0
                                }
                                mediaPlayer.start()
                                isPlaying = true
                                hasStartedPlaying = true
                            } catch (_: Exception) {}
                        }
                    },
                    modifier = Modifier
                        .size(60.dp)
                        .align(Alignment.Center)
                        .clip(CircleShape)
                        .background(BrandBlue)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Bottom Timeline Row
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Slider(
                        value = currentPosition.toFloat(),
                        onValueChange = { newPos ->
                            currentPosition = newPos.toInt()
                            try {
                                mediaPlayer.seekTo(newPos.toInt())
                            } catch (_: Exception) {}
                        },
                        valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = BrandBlue,
                            activeTrackColor = BrandBlue,
                            inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(20.dp)
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatDurationMs(currentPosition),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Text(
                            text = formatDurationMs(duration),
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}

/**
 * 1:1 Square Image Carousel Preview.
 * - Displays single photo or multi-photo carousels inside a 1:1 square frame.
 * - Uses ContentScale.Fit to preserve original image dimensions and aspect ratio.
 * - Shows index badge "2 / 8" in the top corner.
 * - Offers Next and Previous buttons, plus horizontal swipe navigation.
 * - Clear loading and error states.
 * - Absolutely NO video controls.
 */
@Composable
fun SquareImageCarouselPreview(
    imageUrls: List<String>,
    currentIndex: Int,
    onIndexChanged: (Int) -> Unit,
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .aspectRatio(1f)
) {
    if (imageUrls.isEmpty()) return

    val total = imageUrls.size
    val safeIndex = currentIndex.coerceIn(0, total - 1)
    val currentUrl = imageUrls[safeIndex]
    val layoutDirection = LocalLayoutDirection.current
    val isRtl = layoutDirection == LayoutDirection.Rtl

    var dragAmount by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black)
            .border(1.dp, SubstackBorder, RoundedCornerShape(16.dp))
            .pointerInput(total, safeIndex) {
                if (total > 1) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            val threshold = 40f
                            if (dragAmount < -threshold) {
                                // Swiped towards left
                                val next = if (isRtl) safeIndex - 1 else safeIndex + 1
                                if (next in 0 until total) onIndexChanged(next)
                            } else if (dragAmount > threshold) {
                                // Swiped towards right
                                val prev = if (isRtl) safeIndex + 1 else safeIndex - 1
                                if (prev in 0 until total) onIndexChanged(prev)
                            }
                            dragAmount = 0f
                        },
                        onHorizontalDrag = { _, delta ->
                            dragAmount += delta
                        }
                    )
                }
            },
        contentAlignment = Alignment.Center
    ) {
        // Image content with ContentScale.Fit
        SubcomposeAsyncImage(
            model = currentUrl,
            contentDescription = "Photo ${safeIndex + 1}",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        ) {
            when (painter.state) {
                is AsyncImagePainter.State.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            color = BrandBlue,
                            modifier = Modifier.size(32.dp),
                            strokeWidth = 3.dp
                        )
                    }
                }
                is AsyncImagePainter.State.Error -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.BrokenImage,
                            contentDescription = "Error",
                            tint = Color.LightGray,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "تعذر تحميل الصورة",
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )
                    }
                }
                else -> {
                    SubcomposeAsyncImageContent()
                }
            }
        }

        // Top indicator badge: e.g. "2 / 8"
        if (total > 1) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.Black.copy(alpha = 0.7f),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
            ) {
                Text(
                    text = "${safeIndex + 1} / $total",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        // Navigation Arrows for carousel
        if (total > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Previous button
                IconButton(
                    onClick = {
                        val prev = if (safeIndex > 0) safeIndex - 1 else total - 1
                        onIndexChanged(prev)
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.65f))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Previous Image",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Next button
                IconButton(
                    onClick = {
                        val next = if (safeIndex < total - 1) safeIndex + 1 else 0
                        onIndexChanged(next)
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.65f))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Next Image",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

private fun formatDurationMs(millis: Int): String {
    val sec = millis / 1000
    val m = sec / 60
    val s = sec % 60
    return String.format(Locale.US, "%02d:%02d", m, s)
}
