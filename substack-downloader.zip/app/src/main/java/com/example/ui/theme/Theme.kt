package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SubstackDarkColorScheme = darkColorScheme(
    primary = SubstackOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF381605),
    onPrimaryContainer = SubstackOrangeLight,
    secondary = SubstackOrangeLight,
    onSecondary = Color.Black,
    background = SubstackBackground,
    onBackground = SubstackTextPrimary,
    surface = SubstackPanel,
    onSurface = SubstackTextPrimary,
    surfaceVariant = SubstackPanelVariant,
    onSurfaceVariant = SubstackTextMuted,
    error = SubstackRed,
    onError = Color.White
)

private val SubstackLightColorScheme = lightColorScheme(
    primary = SubstackOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFECE0),
    onPrimaryContainer = Color(0xFF6B2200),
    secondary = Color(0xFFCC5210),
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF64748B)
)

@Composable
fun SubstackDownloaderTheme(
    darkTheme: Boolean = true, // Default to sleek dark mode like Substack Note UI
    dynamicColor: Boolean = false, // Preserve brand orange aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = androidx.compose.ui.platform.LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> SubstackDarkColorScheme
        else -> SubstackLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
