package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import com.example.data.model.DownloadItem
import com.example.ui.components.InAppVideoPlayer
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.SubstackBackground
import com.example.ui.theme.SubstackBorder
import com.example.ui.theme.SubstackOrange
import com.example.ui.theme.SubstackPanel
import com.example.ui.theme.SubstackTextMuted
import com.example.ui.theme.SubstackTextPrimary
import com.example.ui.util.LocalAppStrings
import com.example.ui.util.getAppLayoutDirection
import com.example.ui.util.getAppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: DownloadViewModel) {
    val settings by viewModel.appSettings.collectAsState()
    val strings = getAppStrings(settings.language)
    val layoutDirection = getAppLayoutDirection(settings.language)

    val currentTab by viewModel.currentTab.collectAsState()
    val playingItem by viewModel.playingItem.collectAsState()
    val snackbarMessage by viewModel.snackbarMessage.collectAsState()
    val queueItems by viewModel.activeQueueDownloads.collectAsState()

    val activeCount = queueItems.count {
        it.status == DownloadItem.STATUS_DOWNLOADING ||
        it.status == DownloadItem.STATUS_QUEUED ||
        it.status == DownloadItem.STATUS_RESOLVING
    }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissSnackbar()
        }
    }

    CompositionLocalProvider(
        LocalAppStrings provides strings,
        LocalLayoutDirection provides layoutDirection
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SubstackBackground)
        ) {
            Scaffold(
                containerColor = SubstackBackground,
                bottomBar = {
                    CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr) {
                        NavigationBar(
                            containerColor = SubstackPanel,
                            tonalElevation = 0.dp,
                            modifier = Modifier.border(
                                width = 1.dp,
                                color = SubstackBorder,
                                shape = androidx.compose.ui.graphics.RectangleShape
                            )
                        ) {
                            // Tab 0: Home (Always on the Left)
                            NavigationBarItem(
                                selected = currentTab == 0,
                                onClick = { viewModel.setCurrentTab(0) },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 0) Icons.Filled.Home else Icons.Outlined.Home,
                                        contentDescription = strings.navHome,
                                        modifier = Modifier.size(22.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = strings.navHome,
                                        fontSize = 11.sp,
                                        color = if (currentTab == 0) SubstackOrange else SubstackTextMuted
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = SubstackOrange,
                                    selectedTextColor = SubstackOrange,
                                    indicatorColor = SubstackOrange.copy(alpha = 0.15f),
                                    unselectedIconColor = SubstackTextMuted,
                                    unselectedTextColor = SubstackTextMuted
                                )
                            )

                            // Tab 1: Downloads (Center)
                            NavigationBarItem(
                                selected = currentTab == 1,
                                onClick = { viewModel.setCurrentTab(1) },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (activeCount > 0) {
                                                Badge(
                                                    containerColor = SubstackOrange,
                                                    contentColor = Color.White
                                                ) {
                                                    Text("$activeCount")
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (currentTab == 1) Icons.Filled.Download else Icons.Outlined.Download,
                                            contentDescription = strings.navDownloads,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                },
                                label = {
                                    Text(
                                        text = strings.navDownloads,
                                        fontSize = 11.sp,
                                        color = if (currentTab == 1) SubstackOrange else SubstackTextMuted
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = SubstackOrange,
                                    selectedTextColor = SubstackOrange,
                                    indicatorColor = SubstackOrange.copy(alpha = 0.15f),
                                    unselectedIconColor = SubstackTextMuted,
                                    unselectedTextColor = SubstackTextMuted
                                )
                            )

                            // Tab 2: Settings (Right)
                            NavigationBarItem(
                                selected = currentTab == 2,
                                onClick = { viewModel.setCurrentTab(2) },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 2) Icons.Filled.Settings else Icons.Outlined.Settings,
                                        contentDescription = strings.navSettings,
                                        modifier = Modifier.size(22.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = strings.navSettings,
                                        fontSize = 11.sp,
                                        color = if (currentTab == 2) SubstackOrange else SubstackTextMuted
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = SubstackOrange,
                                    selectedTextColor = SubstackOrange,
                                    indicatorColor = SubstackOrange.copy(alpha = 0.15f),
                                    unselectedIconColor = SubstackTextMuted,
                                    unselectedTextColor = SubstackTextMuted
                                )
                            )
                        }
                    }
                },
                snackbarHost = { SnackbarHost(snackbarHostState) }
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    when (currentTab) {
                        0 -> HomeScreen(viewModel = viewModel)
                        1 -> DownloadsScreen(viewModel = viewModel)
                        2 -> SettingsScreen(viewModel = viewModel)
                    }
                }
            }

            // In-App Media Player Fullscreen Overlay
            AnimatedVisibility(
                visible = playingItem != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                playingItem?.let { item ->
                    InAppVideoPlayer(
                        item = item,
                        onClose = { viewModel.closePlayer() },
                        onExport = { viewModel.exportItemToGallery(item) },
                        onShare = { viewModel.shareItem(item) }
                    )
                }
            }
        }
    }
}
