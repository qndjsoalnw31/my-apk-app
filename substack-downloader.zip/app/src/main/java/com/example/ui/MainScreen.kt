package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.DownloadItemRow
import com.example.ui.components.HeaderStatsCard
import com.example.ui.components.InAppVideoPlayer
import com.example.ui.components.PreviewCard
import com.example.ui.components.UrlInspectorCard
import com.example.ui.theme.SubstackOrange

@Composable
fun MainScreen(viewModel: DownloadViewModel) {
    // Provide Arabic RTL Layout Direction
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {

        val urlInput by viewModel.urlInput.collectAsStateWithLifecycle()
        val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
        val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
        val previewState by viewModel.previewState.collectAsStateWithLifecycle()
        val downloadsList by viewModel.downloadsList.collectAsStateWithLifecycle()
        val activeProgress by viewModel.activeProgress.collectAsStateWithLifecycle()
        val selectedVideo by viewModel.selectedVideoForPlayer.collectAsStateWithLifecycle()
        val snackbarMsg by viewModel.snackbarMessage.collectAsStateWithLifecycle()

        val snackbarHostState = remember { SnackbarHostState() }

        LaunchedEffect(snackbarMsg) {
            snackbarMsg?.let { msg ->
                snackbarHostState.showSnackbar(msg)
                viewModel.clearSnackbar()
            }
        }

        val activeCount = downloadsList.count {
            it.status == com.example.data.model.DownloadItem.STATUS_DOWNLOADING ||
            it.status == com.example.data.model.DownloadItem.STATUS_RESOLVING
        }

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    HeaderStatsCard(
                        downloads = downloadsList,
                        activeCount = activeCount
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    TabRow(
                        selectedTabIndex = activeTab,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = SubstackOrange,
                        indicator = { tabPositions ->
                            if (activeTab < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                                    color = SubstackOrange
                                )
                            }
                        },
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                    ) {
                        Tab(
                            selected = activeTab == 0,
                            onClick = { viewModel.activeTab.value = 0 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "الفحص والتنزيل",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        )

                        Tab(
                            selected = activeTab == 1,
                            onClick = { viewModel.activeTab.value = 1 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "سجل التنزيلات (${downloadsList.size})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (activeTab == 0) {
                        // Inspector & Download Tab
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                UrlInspectorCard(
                                    urlInput = urlInput,
                                    onUrlChanged = viewModel::onUrlInputChanged,
                                    onInspectRequested = viewModel::inspectNoteUrl,
                                    onDirectDownloadRequested = viewModel::startDirectDownload,
                                    isLoading = previewState is PreviewUiState.Loading
                                )
                            }

                            item {
                                when (val state = previewState) {
                                    is PreviewUiState.Loading -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 24.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                CircularProgressIndicator(color = SubstackOrange)
                                                Spacer(modifier = Modifier.height(12.dp))
                                                Text(
                                                    text = "جاري قراءة Note واستخراج روابط الفيديو...",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }

                                    is PreviewUiState.Success -> {
                                        PreviewCard(
                                            noteDetails = state.noteDetails,
                                            onStartDownload = { formatType, qualityLabel ->
                                                viewModel.startDownloadFromPreview(formatType, qualityLabel)
                                            }
                                        )
                                    }

                                    is PreviewUiState.Error -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(16.dp))
                                                .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f))
                                                .padding(16.dp)
                                        ) {
                                            Text(
                                                text = state.message,
                                                color = MaterialTheme.colorScheme.onErrorContainer,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                        }
                                    }

                                    is PreviewUiState.Idle -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 16.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                modifier = Modifier.padding(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Movie,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                                    modifier = Modifier.size(54.dp)
                                                )
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Text(
                                                    text = "ضع رابط الملاحظة فوق واضغط على \"فحص المعاينة\" لرؤية تفاصيل الفيديو وصورة العرض قبل التحميل.",
                                                    textAlign = TextAlign.Center,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // Downloads History Tab
                        Column {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { viewModel.searchQuery.value = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = {
                                    Text(
                                        text = "البحث في السجل والتنزيلات...",
                                        fontSize = 13.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = null,
                                        tint = SubstackOrange
                                    )
                                },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "مسح البحث"
                                            )
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = SubstackOrange,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            if (downloadsList.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.History,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                                            modifier = Modifier.size(64.dp)
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = if (searchQuery.isNotBlank()) "لا توجد نتائج تطابق بحثك." else "لا توجد تنزيلات في السجل حتى الآن.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    items(
                                        items = downloadsList,
                                        key = { it.id }
                                    ) { downloadItem ->
                                        DownloadItemRow(
                                            item = downloadItem,
                                            progress = activeProgress[downloadItem.id],
                                            onPause = { viewModel.pauseDownload(downloadItem.id) },
                                            onResume = { viewModel.resumeDownload(downloadItem.id) },
                                            onCancel = { viewModel.cancelDownload(downloadItem.id) },
                                            onDelete = { viewModel.deleteDownload(downloadItem.id) },
                                            onPlay = { viewModel.playVideo(downloadItem) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // In-App Video Player Dialog
                selectedVideo?.let { item ->
                    InAppVideoPlayer(
                        downloadItem = item,
                        onDismiss = viewModel::closeVideoPlayer
                    )
                }
            }
        }
    }
}
