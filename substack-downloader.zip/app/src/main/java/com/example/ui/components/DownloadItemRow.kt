package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadProgress
import com.example.ui.theme.SubstackGreen
import com.example.ui.theme.SubstackOrange
import com.example.ui.theme.SubstackRed
import com.example.util.MediaExportHelper

@Composable
fun DownloadItemRow(
    item: DownloadItem,
    progress: DownloadProgress?,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    onPlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isDownloading = item.status == DownloadItem.STATUS_DOWNLOADING || item.status == DownloadItem.STATUS_RESOLVING
    val isPaused = item.status == DownloadItem.STATUS_PAUSED
    val isDone = item.status == DownloadItem.STATUS_DONE
    val isError = item.status == DownloadItem.STATUS_ERROR
    val isAudio = item.formatType == DownloadItem.FORMAT_AUDIO

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = when {
                    isDownloading -> SubstackOrange.copy(alpha = 0.4f)
                    isDone -> SubstackGreen.copy(alpha = 0.3f)
                    isError -> SubstackRed.copy(alpha = 0.3f)
                    else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                },
                shape = RoundedCornerShape(16.dp)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isDone -> SubstackGreen.copy(alpha = 0.15f)
                                    isError -> SubstackRed.copy(alpha = 0.15f)
                                    else -> SubstackOrange.copy(alpha = 0.15f)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when {
                                isDone && isAudio -> Icons.Default.MusicNote
                                isDone -> Icons.Default.PlayArrow
                                isError -> Icons.Default.Error
                                else -> Icons.Default.Refresh
                            },
                            contentDescription = null,
                            tint = when {
                                isDone -> SubstackGreen
                                isError -> SubstackRed
                                else -> SubstackOrange
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            // Format / Quality Tag
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SubstackOrange.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isAudio) "صوت MP3" else item.qualityLabel,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SubstackOrange
                                    )
                                )
                            }
                        }
                        Text(
                            text = item.filename,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isDone) {
                        IconButton(
                            onClick = {
                                MediaExportHelper.shareFile(
                                    context = context,
                                    filePath = item.filePath,
                                    isAudio = isAudio,
                                    title = item.title
                                )
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "مشاركة",
                                tint = SubstackOrange
                            )
                        }
                    }

                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (isDownloading || isPaused) {
                Spacer(modifier = Modifier.height(10.dp))

                val pct = progress?.percentage ?: 0f
                LinearProgressIndicator(
                    progress = { (pct / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = SubstackOrange,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val downloadedText = formatBytes(progress?.downloadedBytes ?: item.downloadedSize)
                    val totalText = formatBytes(progress?.totalBytes ?: item.size)
                    val speedText = if (progress != null && progress.bytesPerSec > 0) {
                        "${formatBytes(progress.bytesPerSec.toLong())}/ث"
                    } else "0 KB/ث"

                    val etaText = if (progress != null && progress.etaSeconds > 0) {
                        "${progress.etaSeconds} ث"
                    } else "--"

                    Text(
                        text = if (isPaused) "متوقف مؤقتاً" else "$downloadedText / $totalText • $speedText (متبقي: $etaText)",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row {
                        if (isDownloading) {
                            IconButton(onClick = onPause, modifier = Modifier.size(28.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Pause,
                                    contentDescription = "إيقاف مؤقت",
                                    tint = SubstackOrange
                                )
                            }
                        } else if (isPaused) {
                            IconButton(onClick = onResume, modifier = Modifier.size(28.dp)) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "استئناف",
                                    tint = SubstackGreen
                                )
                            }
                        }

                        IconButton(onClick = onCancel, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إلغاء",
                                tint = SubstackRed
                            )
                        }
                    }
                }
            } else if (isDone) {
                Spacer(modifier = Modifier.height(10.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الحجم: ${formatBytes(item.size)} • تم الحفظ بنجاح",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = SubstackGreen
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Action Buttons for Done Item: Play, Export/Save to Gallery, Share
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Play In-App
                    OutlinedButton(
                        onClick = onPlay,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (isAudio) Icons.Default.MusicNote else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = SubstackOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "تشغيل",
                            fontSize = 12.sp,
                            color = SubstackOrange,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Export / Save to Phone Storage (Gallery / MediaStore)
                    FilledTonalButton(
                        onClick = {
                            MediaExportHelper.exportToPublicGallery(
                                context = context,
                                filePath = item.filePath,
                                isAudio = isAudio,
                                fileName = item.filename
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SubstackGreen.copy(alpha = 0.15f),
                            contentColor = SubstackGreen
                        ),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "تصدير للهاتف",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Share
                    FilledTonalButton(
                        onClick = {
                            MediaExportHelper.shareFile(
                                context = context,
                                filePath = item.filePath,
                                isAudio = isAudio,
                                title = item.title
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SubstackOrange.copy(alpha = 0.15f),
                            contentColor = SubstackOrange
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "مشاركة",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else if (isError) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = item.errorMessage ?: "حدث خطأ أثناء التحميل.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SubstackRed,
                    fontSize = 11.sp
                )
            }
        }
    }
}


