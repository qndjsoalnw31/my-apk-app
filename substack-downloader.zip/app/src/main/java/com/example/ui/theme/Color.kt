package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

// Identity & Accent Colors
val SubstackOrange = Color(0xFFFF6719)
val SubstackOrangeLight = Color(0xFFFF8542)
val SubstackOrangeDark = Color(0xFFD94D05)

val SubstackGreen = Color(0xFF22C55E)
val SubstackRed = Color(0xFFEF4444)
val SubstackBlue = Color(0xFF3B82F6)

data class AppColors(
    val background: Color,
    val panel: Color,
    val panelVariant: Color,
    val input: Color,
    val border: Color,
    val textPrimary: Color,
    val textMuted: Color,
    val textSubtle: Color,
    val isDark: Boolean
)

val DarkAppColors = AppColors(
    background = Color(0xFF0D0F12),
    panel = Color(0xFF15181D),
    panelVariant = Color(0xFF1C2027),
    input = Color(0xFF15181D),
    border = Color(0xFF232832),
    textPrimary = Color(0xFFFFFFFF),
    textMuted = Color(0xFF9E9EA7),
    textSubtle = Color(0xFF5C6470),
    isDark = true
)

val LightAppColors = AppColors(
    background = Color(0xFFF8FAFC),
    panel = Color(0xFFFFFFFF),
    panelVariant = Color(0xFFF1F5F9),
    input = Color(0xFFFFFFFF),
    border = Color(0xFFE2E8F0),
    textPrimary = Color(0xFF0F172A),
    textMuted = Color(0xFF475569),
    textSubtle = Color(0xFF94A3B8),
    isDark = false
)

val LocalAppColors = compositionLocalOf { DarkAppColors }

val SubstackBackground: Color
    @Composable
    get() = LocalAppColors.current.background

val SubstackPanel: Color
    @Composable
    get() = LocalAppColors.current.panel

val SubstackPanelVariant: Color
    @Composable
    get() = LocalAppColors.current.panelVariant

val SubstackInput: Color
    @Composable
    get() = LocalAppColors.current.input

val SubstackBorder: Color
    @Composable
    get() = LocalAppColors.current.border

val SubstackTextPrimary: Color
    @Composable
    get() = LocalAppColors.current.textPrimary

val SubstackTextMuted: Color
    @Composable
    get() = LocalAppColors.current.textMuted

val SubstackTextSubtle: Color
    @Composable
    get() = LocalAppColors.current.textSubtle


