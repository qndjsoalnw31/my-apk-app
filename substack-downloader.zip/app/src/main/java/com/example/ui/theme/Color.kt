package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SubstackOrange = Color(0xFFFF6719)
val SubstackOrangeLight = Color(0xFFFF914D)
val SubstackBackground = Color(0xFF070A0F)
val SubstackPanel = Color(0xFF101722)
val SubstackPanelVariant = Color(0xFF151E2B)
val SubstackInput = Color(0xFF0A1018)
val SubstackTextPrimary = Color(0xFFF8FAFC)
val SubstackTextMuted = Color(0xFF94A3B8)
val SubstackGreen = Color(0xFF22C55E)
val SubstackRed = Color(0xFFEF4444)
val SubstackBlue = Color(0xFF3B82F6)
