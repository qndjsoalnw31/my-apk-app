package com.example.ui.util

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

interface Strings {
    // Navigation
    val navHome: String
    val navDownloads: String
    val navSettings: String

    // Home Screen
    val appTitle: String
    val heroTitle: String
    val heroSubtitle: String
    val platformSubstack: String
    val platformTikTok: String
    val urlPlaceholder: String
    val btnPaste: String
    val btnStartDownload: String
    val featureHighQuality: String
    val featureFast: String
    val featureFree: String
    val extractingTikTok: String
    val extractingSubstack: String
    val couldNotFetchMedia: String
    val tipPasteHint: String
    val linkDetectedClipboard: String
    val btnUse: String

    // Platform Chooser Sheet
    val platformChooserTitle: String
    val substackPlatformDesc: String
    val tiktokPlatformDesc: String

    // Home Media Inspection
    val downloadCurrentImageBtn: (Int) -> String
    val downloadSinglePhotoBtn: String
    val downloadAllImagesBtn: (Int) -> String
    val downloadAudioAttached: String
    val availableQualityLabel: String
    val bestQualityAvailable: String
    val downloadVideoBtn: String
    val downloadAudioBtn: String

    // Downloads Screen
    val downloadsTitle: String
    val tabCompleted: String
    val tabActive: String
    val noActiveDownloads: String
    val noActiveSubtitle: String
    val btnGoToHome: String
    val fileSizeLabel: String
    val etaLabel: String
    val qualityLabel: String
    val btnCancelDownload: String
    val searchPlaceholder: String
    val filterAll: String
    val filterSubstack: String
    val filterTikTok: String
    val noCompletedDownloads: String
    val noMatchingDownloads: String

    // Details Sheet
    val sheetDetailsTitle: String
    val btnOpenFile: String
    val btnShareFile: String
    val btnRedownload: String
    val btnDeleteFile: String
    val detailsDomainLabel: String
    val detailsDateLabel: String
    val detailsFormatLabel: String

    // In-App Media Player
    val playerFileNotFound: String
    val playerErrorPlaying: String
    val btnClose: String
    val playbackSpeedLabel: String
    val menuShare: String
    val menuExportGallery: String
    val menuPlay: String
    val menuDelete: String

    // Settings Screen
    val settingsTitle: String
    val sectionAppearance: String
    val themeLight: String
    val themeDark: String
    val themeSystem: String
    val sectionGeneral: String
    val folderLabel: String
    val languageLabel: String
    val currentLanguageName: String
    val notificationsLabel: String
    val autoClearLabel: String
    val autoClearSubtitle: String
    val aboutLabel: String
    val versionLabel: String
    val languageDialogTitle: String
    val langArabic: String
    val langEnglish: String
    val btnCancel: String

    // About App Screen
    val aboutAppTitle: String
    val aboutAppDescription: String
    val developerLabel: String
    val developerValue: String
    val locationLabel: String
    val locationValue: String
    val emailLabel: String
    val emailValue: String
    val privacyPolicyLabel: String
    val privacyPolicyPoints: List<String>
    val btnGotIt: String
}

class EnglishStrings : Strings {
    // Navigation
    override val navHome = "Home"
    override val navDownloads = "Downloads"
    override val navSettings = "Settings"

    // Home Screen
    override val appTitle = "Substack Downloader"
    override val heroTitle = "Download Content Easily"
    override val heroSubtitle = "From Substack & TikTok in high quality"
    override val platformSubstack = "Substack"
    override val platformTikTok = "TikTok"
    override val urlPlaceholder = "Enter article or video link here..."
    override val btnPaste = "Paste"
    override val btnStartDownload = "Start Download"
    override val featureHighQuality = "High Quality"
    override val featureFast = "Fast"
    override val featureFree = "Free"
    override val extractingTikTok = "Extracting TikTok content..."
    override val extractingSubstack = "Extracting Substack media..."
    override val couldNotFetchMedia = "Could not extract media"
    override val tipPasteHint = "You can paste links from Substack and TikTok here..."
    override val linkDetectedClipboard = "Link detected in clipboard"
    override val btnUse = "Use"

    // Platform Chooser Sheet
    override val platformChooserTitle = "Choose Platform"
    override val substackPlatformDesc = "Articles, Podcasts, Videos"
    override val tiktokPlatformDesc = "Short & Long Videos"

    // Home Media Inspection
    override val downloadCurrentImageBtn = { idx: Int -> "Download Current Photo ($idx)" }
    override val downloadSinglePhotoBtn = "Download Photo"
    override val downloadAllImagesBtn = { total: Int -> "Download All Photos ($total)" }
    override val downloadAudioAttached = "Download Attached Audio (MP3)"
    override val availableQualityLabel = "Available Quality:"
    override val bestQualityAvailable = "Best Quality Available"
    override val downloadVideoBtn = "Download Video"
    override val downloadAudioBtn = "Download Audio (MP3)"

    // Downloads Screen
    override val downloadsTitle = "Downloads"
    override val tabCompleted = "Completed"
    override val tabActive = "Downloading"
    override val noActiveDownloads = "No active downloads currently"
    override val noActiveSubtitle = "Paste a Substack or TikTok link to start downloading"
    override val btnGoToHome = "Go to Home"
    override val fileSizeLabel = "File Size"
    override val etaLabel = "Estimated Time"
    override val qualityLabel = "Quality"
    override val btnCancelDownload = "Cancel Download"
    override val searchPlaceholder = "Search downloads..."
    override val filterAll = "All"
    override val filterSubstack = "Substack"
    override val filterTikTok = "TikTok"
    override val noCompletedDownloads = "Download history is empty"
    override val noMatchingDownloads = "No matching results found"

    // Details Sheet
    override val sheetDetailsTitle = "Download Details"
    override val btnOpenFile = "Open File"
    override val btnShareFile = "Share"
    override val btnRedownload = "Re-download"
    override val btnDeleteFile = "Delete File"
    override val detailsDomainLabel = "Source Domain"
    override val detailsDateLabel = "Download Date"
    override val detailsFormatLabel = "File Type"

    // In-App Media Player
    override val playerFileNotFound = "Media file not found on storage"
    override val playerErrorPlaying = "Error playing media"
    override val btnClose = "Close"
    override val playbackSpeedLabel = "Speed"
    override val menuShare = "Share"
    override val menuExportGallery = "Export to Gallery"
    override val menuPlay = "Play"
    override val menuDelete = "Delete"

    // Settings Screen
    override val settingsTitle = "Settings"
    override val sectionAppearance = "Appearance"
    override val themeLight = "Light Mode"
    override val themeDark = "Dark Mode"
    override val themeSystem = "System"
    override val sectionGeneral = "General"
    override val folderLabel = "Download Folder"
    override val languageLabel = "Language"
    override val currentLanguageName = "English"
    override val notificationsLabel = "Notifications"
    override val autoClearLabel = "Auto Clear"
    override val autoClearSubtitle = "When download completes"
    override val aboutLabel = "About App"
    override val versionLabel = "Version 1.2"
    override val languageDialogTitle = "App Language"
    override val langArabic = "العربية"
    override val langEnglish = "English"
    override val btnCancel = "Cancel"

    // About App Screen
    override val aboutAppTitle = "About App"
    override val aboutAppDescription = "A simple and fast app to download media and articles from Substack and TikTok in high quality."
    override val developerLabel = "Developer"
    override val developerValue = "@TSSTTl"
    override val locationLabel = "Location"
    override val locationValue = "Iraq"
    override val emailLabel = "Email"
    override val emailValue = "ayrwynsmyth39@gmail.com"
    override val privacyPolicyLabel = "Privacy Policy"
    override val privacyPolicyPoints = listOf(
        "• All downloads are processed directly on your device without sending media to external servers.",
        "• No personal data or user tracking logs are collected.",
        "• The app respects intellectual property rights and securely saves media locally."
    )
    override val btnGotIt = "OK"
}

class ArabicStrings : Strings {
    // Navigation
    override val navHome = "الرئيسية"
    override val navDownloads = "التنزيلات"
    override val navSettings = "الإعدادات"

    // Home Screen
    override val appTitle = "Substack Downloader"
    override val heroTitle = "حمّل محتواك بسهولة"
    override val heroSubtitle = "من Substack و TikTok بجودة عالية"
    override val platformSubstack = "Substack"
    override val platformTikTok = "TikTok"
    override val urlPlaceholder = "أدخل رابط المقال أو الفيديو هنا..."
    override val btnPaste = "لصق"
    override val btnStartDownload = "بدء التحميل"
    override val featureHighQuality = "جودة عالية"
    override val featureFast = "سريع"
    override val featureFree = "مجاني"
    override val extractingTikTok = "جاري استخراج محتوى تيك توك..."
    override val extractingSubstack = "جاري استخراج وسائط Substack..."
    override val couldNotFetchMedia = "تعذر استخراج المحتوى"
    override val tipPasteHint = "يمكنك لصق رابط أي محتوى من Substack و TikTok هنا..."
    override val linkDetectedClipboard = "تم اكتشاف رابط في الحافظة"
    override val btnUse = "استخدام"

    // Platform Chooser Sheet
    override val platformChooserTitle = "اختيار المنصة"
    override val substackPlatformDesc = "مقالات، بودكاست، فيديوهات"
    override val tiktokPlatformDesc = "فيديوهات قصيرة وطويلة"

    // Home Media Inspection
    override val downloadCurrentImageBtn = { idx: Int -> "تنزيل الصورة الحالية ($idx)" }
    override val downloadSinglePhotoBtn = "تنزيل الصورة"
    override val downloadAllImagesBtn = { total: Int -> "تنزيل جميع الصور ($total)" }
    override val downloadAudioAttached = "تنزيل الصوت المرتبط (MP3)"
    override val availableQualityLabel = "الجودة المتاحة:"
    override val bestQualityAvailable = "أعلى جودة متوفرة"
    override val downloadVideoBtn = "تنزيل الفيديو"
    override val downloadAudioBtn = "تنزيل الصوت (MP3)"

    // Downloads Screen
    override val downloadsTitle = "التنزيلات"
    override val tabCompleted = "المكتملة"
    override val tabActive = "جاري التحميل"
    override val noActiveDownloads = "لا توجد تنزيلات جارية حالياً"
    override val noActiveSubtitle = "يمكنك لصق رابط من Substack أو TikTok لبدء التنزيل"
    override val btnGoToHome = "الانتقال للرئيسية"
    override val fileSizeLabel = "حجم الملف"
    override val etaLabel = "المدة المتوقعة"
    override val qualityLabel = "الجودة"
    override val btnCancelDownload = "إلغاء التحميل"
    override val searchPlaceholder = "ابحث في التنزيلات..."
    override val filterAll = "الكل"
    override val filterSubstack = "Substack"
    override val filterTikTok = "TikTok"
    override val noCompletedDownloads = "سجل التنزيلات فارغ"
    override val noMatchingDownloads = "لا توجد نتائج مطابقة"

    // Details Sheet
    override val sheetDetailsTitle = "تفاصيل التحميل"
    override val btnOpenFile = "فتح الملف"
    override val btnShareFile = "مشاركة"
    override val btnRedownload = "إعادة التنزيل"
    override val btnDeleteFile = "حذف الملف"
    override val detailsDomainLabel = "الموقع المصدر"
    override val detailsDateLabel = "تاريخ التنزيل"
    override val detailsFormatLabel = "نوع الملف"

    // In-App Media Player
    override val playerFileNotFound = "الملف غير موجود على مسار التخزين"
    override val playerErrorPlaying = "خطأ في تشغيل الوسائط"
    override val btnClose = "إغلاق"
    override val playbackSpeedLabel = "سرعة التشغيل"
    override val menuShare = "مشاركة"
    override val menuExportGallery = "حفظ في المعرض"
    override val menuPlay = "تشغيل الوسائط"
    override val menuDelete = "حذف"

    // Settings Screen
    override val settingsTitle = "الإعدادات"
    override val sectionAppearance = "المظهر"
    override val themeLight = "الوضع الفاتح"
    override val themeDark = "الوضع الداكن"
    override val themeSystem = "تلقائي"
    override val sectionGeneral = "عام"
    override val folderLabel = "مجلد التنزيلات"
    override val languageLabel = "اللغة"
    override val currentLanguageName = "العربية"
    override val notificationsLabel = "إشعارات"
    override val autoClearLabel = "المسح التلقائي"
    override val autoClearSubtitle = "عند انتهاء التحميل"
    override val aboutLabel = "حول التطبيق"
    override val versionLabel = "الإصدار 1.2"
    override val languageDialogTitle = "لغة التطبيق"
    override val langArabic = "العربية"
    override val langEnglish = "English"
    override val btnCancel = "إلغاء"

    // About App Screen
    override val aboutAppTitle = "حول التطبيق"
    override val aboutAppDescription = "تطبيق بسيط وسريع لتحميل مقالات ومقاطع الفيديو من Substack و TikTok بجودة عالية."
    override val developerLabel = "المطور"
    override val developerValue = "@TSSTTl"
    override val locationLabel = "الموقع"
    override val locationValue = "العراق"
    override val emailLabel = "البريد الإلكتروني"
    override val emailValue = "ayrwynsmyth39@gmail.com"
    override val privacyPolicyLabel = "سياسة الخصوصية"
    override val privacyPolicyPoints = listOf(
        "• كافة عمليات التنزيل تتم مباشرة على جهازك دون إرسال أي وسائط لخوادم خارجية.",
        "• لا يتم جمع أي بيانات شخصية أو سجلات تتبع للمستخدم.",
        "• التطبيق يحترم حقوق الملكية الفكرية ويقوم بالحفظ الآمن محلياً."
    )
    override val btnGotIt = "حسناً"
}

val LocalAppStrings = compositionLocalOf<Strings> { ArabicStrings() }

fun getAppStrings(languageSetting: String): Strings {
    return when (languageSetting.lowercase()) {
        "en" -> EnglishStrings()
        "ar" -> ArabicStrings()
        else -> {
            val systemLang = Locale.getDefault().language.lowercase()
            if (systemLang.startsWith("en")) EnglishStrings() else ArabicStrings()
        }
    }
}

fun getAppLayoutDirection(languageSetting: String): LayoutDirection {
    return when (languageSetting.lowercase()) {
        "en" -> LayoutDirection.Ltr
        "ar" -> LayoutDirection.Rtl
        else -> {
            val systemLang = Locale.getDefault().language.lowercase()
            if (systemLang.startsWith("en")) LayoutDirection.Ltr else LayoutDirection.Rtl
        }
    }
}
