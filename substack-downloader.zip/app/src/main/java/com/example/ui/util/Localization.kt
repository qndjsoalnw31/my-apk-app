package com.example.ui.util

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

interface Strings {
    // Navigation
    val navHome: String
    val navDownloads: String
    val navSettings: String

    // Home Screen
    val appTitle: String
    val appSubtitle: String
    val pastePlaceholder: String
    val pasteClipboard: String
    val formatVideo: String
    val formatAudio: String
    val btnInspect: String
    val btnDownload: String
    val btnDirectDownload: String
    val btnInspectQuality: String
    val btnPreview: String
    val linkDetectedClipboard: String
    val btnInstantDownload: String
    val extractingMedia: String
    val couldNotFetchMedia: String
    val homeSupportedHint: String
    val availableQuality: String
    val bestAvailableQuality: String
    val downloadVideoBtn: String
    val downloadAudioBtn: String
    val durationLabel: String

    // Downloads Screen
    val downloadsTitle: String
    val tabActive: String
    val tabCompleted: String
    val inProgressCount: (Int) -> String
    val btnPauseAll: String
    val btnResumeAll: String
    val noActiveDownloads: String
    val noActiveSubtitle: String
    val btnGoToHome: String
    val noCompletedDownloads: String
    val noCompletedSubtitle: String
    val noMatchingDownloads: String
    val tryAnotherSearch: String
    val statusDownloading: String
    val statusQueued: String
    val statusResolving: String
    val statusPaused: String
    val statusError: String
    val searchPlaceholder: String
    val filterAll: String
    val filterVideos: String
    val filterAudio: String
    val sortNewest: String
    val sortOldest: String
    val sortLargest: String
    val sortTitle: String
    val selectedCount: (Int) -> String
    val btnSelectAll: String
    val menuPlay: String
    val menuExportGallery: String
    val menuShare: String
    val menuOpenExternal: String
    val menuRename: String
    val menuDelete: String

    // Dialogs
    val dialogRenameTitle: String
    val dialogRenameLabel: String
    val dialogDeleteTitle: String
    val dialogDeleteMessage: String
    val dialogBatchDeleteTitle: String
    val dialogBatchDeleteMessage: (Int) -> String
    val btnCancel: String
    val btnSave: String
    val btnDelete: String
    val btnClear: String
    val btnGotIt: String
    val btnClose: String
    val playerFileNotFound: String
    val playerErrorPlaying: String
    val playbackSpeedLabel: String

    // Settings Screen
    val settingsTitle: String
    val sectionAppearance: String
    val labelAppTheme: String
    val themeSystem: String
    val themeDark: String
    val themeLight: String
    val labelLanguage: String
    val langSystem: String
    val langArabic: String
    val langEnglish: String
    val labelDefaultQuality: String
    val qualityAuto: String
    val quality1080p: String
    val quality720p: String
    val quality480p: String
    val qualityAudioOnly: String

    val sectionNetwork: String
    val labelWifiOnly: String
    val descWifiOnly: String
    val labelAutoRetry: String
    val descAutoRetry: String
    val labelConcurrentDownloads: String
    val descConcurrentDownloads: String
    val labelAutoClipboard: String
    val descAutoClipboard: String
    val labelNotifications: String
    val descNotifications: String

    val sectionStorage: String
    val labelDownloadStorage: String
    val descDownloadStorage: String
    val btnCleanHistory: String
    val btnClearAll: String
    val dialogClearHistoryTitle: String
    val dialogClearHistoryMessage: String

    val sectionAbout: String
    val appVersionLabel: String
    val btnPrivacyPolicy: String
    val btnLicenses: String
    val dialogPrivacyTitle: String
    val dialogPrivacyContent: List<String>
    val dialogLicensesTitle: String
    val dialogLicensesContent: List<String>
}

class EnglishStrings : Strings {
    override val navHome = "Home"
    override val navDownloads = "Downloads"
    override val navSettings = "Settings"

    override val appTitle = "Substack Downloader"
    override val appSubtitle = "Download videos and audio from Substack"
    override val pastePlaceholder = "Paste Substack link"
    override val pasteClipboard = "Paste from clipboard"
    override val formatVideo = "Video"
    override val formatAudio = "Audio"
    override val btnInspect = "Inspect"
    override val btnDownload = "Download"
    override val btnDirectDownload = "Quick Download"
    override val btnInspectQuality = "Inspect & Choose Quality"
    override val btnPreview = "Preview"
    override val linkDetectedClipboard = "Link detected in clipboard"
    override val btnInstantDownload = "Download Now"
    override val extractingMedia = "Extracting Substack media..."
    override val couldNotFetchMedia = "Could not fetch media"
    override val homeSupportedHint = "Supports Substack video posts, podcast episodes & voice notes"
    override val availableQuality = "Available Quality:"
    override val bestAvailableQuality = "Best Available Quality"
    override val downloadVideoBtn = "Download Video"
    override val downloadAudioBtn = "Download Audio"
    override val durationLabel = "Duration"

    override val downloadsTitle = "Downloads"
    override val tabActive = "Active"
    override val tabCompleted = "Completed"
    override val inProgressCount = { count: Int -> "$count in progress" }
    override val btnPauseAll = "Pause all"
    override val btnResumeAll = "Resume all"
    override val noActiveDownloads = "No active downloads"
    override val noActiveSubtitle = "Paste a Substack link to start downloading"
    override val btnGoToHome = "Go to Home"
    override val noCompletedDownloads = "No completed downloads yet"
    override val noCompletedSubtitle = "Downloaded media will be stored and organized here"
    override val noMatchingDownloads = "No matching downloads"
    override val tryAnotherSearch = "Try another search term"
    override val statusDownloading = "Downloading"
    override val statusQueued = "Queued"
    override val statusResolving = "Resolving"
    override val statusPaused = "Paused"
    override val statusError = "Error"
    override val searchPlaceholder = "Search by title or author..."
    override val filterAll = "All"
    override val filterVideos = "Videos"
    override val filterAudio = "Audio"
    override val sortNewest = "Newest first"
    override val sortOldest = "Oldest first"
    override val sortLargest = "Largest size"
    override val sortTitle = "By title (A-Z)"
    override val selectedCount = { count: Int -> "$count selected" }
    override val btnSelectAll = "Select all"
    override val menuPlay = "Play Media"
    override val menuExportGallery = "Export to Gallery"
    override val menuShare = "Share"
    override val menuOpenExternal = "Open in External App"
    override val menuRename = "Rename"
    override val menuDelete = "Delete"

    override val dialogRenameTitle = "Rename File"
    override val dialogRenameLabel = "New file name"
    override val dialogDeleteTitle = "Delete File"
    override val dialogDeleteMessage = "Do you want to delete this file from your device?"
    override val dialogBatchDeleteTitle = "Delete Selected Items"
    override val dialogBatchDeleteMessage = { count: Int -> "Are you sure you want to delete $count item(s) from storage?" }
    override val btnCancel = "Cancel"
    override val btnSave = "Save"
    override val btnDelete = "Delete"
    override val btnClear = "Clear"
    override val btnGotIt = "Got it"
    override val btnClose = "Close"
    override val playerFileNotFound = "Media file not found on storage"
    override val playerErrorPlaying = "Error playing media"
    override val playbackSpeedLabel = "Speed"

    override val settingsTitle = "Settings"
    override val sectionAppearance = "Appearance & Language"
    override val labelAppTheme = "App Theme"
    override val themeSystem = "System"
    override val themeDark = "Dark"
    override val themeLight = "Light"
    override val labelLanguage = "App Language"
    override val langSystem = "System"
    override val langArabic = "العربية"
    override val langEnglish = "English"
    override val labelDefaultQuality = "Default Preferred Quality"
    override val qualityAuto = "Auto (Best)"
    override val quality1080p = "1080p"
    override val quality720p = "720p"
    override val quality480p = "480p"
    override val qualityAudioOnly = "Audio Only"

    override val sectionNetwork = "Network & Download Engine"
    override val labelWifiOnly = "Download on Wi-Fi Only"
    override val descWifiOnly = "Prevent downloads over cellular data connections"
    override val labelAutoRetry = "Auto-retry on Disconnect"
    override val descAutoRetry = "Automatically retry chunks when temporary connection drops occur"
    override val labelConcurrentDownloads = "Concurrent Downloads"
    override val descConcurrentDownloads = "Max parallel downloads running at the same time"
    override val labelAutoClipboard = "Clipboard Link Detection"
    override val descAutoClipboard = "Auto-detect copied Substack links when opening the app"
    override val labelNotifications = "System Notifications"
    override val descNotifications = "Show progress, speed, and completion notifications"

    override val sectionStorage = "Storage & Cache"
    override val labelDownloadStorage = "Download Storage"
    override val descDownloadStorage = "Secure local directory with direct export to device Media Gallery"
    override val btnCleanHistory = "Clean History"
    override val btnClearAll = "Clear All"
    override val dialogClearHistoryTitle = "Clear All History"
    override val dialogClearHistoryMessage = "Are you sure you want to clear all download history and remove database records?"

    override val sectionAbout = "About & Privacy"
    override val appVersionLabel = "Version 2.0 (Build 2) • Dark Minimal Edition"
    override val btnPrivacyPolicy = "Privacy Policy"
    override val btnLicenses = "Licenses"
    override val dialogPrivacyTitle = "Privacy & Security"
    override val dialogPrivacyContent = listOf(
        "• 100% Local Processing: Substack Downloader processes everything directly on your device.",
        "• Zero Tracking: No telemetry, analytics, or third-party servers collect your data.",
        "• SSRF & DNS Protection: Safe DNS resolution blocks unauthorized internal loopback networks.",
        "• Scoped Storage: Media files are safely managed via Android FileProvider and MediaStore APIs."
    )
    override val dialogLicensesTitle = "Open Source Licenses"
    override val dialogLicensesContent = listOf(
        "• Jetpack Compose & AndroidX (Apache 2.0)",
        "• OkHttp (Square - Apache 2.0)",
        "• Room Persistence Library (Google - Apache 2.0)",
        "• Coil Image Loading (Apache 2.0)",
        "• Kotlin Coroutines (JetBrains - Apache 2.0)"
    )
}

class ArabicStrings : Strings {
    override val navHome = "الرئيسية"
    override val navDownloads = "التنزيلات"
    override val navSettings = "الإعدادات"

    override val appTitle = "Substack Downloader"
    override val appSubtitle = "تنزيل الفيديو والصوت من منصة Substack"
    override val pastePlaceholder = "الصق رابط Substack هنا"
    override val pasteClipboard = "لصق من الحافظة"
    override val formatVideo = "فيديو"
    override val formatAudio = "صوت"
    override val btnInspect = "فحص الرابط"
    override val btnDownload = "تنزيل"
    override val btnDirectDownload = "تنزيل سريع ومباشر"
    override val btnInspectQuality = "فحص وتحديد الجودة"
    override val btnPreview = "معاينة"
    override val linkDetectedClipboard = "تم اكتشاف رابط في الحافظة"
    override val btnInstantDownload = "تنزيل فوري"
    override val extractingMedia = "جاري استخراج وسائط Substack..."
    override val couldNotFetchMedia = "تعذر جلب الوسائط"
    override val homeSupportedHint = "يدعم منشورات الفيديو والبودكاست والملاحظات الصوتية"
    override val availableQuality = "الجودة المتاحة:"
    override val bestAvailableQuality = "أعلى جودة متوفرة"
    override val downloadVideoBtn = "تنزيل الفيديو"
    override val downloadAudioBtn = "تنزيل الصوت"
    override val durationLabel = "المدة"

    override val downloadsTitle = "التنزيلات"
    override val tabActive = "النشطة"
    override val tabCompleted = "المكتملة"
    override val inProgressCount = { count: Int -> "$count قيد التحميل" }
    override val btnPauseAll = "إيقاف الكل"
    override val btnResumeAll = "استئناف الكل"
    override val noActiveDownloads = "لا توجد تنزيلات نشطة"
    override val noActiveSubtitle = "الصق رابط Substack لبدء التحميل فوراً"
    override val btnGoToHome = "الانتقال للرئيسية"
    override val noCompletedDownloads = "لا توجد تنزيلات مكتملة بعد"
    override val noCompletedSubtitle = "ستظهر الملفات والوسائط المنزلة هنا"
    override val noMatchingDownloads = "لا توجد نتائج مطابقة"
    override val tryAnotherSearch = "جرب البحث بكلمة أخرى"
    override val statusDownloading = "جاري التنزيل"
    override val statusQueued = "في قائمة الانتظار"
    override val statusResolving = "جاري التجهيز"
    override val statusPaused = "متوقف مؤقتاً"
    override val statusError = "حدث خطأ"
    override val searchPlaceholder = "ابحث بالاسم أو الكاتب..."
    override val filterAll = "الكل"
    override val filterVideos = "فيديو"
    override val filterAudio = "صوت"
    override val sortNewest = "الأحدث أولاً"
    override val sortOldest = "الأقدم أولاً"
    override val sortLargest = "الأكبر حجماً"
    override val sortTitle = "أبجدياً (أ-ي)"
    override val selectedCount = { count: Int -> "تم تحديد $count" }
    override val btnSelectAll = "تحديد الكل"
    override val menuPlay = "تشغيل الوسائط"
    override val menuExportGallery = "حفظ في المعرض"
    override val menuShare = "مشاركة"
    override val menuOpenExternal = "فتح بتطبيق خارجي"
    override val menuRename = "إعادة تسمية"
    override val menuDelete = "حذف"

    override val dialogRenameTitle = "إعادة تسمية الملف"
    override val dialogRenameLabel = "الاسم الجديد"
    override val dialogDeleteTitle = "حذف الملف"
    override val dialogDeleteMessage = "هل تريد حذف هذا الملف نهائياً من جهازك؟"
    override val dialogBatchDeleteTitle = "حذف العناصر المحددة"
    override val dialogBatchDeleteMessage = { count: Int -> "هل أنت متأكد من حذف $count عنصر/عناصر من التخزين؟" }
    override val btnCancel = "إلغاء"
    override val btnSave = "حفظ"
    override val btnDelete = "حذف"
    override val btnClear = "مسح"
    override val btnGotIt = "حسناً"
    override val btnClose = "إغلاق"
    override val playerFileNotFound = "الملف غير موجود على مسار التخزين"
    override val playerErrorPlaying = "خطأ في تشغيل الوسائط"
    override val playbackSpeedLabel = "سرعة التشغيل"

    override val settingsTitle = "الإعدادات"
    override val sectionAppearance = "المظهر واللغة"
    override val labelAppTheme = "مظهر التطبيق"
    override val themeSystem = "تلقائي (النظام)"
    override val themeDark = "داكن"
    override val themeLight = "فاتح"
    override val labelLanguage = "لغة التطبيق"
    override val langSystem = "تلقائي (النظام)"
    override val langArabic = "العربية"
    override val langEnglish = "English"
    override val labelDefaultQuality = "الجودة الافتراضية المفضلة"
    override val qualityAuto = "تلقائي (أفضل جودة)"
    override val quality1080p = "1080p"
    override val quality720p = "720p"
    override val quality480p = "480p"
    override val qualityAudioOnly = "صوت فقط"

    override val sectionNetwork = "الشبكة ومحرك التنزيل"
    override val labelWifiOnly = "التنزيل عبر Wi-Fi فقط"
    override val descWifiOnly = "منع التنزيلات عبر بيانات الجوال لتوفير الرصيد"
    override val labelAutoRetry = "إعادة المحاولة التلقائية"
    override val descAutoRetry = "إعادة المحاولة تلقائياً عند انقطاع الاتصال المؤقت"
    override val labelConcurrentDownloads = "عدد التنزيلات المتزامنة"
    override val descConcurrentDownloads = "الحد الأقصى للتنزيلات المتزامنة في نفس الوقت"
    override val labelAutoClipboard = "اكتشاف الروابط من الحافظة"
    override val descAutoClipboard = "التعرف التلقائي على روابط Substack المنسوخة عند فتح التطبيق"
    override val labelNotifications = "إشعارات النظام"
    override val descNotifications = "عرض تقدم وسرعة التحميل وإشعار الاكتمال"

    override val sectionStorage = "التخزين والذاكرة المؤقتة"
    override val labelDownloadStorage = "مجلد التنزيلات"
    override val descDownloadStorage = "تخزين محلي آمن مع دعم التصدير المباشر لمعرض الصور والفيديوهات"
    override val btnCleanHistory = "تنظيف السجل"
    override val btnClearAll = "مسح الكل"
    override val dialogClearHistoryTitle = "مسح سجل التنزيلات"
    override val dialogClearHistoryMessage = "هل أنت متأكد من مسح كافة سجلات التنزيل من قاعدة البيانات؟"

    override val sectionAbout = "حول التطبيق والخصوصية"
    override val appVersionLabel = "الإصدار 2.0 (بناء 2) • نمط Dark Minimal"
    override val btnPrivacyPolicy = "سياسة الخصوصية"
    override val btnLicenses = "التراخيص مفتوحة المصدر"
    override val dialogPrivacyTitle = "الخصوصية والأمان"
    override val dialogPrivacyContent = listOf(
        "• معالجة محلية 100%: تتم جميع عمليات التحليل والتنزيل محلياً داخل جهازك.",
        "• بدون أي تتبع: لا نقوم بجمع أي بيانات أو استخدام خوادم تحليلية خارجية.",
        "• حماية SSRF و DNS: حظر النطاقات الداخلية لضمان أمان الشبكة.",
        "• تخزين معزول وآمن: إدارة الملفات وفق أعلى معايير أندرويد وScoped Storage."
    )
    override val dialogLicensesTitle = "التراخيص المفتوحة المصدر"
    override val dialogLicensesContent = listOf(
        "• Jetpack Compose & AndroidX (Apache 2.0)",
        "• OkHttp (Square - Apache 2.0)",
        "• Room Persistence Library (Google - Apache 2.0)",
        "• Coil Image Loading (Apache 2.0)",
        "• Kotlin Coroutines (JetBrains - Apache 2.0)"
    )
}

val LocalAppStrings = compositionLocalOf<Strings> { EnglishStrings() }

fun getAppStrings(languageSetting: String): Strings {
    return when (languageSetting) {
        "ar" -> ArabicStrings()
        "en" -> EnglishStrings()
        else -> {
            val systemLang = Locale.getDefault().language
            if (systemLang.startsWith("ar")) ArabicStrings() else EnglishStrings()
        }
    }
}

fun getAppLayoutDirection(languageSetting: String): LayoutDirection {
    return when (languageSetting) {
        "ar" -> LayoutDirection.Rtl
        "en" -> LayoutDirection.Ltr
        else -> {
            val systemLang = Locale.getDefault().language
            if (systemLang.startsWith("ar")) LayoutDirection.Rtl else LayoutDirection.Ltr
        }
    }
}
