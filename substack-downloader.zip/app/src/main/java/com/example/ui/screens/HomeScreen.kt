package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.ContentType
import com.example.data.model.DownloadItem
import com.example.data.model.NoteDetails
import com.example.data.model.VideoSource
import com.example.ui.DownloadViewModel
import com.example.ui.InspectionUiState
import com.example.ui.PlatformMode
import com.example.ui.components.SquareImageCarouselPreview
import com.example.ui.components.SquareVideoPlayer
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandGold
import com.example.ui.theme.SubstackBackground
import com.example.ui.theme.SubstackBorder
import com.example.ui.theme.SubstackOrange
import com.example.ui.theme.SubstackPanel
import com.example.ui.theme.SubstackPanelVariant
import com.example.ui.theme.SubstackTextMuted
import com.example.ui.theme.SubstackTextPrimary
import com.example.ui.theme.SubstackTextSubtle
import com.example.ui.theme.TikTokCyan
import com.example.ui.util.LocalAppStrings
import com.example.ui.util.MediaExportHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: DownloadViewModel) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val urlInput by viewModel.urlInput.collectAsState()
    val inspectionState by viewModel.inspectionState.collectAsState()
    val platformMode by viewModel.platformMode.collectAsState()
    val selectedFormat by viewModel.selectedFormat.collectAsState()
    val selectedSource by viewModel.selectedSource.collectAsState()
    val clipboardDetectedUrl by viewModel.clipboardUrlDetected.collectAsState()

    var showPlatformSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SubstackBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        // Top Header Bar: Menu on Left, Logo + Title in Center, Gold Crown on Right
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = { showPlatformSheet = true },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Menu",
                    tint = SubstackTextPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, SubstackBorder, RoundedCornerShape(8.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo_exact_1788333333093),
                        contentDescription = "App Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Substack Downloader",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = SubstackTextPrimary
                )
            }

            IconButton(
                onClick = { /* Crown / VIP Feature indicator */ },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = "VIP Badge",
                    tint = BrandGold,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Hero Heading Section
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = strings.heroTitle,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = SubstackTextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = strings.heroSubtitle,
                fontSize = 13.sp,
                color = SubstackTextMuted
            )
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Platform Switcher Tabs: Substack vs TikTok
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val isSubstack = platformMode == PlatformMode.SUBSTACK
            val isTikTok = platformMode == PlatformMode.TIKTOK

            // Substack Tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isSubstack) BrandBlue else SubstackPanel)
                    .border(
                        width = 1.dp,
                        color = if (isSubstack) BrandBlue else SubstackBorder,
                        shape = RoundedCornerShape(14.dp)
                    )
                    .clickable { viewModel.setPlatformMode(PlatformMode.SUBSTACK) },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bookmark,
                        contentDescription = null,
                        tint = if (isSubstack) Color.White else SubstackOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Substack",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSubstack) Color.White else SubstackTextPrimary
                    )
                }
            }

            // TikTok Tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isTikTok) BrandBlue else SubstackPanel)
                    .border(
                        width = 1.dp,
                        color = if (isTikTok) BrandBlue else SubstackBorder,
                        shape = RoundedCornerShape(14.dp)
                    )
                    .clickable { viewModel.setPlatformMode(PlatformMode.TIKTOK) },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = if (isTikTok) Color.White else TikTokCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TikTok",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isTikTok) Color.White else SubstackTextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Clipboard auto-detected banner
        AnimatedVisibility(
            visible = clipboardDetectedUrl != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SubstackPanel),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandBlue.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = null,
                        tint = BrandBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.linkDetectedClipboard,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SubstackTextPrimary
                        )
                        Text(
                            text = clipboardDetectedUrl ?: "",
                            fontSize = 11.sp,
                            color = SubstackTextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Button(
                        onClick = { viewModel.useClipboardUrl() },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(strings.btnUse, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { viewModel.dismissClipboardBanner() }, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Dismiss", tint = SubstackTextSubtle, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        // URL Input Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = SubstackPanel,
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Link,
                    contentDescription = null,
                    tint = if (urlInput.isNotBlank()) BrandBlue else SubstackTextSubtle,
                    modifier = Modifier.size(20.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                BasicTextField(
                    value = urlInput,
                    onValueChange = { viewModel.onUrlChanged(it) },
                    modifier = Modifier.weight(1f),
                    textStyle = TextStyle(
                        fontSize = 14.sp,
                        color = SubstackTextPrimary
                    ),
                    singleLine = true,
                    decorationBox = { innerTextField ->
                        if (urlInput.isEmpty()) {
                            Text(
                                text = strings.urlPlaceholder,
                                fontSize = 14.sp,
                                color = SubstackTextSubtle
                            )
                        }
                        innerTextField()
                    }
                )

                if (urlInput.isNotBlank()) {
                    IconButton(
                        onClick = { viewModel.onUrlChanged("") },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear",
                            tint = SubstackTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Paste Pill Button
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = BrandBlue.copy(alpha = 0.15f),
                    modifier = Modifier.clickable {
                        try {
                            val clipService = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            val text = clipService?.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                            if (text.isNotBlank()) {
                                viewModel.onUrlChanged(text.trim())
                            }
                        } catch (_: Exception) {}
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentPaste,
                            contentDescription = null,
                            tint = BrandBlue,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = strings.btnPaste,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandBlue
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Main Action Button
        Button(
            onClick = {
                if (urlInput.isNotBlank()) {
                    if (inspectionState is InspectionUiState.Success) {
                        viewModel.startQuickDownload()
                    } else {
                        viewModel.inspectUrl()
                    }
                }
            },
            enabled = urlInput.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = BrandBlue,
                contentColor = Color.White,
                disabledContainerColor = BrandBlue.copy(alpha = 0.35f),
                disabledContentColor = Color.White.copy(alpha = 0.5f)
            ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
        ) {
            Icon(
                imageVector = Icons.Default.FileDownload,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = strings.btnStartDownload,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Feature Badges: Free | Fast | High Quality
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // High Quality
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.HighQuality,
                    contentDescription = null,
                    tint = SubstackTextMuted,
                    modifier = Modifier.size(17.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(text = strings.featureHighQuality, fontSize = 12.sp, color = SubstackTextMuted)
            }

            // Fast
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = null,
                    tint = SubstackTextMuted,
                    modifier = Modifier.size(17.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(text = strings.featureFast, fontSize = 12.sp, color = SubstackTextMuted)
            }

            // Free
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = SubstackTextMuted,
                    modifier = Modifier.size(17.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(text = strings.featureFree, fontSize = 12.sp, color = SubstackTextMuted)
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Inspection / Preview Area
        when (val state = inspectionState) {
            is InspectionUiState.Loading -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SubstackPanel),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = BrandBlue,
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (platformMode == PlatformMode.TIKTOK) strings.extractingTikTok else strings.extractingSubstack,
                            fontSize = 13.sp,
                            color = SubstackTextMuted
                        )
                    }
                }
            }

            is InspectionUiState.Error -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SubstackPanel),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF632222))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = strings.couldNotFetchMedia,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFF6B6B)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = state.message,
                            fontSize = 12.sp,
                            color = SubstackTextMuted
                        )
                    }
                }
            }

            is InspectionUiState.Success -> {
                SquareMediaInspectionCard(
                    details = state.details,
                    selectedSource = selectedSource,
                    selectedFormat = selectedFormat,
                    onSelectSource = { viewModel.setSelectedSource(it) },
                    onStartDownload = { viewModel.startQuickDownload() },
                    viewModel = viewModel
                )
            }

            is InspectionUiState.Idle -> {
                // Tip Card matching reference image
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SubstackPanel,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = BrandBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = strings.tipPasteHint,
                            fontSize = 12.sp,
                            color = SubstackTextMuted
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    // Platform Chooser Bottom Sheet
    if (showPlatformSheet) {
        ModalBottomSheet(
            onDismissRequest = { showPlatformSheet = false },
            sheetState = sheetState,
            containerColor = SubstackPanel,
            dragHandle = null
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = strings.platformChooserTitle,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = SubstackTextPrimary
                    )
                    IconButton(onClick = { showPlatformSheet = false }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Close",
                            tint = SubstackTextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Card 1: Substack
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SubstackBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.setPlatformMode(PlatformMode.SUBSTACK)
                            showPlatformSheet = false
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SubstackOrange.copy(alpha = 0.15f),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Bookmark,
                                    contentDescription = null,
                                    tint = SubstackOrange,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.platformSubstack,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = SubstackTextPrimary
                            )
                            Text(
                                text = strings.substackPlatformDesc,
                                fontSize = 12.sp,
                                color = SubstackTextMuted
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = SubstackTextSubtle,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Card 2: TikTok
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SubstackBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.setPlatformMode(PlatformMode.TIKTOK)
                            showPlatformSheet = false
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = TikTokCyan.copy(alpha = 0.15f),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = TikTokCyan,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.platformTikTok,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = SubstackTextPrimary
                            )
                            Text(
                                text = strings.tiktokPlatformDesc,
                                fontSize = 12.sp,
                                color = SubstackTextMuted
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = SubstackTextSubtle,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tip Card at bottom of sheet
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SubstackPanelVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = BrandBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = strings.tipPasteHint,
                            fontSize = 11.sp,
                            color = SubstackTextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

/**
 * Inspection Preview Card:
 * - Employs a strict 1:1 Aspect Ratio frame for media preview with ContentScale.Fit.
 * - In Photo Mode: Displays SquareImageCarouselPreview (1:1, ContentScale.Fit, "2 / 8" counter, navigation, single & all download buttons).
 * - In Video Mode: Displays SquareVideoPlayer (1:1, ContentScale.Fit, portrait with pillarbox, landscape with letterbox, controls).
 * - No video controls in photo mode; no photo controls in video mode.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SquareMediaInspectionCard(
    details: NoteDetails,
    selectedSource: VideoSource?,
    selectedFormat: String,
    onSelectSource: (VideoSource) -> Unit,
    onStartDownload: () -> Unit,
    viewModel: DownloadViewModel
) {
    val strings = LocalAppStrings.current
    val isPhotoPost = details.contentType == ContentType.IMAGE ||
            details.contentType == ContentType.IMAGE_CAROUSEL ||
            details.imageUrls.isNotEmpty()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SubstackPanel),
        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (isPhotoPost && details.imageUrls.isNotEmpty()) {
                // PHOTO / CAROUSEL MODE
                var currentImageIndex by remember(details) { mutableIntStateOf(0) }
                val totalImages = details.imageUrls.size
                val currentImageUrl = details.imageUrls.getOrElse(currentImageIndex) { details.imageUrls.first() }

                // 1:1 Square Image Preview Frame
                SquareImageCarouselPreview(
                    imageUrls = details.imageUrls,
                    currentIndex = currentImageIndex,
                    onIndexChanged = { currentImageIndex = it }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Title and Author
                Text(
                    text = details.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SubstackTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = details.author,
                    fontSize = 12.sp,
                    color = SubstackTextMuted
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Download Current Image Button
                Button(
                    onClick = {
                        viewModel.downloadSingleImage(
                            imageUrl = currentImageUrl,
                            title = details.title,
                            index = if (totalImages > 1) currentImageIndex + 1 else null
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (totalImages > 1) strings.downloadCurrentImageBtn(currentImageIndex + 1) else strings.downloadSinglePhotoBtn,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Download All Images Button (if multiple images)
                if (totalImages > 1) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.downloadAllImages(details) },
                        shape = RoundedCornerShape(12.dp),
                        color = SubstackPanelVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = null,
                                tint = SubstackTextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.downloadAllImagesBtn(totalImages),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = SubstackTextPrimary
                            )
                        }
                    }
                }

                // Audio stream download option if background music is attached
                val audioSource = details.videoSources.firstOrNull { it.type == "audio" }
                if (audioSource != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                viewModel.setSelectedSource(audioSource)
                                viewModel.setSelectedFormat(DownloadItem.FORMAT_AUDIO)
                                viewModel.startQuickDownload()
                            },
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Transparent,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = SubstackTextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.downloadAudioAttached,
                                fontSize = 12.sp,
                                color = SubstackTextMuted
                            )
                        }
                    }
                }

            } else {
                // VIDEO MODE
                val activeVideoUrl = selectedSource?.url
                    ?: details.videoSources.firstOrNull { it.type == "mp4" }?.url
                    ?: details.videoSources.firstOrNull()?.url
                    ?: ""

                // 1:1 Square Video Preview Player
                SquareVideoPlayer(
                    videoUrl = activeVideoUrl,
                    coverUrl = details.imageUrl
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Title, Author and Duration
                Text(
                    text = details.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SubstackTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = details.author,
                        fontSize = 12.sp,
                        color = SubstackTextMuted
                    )
                    if (details.durationSeconds != null && details.durationSeconds > 0) {
                        Text(
                            text = " • ${MediaExportHelper.formatDuration(details.durationSeconds)}",
                            fontSize = 12.sp,
                            color = SubstackTextSubtle
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quality Selector Chips
                Text(
                    text = strings.availableQualityLabel,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SubstackTextMuted
                )
                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (details.videoSources.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SubstackPanelVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                        ) {
                            Text(
                                text = strings.bestQualityAvailable,
                                fontSize = 12.sp,
                                color = SubstackTextPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    } else {
                        details.videoSources.forEach { source ->
                            val isSelected = selectedSource == source
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) BrandBlue.copy(alpha = 0.2f) else SubstackPanelVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) BrandBlue else SubstackBorder
                                ),
                                modifier = Modifier.clickable { onSelectSource(source) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = BrandBlue,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                    }
                                    Text(
                                        text = source.quality,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) BrandBlue else SubstackTextPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Primary Video Download Button
                Button(
                    onClick = onStartDownload,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedFormat == DownloadItem.FORMAT_AUDIO) strings.downloadAudioBtn else strings.downloadVideoBtn,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
