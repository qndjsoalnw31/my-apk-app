package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.DownloadItem
import com.example.data.model.NoteDetails
import com.example.data.model.VideoSource
import com.example.ui.DownloadViewModel
import com.example.ui.InspectionUiState
import com.example.ui.theme.SubstackBackground
import com.example.ui.theme.SubstackBorder
import com.example.ui.theme.SubstackOrange
import com.example.ui.theme.SubstackPanel
import com.example.ui.theme.SubstackPanelVariant
import com.example.ui.theme.SubstackTextMuted
import com.example.ui.theme.SubstackTextPrimary
import com.example.ui.theme.SubstackTextSubtle
import com.example.ui.util.LocalAppStrings
import com.example.ui.util.MediaExportHelper

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(viewModel: DownloadViewModel) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val urlInput by viewModel.urlInput.collectAsState()
    val inspectionState by viewModel.inspectionState.collectAsState()
    val selectedFormat by viewModel.selectedFormat.collectAsState()
    val selectedSource by viewModel.selectedSource.collectAsState()
    val clipboardDetectedUrl by viewModel.clipboardUrlDetected.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SubstackBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // App Header: Minimal, Clean, Direct with App Logo
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .border(1.dp, SubstackBorder, RoundedCornerShape(13.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.app_logo_exact_1788333333093),
                    contentDescription = "App Logo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = strings.appTitle,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = SubstackTextPrimary,
                    letterSpacing = (-0.3).sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = strings.appSubtitle,
                    fontSize = 13.sp,
                    color = SubstackTextMuted,
                    fontWeight = FontWeight.Normal
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Clipboard auto-detected banner
        AnimatedVisibility(
            visible = clipboardDetectedUrl != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = SubstackPanel),
                border = androidx.compose.foundation.BorderStroke(1.dp, SubstackOrange.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = SubstackOrange.copy(alpha = 0.15f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Link,
                                contentDescription = null,
                                tint = SubstackOrange,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.linkDetectedClipboard,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SubstackTextPrimary
                        )
                        Text(
                            text = clipboardDetectedUrl ?: "",
                            fontSize = 11.sp,
                            color = SubstackTextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { viewModel.useClipboardUrl() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SubstackOrange,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(strings.btnPreview, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = { viewModel.dismissClipboardBanner() },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Dismiss",
                            tint = SubstackTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Main Input Card: Dark Minimal (#15181D)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SubstackPanel),
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Large Input Field
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { viewModel.onUrlChanged(it) },
                    placeholder = {
                        Text(
                            text = strings.pastePlaceholder,
                            color = SubstackTextSubtle,
                            fontSize = 15.sp
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = false,
                    maxLines = 3,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Link,
                            contentDescription = null,
                            tint = if (urlInput.isNotBlank()) SubstackOrange else SubstackTextSubtle,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (urlInput.isNotBlank()) {
                                IconButton(onClick = { viewModel.onUrlChanged("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear",
                                        tint = SubstackTextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            IconButton(onClick = {
                                try {
                                    val clipService = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    val text = clipService?.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                                    if (text.isNotBlank()) {
                                        viewModel.onUrlChanged(text.trim())
                                        viewModel.inspectUrl(text.trim())
                                    }
                                } catch (_: Exception) {}
                            }) {
                                Icon(
                                    imageVector = Icons.Default.ContentPaste,
                                    contentDescription = strings.pasteClipboard,
                                    tint = SubstackOrange,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SubstackBackground,
                        unfocusedContainerColor = SubstackBackground,
                        focusedBorderColor = SubstackOrange,
                        unfocusedBorderColor = SubstackBorder,
                        focusedTextColor = SubstackTextPrimary,
                        unfocusedTextColor = SubstackTextPrimary,
                        cursorColor = SubstackOrange
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Format Selector: "Video | Audio"
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SubstackBackground, RoundedCornerShape(12.dp))
                        .border(1.dp, SubstackBorder, RoundedCornerShape(12.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val isVideo = selectedFormat == DownloadItem.FORMAT_VIDEO
                    val isAudio = selectedFormat == DownloadItem.FORMAT_AUDIO

                    // Video Tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(if (isVideo) SubstackPanelVariant else Color.Transparent)
                            .clickable { viewModel.setSelectedFormat(DownloadItem.FORMAT_VIDEO) },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                tint = if (isVideo) SubstackOrange else SubstackTextMuted,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.formatVideo,
                                fontSize = 13.sp,
                                fontWeight = if (isVideo) FontWeight.Bold else FontWeight.Medium,
                                color = if (isVideo) SubstackTextPrimary else SubstackTextMuted
                            )
                        }
                    }

                    // Audio Tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(if (isAudio) SubstackPanelVariant else Color.Transparent)
                            .clickable { viewModel.setSelectedFormat(DownloadItem.FORMAT_AUDIO) },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Audiotrack,
                                contentDescription = null,
                                tint = if (isAudio) SubstackOrange else SubstackTextMuted,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.formatAudio,
                                fontSize = 13.sp,
                                fontWeight = if (isAudio) FontWeight.Bold else FontWeight.Medium,
                                color = if (isAudio) SubstackTextPrimary else SubstackTextMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons: Inspect / Download
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Preview / Inspect Button
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable(enabled = urlInput.isNotBlank() && inspectionState !is InspectionUiState.Loading) {
                                viewModel.inspectUrl()
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = SubstackPanelVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (inspectionState is InspectionUiState.Loading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = SubstackOrange,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = null,
                                        tint = if (urlInput.isNotBlank()) SubstackTextPrimary else SubstackTextSubtle,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = strings.btnInspect,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (urlInput.isNotBlank()) SubstackTextPrimary else SubstackTextSubtle
                                    )
                                }
                            }
                        }
                    }

                    // Download Primary Button (Accent #FF6719)
                    Button(
                        onClick = { viewModel.startQuickDownload() },
                        enabled = urlInput.isNotBlank(),
                        modifier = Modifier
                            .weight(1.2f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SubstackOrange,
                            contentColor = Color.White,
                            disabledContainerColor = SubstackOrange.copy(alpha = 0.3f),
                            disabledContentColor = Color.White.copy(alpha = 0.4f)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = strings.btnDownload,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Inspection / Preview State
        when (val state = inspectionState) {
            is InspectionUiState.Loading -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = SubstackPanel),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = SubstackOrange,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = strings.extractingMedia,
                            fontSize = 13.sp,
                            color = SubstackTextMuted
                        )
                    }
                }
            }

            is InspectionUiState.Error -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = SubstackPanel),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF5C1D1D))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = strings.couldNotFetchMedia,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFF6B6B)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = state.message,
                            fontSize = 12.sp,
                            color = SubstackTextMuted
                        )
                    }
                }
            }

            is InspectionUiState.Success -> {
                CompactPreviewCard(
                    details = state.details,
                    selectedSource = selectedSource,
                    selectedFormat = selectedFormat,
                    onSelectSource = { viewModel.setSelectedSource(it) },
                    onStartDownload = { viewModel.startQuickDownload() }
                )
            }

            is InspectionUiState.Idle -> {
                // Clean subtle hint
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = strings.homeSupportedHint,
                        fontSize = 12.sp,
                        color = SubstackTextSubtle
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CompactPreviewCard(
    details: NoteDetails,
    selectedSource: VideoSource?,
    selectedFormat: String,
    onSelectSource: (VideoSource) -> Unit,
    onStartDownload: () -> Unit
) {
    val strings = LocalAppStrings.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SubstackPanel),
        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Thumbnail + Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                if (!details.imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = details.imageUrl,
                        contentDescription = "Thumbnail",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SubstackPanelVariant)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = details.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = SubstackTextPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = details.author,
                        fontSize = 12.sp,
                        color = SubstackOrange
                    )
                    if (details.durationSeconds != null && details.durationSeconds > 0) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${strings.durationLabel}: ${MediaExportHelper.formatDuration(details.durationSeconds)}",
                            fontSize = 11.sp,
                            color = SubstackTextSubtle
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quality Selection Chips
            Text(
                text = strings.availableQuality,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = SubstackTextMuted
            )
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (details.videoSources.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SubstackPanelVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Text(
                            text = strings.bestAvailableQuality,
                            fontSize = 12.sp,
                            color = SubstackTextPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                } else {
                    details.videoSources.forEach { source ->
                        val isSelected = selectedSource == source
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) SubstackOrange.copy(alpha = 0.15f) else SubstackPanelVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) SubstackOrange else SubstackBorder
                            ),
                            modifier = Modifier.clickable { onSelectSource(source) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = SubstackOrange,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                Text(
                                    text = source.quality,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) SubstackOrange else SubstackTextPrimary
                                )
                                if (source.resolution != null) {
                                    Text(
                                        text = " (${source.resolution})",
                                        fontSize = 11.sp,
                                        color = SubstackTextSubtle
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Prominent Download Button (Accent #FF6719)
            Button(
                onClick = onStartDownload,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SubstackOrange,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (selectedFormat == DownloadItem.FORMAT_AUDIO) strings.downloadAudioBtn else strings.downloadVideoBtn,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
