package com.example.ui.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.security.SecurityLogger
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MediaExportHelper {

    fun shareFile(context: Context, filePath: String, mimeType: String = "video/*") {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                SecurityLogger.w("Cannot share non-existing file: $filePath")
                return
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الوسائط عبر").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            SecurityLogger.e("Share file failed", e)
        }
    }

    fun shareMultipleFiles(context: Context, filePaths: List<String>) {
        try {
            val uris = ArrayList<Uri>()
            for (path in filePaths) {
                val file = File(path)
                if (file.exists()) {
                    uris.add(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
                }
            }

            if (uris.isEmpty()) return

            val shareIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الملفات المحددة").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            SecurityLogger.e("Share multiple failed", e)
        }
    }

    fun openWithExternalApp(context: Context, filePath: String, mimeType: String = "video/*") {
        try {
            val file = File(filePath)
            if (!file.exists()) return

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(viewIntent)
        } catch (e: Exception) {
            SecurityLogger.e("Open external player failed", e)
        }
    }

    fun exportToGallery(context: Context, sourceFilePath: String, isAudio: Boolean): Result<String> {
        return try {
            val sourceFile = File(sourceFilePath)
            if (!sourceFile.exists() || sourceFile.length() == 0L) {
                return Result.failure(IllegalStateException("الملف غير موجود."))
            }

            val filename = sourceFile.name
            val mimeType = if (isAudio) "audio/mpeg" else "video/mp4"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val collection = if (isAudio) {
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }

                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        if (isAudio) Environment.DIRECTORY_MUSIC + "/Substack"
                        else Environment.DIRECTORY_MOVIES + "/Substack"
                    )
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val itemUri = resolver.insert(collection, values)
                    ?: return Result.failure(IllegalStateException("فشل إنشاء ملف MediaStore جديد."))

                resolver.openOutputStream(itemUri).use { out ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(out ?: throw IllegalStateException("فشل فتح مخرج الكتابة."))
                    }
                }

                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)

                Result.success("تم تصدير الملف بنجاح إلى المعرض العام.")
            } else {
                val publicDir = if (isAudio) {
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
                } else {
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                }
                val substackDir = File(publicDir, "Substack")
                if (!substackDir.exists()) substackDir.mkdirs()

                val destFile = File(substackDir, filename)
                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(destFile).use { out ->
                        input.copyTo(out)
                    }
                }
                Result.success("تم تصدير الملف إلى: ${destFile.absolutePath}")
            }
        } catch (e: Exception) {
            SecurityLogger.e("Export to gallery failed", e)
            Result.failure(e)
        }
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0

        return when {
            gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.0f KB", kb)
            else -> "$bytes B"
        }
    }

    fun formatDuration(seconds: Double?): String {
        if (seconds == null || seconds <= 0) return ""
        val sec = seconds.toLong()
        val m = sec / 60
        val s = sec % 60
        val h = m / 60
        return if (h > 0) {
            String.format(Locale.US, "%d:%02d:%02d", h, m % 60, s)
        } else {
            String.format(Locale.US, "%02d:%02d", m, s)
        }
    }

    fun formatDate(epochMillis: Long): String {
        if (epochMillis <= 0) return ""
        val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
        return sdf.format(Date(epochMillis))
    }
}
