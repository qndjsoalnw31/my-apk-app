package com.example.ui.util

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.data.model.DownloadItem
import com.example.security.SecurityLogger
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MediaExportHelper {

    const val SUBFOLDER_NAME = "SubstackDownloader"

    /**
     * Checks whether the app currently has the required permission to save files to shared storage.
     * - Android 10+ (API 29+): Returns true because MediaStore allows inserting into
     *   Download, Movies, Pictures, and Music without runtime storage permissions.
     * - Android 9 and below (API 24..28): Requires WRITE_EXTERNAL_STORAGE at runtime.
     */
    fun hasStoragePermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            true
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun shareFile(context: Context, filePath: String, mimeType: String = "video/*") {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                SecurityLogger.w("Cannot share non-existing file: $filePath")
                return
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الوسائط عبر").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            SecurityLogger.e("Share file failed", e)
        }
    }

    fun shareMultipleFiles(context: Context, filePaths: List<String>) {
        try {
            val uris = ArrayList<Uri>()
            for (path in filePaths) {
                val file = File(path)
                if (file.exists()) {
                    uris.add(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
                }
            }

            if (uris.isEmpty()) return

            val shareIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الملفات المحددة").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            SecurityLogger.e("Share multiple failed", e)
        }
    }

    fun openWithExternalApp(context: Context, filePath: String, mimeType: String = "video/*") {
        try {
            val file = File(filePath)
            if (!file.exists()) return

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(viewIntent)
        } catch (e: Exception) {
            SecurityLogger.e("Open external player failed", e)
        }
    }

    /**
     * Automatically saves a downloaded media file into the phone's shared public storage so that:
     * 1. It appears immediately in the "Files" (الملفات) app under `Download/SubstackDownloader`.
     * 2. It appears immediately in the "Gallery" (المعرض) / Photos / Music app under
     *    `Movies/SubstackDownloader`, `Pictures/SubstackDownloader`, or `Music/SubstackDownloader`.
     * 3. If the user selected a custom SAF directory (`customFolderUri`), it also saves into that directory.
     */
    fun saveToPublicSharedStorage(
        context: Context,
        sourceFile: File,
        displayFileName: String = sourceFile.name,
        formatType: String = DownloadItem.FORMAT_VIDEO,
        customFolderUri: String = ""
    ): Result<String> {
        val isAudio = formatType == DownloadItem.FORMAT_AUDIO
        val isImage = formatType == DownloadItem.FORMAT_IMAGE
        return exportFileToSharedStorage(
            context = context,
            sourceFile = sourceFile,
            displayFileName = displayFileName,
            isAudio = isAudio,
            isImage = isImage,
            customFolderUri = customFolderUri
        )
    }

    fun exportToGallery(
        context: Context,
        sourceFilePath: String,
        isAudio: Boolean,
        isImage: Boolean = false
    ): Result<String> {
        val sourceFile = File(sourceFilePath)
        return exportFileToSharedStorage(
            context = context,
            sourceFile = sourceFile,
            displayFileName = sourceFile.name,
            isAudio = isAudio,
            isImage = isImage,
            customFolderUri = ""
        )
    }

    private fun exportFileToSharedStorage(
        context: Context,
        sourceFile: File,
        displayFileName: String,
        isAudio: Boolean,
        isImage: Boolean,
        customFolderUri: String
    ): Result<String> {
        return try {
            if (!sourceFile.exists() || sourceFile.length() == 0L) {
                return Result.failure(IllegalStateException("الملف غير موجود."))
            }

            val mimeType = when {
                isImage -> "image/jpeg"
                isAudio -> "audio/mpeg"
                else -> "video/mp4"
            }

            // 1. If user configured a custom SAF folder via OpenDocumentTree, write to it
            if (customFolderUri.isNotBlank()) {
                try {
                    val treeUri = Uri.parse(customFolderUri)
                    saveToDocumentTree(context, sourceFile, treeUri, displayFileName, mimeType)
                } catch (e: Exception) {
                    SecurityLogger.w("Custom folder SAF write fallback to MediaStore: ${e.message}")
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val nowSeconds = System.currentTimeMillis() / 1000
                val nowMillis = System.currentTimeMillis()

                // A. Insert into Media Gallery Collection (Movies / Pictures / Music) so it appears in Gallery (المعرض)
                val mediaCollection = when {
                    isImage -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    isAudio -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    else -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }
                val mediaRelativePath = when {
                    isImage -> "${Environment.DIRECTORY_PICTURES}/$SUBFOLDER_NAME"
                    isAudio -> "${Environment.DIRECTORY_MUSIC}/$SUBFOLDER_NAME"
                    else -> "${Environment.DIRECTORY_MOVIES}/$SUBFOLDER_NAME"
                }

                val mediaValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, displayFileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, mediaRelativePath)
                    put(MediaStore.MediaColumns.DATE_ADDED, nowSeconds)
                    put(MediaStore.MediaColumns.DATE_MODIFIED, nowSeconds)
                    put(MediaStore.MediaColumns.DATE_TAKEN, nowMillis)
                    put(MediaStore.MediaColumns.SIZE, sourceFile.length())
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                var savedInMediaStore = false
                val mediaUri = resolver.insert(mediaCollection, mediaValues)
                if (mediaUri != null) {
                    try {
                        resolver.openOutputStream(mediaUri)?.use { out ->
                            FileInputStream(sourceFile).use { input ->
                                input.copyTo(out)
                            }
                        }
                        val publishValues = ContentValues().apply {
                            put(MediaStore.MediaColumns.IS_PENDING, 0)
                        }
                        resolver.update(mediaUri, publishValues, null, null)
                        savedInMediaStore = true
                    } catch (e: Exception) {
                        resolver.delete(mediaUri, null, null)
                        SecurityLogger.w("MediaStore gallery write warning: ${e.message}")
                    }
                }

                // B. Also insert into MediaStore.Downloads (Download/SubstackDownloader) so it appears in Files -> Downloads (الملفات -> التنزيلات)
                var savedInDownloads = false
                try {
                    val downloadsCollection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    val downloadValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, displayFileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$SUBFOLDER_NAME")
                        put(MediaStore.MediaColumns.DATE_ADDED, nowSeconds)
                        put(MediaStore.MediaColumns.DATE_MODIFIED, nowSeconds)
                        put(MediaStore.MediaColumns.SIZE, sourceFile.length())
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val downloadUri = resolver.insert(downloadsCollection, downloadValues)
                    if (downloadUri != null) {
                        try {
                            resolver.openOutputStream(downloadUri)?.use { out ->
                                FileInputStream(sourceFile).use { input ->
                                    input.copyTo(out)
                                }
                            }
                            val publishDownloadValues = ContentValues().apply {
                                put(MediaStore.MediaColumns.IS_PENDING, 0)
                            }
                            resolver.update(downloadUri, publishDownloadValues, null, null)
                            savedInDownloads = true
                        } catch (e: Exception) {
                            resolver.delete(downloadUri, null, null)
                            SecurityLogger.w("MediaStore Downloads write warning: ${e.message}")
                        }
                    }
                } catch (e: Exception) {
                    SecurityLogger.w("MediaStore.Downloads collection warning: ${e.message}")
                }

                if (!savedInMediaStore && !savedInDownloads) {
                    return Result.failure(IllegalStateException("فشل حفظ الملف في ذاكرة الهاتف المشتركة."))
                }

                Result.success("تم حفظ الملف في المعرض ومجلد التنزيلات ($SUBFOLDER_NAME).")
            } else {
                // Android 9 (API 28) and below: Direct Public Directory File Write + MediaScanner
                val scannedPaths = mutableListOf<String>()

                // 1. Public Media Directory (Movies / Pictures / Music) for Gallery
                val publicMediaRoot = when {
                    isImage -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    isAudio -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
                    else -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                }
                val publicMediaDir = File(publicMediaRoot, SUBFOLDER_NAME)
                if (!publicMediaDir.exists()) publicMediaDir.mkdirs()
                val mediaDestFile = File(publicMediaDir, displayFileName)
                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(mediaDestFile).use { out ->
                        input.copyTo(out)
                    }
                }
                scannedPaths.add(mediaDestFile.absolutePath)

                // 2. Public Download Directory (Download/SubstackDownloader) for Files app
                try {
                    val publicDownloadsRoot = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val publicDownloadsDir = File(publicDownloadsRoot, SUBFOLDER_NAME)
                    if (!publicDownloadsDir.exists()) publicDownloadsDir.mkdirs()
                    val downloadDestFile = File(publicDownloadsDir, displayFileName)
                    FileInputStream(sourceFile).use { input ->
                        FileOutputStream(downloadDestFile).use { out ->
                            input.copyTo(out)
                        }
                    }
                    scannedPaths.add(downloadDestFile.absolutePath)
                } catch (e: Exception) {
                    SecurityLogger.w("Legacy Downloads folder copy warning: ${e.message}")
                }

                try {
                    MediaScannerConnection.scanFile(
                        context,
                        scannedPaths.toTypedArray(),
                        Array(scannedPaths.size) { mimeType },
                        null
                    )
                } catch (_: Exception) {}

                Result.success("تم حفظ الملف في المعرض ومجلد التنزيلات: ${mediaDestFile.absolutePath}")
            }
        } catch (e: Exception) {
            SecurityLogger.e("Export to shared storage failed", e)
            Result.failure(e)
        }
    }

    private fun saveToDocumentTree(
        context: Context,
        sourceFile: File,
        treeUri: Uri,
        displayFileName: String,
        mimeType: String
    ) {
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
        val targetUri = DocumentsContract.createDocument(
            context.contentResolver,
            parentDocUri,
            mimeType,
            displayFileName
        ) ?: return

        context.contentResolver.openOutputStream(targetUri)?.use { out ->
            FileInputStream(sourceFile).use { input ->
                input.copyTo(out)
            }
        }
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0

        return when {
            gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.0f KB", kb)
            else -> "$bytes B"
        }
    }

    fun formatDuration(seconds: Double?): String {
        if (seconds == null || seconds <= 0) return ""
        val sec = seconds.toLong()
        val m = sec / 60
        val s = sec % 60
        val h = m / 60
        return if (h > 0) {
            String.format(Locale.US, "%d:%02d:%02d", h, m % 60, s)
        } else {
            String.format(Locale.US, "%02d:%02d", m, s)
        }
    }

    fun formatDate(epochMillis: Long): String {
        if (epochMillis <= 0) return ""
        val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
        return sdf.format(Date(epochMillis))
    }
}
