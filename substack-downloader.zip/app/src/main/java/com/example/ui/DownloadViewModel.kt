package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadProgress
import com.example.data.model.NoteDetails
import com.example.repository.DownloadRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface PreviewUiState {
    object Idle : PreviewUiState
    object Loading : PreviewUiState
    data class Success(val noteDetails: NoteDetails) : PreviewUiState
    data class Error(val message: String) : PreviewUiState
}

class DownloadViewModel(application: Application) : AndroidViewModel(application) {

    val repository: DownloadRepository by lazy {
        try {
            DownloadRepository(getApplication())
        } catch (e: Throwable) {
            Log.e("DownloadViewModel", "Error creating repository, initializing safely: ${e.message}")
            DownloadRepository(getApplication())
        }
    }

    val urlInput = MutableStateFlow("")
    val searchQuery = MutableStateFlow("")
    val activeTab = MutableStateFlow(0) // 0 = Downloader, 1 = History

    val previewState = MutableStateFlow<PreviewUiState>(PreviewUiState.Idle)

    val activeProgress: StateFlow<Map<String, DownloadProgress>> by lazy { repository.activeProgress }

    @OptIn(ExperimentalCoroutinesApi::class)
    val downloadsList: StateFlow<List<DownloadItem>> by lazy {
        searchQuery
            .flatMapLatest { query ->
                if (query.isBlank()) {
                    repository.allDownloads
                } else {
                    repository.searchDownloads(query)
                }
            }.stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )
    }


    val selectedVideoForPlayer = MutableStateFlow<DownloadItem?>(null)
    val snackbarMessage = MutableStateFlow<String?>(null)

    fun onUrlInputChanged(newUrl: String) {
        urlInput.value = newUrl
        if (previewState.value !is PreviewUiState.Idle) {
            previewState.value = PreviewUiState.Idle
        }
    }

    fun inspectNoteUrl() {
        val url = urlInput.value.trim()
        if (url.isBlank()) {
            snackbarMessage.value = "الرجاء أدخل رابط Note من Substack أولاً."
            return
        }

        viewModelScope.launch {
            previewState.value = PreviewUiState.Loading
            try {
                val details = repository.resolveNoteUrl(url)
                previewState.value = PreviewUiState.Success(details)
            } catch (e: Exception) {
                previewState.value = PreviewUiState.Error(
                    e.localizedMessage ?: "فشل قراءة بيانات الملاحظة. تأكد من صحة الرابط."
                )
            }
        }
    }

    fun startDownloadFromPreview(
        formatType: String = DownloadItem.FORMAT_VIDEO,
        qualityLabel: String = "1080p HD"
    ) {
        val state = previewState.value
        if (state is PreviewUiState.Success) {
            repository.startDownload(
                scope = viewModelScope,
                url = urlInput.value.trim(),
                noteDetails = state.noteDetails,
                formatType = formatType,
                qualityLabel = qualityLabel
            )
            val formatMsg = if (formatType == DownloadItem.FORMAT_AUDIO) "الصوت (MP3)" else "الفيديو ($qualityLabel)"
            snackbarMessage.value = "تمت إضافة تنزيل $formatMsg وحفظه بالهاتف مباشرة!"
            previewState.value = PreviewUiState.Idle
            urlInput.value = ""
            activeTab.value = 1 // Switch to downloads tab to view progress
        }
    }

    fun startDirectDownload(
        formatType: String = DownloadItem.FORMAT_VIDEO,
        qualityLabel: String = "1080p HD"
    ) {
        val url = urlInput.value.trim()
        if (url.isBlank()) {
            snackbarMessage.value = "الرجاء أدخل رابط Note من Substack."
            return
        }

        repository.startDownload(
            scope = viewModelScope,
            url = url,
            formatType = formatType,
            qualityLabel = qualityLabel
        )
        snackbarMessage.value = "بدأ التنزيل في حافظة الهاتف..."
        urlInput.value = ""
        previewState.value = PreviewUiState.Idle
        activeTab.value = 1
    }

    fun pauseDownload(id: String) {
        repository.pauseDownload(id)
    }

    fun resumeDownload(id: String) {
        repository.resumeDownload(viewModelScope, id)
    }

    fun cancelDownload(id: String) {
        repository.cancelDownload(viewModelScope, id)
    }

    fun deleteDownload(id: String) {
        viewModelScope.launch {
            repository.deleteDownload(id)
            snackbarMessage.value = "تم حذف التنزيل والملف."
        }
    }

    fun playVideo(item: DownloadItem) {
        selectedVideoForPlayer.value = item
    }

    fun closeVideoPlayer() {
        selectedVideoForPlayer.value = null
    }

    fun clearSnackbar() {
        snackbarMessage.value = null
    }
}
