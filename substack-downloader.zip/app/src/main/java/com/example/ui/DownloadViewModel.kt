package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadProgress
import com.example.data.model.NoteDetails
import com.example.data.model.VideoSource
import com.example.data.settings.AppSettings
import com.example.repository.DownloadRepository
import com.example.security.SecurityGuard
import com.example.security.SecurityLogger
import com.example.ui.util.MediaExportHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class InspectionUiState {
    object Idle : InspectionUiState()
    object Loading : InspectionUiState()
    data class Success(val details: NoteDetails) : InspectionUiState()
    data class Error(val message: String) : InspectionUiState()
}

enum class HistorySortOrder {
    DATE_DESC,
    DATE_ASC,
    SIZE_DESC,
    NAME_ASC
}

class DownloadViewModel(application: Application) : AndroidViewModel(application) {

    val repository = DownloadRepository(application)

    // Current navigation tab index: 0=Home, 1=Downloads, 2=Settings
    private val _currentTab = MutableStateFlow(0)
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    fun setCurrentTab(tab: Int) {
        _currentTab.value = tab.coerceIn(0, 2)
    }

    // Downloads Sub-tab: 0=Active, 1=Completed
    private val _downloadsSubTab = MutableStateFlow(0)
    val downloadsSubTab: StateFlow<Int> = _downloadsSubTab.asStateFlow()

    fun setDownloadsSubTab(subTab: Int) {
        _downloadsSubTab.value = subTab.coerceIn(0, 1)
    }

    // Input URL and Inspection
    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _inspectionState = MutableStateFlow<InspectionUiState>(InspectionUiState.Idle)
    val inspectionState: StateFlow<InspectionUiState> = _inspectionState.asStateFlow()

    private val _selectedFormat = MutableStateFlow(DownloadItem.FORMAT_VIDEO)
    val selectedFormat: StateFlow<String> = _selectedFormat.asStateFlow()

    private val _selectedSource = MutableStateFlow<VideoSource?>(null)
    val selectedSource: StateFlow<VideoSource?> = _selectedSource.asStateFlow()

    // Clipboard detection banner
    private val _clipboardUrlDetected = MutableStateFlow<String?>(null)
    val clipboardUrlDetected: StateFlow<String?> = _clipboardUrlDetected.asStateFlow()

    // Active progress map
    val activeProgress: StateFlow<Map<String, DownloadProgress>> = repository.activeProgress

    // Settings
    val appSettings: StateFlow<AppSettings> = repository.settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    // All Downloads from repository
    val allDownloads: StateFlow<List<DownloadItem>> = repository.allDownloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // History filter & sort
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterFormat = MutableStateFlow("ALL") // "ALL", "VIDEO", "AUDIO"
    val filterFormat: StateFlow<String> = _filterFormat.asStateFlow()

    private val _sortOrder = MutableStateFlow(HistorySortOrder.DATE_DESC)
    val sortOrder: StateFlow<HistorySortOrder> = _sortOrder.asStateFlow()

    // Multi selection for History
    private val _selectedItemIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedItemIds: StateFlow<Set<String>> = _selectedItemIds.asStateFlow()

    // Active Video Player Item
    private val _playingItem = MutableStateFlow<DownloadItem?>(null)
    val playingItem: StateFlow<DownloadItem?> = _playingItem.asStateFlow()

    // User Feedback Toast / Snackbar Message
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Filtered & Sorted History Flow
    val filteredHistory: StateFlow<List<DownloadItem>> = combine(
        allDownloads,
        _searchQuery,
        _filterFormat,
        _sortOrder
    ) { downloads, query, format, sort ->
        var list = downloads.filter { it.status == DownloadItem.STATUS_DONE }

        if (format != "ALL") {
            list = list.filter { it.formatType == format }
        }

        if (query.isNotBlank()) {
            val safeQ = query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(safeQ) ||
                        it.author.lowercase().contains(safeQ) ||
                        it.filename.lowercase().contains(safeQ) ||
                        it.description.lowercase().contains(safeQ)
            }
        }

        when (sort) {
            HistorySortOrder.DATE_DESC -> list.sortedByDescending { it.completedAt ?: it.createdAt }
            HistorySortOrder.DATE_ASC -> list.sortedBy { it.completedAt ?: it.createdAt }
            HistorySortOrder.SIZE_DESC -> list.sortedByDescending { it.size }
            HistorySortOrder.NAME_ASC -> list.sortedBy { it.title.lowercase() }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Queue Downloads Flow
    val activeQueueDownloads: StateFlow<List<DownloadItem>> = allDownloads.combine(activeProgress) { downloads, _ ->
        downloads.filter { it.status != DownloadItem.STATUS_DONE }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onUrlChanged(newUrl: String) {
        _urlInput.value = newUrl
        if (_inspectionState.value !is InspectionUiState.Idle) {
            _inspectionState.value = InspectionUiState.Idle
        }
    }

    fun onClipboardDetected(url: String) {
        if (_urlInput.value != url) {
            _clipboardUrlDetected.value = url
        }
    }

    fun dismissClipboardBanner() {
        _clipboardUrlDetected.value = null
    }

    fun useClipboardUrl() {
        val url = _clipboardUrlDetected.value ?: return
        _urlInput.value = url
        _clipboardUrlDetected.value = null
        inspectUrl(url)
    }

    fun setSelectedFormat(format: String) {
        _selectedFormat.value = format
    }

    fun setSelectedSource(source: VideoSource?) {
        _selectedSource.value = source
    }

    fun inspectUrl(urlToInspect: String? = null) {
        val raw = urlToInspect ?: _urlInput.value
        val valid = SecurityGuard.validateAndSanitizeUrl(raw)
        if (valid.isFailure) {
            _inspectionState.value = InspectionUiState.Error(
                valid.exceptionOrNull()?.localizedMessage ?: "الرابط المدخل غير صالح."
            )
            return
        }

        viewModelScope.launch {
            _inspectionState.value = InspectionUiState.Loading
            try {
                val details = repository.resolveNoteUrl(valid.getOrThrow())
                _inspectionState.value = InspectionUiState.Success(details)
                _selectedSource.value = details.videoSources.firstOrNull()
            } catch (e: Throwable) {
                SecurityLogger.e("Inspection error", e)
                val safeMsg = SecurityGuard.sanitizeErrorMessage(e)
                _inspectionState.value = InspectionUiState.Error(safeMsg)
            }
        }
    }

    fun startQuickDownload(urlToDownload: String? = null) {
        val raw = urlToDownload ?: _urlInput.value
        val valid = SecurityGuard.validateAndSanitizeUrl(raw)
        if (valid.isFailure) {
            showSnackbar(valid.exceptionOrNull()?.localizedMessage ?: "الرابط غير صالح.")
            return
        }

        val details = (_inspectionState.value as? InspectionUiState.Success)?.details
        val source = _selectedSource.value
        val format = _selectedFormat.value
        val quality = source?.quality ?: "1080p HD"

        try {
            repository.startDownload(
                scope = viewModelScope,
                url = valid.getOrThrow(),
                customTitle = details?.title,
                noteDetails = details,
                selectedSource = source,
                formatType = format,
                qualityLabel = quality
            )
            showSnackbar("تمت إضافة التنزيل إلى قائمة الانتظار.")
            _urlInput.value = ""
            _inspectionState.value = InspectionUiState.Idle
            _currentTab.value = 1 // Switch to Downloads tab
            _downloadsSubTab.value = 0 // Show Active downloads
        } catch (e: Exception) {
            showSnackbar(SecurityGuard.sanitizeErrorMessage(e))
        }
    }

    fun pauseDownload(id: String) = repository.pauseDownload(id)
    fun resumeDownload(id: String) = repository.resumeDownload(id)
    fun retryDownload(id: String) = repository.retryDownload(id)
    fun cancelDownload(id: String) = repository.cancelDownload(id)
    fun pauseAll() = repository.pauseAll()
    fun resumeAll() = repository.resumeAll()
    fun retryAllFailed() = repository.retryAllFailed()
    fun cancelAll() = repository.cancelAll()

    fun setSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun setFilterFormat(format: String) {
        _filterFormat.value = format
    }

    fun setSortOrder(order: HistorySortOrder) {
        _sortOrder.value = order
    }

    fun toggleItemSelection(id: String) {
        _selectedItemIds.update { set ->
            if (set.contains(id)) set - id else set + id
        }
    }

    fun selectAllHistory() {
        val allDoneIds = filteredHistory.value.map { it.id }.toSet()
        _selectedItemIds.value = allDoneIds
    }

    fun clearSelection() {
        _selectedItemIds.value = emptySet()
    }

    fun deleteSelectedItems() {
        val ids = _selectedItemIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.deleteDownloadsBatch(ids, deleteFilesFromStorage = true)
            clearSelection()
            showSnackbar("تم حذف ${ids.size} عنصر بنجاح.")
        }
    }

    fun deleteSingleItem(id: String) {
        viewModelScope.launch {
            repository.deleteDownload(id, deleteFileFromStorage = true)
            showSnackbar("تم حذف الملف بنجاح.")
        }
    }

    fun renameItem(id: String, newName: String) {
        viewModelScope.launch {
            val ok = repository.renameDownloadFile(id, newName)
            if (ok) {
                showSnackbar("تمت إعادة تسمية الملف.")
            } else {
                showSnackbar("فشلت إعادة التسمية. تأكد من صحة الاسم.")
            }
        }
    }

    fun playItem(item: DownloadItem) {
        _playingItem.value = item
    }

    fun closePlayer() {
        _playingItem.value = null
    }

    fun exportItemToGallery(item: DownloadItem) {
        val res = MediaExportHelper.exportToGallery(
            getApplication(),
            item.filePath,
            item.formatType == DownloadItem.FORMAT_AUDIO
        )
        if (res.isSuccess) {
            showSnackbar(res.getOrNull() ?: "تم تصدير الملف إلى المعرض بنجاح.")
        } else {
            showSnackbar("فشل تصدير الملف: ${res.exceptionOrNull()?.localizedMessage}")
        }
    }

    fun shareItem(item: DownloadItem) {
        MediaExportHelper.shareFile(
            getApplication(),
            item.filePath,
            if (item.formatType == DownloadItem.FORMAT_AUDIO) "audio/*" else "video/*"
        )
    }

    fun shareSelectedItems() {
        val paths = filteredHistory.value
            .filter { _selectedItemIds.value.contains(it.id) && it.filePath.isNotBlank() }
            .map { it.filePath }
        if (paths.isNotEmpty()) {
            MediaExportHelper.shareMultipleFiles(getApplication(), paths)
        }
    }

    fun openExternal(item: DownloadItem) {
        MediaExportHelper.openWithExternalApp(
            getApplication(),
            item.filePath,
            if (item.formatType == DownloadItem.FORMAT_AUDIO) "audio/*" else "video/*"
        )
    }

    // Settings actions
    fun updateTheme(themeMode: String) {
        viewModelScope.launch { repository.settingsRepository.updateThemeMode(themeMode) }
    }

    fun updateLanguage(lang: String) {
        viewModelScope.launch { repository.settingsRepository.updateLanguage(lang) }
    }

    fun updateDefaultQuality(quality: String) {
        viewModelScope.launch { repository.settingsRepository.updateDefaultQuality(quality) }
    }

    fun updateConcurrentDownloads(limit: Int) {
        viewModelScope.launch { repository.settingsRepository.updateConcurrentDownloads(limit) }
    }

    fun updateAutoRetry(enabled: Boolean) {
        viewModelScope.launch { repository.settingsRepository.updateAutoRetry(enabled) }
    }

    fun updateAutoClipboard(enabled: Boolean) {
        viewModelScope.launch { repository.settingsRepository.updateAutoClipboard(enabled) }
    }

    fun updateWifiOnly(enabled: Boolean) {
        viewModelScope.launch { repository.settingsRepository.updateWifiOnly(enabled) }
    }

    fun updateNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.settingsRepository.updateNotificationsEnabled(enabled) }
    }

    fun clearCompletedHistory() {
        viewModelScope.launch {
            repository.clearCompletedHistory()
            showSnackbar("تم مسح سجل التنزيلات المكتملة.")
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
            showSnackbar("تم مسح السجل بالكامل.")
        }
    }

    fun showSnackbar(msg: String) {
        _snackbarMessage.value = msg
    }

    fun dismissSnackbar() {
        _snackbarMessage.value = null
    }
}
