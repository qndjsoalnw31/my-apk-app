package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadProgress
import com.example.data.model.NoteDetails
import com.example.data.model.VideoSource
import com.example.data.settings.AppSettings
import com.example.network.TikTokParser
import com.example.repository.DownloadRepository
import com.example.security.SecurityGuard
import com.example.security.SecurityLogger
import com.example.ui.util.MediaExportHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class InspectionUiState {
    object Idle : InspectionUiState()
    object Loading : InspectionUiState()
    data class Success(val details: NoteDetails) : InspectionUiState()
    data class Error(val message: String) : InspectionUiState()
}

enum class PlatformMode {
    SUBSTACK,
    TIKTOK
}

enum class HistorySortOrder {
    DATE_DESC,
    DATE_ASC,
    SIZE_DESC,
    NAME_ASC
}

class DownloadViewModel(application: Application) : AndroidViewModel(application) {

    val repository = DownloadRepository(application)

    // Current navigation tab index: 0=Home, 1=Downloads, 2=Settings
    private val _currentTab = MutableStateFlow(0)
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    fun setCurrentTab(tab: Int) {
        _currentTab.value = tab.coerceIn(0, 2)
    }

    // Downloads Sub-tab: 0=Active, 1=Completed
    private val _downloadsSubTab = MutableStateFlow(0)
    val downloadsSubTab: StateFlow<Int> = _downloadsSubTab.asStateFlow()

    fun setDownloadsSubTab(subTab: Int) {
        _downloadsSubTab.value = subTab.coerceIn(0, 1)
    }

    // Platform mode: Substack (Main App) or TikTok Downloader
    private val _platformMode = MutableStateFlow(PlatformMode.SUBSTACK)
    val platformMode: StateFlow<PlatformMode> = _platformMode.asStateFlow()

    fun setPlatformMode(mode: PlatformMode) {
        _platformMode.value = mode
    }

    // Input URL and Inspection
    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _inspectionState = MutableStateFlow<InspectionUiState>(InspectionUiState.Idle)
    val inspectionState: StateFlow<InspectionUiState> = _inspectionState.asStateFlow()

    private val _selectedFormat = MutableStateFlow(DownloadItem.FORMAT_VIDEO)
    val selectedFormat: StateFlow<String> = _selectedFormat.asStateFlow()

    private val _selectedSource = MutableStateFlow<VideoSource?>(null)
    val selectedSource: StateFlow<VideoSource?> = _selectedSource.asStateFlow()

    // Clipboard detection banner
    private val _clipboardUrlDetected = MutableStateFlow<String?>(null)
    val clipboardUrlDetected: StateFlow<String?> = _clipboardUrlDetected.asStateFlow()

    // Active progress map
    val activeProgress: StateFlow<Map<String, DownloadProgress>> = repository.activeProgress

    // Settings - In-memory reactive state with DataStore persistence
    private val _appSettings = MutableStateFlow(AppSettings())
    val appSettings: StateFlow<AppSettings> = _appSettings.asStateFlow()

    init {
        viewModelScope.launch {
            repository.settingsRepository.settingsFlow.collect { storedSettings ->
                _appSettings.value = storedSettings
            }
        }
    }

    // All Downloads from repository
    val allDownloads: StateFlow<List<DownloadItem>> = repository.allDownloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // History filter & sort
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterFormat = MutableStateFlow("ALL") // "ALL", "VIDEO", "AUDIO"
    val filterFormat: StateFlow<String> = _filterFormat.asStateFlow()

    private val _sortOrder = MutableStateFlow(HistorySortOrder.DATE_DESC)
    val sortOrder: StateFlow<HistorySortOrder> = _sortOrder.asStateFlow()

    // Multi selection for History
    private val _selectedItemIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedItemIds: StateFlow<Set<String>> = _selectedItemIds.asStateFlow()

    // Active Video Player Item
    private val _playingItem = MutableStateFlow<DownloadItem?>(null)
    val playingItem: StateFlow<DownloadItem?> = _playingItem.asStateFlow()

    // User Feedback Toast / Snackbar Message
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Filtered & Sorted History Flow
    val filteredHistory: StateFlow<List<DownloadItem>> = combine(
        allDownloads,
        _searchQuery,
        _filterFormat,
        _sortOrder
    ) { downloads, query, format, sort ->
        var list = downloads.filter { it.status == DownloadItem.STATUS_DONE }

        if (format != "ALL") {
            list = list.filter { it.formatType == format }
        }

        if (query.isNotBlank()) {
            val safeQ = query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(safeQ) ||
                        it.author.lowercase().contains(safeQ) ||
                        it.filename.lowercase().contains(safeQ) ||
                        it.description.lowercase().contains(safeQ)
            }
        }

        when (sort) {
            HistorySortOrder.DATE_DESC -> list.sortedByDescending { it.completedAt ?: it.createdAt }
            HistorySortOrder.DATE_ASC -> list.sortedBy { it.completedAt ?: it.createdAt }
            HistorySortOrder.SIZE_DESC -> list.sortedByDescending { it.size }
            HistorySortOrder.NAME_ASC -> list.sortedBy { it.title.lowercase() }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Queue Downloads Flow
    val activeQueueDownloads: StateFlow<List<DownloadItem>> = allDownloads.combine(activeProgress) { downloads, _ ->
        downloads.filter { it.status != DownloadItem.STATUS_DONE }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onUrlChanged(newUrl: String) {
        _urlInput.value = newUrl
        if (TikTokParser.isTikTokUrl(newUrl)) {
            _platformMode.value = PlatformMode.TIKTOK
        } else if (newUrl.contains("substack", ignoreCase = true)) {
            _platformMode.value = PlatformMode.SUBSTACK
        }
        if (_inspectionState.value !is InspectionUiState.Idle) {
            _inspectionState.value = InspectionUiState.Idle
        }
    }

    fun onClipboardDetected(url: String) {
        if (_urlInput.value != url) {
            _clipboardUrlDetected.value = url
            if (TikTokParser.isTikTokUrl(url)) {
                _platformMode.value = PlatformMode.TIKTOK
            }
        }
    }

    fun dismissClipboardBanner() {
        _clipboardUrlDetected.value = null
    }

    fun useClipboardUrl() {
        val url = _clipboardUrlDetected.value ?: return
        _urlInput.value = url
        _clipboardUrlDetected.value = null
        inspectUrl(url)
    }

    fun setSelectedFormat(format: String) {
        _selectedFormat.value = format
    }

    fun setSelectedSource(source: VideoSource?) {
        _selectedSource.value = source
    }

    fun inspectUrl(urlToInspect: String? = null) {
        val raw = urlToInspect ?: _urlInput.value
        val valid = SecurityGuard.validateAndSanitizeUrl(raw)
        if (valid.isFailure) {
            _inspectionState.value = InspectionUiState.Error(
                valid.exceptionOrNull()?.localizedMessage ?: "الرابط المدخل غير صالح."
            )
            return
        }

        viewModelScope.launch {
            _inspectionState.value = InspectionUiState.Loading
            try {
                val details = repository.resolveNoteUrl(valid.getOrThrow())
                _inspectionState.value = InspectionUiState.Success(details)
                val defaultQual = appSettings.value.defaultQuality
                val preferredSource = if (defaultQual == "audio" || _selectedFormat.value == DownloadItem.FORMAT_AUDIO) {
                    details.videoSources.firstOrNull { it.type == "audio" }
                } else if (defaultQual != "auto") {
                    details.videoSources.firstOrNull { it.quality.contains(defaultQual, ignoreCase = true) }
                } else null
                _selectedSource.value = preferredSource ?: details.videoSources.firstOrNull()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                SecurityLogger.e("Inspection error", e)
                val safeMsg = SecurityGuard.sanitizeErrorMessage(e)
                _inspectionState.value = InspectionUiState.Error(safeMsg)
            }
        }
    }

    fun startQuickDownload(urlToDownload: String? = null) {
        val raw = urlToDownload ?: _urlInput.value
        val valid = SecurityGuard.validateAndSanitizeUrl(raw)
        if (valid.isFailure) {
            showSnackbar(valid.exceptionOrNull()?.localizedMessage ?: "الرابط غير صالح.")
            return
        }

        val details = (_inspectionState.value as? InspectionUiState.Success)?.details
        val format = _selectedFormat.value
        val defaultQual = appSettings.value.defaultQuality
        val source = _selectedSource.value ?: run {
            if (format == DownloadItem.FORMAT_AUDIO || defaultQual == "audio") {
                details?.videoSources?.firstOrNull { it.type == "audio" }
            } else if (defaultQual != "auto") {
                details?.videoSources?.firstOrNull { it.quality.contains(defaultQual, ignoreCase = true) }
            } else null
        } ?: details?.videoSources?.firstOrNull()

        val quality = source?.quality ?: when (defaultQual) {
            "720p" -> "720p HD"
            "480p" -> "480p SD"
            "360p" -> "360p"
            "audio" -> "Audio MP3"
            else -> "1080p HD"
        }

        try {
            repository.startDownload(
                scope = viewModelScope,
                url = valid.getOrThrow(),
                customTitle = details?.title,
                noteDetails = details,
                selectedSource = source,
                formatType = format,
                qualityLabel = quality
            )
            showSnackbar("تمت إضافة التنزيل إلى قائمة الانتظار.")
            _urlInput.value = ""
            _inspectionState.value = InspectionUiState.Idle
            _currentTab.value = 1 // Switch to Downloads tab
            _downloadsSubTab.value = 0 // Show Active downloads
        } catch (e: Exception) {
            showSnackbar(SecurityGuard.sanitizeErrorMessage(e))
        }
    }

    fun pauseDownload(id: String) = repository.pauseDownload(id)
    fun resumeDownload(id: String) = repository.resumeDownload(id)
    fun retryDownload(id: String) = repository.retryDownload(id)
    fun cancelDownload(id: String) = repository.cancelDownload(id)
    fun pauseAll() = repository.pauseAll()
    fun resumeAll() = repository.resumeAll()
    fun retryAllFailed() = repository.retryAllFailed()
    fun cancelAll() = repository.cancelAll()

    fun setSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun setFilterFormat(format: String) {
        _filterFormat.value = format
    }

    fun setSortOrder(order: HistorySortOrder) {
        _sortOrder.value = order
    }

    fun toggleItemSelection(id: String) {
        _selectedItemIds.update { set ->
            if (set.contains(id)) set - id else set + id
        }
    }

    fun selectAllHistory() {
        val allDoneIds = filteredHistory.value.map { it.id }.toSet()
        _selectedItemIds.value = allDoneIds
    }

    fun clearSelection() {
        _selectedItemIds.value = emptySet()
    }

    fun deleteSelectedItems() {
        val ids = _selectedItemIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.deleteDownloadsBatch(ids, deleteFilesFromStorage = true)
            clearSelection()
            showSnackbar("تم حذف ${ids.size} عنصر بنجاح.")
        }
    }

    fun deleteSingleItem(id: String) {
        viewModelScope.launch {
            repository.deleteDownload(id, deleteFileFromStorage = true)
            showSnackbar("تم حذف الملف بنجاح.")
        }
    }

    fun renameItem(id: String, newName: String) {
        viewModelScope.launch {
            val ok = repository.renameDownloadFile(id, newName)
            if (ok) {
                showSnackbar("تمت إعادة تسمية الملف.")
            } else {
                showSnackbar("فشلت إعادة التسمية. تأكد من صحة الاسم.")
            }
        }
    }

    fun downloadSingleImage(imageUrl: String, title: String, index: Int? = null) {
        val valid = SecurityGuard.validateAndSanitizeUrl(imageUrl)
        if (valid.isFailure) {
            showSnackbar("رابط الصورة غير صالح.")
            return
        }
        val details = (_inspectionState.value as? InspectionUiState.Success)?.details
        val imageTitle = if (index != null) "$title - $index" else title
        val imageSource = VideoSource(
            type = "image",
            quality = "صورة أصلية",
            url = valid.getOrThrow(),
            mimeType = "image/jpeg",
            isHls = false
        )
        try {
            repository.startDownload(
                scope = viewModelScope,
                url = valid.getOrThrow(),
                customTitle = imageTitle,
                noteDetails = details,
                selectedSource = imageSource,
                formatType = DownloadItem.FORMAT_IMAGE,
                qualityLabel = "أعلى جودة"
            )
            showSnackbar("تم بدء تنزيل الصورة.")
            _currentTab.value = 1
            _downloadsSubTab.value = 0
        } catch (e: Exception) {
            showSnackbar(SecurityGuard.sanitizeErrorMessage(e))
        }
    }

    fun downloadAllImages(details: NoteDetails) {
        if (details.imageUrls.isEmpty()) {
            showSnackbar("لا توجد صور للتنزيل.")
            return
        }
        var count = 0
        details.imageUrls.forEachIndexed { idx, imgUrl ->
            val valid = SecurityGuard.validateAndSanitizeUrl(imgUrl)
            if (valid.isSuccess) {
                val imageTitle = "${details.title} - ${idx + 1}"
                val imageSource = VideoSource(
                    type = "image",
                    quality = "صورة أصلية",
                    url = valid.getOrThrow(),
                    mimeType = "image/jpeg",
                    isHls = false
                )
                repository.startDownload(
                    scope = viewModelScope,
                    url = valid.getOrThrow(),
                    customTitle = imageTitle,
                    noteDetails = details,
                    selectedSource = imageSource,
                    formatType = DownloadItem.FORMAT_IMAGE,
                    qualityLabel = "أعلى جودة"
                )
                count++
            }
        }
        showSnackbar("تمت إضافة $count صورة إلى قائمة التنزيل.")
        _currentTab.value = 1
        _downloadsSubTab.value = 0
    }

    fun playItem(item: DownloadItem) {
        _playingItem.value = item
    }

    fun closePlayer() {
        _playingItem.value = null
    }

    fun exportItemToGallery(item: DownloadItem) {
        val res = MediaExportHelper.exportToGallery(
            getApplication(),
            item.filePath,
            item.formatType == DownloadItem.FORMAT_AUDIO,
            item.formatType == DownloadItem.FORMAT_IMAGE
        )
        if (res.isSuccess) {
            showSnackbar(res.getOrNull() ?: "تم تصدير الملف إلى المعرض بنجاح.")
        } else {
            showSnackbar("فشل تصدير الملف: ${res.exceptionOrNull()?.localizedMessage}")
        }
    }

    fun shareItem(item: DownloadItem) {
        val mime = when (item.formatType) {
            DownloadItem.FORMAT_IMAGE -> "image/*"
            DownloadItem.FORMAT_AUDIO -> "audio/*"
            else -> "video/*"
        }
        MediaExportHelper.shareFile(
            getApplication(),
            item.filePath,
            mime
        )
    }

    fun shareSelectedItems() {
        val paths = filteredHistory.value
            .filter { _selectedItemIds.value.contains(it.id) && it.filePath.isNotBlank() }
            .map { it.filePath }
        if (paths.isNotEmpty()) {
            MediaExportHelper.shareMultipleFiles(getApplication(), paths)
        }
    }

    fun openExternal(item: DownloadItem) {
        MediaExportHelper.openWithExternalApp(
            getApplication(),
            item.filePath,
            if (item.formatType == DownloadItem.FORMAT_AUDIO) "audio/*" else "video/*"
        )
    }

    // Settings actions
    fun updateTheme(themeMode: String) {
        _appSettings.update { it.copy(themeMode = themeMode) }
        viewModelScope.launch { repository.settingsRepository.updateThemeMode(themeMode) }
    }

    fun updateLanguage(lang: String) {
        val sanitized = if (lang.equals("en", ignoreCase = true)) "en" else "ar"
        _appSettings.update { it.copy(language = sanitized) }
        viewModelScope.launch { repository.settingsRepository.updateLanguage(sanitized) }
    }

    fun updateDefaultQuality(quality: String) {
        _appSettings.update { it.copy(defaultQuality = quality) }
        viewModelScope.launch { repository.settingsRepository.updateDefaultQuality(quality) }
    }

    fun updateConcurrentDownloads(limit: Int) {
        _appSettings.update { it.copy(concurrentDownloads = limit.coerceIn(1, 3)) }
        viewModelScope.launch { repository.settingsRepository.updateConcurrentDownloads(limit) }
    }

    fun updateAutoRetry(enabled: Boolean) {
        _appSettings.update { it.copy(autoRetry = enabled) }
        viewModelScope.launch { repository.settingsRepository.updateAutoRetry(enabled) }
    }

    fun updateAutoClipboard(enabled: Boolean) {
        _appSettings.update { it.copy(autoClipboard = enabled) }
        viewModelScope.launch { repository.settingsRepository.updateAutoClipboard(enabled) }
    }

    fun updateWifiOnly(enabled: Boolean) {
        _appSettings.update { it.copy(wifiOnly = enabled) }
        viewModelScope.launch { repository.settingsRepository.updateWifiOnly(enabled) }
    }

    fun updateNotificationsEnabled(enabled: Boolean) {
        _appSettings.update { it.copy(notificationsEnabled = enabled) }
        viewModelScope.launch { repository.settingsRepository.updateNotificationsEnabled(enabled) }
    }

    fun clearCompletedHistory() {
        viewModelScope.launch {
            repository.clearCompletedHistory()
            showSnackbar("تم مسح سجل التنزيلات المكتملة.")
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
            showSnackbar("تم مسح السجل بالكامل.")
        }
    }

    fun showSnackbar(msg: String) {
        _snackbarMessage.value = msg
    }

    fun dismissSnackbar() {
        _snackbarMessage.value = null
    }
}
