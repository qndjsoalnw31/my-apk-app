package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.DownloadViewModel
import com.example.ui.theme.SubstackBackground
import com.example.ui.theme.SubstackBorder
import com.example.ui.theme.SubstackOrange
import com.example.ui.theme.SubstackPanel
import com.example.ui.theme.SubstackPanelVariant
import com.example.ui.theme.SubstackRed
import com.example.ui.theme.SubstackTextMuted
import com.example.ui.theme.SubstackTextPrimary
import com.example.ui.theme.SubstackTextSubtle
import com.example.ui.util.LocalAppStrings

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(viewModel: DownloadViewModel) {
    val strings = LocalAppStrings.current
    val settings by viewModel.appSettings.collectAsState()
    val scrollState = rememberScrollState()

    var showClearHistoryDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showLicensesDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SubstackBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        // Screen Title
        Text(
            text = strings.navSettings,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = SubstackTextPrimary,
            letterSpacing = (-0.5).sp
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Section: Appearance & Preferences
        SettingsSectionTitle(title = strings.sectionAppearance)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SubstackPanel),
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Language Selection (Arabic / English)
                Text(
                    text = strings.labelLanguage,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SubstackTextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val languages = listOf("en" to strings.langEnglish, "ar" to strings.langArabic)
                    languages.forEach { (code, label) ->
                        val isSelected = settings.language == code
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.updateLanguage(code) },
                            label = { Text(label, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            shape = RoundedCornerShape(10.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SubstackOrange.copy(alpha = 0.2f),
                                selectedLabelColor = SubstackOrange,
                                containerColor = SubstackPanelVariant,
                                labelColor = SubstackTextMuted
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) SubstackOrange else SubstackBorder
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Theme Selection
                Text(
                    text = strings.labelAppTheme,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SubstackTextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val themes = listOf(
                        "system" to strings.themeSystem,
                        "dark" to strings.themeDark,
                        "light" to strings.themeLight
                    )
                    themes.forEach { (mode, label) ->
                        val isSelected = settings.themeMode == mode
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.updateTheme(mode) },
                            label = { Text(label, fontSize = 12.sp) },
                            shape = RoundedCornerShape(10.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SubstackOrange.copy(alpha = 0.2f),
                                selectedLabelColor = SubstackOrange,
                                containerColor = SubstackPanelVariant,
                                labelColor = SubstackTextMuted
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) SubstackOrange else SubstackBorder
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Default Quality
                Text(
                    text = strings.labelDefaultQuality,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SubstackTextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val qualities = listOf(
                        "auto" to strings.qualityAuto,
                        "1080p" to strings.quality1080p,
                        "720p" to strings.quality720p,
                        "480p" to strings.quality480p,
                        "audio" to strings.qualityAudioOnly
                    )
                    qualities.forEach { (key, label) ->
                        val isSelected = settings.defaultQuality == key
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.updateDefaultQuality(key) },
                            label = { Text(label, fontSize = 12.sp) },
                            shape = RoundedCornerShape(10.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SubstackOrange.copy(alpha = 0.2f),
                                selectedLabelColor = SubstackOrange,
                                containerColor = SubstackPanelVariant,
                                labelColor = SubstackTextMuted
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) SubstackOrange else SubstackBorder
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Section: Network & Engine
        SettingsSectionTitle(title = strings.sectionNetwork)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SubstackPanel),
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Wi-Fi Only Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.labelWifiOnly,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SubstackTextPrimary
                        )
                        Text(
                            text = strings.descWifiOnly,
                            fontSize = 12.sp,
                            color = SubstackTextMuted
                        )
                    }
                    Switch(
                        checked = settings.wifiOnly,
                        onCheckedChange = { viewModel.updateWifiOnly(it) },
                        colors = customSwitchColors()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Auto Retry Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.labelAutoRetry,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SubstackTextPrimary
                        )
                        Text(
                            text = strings.descAutoRetry,
                            fontSize = 12.sp,
                            color = SubstackTextMuted
                        )
                    }
                    Switch(
                        checked = settings.autoRetry,
                        onCheckedChange = { viewModel.updateAutoRetry(it) },
                        colors = customSwitchColors()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Concurrent Downloads Limit (1..3)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.labelConcurrentDownloads,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SubstackTextPrimary
                        )
                        Text(
                            text = strings.descConcurrentDownloads,
                            fontSize = 12.sp,
                            color = SubstackTextMuted
                        )
                    }

                    SingleChoiceSegmentedButtonRow {
                        listOf(1, 2, 3).forEachIndexed { index, count ->
                            SegmentedButton(
                                selected = settings.concurrentDownloads == count,
                                onClick = { viewModel.updateConcurrentDownloads(count) },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = 3),
                                colors = SegmentedButtonDefaults.colors(
                                    activeContainerColor = SubstackOrange.copy(alpha = 0.2f),
                                    activeContentColor = SubstackOrange,
                                    inactiveContainerColor = SubstackPanelVariant,
                                    inactiveContentColor = SubstackTextMuted,
                                    activeBorderColor = SubstackOrange,
                                    inactiveBorderColor = SubstackBorder
                                )
                            ) {
                                Text("$count", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Clipboard Auto-Detection Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.labelAutoClipboard,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SubstackTextPrimary
                        )
                        Text(
                            text = strings.descAutoClipboard,
                            fontSize = 12.sp,
                            color = SubstackTextMuted
                        )
                    }
                    Switch(
                        checked = settings.autoClipboard,
                        onCheckedChange = { viewModel.updateAutoClipboard(it) },
                        colors = customSwitchColors()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Notifications Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.labelNotifications,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SubstackTextPrimary
                        )
                        Text(
                            text = strings.descNotifications,
                            fontSize = 12.sp,
                            color = SubstackTextMuted
                        )
                    }
                    Switch(
                        checked = settings.notificationsEnabled,
                        onCheckedChange = { viewModel.updateNotificationsEnabled(it) },
                        colors = customSwitchColors()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Section: Storage & History
        SettingsSectionTitle(title = strings.sectionStorage)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SubstackPanel),
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = null,
                        tint = SubstackOrange,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = strings.labelDownloadStorage,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SubstackTextPrimary
                        )
                        Text(
                            text = strings.descDownloadStorage,
                            fontSize = 12.sp,
                            color = SubstackTextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.clearCompletedHistory() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CleaningServices,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = SubstackTextMuted
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.btnCleanHistory, fontSize = 12.sp, color = SubstackTextPrimary)
                    }

                    OutlinedButton(
                        onClick = { showClearHistoryDialog = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = SubstackRed
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.btnClearAll, fontSize = 12.sp, color = SubstackRed)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Section: About & Privacy
        SettingsSectionTitle(title = strings.sectionAbout)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SubstackPanel),
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, SubstackBorder, RoundedCornerShape(12.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.app_logo_exact_1788333333093),
                            contentDescription = "App Logo",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Substack Downloader",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = SubstackTextPrimary
                        )
                        Text(
                            text = strings.appVersionLabel,
                            fontSize = 12.sp,
                            color = SubstackOrange
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { showPrivacyDialog = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = SubstackOrange
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.btnPrivacyPolicy, fontSize = 12.sp, color = SubstackTextPrimary)
                    }

                    OutlinedButton(
                        onClick = { showLicensesDialog = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = SubstackTextMuted
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.btnLicenses, fontSize = 12.sp, color = SubstackTextPrimary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Telegram link on the last line
        val uriHandler = LocalUriHandler.current
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                    try {
                        uriHandler.openUri("https://t.me/TSSTTl")
                    } catch (_: Exception) {}
                }
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Telegram: ",
                fontSize = 13.sp,
                color = SubstackTextMuted
            )
            Text(
                text = "@TSSTTl",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = SubstackOrange,
                textDecoration = TextDecoration.Underline
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
    }

    // Clear All Dialog
    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = { Text(strings.dialogClearHistoryTitle, color = SubstackTextPrimary) },
            text = { Text(strings.dialogClearHistoryMessage, color = SubstackTextMuted) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllHistory()
                        showClearHistoryDialog = false
                    }
                ) {
                    Text(strings.btnClear, color = SubstackRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text(strings.btnCancel, color = SubstackTextMuted)
                }
            }
        )
    }

    // Privacy Policy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text(strings.dialogPrivacyTitle, color = SubstackTextPrimary) },
            text = {
                Column {
                    strings.dialogPrivacyContent.forEach { item ->
                        Text(item, fontSize = 13.sp, color = SubstackTextMuted)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text(strings.btnGotIt, color = SubstackOrange)
                }
            }
        )
    }

    // Open Source Licenses Dialog
    if (showLicensesDialog) {
        AlertDialog(
            onDismissRequest = { showLicensesDialog = false },
            title = { Text(strings.dialogLicensesTitle, color = SubstackTextPrimary) },
            text = {
                Column {
                    strings.dialogLicensesContent.forEach { item ->
                        Text(item, fontSize = 13.sp, color = SubstackTextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLicensesDialog = false }) {
                    Text(strings.btnClose, color = SubstackOrange)
                }
            }
        )
    }
}

@Composable
fun SettingsSectionTitle(title: String) {
    Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = SubstackOrange,
        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
    )
}

@Composable
private fun customSwitchColors() = SwitchDefaults.colors(
    checkedThumbColor = Color.White,
    checkedTrackColor = SubstackOrange,
    uncheckedThumbColor = SubstackTextMuted,
    uncheckedTrackColor = SubstackPanelVariant,
    uncheckedBorderColor = SubstackBorder
)
