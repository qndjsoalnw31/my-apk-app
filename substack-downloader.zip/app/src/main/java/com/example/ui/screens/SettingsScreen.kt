package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.DownloadViewModel
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.SubstackBackground
import com.example.ui.theme.SubstackBorder
import com.example.ui.theme.SubstackPanel
import com.example.ui.theme.SubstackPanelVariant
import com.example.ui.theme.SubstackTextMuted
import com.example.ui.theme.SubstackTextPrimary
import com.example.ui.theme.SubstackTextSubtle
import com.example.ui.util.LocalAppStrings

@Composable
fun SettingsScreen(viewModel: DownloadViewModel) {
    var isShowingAboutScreen by remember { mutableStateOf(false) }

    if (isShowingAboutScreen) {
        AboutAppScreen(onBack = { isShowingAboutScreen = false })
    } else {
        MainSettingsContent(
            viewModel = viewModel,
            onNavigateToAbout = { isShowingAboutScreen = true }
        )
    }
}

/**
 * Screen 6: "الإعدادات" / Settings Screen
 */
@Composable
fun MainSettingsContent(
    viewModel: DownloadViewModel,
    onNavigateToAbout: () -> Unit
) {
    val strings = LocalAppStrings.current
    val settings by viewModel.appSettings.collectAsState()
    val scrollState = rememberScrollState()

    var showLanguageDialog by remember { mutableStateOf(false) }
    var autoClearOnFinish by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SubstackBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        // Title
        Text(
            text = strings.settingsTitle,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = SubstackTextPrimary
        )

        Spacer(modifier = Modifier.height(18.dp))

        // SECTION 1: Appearance
        Text(
            text = strings.sectionAppearance,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = SubstackTextMuted,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SubstackPanel),
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
        ) {
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                // Option 1: Light Mode
                ThemeRadioRow(
                    icon = Icons.Default.LightMode,
                    title = strings.themeLight,
                    isSelected = settings.themeMode == "light",
                    onClick = { viewModel.updateTheme("light") }
                )

                // Option 2: Dark Mode
                ThemeRadioRow(
                    icon = Icons.Default.DarkMode,
                    title = strings.themeDark,
                    isSelected = settings.themeMode == "dark",
                    onClick = { viewModel.updateTheme("dark") }
                )

                // Option 3: System Auto
                ThemeRadioRow(
                    icon = Icons.Default.AutoAwesome,
                    title = strings.themeSystem,
                    isSelected = settings.themeMode == "system",
                    onClick = { viewModel.updateTheme("system") }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 2: General
        Text(
            text = strings.sectionGeneral,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = SubstackTextMuted,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SubstackPanel),
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
        ) {
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                // Item 1: Download Folder
                SettingsClickableRow(
                    icon = Icons.Default.Folder,
                    title = strings.folderLabel,
                    subtitle = "/Download/SubstackDownloader",
                    onClick = { /* Scoped Storage */ }
                )

                // Item 2: Language
                SettingsClickableRow(
                    icon = Icons.Default.Language,
                    title = strings.languageLabel,
                    subtitle = strings.currentLanguageName,
                    onClick = { showLanguageDialog = true }
                )

                // Item 3: Notifications
                SettingsSwitchRow(
                    icon = Icons.Default.Notifications,
                    title = strings.notificationsLabel,
                    subtitle = null,
                    isChecked = settings.notificationsEnabled,
                    onCheckedChange = { viewModel.updateNotificationsEnabled(it) }
                )

                // Item 4: Auto Clear
                SettingsSwitchRow(
                    icon = Icons.Default.CleaningServices,
                    title = strings.autoClearLabel,
                    subtitle = strings.autoClearSubtitle,
                    isChecked = autoClearOnFinish,
                    onCheckedChange = { autoClearOnFinish = it }
                )

                // Item 5: About App
                SettingsClickableRow(
                    icon = Icons.Default.Info,
                    title = strings.aboutLabel,
                    subtitle = strings.versionLabel,
                    onClick = onNavigateToAbout
                )
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    // Language Selection Dialog
    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text(strings.languageDialogTitle, color = SubstackTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.updateLanguage("ar")
                                showLanguageDialog = false
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = settings.language == "ar",
                            onClick = {
                                viewModel.updateLanguage("ar")
                                showLanguageDialog = false
                            },
                            colors = RadioButtonDefaults.colors(selectedColor = BrandBlue)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(strings.langArabic, fontSize = 14.sp, color = SubstackTextPrimary)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.updateLanguage("en")
                                showLanguageDialog = false
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = settings.language == "en",
                            onClick = {
                                viewModel.updateLanguage("en")
                                showLanguageDialog = false
                            },
                            colors = RadioButtonDefaults.colors(selectedColor = BrandBlue)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(strings.langEnglish, fontSize = 14.sp, color = SubstackTextPrimary)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showLanguageDialog = false }) {
                    Text(strings.btnCancel, color = SubstackTextMuted)
                }
            }
        )
    }
}

/**
 * Screen 7: "حول التطبيق" / About App Screen
 */
@Composable
fun AboutAppScreen(onBack: () -> Unit) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var showPrivacyDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SubstackBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        // Header with Back button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = SubstackTextPrimary
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = strings.aboutAppTitle,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = SubstackTextPrimary
            )
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Center Hero: App Logo, Name, Version, Description
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(BrandBlue.copy(alpha = 0.15f))
                    .border(1.dp, BrandBlue.copy(alpha = 0.3f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.app_logo_exact_1788333333093),
                    contentDescription = "Logo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = strings.appTitle,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = SubstackTextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = strings.versionLabel,
                fontSize = 12.sp,
                color = SubstackTextMuted
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = strings.aboutAppDescription,
                fontSize = 13.sp,
                color = SubstackTextMuted,
                modifier = Modifier.padding(horizontal = 16.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Info List Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SubstackPanel),
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
        ) {
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                // Item 1: المطور (@TSSTTl) -> Clickable Telegram link
                AboutInfoRow(
                    icon = Icons.Default.Person,
                    label = strings.developerLabel,
                    value = strings.developerValue,
                    isLink = true,
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/TSSTTl"))
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            try {
                                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://telegram.me/TSSTTl"))
                                context.startActivity(browserIntent)
                            } catch (_: Exception) {}
                        }
                    }
                )

                // Item 2: الموقع (العراق / Iraq)
                AboutInfoRow(
                    icon = Icons.Default.Public,
                    label = strings.locationLabel,
                    value = strings.locationValue
                )

                // Item 3: البريد الإلكتروني (ayrwynsmyth39@gmail.com) -> Clickable Email link
                AboutInfoRow(
                    icon = Icons.Default.Email,
                    label = strings.emailLabel,
                    value = strings.emailValue,
                    isLink = true,
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_SENDTO).apply {
                                data = Uri.parse("mailto:${strings.emailValue}")
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            clipboard?.setPrimaryClip(ClipData.newPlainText("email", strings.emailValue))
                        }
                    }
                )

                // Item 4: سياسة الخصوصية
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showPrivacyDialog = true }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = BrandBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = strings.privacyPolicyLabel,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = SubstackTextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = SubstackTextSubtle,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text(strings.privacyPolicyLabel, color = SubstackTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    strings.privacyPolicyPoints.forEach { point ->
                        Text(point, fontSize = 13.sp, color = SubstackTextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text(strings.btnGotIt, color = BrandBlue)
                }
            }
        )
    }
}

@Composable
fun ThemeRadioRow(
    icon: ImageVector,
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isSelected) BrandBlue else SubstackTextMuted,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = SubstackTextPrimary,
            modifier = Modifier.weight(1f)
        )
        RadioButton(
            selected = isSelected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(
                selectedColor = BrandBlue,
                unselectedColor = SubstackBorder
            )
        )
    }
}

@Composable
fun SettingsClickableRow(
    icon: ImageVector,
    title: String,
    subtitle: String?,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = BrandBlue,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = SubstackTextPrimary
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = SubstackTextMuted
                )
            }
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = SubstackTextSubtle,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun SettingsSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String?,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = BrandBlue,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = SubstackTextPrimary
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = SubstackTextMuted
                )
            }
        }
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = BrandBlue,
                uncheckedThumbColor = SubstackTextMuted,
                uncheckedTrackColor = SubstackPanelVariant,
                uncheckedBorderColor = SubstackBorder
            )
        )
    }
}

@Composable
fun AboutInfoRow(
    icon: ImageVector,
    label: String,
    value: String,
    isLink: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color.Transparent,
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = BrandBlue,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    fontSize = 12.sp,
                    color = SubstackTextMuted
                )
                Text(
                    text = value,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isLink) BrandBlue else SubstackTextPrimary
                )
            }
            if (onClick != null) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = if (isLink) BrandBlue else SubstackTextSubtle,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
