package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadProgress
import com.example.ui.DownloadViewModel
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.SubstackBackground
import com.example.ui.theme.SubstackBorder
import com.example.ui.theme.SubstackOrange
import com.example.ui.theme.SubstackPanel
import com.example.ui.theme.SubstackPanelVariant
import com.example.ui.theme.SubstackRed
import com.example.ui.theme.SubstackTextMuted
import com.example.ui.theme.SubstackTextPrimary
import com.example.ui.theme.SubstackTextSubtle
import com.example.ui.theme.TikTokCyan
import com.example.ui.util.LocalAppStrings
import com.example.ui.util.MediaExportHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(viewModel: DownloadViewModel) {
    val strings = LocalAppStrings.current
    val subTab by viewModel.downloadsSubTab.collectAsState()
    val queueItems by viewModel.activeQueueDownloads.collectAsState()
    val progressMap by viewModel.activeProgress.collectAsState()
    val completedItems by viewModel.filteredHistory.collectAsState()
    val allDownloads by viewModel.allDownloads.collectAsState()

    var showSearchBox by remember { mutableStateOf(false) }
    var itemForDetailsSheet by remember { mutableStateOf<DownloadItem?>(null) }
    val detailsSheetState = rememberModalBottomSheetState()

    val activeCount = queueItems.count {
        it.status == DownloadItem.STATUS_DOWNLOADING ||
                it.status == DownloadItem.STATUS_QUEUED ||
                it.status == DownloadItem.STATUS_RESOLVING
    }
    val completedCount = allDownloads.count { it.status == DownloadItem.STATUS_DONE }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SubstackBackground)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        // Top Header: Title on Left, Search Toggle on Right (Matching reference screenshot)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = strings.downloadsTitle,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = SubstackTextPrimary
            )

            IconButton(
                onClick = { showSearchBox = !showSearchBox },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = if (showSearchBox) BrandBlue else SubstackTextPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Segmented Control: Active vs Completed
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SubstackPanel, RoundedCornerShape(14.dp))
                .border(1.dp, SubstackBorder, RoundedCornerShape(14.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Completed Tab (subTab == 1) - Default view in reference mockup
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (subTab == 1) BrandBlue else Color.Transparent)
                    .clickable { viewModel.setDownloadsSubTab(1) },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = strings.tabCompleted,
                        fontSize = 13.sp,
                        fontWeight = if (subTab == 1) FontWeight.Bold else FontWeight.Medium,
                        color = if (subTab == 1) Color.White else SubstackTextMuted
                    )
                    if (completedCount > 0 && subTab != 1) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "($completedCount)",
                            fontSize = 11.sp,
                            color = SubstackTextSubtle
                        )
                    }
                }
            }

            // Active Tab (subTab == 0)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (subTab == 0) BrandBlue else Color.Transparent)
                    .clickable { viewModel.setDownloadsSubTab(0) },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = strings.tabActive,
                        fontSize = 13.sp,
                        fontWeight = if (subTab == 0) FontWeight.Bold else FontWeight.Medium,
                        color = if (subTab == 0) Color.White else SubstackTextMuted
                    )
                    if (activeCount > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = CircleShape,
                            color = if (subTab == 0) Color.White else BrandBlue,
                            modifier = Modifier.size(18.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "$activeCount",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (subTab == 0) BrandBlue else Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Render Active or Completed View
        if (subTab == 0) {
            ActiveDownloadsView(
                viewModel = viewModel,
                queueItems = queueItems,
                progressMap = progressMap
            )
        } else {
            CompletedDownloadsView(
                viewModel = viewModel,
                completedItems = completedItems,
                showSearchBox = showSearchBox,
                onOpenDetails = { itemForDetailsSheet = it }
            )
        }
    }

    // "تفاصيل التحميل" Bottom Sheet (Matching Screen 8)
    itemForDetailsSheet?.let { item ->
        ModalBottomSheet(
            onDismissRequest = { itemForDetailsSheet = null },
            sheetState = detailsSheetState,
            containerColor = SubstackPanel,
            dragHandle = null
        ) {
            DownloadDetailsSheetContent(
                item = item,
                onClose = { itemForDetailsSheet = null },
                onOpenFile = {
                    viewModel.playItem(item)
                    itemForDetailsSheet = null
                },
                onShare = {
                    viewModel.shareItem(item)
                },
                onRedownload = {
                    viewModel.retryDownload(item.id)
                    itemForDetailsSheet = null
                },
                onDelete = {
                    viewModel.deleteSingleItem(item.id)
                    itemForDetailsSheet = null
                }
            )
        }
    }
}

/**
 * Screen 3: "أثناء التحميل" (Active Download View matching reference image)
 */
@Composable
fun ActiveDownloadsView(
    viewModel: DownloadViewModel,
    queueItems: List<DownloadItem>,
    progressMap: Map<String, DownloadProgress>
) {
    val strings = LocalAppStrings.current
    if (queueItems.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = SubstackPanel,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
                    modifier = Modifier.size(72.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            modifier = Modifier.size(32.dp),
                            tint = SubstackTextSubtle
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = strings.noActiveDownloads,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SubstackTextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = strings.noActiveSubtitle,
                    fontSize = 12.sp,
                    color = SubstackTextMuted
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.setCurrentTab(0) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)
                ) {
                    Text(strings.btnGoToHome, fontSize = 13.sp)
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(queueItems, key = { it.id }) { item ->
                val progress = progressMap[item.id]
                ActiveDownloadDetailCard(
                    item = item,
                    progress = progress,
                    onPause = { viewModel.pauseDownload(item.id) },
                    onResume = { viewModel.resumeDownload(item.id) },
                    onCancel = { viewModel.cancelDownload(item.id) }
                )
            }
        }
    }
}

/**
 * Dedicated Card for Screen 3 "أثناء التحميل":
 * - Video thumbnail card with centered Play/Pause badge
 * - Title and Domain (substack.com / tiktok.com)
 * - Blue linear progress bar with percentage "68%" on the right
 * - Info list: File Size, ETA, Quality
 * - "إلغاء التحميل" button with X icon
 */
@Composable
fun ActiveDownloadDetailCard(
    item: DownloadItem,
    progress: DownloadProgress?,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit
) {
    val strings = LocalAppStrings.current
    val percent = progress?.percentage?.toInt() ?: 0
    val isPaused = item.status == DownloadItem.STATUS_PAUSED
    val isTikTok = item.url.contains("tiktok", ignoreCase = true) || item.sourceUrl.contains("tiktok", ignoreCase = true)
    val domain = if (isTikTok) "tiktok.com" else "substack.com"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SubstackPanel),
        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Media Preview Thumbnail with Play badge overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(SubstackBackground)
                    .border(1.dp, SubstackBorder, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (!item.imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Play / Pause Circle in Center
                IconButton(
                    onClick = { if (isPaused) onResume() else onPause() },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.65f))
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = if (isPaused) "Resume" else "Pause",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title & Domain
            Text(
                text = item.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = SubstackTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = domain,
                fontSize = 12.sp,
                color = SubstackTextMuted
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Bar & Percentage
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LinearProgressIndicator(
                    progress = { percent / 100f },
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = BrandBlue,
                    trackColor = SubstackBorder
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "$percent%",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandBlue
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Info rows: File Size | ETA | Quality
            val totalBytes = progress?.totalBytes ?: item.size
            val sizeStr = if (totalBytes > 0) MediaExportHelper.formatBytes(totalBytes) else "..."
            val etaSec = progress?.etaSeconds ?: 0L
            val etaStr = if (etaSec > 0) String.format(Locale.US, "%02d:%02d", etaSec / 60, etaSec % 60) else "00:10"
            val qualityStr = item.qualityLabel.ifBlank { "1080p" }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Row 1: File Size
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = SubstackTextMuted, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = strings.fileSizeLabel, fontSize = 13.sp, color = SubstackTextMuted)
                    }
                    Text(text = sizeStr, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = SubstackTextPrimary)
                }

                // Row 2: Estimated Duration (ETA)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.AccessTime, contentDescription = null, tint = SubstackTextMuted, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = strings.etaLabel, fontSize = 13.sp, color = SubstackTextMuted)
                    }
                    Text(text = etaStr, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = SubstackTextPrimary)
                }

                // Row 3: Quality
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.HighQuality, contentDescription = null, tint = SubstackTextMuted, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = strings.qualityLabel, fontSize = 13.sp, color = SubstackTextMuted)
                    }
                    Text(text = qualityStr, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = SubstackTextPrimary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Cancel Download Button
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SubstackPanelVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .clickable { onCancel() }
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = null,
                        tint = SubstackRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = strings.btnCancelDownload,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = SubstackRed
                    )
                }
            }
        }
    }
}

/**
 * Screen 4: "قائمة التنزيلات" (Completed Downloads matching reference image)
 */
@Composable
fun CompletedDownloadsView(
    viewModel: DownloadViewModel,
    completedItems: List<DownloadItem>,
    showSearchBox: Boolean,
    onOpenDetails: (DownloadItem) -> Unit
) {
    val strings = LocalAppStrings.current
    val searchQuery by viewModel.searchQuery.collectAsState()
    var selectedFilterPlatform by remember { mutableStateOf("ALL") } // "ALL", "SUBSTACK", "TIKTOK"

    val displayedItems = remember(completedItems, selectedFilterPlatform) {
        when (selectedFilterPlatform) {
            "SUBSTACK" -> completedItems.filter { !it.url.contains("tiktok", ignoreCase = true) && !it.sourceUrl.contains("tiktok", ignoreCase = true) }
            "TIKTOK" -> completedItems.filter { it.url.contains("tiktok", ignoreCase = true) || it.sourceUrl.contains("tiktok", ignoreCase = true) }
            else -> completedItems
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Optional Search field when user clicks Search icon
        if (showSearchBox) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text(strings.searchPlaceholder, fontSize = 13.sp, color = SubstackTextSubtle) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = SubstackTextSubtle, modifier = Modifier.size(18.dp))
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = SubstackTextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = SubstackPanel,
                    unfocusedContainerColor = SubstackPanel,
                    focusedBorderColor = BrandBlue,
                    unfocusedBorderColor = SubstackBorder,
                    focusedTextColor = SubstackTextPrimary,
                    unfocusedTextColor = SubstackTextPrimary
                )
            )
        }

        // Platform Filter Chips: "الكل" | "Substack" | "TikTok"
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Chip 1: All
            FilterChip(
                selected = selectedFilterPlatform == "ALL",
                onClick = { selectedFilterPlatform = "ALL" },
                label = { Text(strings.filterAll, fontSize = 12.sp, fontWeight = if (selectedFilterPlatform == "ALL") FontWeight.Bold else FontWeight.Normal) },
                shape = RoundedCornerShape(10.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = BrandBlue,
                    selectedLabelColor = Color.White,
                    containerColor = SubstackPanel,
                    labelColor = SubstackTextMuted
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedFilterPlatform == "ALL",
                    borderColor = if (selectedFilterPlatform == "ALL") BrandBlue else SubstackBorder
                )
            )

            // Chip 2: Substack
            FilterChip(
                selected = selectedFilterPlatform == "SUBSTACK",
                onClick = { selectedFilterPlatform = "SUBSTACK" },
                label = { Text(strings.filterSubstack, fontSize = 12.sp, fontWeight = if (selectedFilterPlatform == "SUBSTACK") FontWeight.Bold else FontWeight.Normal) },
                shape = RoundedCornerShape(10.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = BrandBlue,
                    selectedLabelColor = Color.White,
                    containerColor = SubstackPanel,
                    labelColor = SubstackTextMuted
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedFilterPlatform == "SUBSTACK",
                    borderColor = if (selectedFilterPlatform == "SUBSTACK") BrandBlue else SubstackBorder
                )
            )

            // Chip 3: TikTok
            FilterChip(
                selected = selectedFilterPlatform == "TIKTOK",
                onClick = { selectedFilterPlatform = "TIKTOK" },
                label = { Text(strings.filterTikTok, fontSize = 12.sp, fontWeight = if (selectedFilterPlatform == "TIKTOK") FontWeight.Bold else FontWeight.Normal) },
                shape = RoundedCornerShape(10.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = BrandBlue,
                    selectedLabelColor = Color.White,
                    containerColor = SubstackPanel,
                    labelColor = SubstackTextMuted
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedFilterPlatform == "TIKTOK",
                    borderColor = if (selectedFilterPlatform == "TIKTOK") BrandBlue else SubstackBorder
                )
            )
        }

        if (displayedItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = SubstackTextSubtle
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) strings.noMatchingDownloads else strings.noCompletedDownloads,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SubstackTextPrimary
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(displayedItems, key = { it.id }) { item ->
                    CompletedDownloadItemCard(
                        item = item,
                        onClick = { onOpenDetails(item) },
                        onPlay = { viewModel.playItem(item) },
                        onShare = { viewModel.shareItem(item) },
                        onExport = { viewModel.exportItemToGallery(item) },
                        onDelete = { viewModel.deleteSingleItem(item.id) }
                    )
                }
            }
        }
    }
}

/**
 * Item Card in Screen 4:
 * - Square thumbnail with platform badge (Substack orange tag or TikTok note)
 * - Title
 * - Domain (`substack.com` or `tiktok.com`)
 * - Meta: `12.4 MB • 2025/10/08`
 * - 3-dots menu
 */
@Composable
fun CompletedDownloadItemCard(
    item: DownloadItem,
    onClick: () -> Unit,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isTikTok = item.url.contains("tiktok", ignoreCase = true) || item.sourceUrl.contains("tiktok", ignoreCase = true)
    val domain = if (isTikTok) "tiktok.com" else "substack.com"
    val dateStr = remember(item.completedAt, item.createdAt) {
        val timestamp = item.completedAt ?: item.createdAt
        SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(timestamp))
    }
    val sizeStr = MediaExportHelper.formatBytes(item.size)

    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SubstackPanel),
        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail with Corner Badge
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SubstackBackground)
            ) {
                if (!item.imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = when (item.formatType) {
                                DownloadItem.FORMAT_IMAGE -> Icons.Default.Image
                                DownloadItem.FORMAT_AUDIO -> Icons.Default.Audiotrack
                                else -> Icons.Default.Videocam
                            },
                            contentDescription = null,
                            tint = SubstackTextSubtle,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Platform tag in corner of thumbnail
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (isTikTok) Color.Black.copy(alpha = 0.8f) else SubstackOrange,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(3.dp)
                        .size(16.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isTikTok) Icons.Default.MusicNote else Icons.Default.Bookmark,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details Column
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SubstackTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = domain,
                    fontSize = 11.sp,
                    color = SubstackTextMuted
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "$sizeStr • $dateStr",
                    fontSize = 11.sp,
                    color = SubstackTextSubtle
                )
            }

            // More Options Menu
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Options",
                        tint = SubstackTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(strings.sheetDetailsTitle) },
                        onClick = {
                            showMenu = false
                            onClick()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(strings.btnOpenFile) },
                        onClick = {
                            showMenu = false
                            onPlay()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(strings.btnShareFile) },
                        onClick = {
                            showMenu = false
                            onShare()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(strings.btnDeleteFile, color = SubstackRed) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}

/**
 * Screen 8: Download Details Sheet
 */
@Composable
fun DownloadDetailsSheetContent(
    item: DownloadItem,
    onClose: () -> Unit,
    onOpenFile: () -> Unit,
    onShare: () -> Unit,
    onRedownload: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isTikTok = item.url.contains("tiktok", ignoreCase = true) || item.sourceUrl.contains("tiktok", ignoreCase = true)
    val domain = if (isTikTok) "tiktok.com" else "substack.com"
    val dateStr = remember(item.completedAt, item.createdAt) {
        val timestamp = item.completedAt ?: item.createdAt
        SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(timestamp))
    }
    val sizeStr = MediaExportHelper.formatBytes(item.size)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = strings.sheetDetailsTitle,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = SubstackTextPrimary
            )
            IconButton(onClick = onClose) {
                Icon(imageVector = Icons.Default.Clear, contentDescription = "Close", tint = SubstackTextMuted)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Thumbnail Card
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = SubstackBackground,
            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SubstackPanelVariant)
                ) {
                    if (!item.imageUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = item.imageUrl,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SubstackTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = domain,
                        fontSize = 12.sp,
                        color = SubstackTextMuted
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "$sizeStr • $dateStr",
                        fontSize = 11.sp,
                        color = SubstackTextSubtle
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Action Item 1: Open File
        DetailActionRow(
            icon = Icons.Default.OpenInNew,
            label = strings.btnOpenFile,
            onClick = onOpenFile
        )

        // Action Item 2: Share
        DetailActionRow(
            icon = Icons.Default.Share,
            label = strings.btnShareFile,
            onClick = onShare
        )

        // Action Item 3: Re-download
        DetailActionRow(
            icon = Icons.Default.Refresh,
            label = strings.btnRedownload,
            onClick = onRedownload
        )

        // Action Item 4: Delete from history
        DetailActionRow(
            icon = Icons.Default.Delete,
            label = strings.btnDeleteFile,
            isDestructive = true,
            onClick = onDelete
        )

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun DetailActionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.Transparent,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isDestructive) SubstackRed else SubstackTextPrimary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = label,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = if (isDestructive) SubstackRed else SubstackTextPrimary
            )
        }
    }
}
