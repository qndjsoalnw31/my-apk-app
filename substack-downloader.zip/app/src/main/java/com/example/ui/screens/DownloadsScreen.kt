package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadProgress
import com.example.ui.DownloadViewModel
import com.example.ui.HistorySortOrder
import com.example.ui.theme.SubstackBackground
import com.example.ui.theme.SubstackBorder
import com.example.ui.theme.SubstackOrange
import com.example.ui.theme.SubstackPanel
import com.example.ui.theme.SubstackPanelVariant
import com.example.ui.theme.SubstackRed
import com.example.ui.theme.SubstackTextMuted
import com.example.ui.theme.SubstackTextPrimary
import com.example.ui.theme.SubstackTextSubtle
import com.example.ui.util.LocalAppStrings
import com.example.ui.util.MediaExportHelper
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(viewModel: DownloadViewModel) {
    val strings = LocalAppStrings.current
    val subTab by viewModel.downloadsSubTab.collectAsState()
    val queueItems by viewModel.activeQueueDownloads.collectAsState()
    val progressMap by viewModel.activeProgress.collectAsState()
    val completedItems by viewModel.filteredHistory.collectAsState()
    val allDownloads by viewModel.allDownloads.collectAsState()

    val activeCount = queueItems.count { it.status == DownloadItem.STATUS_DOWNLOADING || it.status == DownloadItem.STATUS_QUEUED || it.status == DownloadItem.STATUS_RESOLVING }
    val completedCount = allDownloads.count { it.status == DownloadItem.STATUS_DONE }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SubstackBackground)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        // Top Header
        Text(
            text = strings.navDownloads,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = SubstackTextPrimary,
            letterSpacing = (-0.5).sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Segmented Control: "Active | Completed"
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SubstackPanel, RoundedCornerShape(14.dp))
                .border(1.dp, SubstackBorder, RoundedCornerShape(14.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Active Tab (subTab == 0)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (subTab == 0) SubstackPanelVariant else Color.Transparent)
                    .clickable { viewModel.setDownloadsSubTab(0) },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = strings.tabActive,
                        fontSize = 13.sp,
                        fontWeight = if (subTab == 0) FontWeight.Bold else FontWeight.Medium,
                        color = if (subTab == 0) SubstackTextPrimary else SubstackTextMuted
                    )
                    if (activeCount > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = CircleShape,
                            color = SubstackOrange,
                            modifier = Modifier.size(18.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "$activeCount",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // Completed Tab (subTab == 1)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (subTab == 1) SubstackPanelVariant else Color.Transparent)
                    .clickable { viewModel.setDownloadsSubTab(1) },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = strings.tabCompleted,
                        fontSize = 13.sp,
                        fontWeight = if (subTab == 1) FontWeight.Bold else FontWeight.Medium,
                        color = if (subTab == 1) SubstackTextPrimary else SubstackTextMuted
                    )
                    if (completedCount > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = CircleShape,
                            color = SubstackPanelVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
                            modifier = Modifier.size(18.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "$completedCount",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SubstackTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Render Active or Completed View
        if (subTab == 0) {
            ActiveDownloadsView(
                viewModel = viewModel,
                queueItems = queueItems,
                progressMap = progressMap
            )
        } else {
            CompletedDownloadsView(
                viewModel = viewModel,
                completedItems = completedItems
            )
        }
    }
}

@Composable
fun ActiveDownloadsView(
    viewModel: DownloadViewModel,
    queueItems: List<DownloadItem>,
    progressMap: Map<String, DownloadProgress>
) {
    val strings = LocalAppStrings.current
    val downloadingCount = queueItems.count { it.status == DownloadItem.STATUS_DOWNLOADING }
    val pausedCount = queueItems.count { it.status == DownloadItem.STATUS_PAUSED }

    Column(modifier = Modifier.fillMaxSize()) {
        // Quick control actions when active items exist
        if (queueItems.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.inProgressCount(queueItems.size),
                    fontSize = 12.sp,
                    color = SubstackTextMuted,
                    fontWeight = FontWeight.Medium
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (downloadingCount > 0) {
                        TextButton(
                            onClick = { viewModel.pauseAll() },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = null,
                                tint = SubstackOrange,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.btnPauseAll, fontSize = 12.sp, color = SubstackOrange)
                        }
                    }
                    if (pausedCount > 0) {
                        TextButton(
                            onClick = { viewModel.resumeAll() },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = SubstackOrange,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.btnResumeAll, fontSize = 12.sp, color = SubstackOrange)
                        }
                    }
                }
            }
        }

        if (queueItems.isEmpty()) {
            // Minimal Empty State
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = SubstackPanel,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.FileDownload,
                                contentDescription = null,
                                modifier = Modifier.size(32.dp),
                                tint = SubstackTextSubtle
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = strings.noActiveDownloads,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SubstackTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = strings.noActiveSubtitle,
                        fontSize = 13.sp,
                        color = SubstackTextMuted
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    Button(
                        onClick = { viewModel.setCurrentTab(0) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SubstackPanelVariant,
                            contentColor = SubstackTextPrimary
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Text(strings.btnGoToHome, fontSize = 13.sp)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(queueItems, key = { it.id }) { item ->
                    val progress = progressMap[item.id]
                    ActiveItemCard(
                        item = item,
                        progress = progress,
                        onPause = { viewModel.pauseDownload(item.id) },
                        onResume = { viewModel.resumeDownload(item.id) },
                        onRetry = { viewModel.retryDownload(item.id) },
                        onCancel = { viewModel.cancelDownload(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun ActiveItemCard(
    item: DownloadItem,
    progress: DownloadProgress?,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRetry: () -> Unit,
    onCancel: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isAudio = item.formatType == DownloadItem.FORMAT_AUDIO

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SubstackPanel),
        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                // Thumbnail or Icon
                if (!item.imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(SubstackPanelVariant)
                    )
                } else {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SubstackPanelVariant,
                        modifier = Modifier.size(56.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isAudio) Icons.Default.Audiotrack else Icons.Default.Videocam,
                                contentDescription = null,
                                tint = SubstackOrange,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SubstackTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${item.author} • ${item.qualityLabel}",
                        fontSize = 11.sp,
                        color = SubstackTextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    // Status Pill
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (item.status) {
                            DownloadItem.STATUS_DOWNLOADING -> SubstackOrange.copy(alpha = 0.15f)
                            DownloadItem.STATUS_PAUSED -> SubstackPanelVariant
                            DownloadItem.STATUS_ERROR -> Color(0xFF3B1212)
                            else -> SubstackPanelVariant
                        }
                    ) {
                        Text(
                            text = when (item.status) {
                                DownloadItem.STATUS_DOWNLOADING -> strings.statusDownloading
                                DownloadItem.STATUS_QUEUED -> strings.statusQueued
                                DownloadItem.STATUS_RESOLVING -> strings.statusResolving
                                DownloadItem.STATUS_PAUSED -> strings.statusPaused
                                DownloadItem.STATUS_ERROR -> strings.statusError
                                else -> item.status
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = when (item.status) {
                                DownloadItem.STATUS_DOWNLOADING -> SubstackOrange
                                DownloadItem.STATUS_PAUSED -> SubstackTextMuted
                                DownloadItem.STATUS_ERROR -> SubstackRed
                                else -> SubstackTextMuted
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Pause / Resume / Cancel Controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when (item.status) {
                        DownloadItem.STATUS_DOWNLOADING -> {
                            IconButton(onClick = onPause, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Pause,
                                    contentDescription = "Pause",
                                    tint = SubstackOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        DownloadItem.STATUS_PAUSED -> {
                            IconButton(onClick = onResume, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Resume",
                                    tint = SubstackOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        DownloadItem.STATUS_ERROR -> {
                            IconButton(onClick = onRetry, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Retry",
                                    tint = SubstackOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    IconButton(onClick = onCancel, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancel",
                            tint = SubstackTextSubtle,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Progress Bar & Stats
            if (item.status == DownloadItem.STATUS_DOWNLOADING) {
                val percent = progress?.percentage ?: 0f
                LinearProgressIndicator(
                    progress = { percent / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = SubstackOrange,
                    trackColor = SubstackBorder
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val downloadedStr = MediaExportHelper.formatBytes(progress?.downloadedBytes ?: 0L)
                    val totalStr = if ((progress?.totalBytes ?: 0L) > 0) MediaExportHelper.formatBytes(progress?.totalBytes ?: 0L) else "..."
                    val speedStr = String.format(Locale.US, "%.1f MB/s", (progress?.bytesPerSec ?: 0.0) / (1024 * 1024))
                    val etaStr = if ((progress?.etaSeconds ?: 0L) > 0) {
                        String.format(Locale.US, "%02d:%02d", (progress?.etaSeconds ?: 0L) / 60, (progress?.etaSeconds ?: 0L) % 60)
                    } else "..."

                    Text(
                        text = "$downloadedStr / $totalStr (${percent.toInt()}%)",
                        fontSize = 11.sp,
                        color = SubstackTextMuted
                    )
                    Text(
                        text = "$speedStr • ETA $etaStr",
                        fontSize = 11.sp,
                        color = SubstackTextSubtle
                    )
                }
            } else if (item.status == DownloadItem.STATUS_RESOLVING) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = SubstackOrange,
                    trackColor = SubstackBorder
                )
            } else if (item.status == DownloadItem.STATUS_ERROR && !item.errorMessage.isNullOrBlank()) {
                Text(
                    text = item.errorMessage,
                    fontSize = 11.sp,
                    color = SubstackRed
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompletedDownloadsView(
    viewModel: DownloadViewModel,
    completedItems: List<DownloadItem>
) {
    val strings = LocalAppStrings.current
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filterFormat by viewModel.filterFormat.collectAsState()
    val sortOrder by viewModel.sortOrder.collectAsState()
    val selectedItemIds by viewModel.selectedItemIds.collectAsState()

    var showSortMenu by remember { mutableStateOf(false) }
    var itemToRename by remember { mutableStateOf<DownloadItem?>(null) }
    var renameInputText by remember { mutableStateOf("") }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var itemToDeleteSingle by remember { mutableStateOf<DownloadItem?>(null) }

    val isSelectionMode = selectedItemIds.isNotEmpty()

    Column(modifier = Modifier.fillMaxSize()) {
        // Multi-Selection Header Bar or Search & Filter Bar
        AnimatedVisibility(visible = isSelectionMode) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SubstackPanel),
                border = androidx.compose.foundation.BorderStroke(1.dp, SubstackOrange)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.clearSelection() }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancel",
                            tint = SubstackTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Text(
                        text = strings.selectedCount(selectedItemIds.size),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = SubstackTextPrimary,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(onClick = { viewModel.selectAllHistory() }) {
                        Text(strings.btnSelectAll, fontSize = 12.sp, color = SubstackOrange)
                    }

                    IconButton(onClick = { viewModel.shareSelectedItems() }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            tint = SubstackTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(onClick = { showDeleteConfirmDialog = true }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = SubstackRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Search Bar & Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text(strings.searchPlaceholder, fontSize = 13.sp, color = SubstackTextSubtle) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = SubstackTextSubtle,
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear",
                                tint = SubstackTextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = SubstackPanel,
                    unfocusedContainerColor = SubstackPanel,
                    focusedBorderColor = SubstackOrange,
                    unfocusedBorderColor = SubstackBorder,
                    focusedTextColor = SubstackTextPrimary,
                    unfocusedTextColor = SubstackTextPrimary,
                    cursorColor = SubstackOrange
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            Box {
                IconButton(
                    onClick = { showSortMenu = true },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SubstackPanel)
                        .border(1.dp, SubstackBorder, RoundedCornerShape(12.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Sort,
                        contentDescription = "Sort",
                        tint = SubstackOrange,
                        modifier = Modifier.size(20.dp)
                    )
                }

                DropdownMenu(
                    expanded = showSortMenu,
                    onDismissRequest = { showSortMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(strings.sortNewest) },
                        onClick = {
                            viewModel.setSortOrder(HistorySortOrder.DATE_DESC)
                            showSortMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(strings.sortOldest) },
                        onClick = {
                            viewModel.setSortOrder(HistorySortOrder.DATE_ASC)
                            showSortMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(strings.sortLargest) },
                        onClick = {
                            viewModel.setSortOrder(HistorySortOrder.SIZE_DESC)
                            showSortMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(strings.sortTitle) },
                        onClick = {
                            viewModel.setSortOrder(HistorySortOrder.NAME_ASC)
                            showSortMenu = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Format Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filterFormat == "ALL",
                onClick = { viewModel.setFilterFormat("ALL") },
                label = { Text(strings.filterAll, fontSize = 12.sp) },
                shape = RoundedCornerShape(10.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = SubstackOrange.copy(alpha = 0.2f),
                    selectedLabelColor = SubstackOrange,
                    containerColor = SubstackPanel,
                    labelColor = SubstackTextMuted
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = filterFormat == "ALL",
                    borderColor = if (filterFormat == "ALL") SubstackOrange else SubstackBorder
                )
            )

            FilterChip(
                selected = filterFormat == DownloadItem.FORMAT_VIDEO,
                onClick = { viewModel.setFilterFormat(DownloadItem.FORMAT_VIDEO) },
                label = { Text(strings.filterVideos, fontSize = 12.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                },
                shape = RoundedCornerShape(10.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = SubstackOrange.copy(alpha = 0.2f),
                    selectedLabelColor = SubstackOrange,
                    containerColor = SubstackPanel,
                    labelColor = SubstackTextMuted
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = filterFormat == DownloadItem.FORMAT_VIDEO,
                    borderColor = if (filterFormat == DownloadItem.FORMAT_VIDEO) SubstackOrange else SubstackBorder
                )
            )

            FilterChip(
                selected = filterFormat == DownloadItem.FORMAT_AUDIO,
                onClick = { viewModel.setFilterFormat(DownloadItem.FORMAT_AUDIO) },
                label = { Text(strings.filterAudio, fontSize = 12.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Audiotrack,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                },
                shape = RoundedCornerShape(10.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = SubstackOrange.copy(alpha = 0.2f),
                    selectedLabelColor = SubstackOrange,
                    containerColor = SubstackPanel,
                    labelColor = SubstackTextMuted
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = filterFormat == DownloadItem.FORMAT_AUDIO,
                    borderColor = if (filterFormat == DownloadItem.FORMAT_AUDIO) SubstackOrange else SubstackBorder
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (completedItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = SubstackPanel,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = null,
                                modifier = Modifier.size(32.dp),
                                tint = SubstackTextSubtle
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) strings.noMatchingDownloads else strings.noCompletedDownloads,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SubstackTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) strings.tryAnotherSearch else strings.noCompletedSubtitle,
                        fontSize = 13.sp,
                        color = SubstackTextMuted
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(completedItems, key = { it.id }) { item ->
                    val isSelected = selectedItemIds.contains(item.id)

                    CompletedItemCard(
                        item = item,
                        isSelected = isSelected,
                        isSelectionMode = isSelectionMode,
                        onToggleSelect = { viewModel.toggleItemSelection(item.id) },
                        onPlay = { viewModel.playItem(item) },
                        onExport = { viewModel.exportItemToGallery(item) },
                        onShare = { viewModel.shareItem(item) },
                        onOpenExternal = { viewModel.openExternal(item) },
                        onRename = {
                            itemToRename = item
                            renameInputText = item.title
                        },
                        onDelete = {
                            itemToDeleteSingle = item
                        }
                    )
                }
            }
        }
    }

    // Rename Dialog
    itemToRename?.let { item ->
        AlertDialog(
            onDismissRequest = { itemToRename = null },
            title = { Text(strings.dialogRenameTitle, color = SubstackTextPrimary) },
            text = {
                OutlinedTextField(
                    value = renameInputText,
                    onValueChange = { renameInputText = it },
                    label = { Text(strings.dialogRenameLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (renameInputText.isNotBlank()) {
                            viewModel.renameItem(item.id, renameInputText.trim())
                        }
                        itemToRename = null
                    }
                ) {
                    Text(strings.btnSave, color = SubstackOrange)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToRename = null }) {
                    Text(strings.btnCancel, color = SubstackTextMuted)
                }
            }
        )
    }

    // Batch Delete Confirmation Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text(strings.dialogBatchDeleteTitle, color = SubstackTextPrimary) },
            text = { Text(strings.dialogBatchDeleteMessage(selectedItemIds.size), color = SubstackTextMuted) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteSelectedItems()
                        showDeleteConfirmDialog = false
                    }
                ) {
                    Text(strings.btnDelete, color = SubstackRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text(strings.btnCancel, color = SubstackTextMuted)
                }
            }
        )
    }

    // Single Delete Confirmation Dialog
    itemToDeleteSingle?.let { item ->
        AlertDialog(
            onDismissRequest = { itemToDeleteSingle = null },
            title = { Text(strings.dialogDeleteTitle, color = SubstackTextPrimary) },
            text = { Text(strings.dialogDeleteMessage, color = SubstackTextMuted) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteSingleItem(item.id)
                        itemToDeleteSingle = null
                    }
                ) {
                    Text(strings.btnDelete, color = SubstackRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDeleteSingle = null }) {
                    Text(strings.btnCancel, color = SubstackTextMuted)
                }
            }
        )
    }
}

@Composable
fun CompletedItemCard(
    item: DownloadItem,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    onToggleSelect: () -> Unit,
    onPlay: () -> Unit,
    onExport: () -> Unit,
    onShare: () -> Unit,
    onOpenExternal: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                if (isSelectionMode) onToggleSelect()
                else onPlay()
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) SubstackPanelVariant else SubstackPanel
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) SubstackOrange else SubstackBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Selection checkbox (when in multi-selection mode)
            if (isSelectionMode) {
                IconButton(onClick = onToggleSelect, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Outlined.Circle,
                        contentDescription = "Select",
                        tint = if (isSelected) SubstackOrange else SubstackTextSubtle,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
            }

            // Thumbnail with Play overlay
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(SubstackPanelVariant)
                    .clickable { onPlay() },
                contentAlignment = Alignment.Center
            ) {
                if (!item.imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Play icon overlay
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.6f),
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SubstackTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${item.author} • ${MediaExportHelper.formatDate(item.completedAt ?: item.createdAt)}",
                    fontSize = 11.sp,
                    color = SubstackTextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = SubstackPanelVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SubstackBorder)
                    ) {
                        Text(
                            text = item.qualityLabel,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = SubstackOrange,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = MediaExportHelper.formatBytes(item.size),
                        fontSize = 11.sp,
                        color = SubstackTextSubtle
                    )

                    if (item.durationSeconds != null && item.durationSeconds > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "• ${MediaExportHelper.formatDuration(item.durationSeconds)}",
                            fontSize = 11.sp,
                            color = SubstackTextSubtle
                        )
                    }
                }
            }

            // Quick Actions & Menu
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        tint = SubstackTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Box {
                    IconButton(onClick = { showMenu = true }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More",
                            tint = SubstackTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(strings.menuExportGallery) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.FileDownload,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            onClick = {
                                onExport()
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.menuOpenExternal) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.OpenInNew,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            onClick = {
                                onOpenExternal()
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.menuRename) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.DriveFileRenameOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            onClick = {
                                onRename()
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.menuDelete, color = SubstackRed) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = null,
                                    tint = SubstackRed,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            onClick = {
                                onDelete()
                                showMenu = false
                            }
                        )
                    }
                }
            }
        }
    }
}
