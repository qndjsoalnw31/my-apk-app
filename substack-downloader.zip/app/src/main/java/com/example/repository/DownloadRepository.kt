package com.example.repository

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.util.Log
import com.example.data.db.AppDatabase
import com.example.data.db.DownloadDao
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadProgress
import com.example.data.model.NoteDetails
import com.example.network.SubstackParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class DownloadRepository(private val context: Context) {

    private val TAG = "DownloadRepository"

    // Safe DB & DAO initialization - Never throws if Room is missing/unusable
    private val dao: DownloadDao? by lazy {
        try {
            AppDatabase.getInstance(context)?.downloadDao()
        } catch (e: Throwable) {
            Log.w(TAG, "Room DAO unavailable, using in-memory state: ${e.message}")
            null
        }
    }

    val parser = SubstackParser()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    // In-memory state fallback when Room DB is unavailable or throws errors
    private val inMemoryDownloads = MutableStateFlow<List<DownloadItem>>(emptyList())

    val allDownloads: Flow<List<DownloadItem>> = flow {
        val daoInstance = dao
        if (daoInstance != null) {
            try {
                daoInstance.getAllDownloads().collect { list ->
                    inMemoryDownloads.value = list
                    emit(list)
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Error streaming from Room DAO, falling back to memory flow: ${e.message}")
                inMemoryDownloads.collect { emit(it) }
            }
        } else {
            inMemoryDownloads.collect { emit(it) }
        }
    }.catch { e ->
        Log.e(TAG, "Flow catch exception, emitting inMemoryDownloads: ${e.message}")
        emit(inMemoryDownloads.value)
    }

    fun searchDownloads(query: String): Flow<List<DownloadItem>> = allDownloads.map { list ->
        if (query.isBlank()) list
        else list.filter {
            it.title.contains(query, ignoreCase = true) ||
                    it.filename.contains(query, ignoreCase = true) ||
                    it.description.contains(query, ignoreCase = true)
        }
    }

    private val _activeProgress = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    val activeProgress: StateFlow<Map<String, DownloadProgress>> = _activeProgress.asStateFlow()

    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val pausedJobs = ConcurrentHashMap.newKeySet<String>()

    /**
     * Safe internal/app-specific storage directory on device.
     * Guaranteed to work without permission errors or ENOENT issues.
     */
    fun getDownloadDir(): File {
        val preferredDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?: context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(context.filesDir, "SubstackDownloads")

        val substackFolder = File(preferredDir, "SubstackDownloads")
        if (!substackFolder.exists()) {
            val created = substackFolder.mkdirs()
            Log.d(TAG, "Created download folder: ${substackFolder.absolutePath} (success=$created)")
        }
        return substackFolder
    }

    private suspend fun safeInsertOrUpdate(item: DownloadItem) {
        inMemoryDownloads.update { current ->
            val filtered = current.filterNot { it.id == item.id }
            listOf(item) + filtered
        }
        try {
            dao?.insertOrUpdate(item)
        } catch (e: Throwable) {
            Log.w(TAG, "Room insert failed, item kept in memory: ${e.message}")
        }
    }

    private suspend fun safeDeleteById(id: String) {
        inMemoryDownloads.update { current -> current.filterNot { it.id == id } }
        try {
            dao?.deleteById(id)
        } catch (e: Throwable) {
            Log.w(TAG, "Room delete failed, item deleted from memory: ${e.message}")
        }
    }

    private suspend fun safeGetDownloadById(id: String): DownloadItem? {
        return try {
            dao?.getDownloadById(id) ?: inMemoryDownloads.value.find { it.id == id }
        } catch (e: Throwable) {
            inMemoryDownloads.value.find { it.id == id }
        }
    }

    suspend fun resolveNoteUrl(url: String): NoteDetails {
        return parser.resolveNote(url)
    }

    fun startDownload(
        scope: CoroutineScope,
        url: String,
        customTitle: String? = null,
        noteDetails: NoteDetails? = null,
        formatType: String = DownloadItem.FORMAT_VIDEO,
        qualityLabel: String = "1080p HD"
    ): String {
        val downloadId = UUID.randomUUID().toString()
        val title = customTitle?.ifBlank { null }
            ?: noteDetails?.title
            ?: if (formatType == DownloadItem.FORMAT_AUDIO) "صوت Substack Note" else "فيديو Substack Note"

        val isAudio = formatType == DownloadItem.FORMAT_AUDIO
        val filename = SubstackParser.safeFilename(title, downloadId = downloadId, isAudio = isAudio)

        val item = DownloadItem(
            id = downloadId,
            noteId = noteDetails?.noteId ?: SubstackParser.extractNoteId(url),
            url = url,
            title = title,
            description = noteDetails?.description ?: "",
            imageUrl = noteDetails?.imageUrl,
            filename = filename,
            status = DownloadItem.STATUS_QUEUED,
            formatType = formatType,
            qualityLabel = qualityLabel,
            createdAt = System.currentTimeMillis()
        )

        val job = scope.launch(Dispatchers.IO) {
            safeInsertOrUpdate(item)
            processDownload(downloadId, item, noteDetails)
        }

        activeJobs[downloadId] = job
        return downloadId
    }

    private suspend fun processDownload(
        downloadId: String,
        initialItem: DownloadItem,
        details: NoteDetails?
    ) {
        val targetFolder = getDownloadDir()
        val destinationFile = File(targetFolder, initialItem.filename)
        val partFile = File(targetFolder, "${initialItem.filename}.part")

        try {
            updateStatus(downloadId, DownloadItem.STATUS_RESOLVING)

            val resolvedNote = details ?: parser.resolveNote(initialItem.url)
            val updatedItem = initialItem.copy(
                noteId = resolvedNote.noteId,
                title = initialItem.title.ifBlank { resolvedNote.title },
                description = resolvedNote.description,
                imageUrl = resolvedNote.imageUrl
            )
            safeInsertOrUpdate(updatedItem)

            if (resolvedNote.videoSources.isEmpty()) {
                throw IllegalStateException("لم يتم العثور على مصادر ميديا قابلة للتنزيل.")
            }

            var downloadSuccess = false
            var lastError: Exception? = null

            for (source in resolvedNote.videoSources) {
                if (pausedJobs.contains(downloadId)) break

                try {
                    updateStatus(downloadId, DownloadItem.STATUS_DOWNLOADING)
                    val directStreamUrl = parser.resolveDirectStreamUrl(source.url)

                    downloadStreamToFile(
                        downloadId = downloadId,
                        streamUrl = directStreamUrl,
                        partFile = partFile,
                        destFile = destinationFile
                    )
                    downloadSuccess = true
                    break
                } catch (e: Exception) {
                    if (e is CancellationException || pausedJobs.contains(downloadId)) {
                        throw e
                    }
                    lastError = e
                }
            }

            if (!downloadSuccess) {
                throw lastError ?: IllegalStateException("فشل تنزيل الوسائط.")
            }

            val finalSize = destinationFile.length()
            val completedItem = updatedItem.copy(
                filePath = destinationFile.absolutePath,
                size = finalSize,
                downloadedSize = finalSize,
                status = DownloadItem.STATUS_DONE,
                completedAt = System.currentTimeMillis(),
                errorMessage = null
            )
            safeInsertOrUpdate(completedItem)

            try {
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(destinationFile.absolutePath),
                    if (initialItem.formatType == DownloadItem.FORMAT_AUDIO) arrayOf("audio/mpeg", "audio/*") else arrayOf("video/mp4", "video/*"),
                    null
                )
            } catch (e: Throwable) {
                Log.w(TAG, "MediaScanner non-critical error: ${e.message}")
            }

            _activeProgress.value = _activeProgress.value - downloadId
        } catch (e: CancellationException) {
            if (pausedJobs.contains(downloadId)) {
                updateStatus(downloadId, DownloadItem.STATUS_PAUSED)
            } else {
                updateStatus(downloadId, DownloadItem.STATUS_CANCELLED)
                if (partFile.exists()) partFile.delete()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Download error", e)
            val failedItem = initialItem.copy(
                status = DownloadItem.STATUS_ERROR,
                errorMessage = e.localizedMessage ?: "حدث خطأ غير متوقع أثناء التنزيل"
            )
            safeInsertOrUpdate(failedItem)
            _activeProgress.value = _activeProgress.value - downloadId
        } finally {
            activeJobs.remove(downloadId)
        }
    }

    private suspend fun downloadStreamToFile(
        downloadId: String,
        streamUrl: String,
        partFile: File,
        destFile: File
    ): Unit = withContext(Dispatchers.IO) {

        val existingBytes = if (partFile.exists()) partFile.length() else 0L

        val requestBuilder = Request.Builder()
            .url(streamUrl)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) Chrome/131.0.0.0 Mobile Safari/537.36")
            .header("Referer", "https://substack.com/")

        if (existingBytes > 0) {
            requestBuilder.header("Range", "bytes=$existingBytes-")
        }

        val response = client.newCall(requestBuilder.build()).execute()
        if (!response.isSuccessful && response.code != 206) {
            response.close()
            if (existingBytes > 0) {
                partFile.delete()
                return@withContext downloadStreamToFile(downloadId, streamUrl, partFile, destFile)
            } else {
                throw IllegalStateException("خادم الفيديو أرجع خطأ (HTTP ${response.code})")
            }
        }

        val isAppend = response.code == 206 && existingBytes > 0
        val body = response.body ?: throw IllegalStateException("جسم الاستجابة فارغ.")

        val contentLength = body.contentLength()
        val totalBytes = if (isAppend) existingBytes + contentLength else contentLength

        var downloaded = if (isAppend) existingBytes else 0L
        val startTime = System.currentTimeMillis()

        body.byteStream().use { input ->
            partFile.parentFile?.let { if (!it.exists()) it.mkdirs() }
            val output = if (isAppend) {
                FileOutputStream(partFile, true)
            } else {
                FileOutputStream(partFile, false)
            }

            output.use { out ->
                val buffer = ByteArray(64 * 1024)
                var bytesRead: Int
                var lastUpdate = System.currentTimeMillis()

                while (input.read(buffer).also { bytesRead = it } != -1) {
                    if (pausedJobs.contains(downloadId) || Thread.currentThread().isInterrupted) {
                        throw CancellationException("Download paused or cancelled")
                    }

                    out.write(buffer, 0, bytesRead)
                    downloaded += bytesRead

                    val now = System.currentTimeMillis()
                    if (now - lastUpdate >= 300) {
                        val elapsedSec = ((now - startTime) / 1000.0).coerceAtLeast(0.001)
                        val speed = (downloaded - (if (isAppend) existingBytes else 0L)) / elapsedSec
                        val remainingBytes = if (totalBytes > downloaded) totalBytes - downloaded else 0L
                        val eta = if (speed > 0) (remainingBytes / speed).toLong() else 0L

                        _activeProgress.value = _activeProgress.value + (
                            downloadId to DownloadProgress(
                                downloadedBytes = downloaded,
                                totalBytes = totalBytes,
                                bytesPerSec = speed,
                                etaSeconds = eta
                            )
                        )
                        lastUpdate = now
                    }
                }
            }
        }

        if (partFile.exists() && partFile.length() > 0) {
            if (destFile.exists()) destFile.delete()
            partFile.renameTo(destFile)
        } else {
            throw IllegalStateException("الملف المكتنز فارغ.")
        }
    }

    fun pauseDownload(downloadId: String) {
        pausedJobs.add(downloadId)
        activeJobs[downloadId]?.cancel()
    }

    fun resumeDownload(scope: CoroutineScope, downloadId: String) {
        pausedJobs.remove(downloadId)
        scope.launch(Dispatchers.IO) {
            val item = safeGetDownloadById(downloadId) ?: return@launch
            val job = scope.launch(Dispatchers.IO) {
                processDownload(downloadId, item, null)
            }
            activeJobs[downloadId] = job
        }
    }

    fun cancelDownload(scope: CoroutineScope, downloadId: String) {
        pausedJobs.remove(downloadId)
        activeJobs[downloadId]?.cancel()
        _activeProgress.value = _activeProgress.value - downloadId

        scope.launch(Dispatchers.IO) {
            val item = safeGetDownloadById(downloadId)
            if (item != null) {
                val file = File(item.filePath)
                if (file.exists()) file.delete()
                val partFile = File(getDownloadDir(), "${item.filename}.part")
                if (partFile.exists()) partFile.delete()

                safeDeleteById(downloadId)
            }
        }
    }

    suspend fun deleteDownload(id: String) {
        val item = safeGetDownloadById(id)
        if (item != null) {
            if (item.filePath.isNotBlank()) {
                val file = File(item.filePath)
                if (file.exists()) {
                    file.delete()
                }
            }
            safeDeleteById(id)
        }
    }

    private suspend fun updateStatus(id: String, status: String) {
        val current = safeGetDownloadById(id)
        if (current != null) {
            safeInsertOrUpdate(current.copy(status = status))
        }
    }
}


