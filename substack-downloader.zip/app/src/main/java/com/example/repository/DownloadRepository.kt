package com.example.repository

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import com.example.data.db.AppDatabase
import com.example.data.db.DownloadDao
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadProgress
import com.example.data.model.NoteDetails
import com.example.data.model.VideoSource
import com.example.data.settings.SettingsRepository
import com.example.network.SubstackParser
import com.example.network.hls.HlsDownloader
import com.example.security.SafeDns
import com.example.security.SecurityGuard
import com.example.security.SecurityLogger
import com.example.service.DownloadForegroundService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class DownloadRepository(private val context: Context) {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val settingsRepository = SettingsRepository(context)
    val parser = SubstackParser()
    val hlsDownloader = HlsDownloader()

    private val dao: DownloadDao? by lazy {
        try {
            AppDatabase.getInstance(context)?.downloadDao()
        } catch (e: Throwable) {
            SecurityLogger.w("Room DAO unavailable: ${e.message}")
            null
        }
    }

    private val client = OkHttpClient.Builder()
        .dns(SafeDns())
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    // Concurrency semaphore configured via settings
    private var downloadSemaphore = Semaphore(2)

    private val inMemoryDownloads = MutableStateFlow<List<DownloadItem>>(emptyList())
    private val _activeProgress = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    val activeProgress: StateFlow<Map<String, DownloadProgress>> = _activeProgress.asStateFlow()

    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val pausedJobs = ConcurrentHashMap.newKeySet<String>()

    init {
        applicationScope.launch {
            settingsRepository.settingsFlow.collect { settings ->
                val limit = settings.concurrentDownloads.coerceIn(1, 3)
                downloadSemaphore = Semaphore(limit)
            }
        }
    }

    val allDownloads: Flow<List<DownloadItem>> = flow {
        val daoInstance = dao
        if (daoInstance != null) {
            try {
                daoInstance.getAllDownloads().collect { list ->
                    inMemoryDownloads.value = list
                    emit(list)
                }
            } catch (e: Throwable) {
                SecurityLogger.e("Streaming from Room DAO failed, fallback to memory", e)
                inMemoryDownloads.collect { emit(it) }
            }
        } else {
            inMemoryDownloads.collect { emit(it) }
        }
    }.catch { e ->
        SecurityLogger.e("Flow error in allDownloads", e)
        emit(inMemoryDownloads.value)
    }

    fun searchDownloads(query: String): Flow<List<DownloadItem>> {
        val safeQuery = SecurityGuard.sanitizeQuery(query)
        return allDownloads.map { list ->
            if (safeQuery.isBlank()) list
            else list.filter {
                it.title.contains(safeQuery, ignoreCase = true) ||
                        it.filename.contains(safeQuery, ignoreCase = true) ||
                        it.author.contains(safeQuery, ignoreCase = true) ||
                        it.description.contains(safeQuery, ignoreCase = true)
            }
        }
    }

    fun getDownloadsByFormat(format: String): Flow<List<DownloadItem>> {
        return allDownloads.map { list ->
            if (format == "ALL") list
            else list.filter { it.formatType == format }
        }
    }

    fun getDownloadDir(): File {
        val preferredDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?: context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(context.filesDir, "SubstackDownloads")

        val substackFolder = File(preferredDir, "SubstackDownloads")
        if (!substackFolder.exists()) {
            substackFolder.mkdirs()
        }
        return substackFolder
    }

    private suspend fun safeInsertOrUpdate(item: DownloadItem) {
        inMemoryDownloads.update { current ->
            val filtered = current.filterNot { it.id == item.id }
            listOf(item) + filtered
        }
        try {
            dao?.insertOrUpdate(item)
        } catch (e: Throwable) {
            SecurityLogger.w("Room insert failed: ${e.message}")
        }
    }

    private suspend fun safeDeleteById(id: String) {
        inMemoryDownloads.update { current -> current.filterNot { it.id == id } }
        try {
            dao?.deleteById(id)
        } catch (e: Throwable) {
            SecurityLogger.w("Room delete failed: ${e.message}")
        }
    }

    private suspend fun safeGetDownloadById(id: String): DownloadItem? {
        return try {
            dao?.getDownloadById(id) ?: inMemoryDownloads.value.find { it.id == id }
        } catch (e: Throwable) {
            inMemoryDownloads.value.find { it.id == id }
        }
    }

    suspend fun resolveNoteUrl(url: String): NoteDetails {
        return parser.resolveNote(url)
    }

    fun startDownload(
        scope: CoroutineScope,
        url: String,
        customTitle: String? = null,
        noteDetails: NoteDetails? = null,
        selectedSource: VideoSource? = null,
        formatType: String = DownloadItem.FORMAT_VIDEO,
        qualityLabel: String = "1080p HD"
    ): String {
        if (!SecurityGuard.checkRateLimit("start_download")) {
            throw SecurityException("تم تجاوز معدل بدء التنزيلات، يرجى الانتظار قليلاً.")
        }

        val validUrl = SecurityGuard.validateAndSanitizeUrl(url).getOrThrow()
        val downloadId = UUID.randomUUID().toString()
        val isAudio = formatType == DownloadItem.FORMAT_AUDIO

        val rawTitle = customTitle?.ifBlank { null }
            ?: noteDetails?.title
            ?: if (isAudio) "Substack Audio" else "Substack Video"

        val title = SecurityGuard.sanitizeText(rawTitle, maxLength = 80)
        val filename = SecurityGuard.sanitizeFileName(title, isAudio = isAudio, suffixId = downloadId)

        val item = DownloadItem(
            id = downloadId,
            noteId = noteDetails?.noteId ?: SubstackParser.extractNoteId(validUrl),
            url = validUrl,
            title = title,
            description = SecurityGuard.sanitizeText(noteDetails?.description ?: "", maxLength = 250),
            author = SecurityGuard.sanitizeText(noteDetails?.author ?: "Substack", maxLength = 50),
            imageUrl = noteDetails?.imageUrl,
            filename = filename,
            status = DownloadItem.STATUS_QUEUED,
            formatType = formatType,
            qualityLabel = SecurityGuard.sanitizeText(qualityLabel, maxLength = 30),
            resolution = selectedSource?.resolution,
            bitrate = selectedSource?.bitrate,
            durationSeconds = noteDetails?.durationSeconds,
            mimeType = selectedSource?.mimeType ?: if (isAudio) "audio/mpeg" else "video/mp4",
            sourceUrl = selectedSource?.url ?: "",
            createdAt = System.currentTimeMillis()
        )

        val job = applicationScope.launch(Dispatchers.IO) {
            safeInsertOrUpdate(item)
            processDownloadQueue(downloadId, item, noteDetails, selectedSource)
        }

        activeJobs[downloadId] = job
        return downloadId
    }

    private suspend fun processDownloadQueue(
        downloadId: String,
        initialItem: DownloadItem,
        details: NoteDetails?,
        source: VideoSource?
    ) {
        val targetFolder = getDownloadDir()
        val destinationFile = File(targetFolder, initialItem.filename)
        val partFile = File(targetFolder, "${initialItem.filename}.part")

        if (!SecurityGuard.isPathStrictlyInsideDirectory(destinationFile, targetFolder) ||
            !SecurityGuard.isPathStrictlyInsideDirectory(partFile, targetFolder)) {
            SecurityLogger.e("Path traversal blocked for $downloadId")
            throw SecurityException("تم حظر مسار الملف لحماية الجهاز.")
        }

        try {
            downloadSemaphore.acquire()

            updateStatus(downloadId, DownloadItem.STATUS_RESOLVING)

            val resolvedNote = details ?: parser.resolveNote(initialItem.url)
            val chosenSource = source ?: resolvedNote.videoSources.firstOrNull {
                if (initialItem.formatType == DownloadItem.FORMAT_AUDIO) it.type == "audio"
                else it.quality == initialItem.qualityLabel
            } ?: resolvedNote.videoSources.firstOrNull()

            if (chosenSource == null && resolvedNote.videoSources.isEmpty()) {
                throw IllegalStateException("لم يتم العثور على مصادر ميديا قابلة للتنزيل.")
            }

            val targetSource = chosenSource ?: resolvedNote.videoSources.first()

            val updatedItem = initialItem.copy(
                noteId = resolvedNote.noteId,
                title = initialItem.title.ifBlank { SecurityGuard.sanitizeText(resolvedNote.title, 80) },
                description = SecurityGuard.sanitizeText(resolvedNote.description, 250),
                author = SecurityGuard.sanitizeText(resolvedNote.author, 50),
                imageUrl = resolvedNote.imageUrl,
                durationSeconds = resolvedNote.durationSeconds,
                sourceUrl = targetSource.url,
                mimeType = targetSource.mimeType
            )
            safeInsertOrUpdate(updatedItem)

            updateStatus(downloadId, DownloadItem.STATUS_DOWNLOADING)

            // Start foreground service for notifications
            val settings = settingsRepository.settingsFlow.first()
            if (settings.notificationsEnabled) {
                DownloadForegroundService.startService(context, downloadId, updatedItem.title)
            }

            val isAudio = initialItem.formatType == DownloadItem.FORMAT_AUDIO

            if (targetSource.isHls || targetSource.url.contains(".m3u8")) {
                // Real HLS Download
                hlsDownloader.downloadHlsStream(
                    streamUrl = targetSource.url,
                    outputPartFile = partFile,
                    destFile = destinationFile,
                    isAudio = isAudio,
                    onProgress = { downloadedBytes, totalBytes, speed, eta, currentSeg, totalSeg ->
                        val percent = if (totalBytes > 0) ((downloadedBytes.toFloat() / totalBytes) * 100).toInt() else 0
                        val progress = DownloadProgress(
                            downloadedBytes = downloadedBytes,
                            totalBytes = totalBytes,
                            bytesPerSec = speed,
                            etaSeconds = eta,
                            isHls = true,
                            currentSegment = currentSeg,
                            totalSegments = totalSeg
                        )
                        _activeProgress.value = _activeProgress.value + (downloadId to progress)

                        if (settings.notificationsEnabled) {
                            val statusText = formatStatusText(downloadedBytes, totalBytes, speed, eta)
                            DownloadForegroundService.updateProgress(context, downloadId, updatedItem.title, percent, statusText)
                        }
                    },
                    isCancelledOrPaused = { pausedJobs.contains(downloadId) || !activeJobs.containsKey(downloadId) }
                )
            } else {
                // Direct HTTP Streaming Download with Range support
                val directStreamUrl = parser.resolveDirectStreamUrl(targetSource.url)
                downloadDirectStream(
                    downloadId = downloadId,
                    streamUrl = directStreamUrl,
                    partFile = partFile,
                    destFile = destinationFile,
                    isAudio = isAudio,
                    title = updatedItem.title,
                    notificationsEnabled = settings.notificationsEnabled
                )
            }

            val finalSize = destinationFile.length()
            val completedItem = updatedItem.copy(
                filePath = destinationFile.absolutePath,
                size = finalSize,
                downloadedSize = finalSize,
                status = DownloadItem.STATUS_DONE,
                completedAt = System.currentTimeMillis(),
                errorMessage = null
            )
            safeInsertOrUpdate(completedItem)

            try {
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(destinationFile.absolutePath),
                    if (isAudio) arrayOf("audio/mpeg", "audio/*") else arrayOf("video/mp4", "video/*"),
                    null
                )
            } catch (e: Throwable) {
                SecurityLogger.w("MediaScanner error: ${e.message}")
            }

            _activeProgress.value = _activeProgress.value - downloadId

        } catch (e: CancellationException) {
            if (pausedJobs.contains(downloadId)) {
                updateStatus(downloadId, DownloadItem.STATUS_PAUSED)
            } else {
                updateStatus(downloadId, DownloadItem.STATUS_CANCELLED)
                if (partFile.exists()) partFile.delete()
            }
        } catch (e: Exception) {
            SecurityLogger.e("Download error safely handled", e)
            val safeErrMsg = SecurityGuard.sanitizeErrorMessage(e)
            val failedItem = initialItem.copy(
                status = DownloadItem.STATUS_ERROR,
                errorMessage = safeErrMsg
            )
            safeInsertOrUpdate(failedItem)
            _activeProgress.value = _activeProgress.value - downloadId
        } finally {
            downloadSemaphore.release()
            activeJobs.remove(downloadId)

            // Stop service if no more active jobs
            if (activeJobs.isEmpty()) {
                DownloadForegroundService.stopService(context)
            } else {
                // Trigger next queued item if available
                triggerNextQueuedDownload()
            }
        }
    }

    private suspend fun downloadDirectStream(
        downloadId: String,
        streamUrl: String,
        partFile: File,
        destFile: File,
        isAudio: Boolean,
        title: String,
        notificationsEnabled: Boolean
    ): Unit = withContext(Dispatchers.IO) {
        val safeStreamUrl = SecurityGuard.validateAndSanitizeUrl(streamUrl).getOrThrow()
        val existingBytes = if (partFile.exists()) partFile.length() else 0L

        val requestBuilder = Request.Builder()
            .url(safeStreamUrl)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) Chrome/131.0.0.0 Mobile Safari/537.36")
            .header("Referer", "https://substack.com/")

        if (existingBytes > 0) {
            requestBuilder.header("Range", "bytes=$existingBytes-")
        }

        val response = client.newCall(requestBuilder.build()).execute()
        if (!response.isSuccessful && response.code != 206) {
            response.close()
            if (existingBytes > 0) {
                partFile.delete()
                return@withContext downloadDirectStream(downloadId, safeStreamUrl, partFile, destFile, isAudio, title, notificationsEnabled)
            } else {
                throw IllegalStateException("خادم الوسائط أرجع خطأ (HTTP ${response.code})")
            }
        }

        val isAppend = response.code == 206 && existingBytes > 0
        val body = response.body ?: throw IllegalStateException("جسم الاستجابة فارغ.")
        val contentLength = body.contentLength()
        val totalBytes = if (isAppend) existingBytes + contentLength else contentLength

        if (totalBytes > SecurityGuard.MAX_ALLOWED_FILE_SIZE_BYTES) {
            response.close()
            throw SecurityException("حجم الملف يتجاوز الحد الأقصى المسموح به (2 جيجابايت).")
        }

        var downloaded = if (isAppend) existingBytes else 0L
        val startTime = System.currentTimeMillis()

        body.byteStream().use { input ->
            partFile.parentFile?.let { if (!it.exists()) it.mkdirs() }
            val output = if (isAppend) FileOutputStream(partFile, true) else FileOutputStream(partFile, false)

            output.use { out ->
                val buffer = ByteArray(64 * 1024)
                var bytesRead: Int
                var lastUpdate = System.currentTimeMillis()

                while (input.read(buffer).also { bytesRead = it } != -1) {
                    if (pausedJobs.contains(downloadId) || Thread.currentThread().isInterrupted) {
                        throw CancellationException("Download paused or cancelled")
                    }

                    if (downloaded + bytesRead > SecurityGuard.MAX_ALLOWED_FILE_SIZE_BYTES) {
                        throw SecurityException("تم تجاوز السعة الآمنة القصوى.")
                    }

                    out.write(buffer, 0, bytesRead)
                    downloaded += bytesRead

                    val now = System.currentTimeMillis()
                    if (now - lastUpdate >= 300) {
                        val elapsedSec = ((now - startTime) / 1000.0).coerceAtLeast(0.001)
                        val speed = (downloaded - (if (isAppend) existingBytes else 0L)) / elapsedSec
                        val remainingBytes = if (totalBytes > downloaded) totalBytes - downloaded else 0L
                        val eta = if (speed > 0) (remainingBytes / speed).toLong() else 0L

                        _activeProgress.value = _activeProgress.value + (
                            downloadId to DownloadProgress(
                                downloadedBytes = downloaded,
                                totalBytes = totalBytes,
                                bytesPerSec = speed,
                                etaSeconds = eta
                            )
                        )

                        if (notificationsEnabled) {
                            val percent = if (totalBytes > 0) ((downloaded.toFloat() / totalBytes) * 100).toInt() else 0
                            val statusText = formatStatusText(downloaded, totalBytes, speed, eta)
                            DownloadForegroundService.updateProgress(context, downloadId, title, percent, statusText)
                        }

                        lastUpdate = now
                    }
                }
            }
        }

        if (partFile.exists() && partFile.length() > 0) {
            val isVerified = SecurityGuard.verifyMediaFileIntegrity(partFile, isAudio)
            if (!isVerified) {
                partFile.delete()
                throw SecurityException("فشل التحقق: الملف لا يطابق توقيع الوسائط المعتمد.")
            }

            if (destFile.exists()) destFile.delete()
            val renamed = partFile.renameTo(destFile)
            if (!renamed) {
                partFile.copyTo(destFile, overwrite = true)
                partFile.delete()
            }
        } else {
            throw IllegalStateException("الملف الناتج فارغ.")
        }
    }

    private fun formatStatusText(downloaded: Long, total: Long, speed: Double, eta: Long): String {
        val speedMb = speed / (1024 * 1024)
        val downloadedMb = downloaded / (1024.0 * 1024.0)
        val totalMb = total / (1024.0 * 1024.0)
        val etaStr = String.format(Locale.US, "%02d:%02d", eta / 60, eta % 60)
        return String.format(
            Locale.US,
            "%.1f MB / %.1f MB • %.1f MB/s • ETA %s",
            downloadedMb,
            totalMb,
            speedMb,
            etaStr
        )
    }

    private fun triggerNextQueuedDownload() {
        applicationScope.launch {
            val next = dao?.getNextQueuedDownload() ?: inMemoryDownloads.value.find { it.status == DownloadItem.STATUS_QUEUED }
            if (next != null && !activeJobs.containsKey(next.id)) {
                resumeDownload(next.id)
            }
        }
    }

    fun pauseDownload(downloadId: String) {
        pausedJobs.add(downloadId)
        activeJobs[downloadId]?.cancel()
        applicationScope.launch {
            updateStatus(downloadId, DownloadItem.STATUS_PAUSED)
        }
    }

    fun pauseAll() {
        for (id in activeJobs.keys()) {
            pauseDownload(id)
        }
    }

    fun resumeDownload(downloadId: String) {
        pausedJobs.remove(downloadId)
        val job = applicationScope.launch(Dispatchers.IO) {
            val item = safeGetDownloadById(downloadId) ?: return@launch
            processDownloadQueue(downloadId, item, null, null)
        }
        activeJobs[downloadId] = job
    }

    fun resumeAll() {
        applicationScope.launch {
            val paused = inMemoryDownloads.value.filter { it.status == DownloadItem.STATUS_PAUSED || it.status == DownloadItem.STATUS_QUEUED }
            for (item in paused) {
                if (!activeJobs.containsKey(item.id)) {
                    resumeDownload(item.id)
                }
            }
        }
    }

    fun retryDownload(downloadId: String) {
        resumeDownload(downloadId)
    }

    fun retryAllFailed() {
        applicationScope.launch {
            val failed = inMemoryDownloads.value.filter { it.status == DownloadItem.STATUS_ERROR }
            for (item in failed) {
                retryDownload(item.id)
            }
        }
    }

    fun cancelDownload(downloadId: String) {
        pausedJobs.remove(downloadId)
        activeJobs[downloadId]?.cancel()
        _activeProgress.value = _activeProgress.value - downloadId

        applicationScope.launch(Dispatchers.IO) {
            val item = safeGetDownloadById(downloadId)
            if (item != null) {
                val targetFolder = getDownloadDir()
                val file = File(item.filePath)
                if (file.exists() && SecurityGuard.isPathStrictlyInsideDirectory(file, targetFolder)) {
                    file.delete()
                }
                val partFile = File(targetFolder, "${item.filename}.part")
                if (partFile.exists() && SecurityGuard.isPathStrictlyInsideDirectory(partFile, targetFolder)) {
                    partFile.delete()
                }
                safeDeleteById(downloadId)
            }
        }
    }

    fun cancelAll() {
        for (id in activeJobs.keys()) {
            cancelDownload(id)
        }
    }

    suspend fun deleteDownload(id: String, deleteFileFromStorage: Boolean = true) {
        val item = safeGetDownloadById(id)
        if (item != null) {
            if (deleteFileFromStorage && item.filePath.isNotBlank()) {
                val targetFolder = getDownloadDir()
                val file = File(item.filePath)
                if (file.exists() && SecurityGuard.isPathStrictlyInsideDirectory(file, targetFolder)) {
                    file.delete()
                }
            }
            safeDeleteById(id)
        }
    }

    suspend fun deleteDownloadsBatch(ids: List<String>, deleteFilesFromStorage: Boolean = true) {
        for (id in ids) {
            deleteDownload(id, deleteFilesFromStorage)
        }
    }

    suspend fun renameDownloadFile(id: String, newName: String): Boolean = withContext(Dispatchers.IO) {
        val item = safeGetDownloadById(id) ?: return@withContext false
        if (item.filePath.isBlank()) return@withContext false

        val oldFile = File(item.filePath)
        val targetFolder = getDownloadDir()
        if (!oldFile.exists() || !SecurityGuard.isPathStrictlyInsideDirectory(oldFile, targetFolder)) {
            return@withContext false
        }

        val cleanNewName = SecurityGuard.sanitizeFileName(newName, item.formatType == DownloadItem.FORMAT_AUDIO)
        val newFile = File(targetFolder, cleanNewName)

        if (oldFile.renameTo(newFile)) {
            val updated = item.copy(
                filename = cleanNewName,
                filePath = newFile.absolutePath,
                title = newName.substringBeforeLast(".")
            )
            safeInsertOrUpdate(updated)
            return@withContext true
        }
        return@withContext false
    }

    suspend fun clearCompletedHistory() {
        try {
            dao?.clearCompleted()
        } catch (e: Throwable) {
            inMemoryDownloads.update { current -> current.filterNot { it.status == DownloadItem.STATUS_DONE } }
        }
    }

    suspend fun clearAllHistory() {
        try {
            dao?.clearAll()
        } catch (e: Throwable) {
            inMemoryDownloads.value = emptyList()
        }
    }

    private suspend fun updateStatus(id: String, status: String) {
        val current = safeGetDownloadById(id)
        if (current != null) {
            safeInsertOrUpdate(current.copy(status = status))
        }
    }
}
