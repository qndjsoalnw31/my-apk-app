package com.example

import com.example.network.TikTokParser
import com.example.network.hls.HlsParser
import com.example.security.SecurityGuard
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Semaphore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.FileOutputStream

class DefectFixesComprehensiveTest {

    @Test
    fun testSemaphorePermitLeakPrevention() = runBlocking {
        val semaphore = Semaphore(2)
        assertEquals(2, semaphore.availablePermits)

        // Simulate cancellation before acquire or during wait
        var permitAcquired = false
        try {
            // Suppose cancelled before acquiring permit
            throw CancellationException("Cancelled before acquire")
        } catch (_: CancellationException) {
            // caught
        } finally {
            if (permitAcquired) {
                semaphore.release()
            }
        }

        // Available permits must still be exactly 2, not 3!
        assertEquals(2, semaphore.availablePermits)
    }

    @Test
    fun testSemaphorePermitNormalRelease() = runBlocking {
        val semaphore = Semaphore(2)
        assertEquals(2, semaphore.availablePermits)

        var permitAcquired = false
        try {
            semaphore.acquire()
            permitAcquired = true
            assertEquals(1, semaphore.availablePermits)
        } finally {
            if (permitAcquired) {
                semaphore.release()
            }
        }

        assertEquals(2, semaphore.availablePermits)
    }

    @Test
    fun testMasterPlaylistDetectionAndExtraction() {
        val parser = HlsParser()
        val masterM3u8 = """
            #EXTM3U
            #EXT-X-STREAM-INF:BANDWIDTH=3000000,RESOLUTION=1280x720
            chunklist_720.m3u8
            #EXT-X-STREAM-INF:BANDWIDTH=1500000,RESOLUTION=854x480
            chunklist_480.m3u8
        """.trimIndent()

        val master = parser.parseMasterContent("https://video.substack.com/master.m3u8", masterM3u8)
        assertEquals(2, master.variants.size)
        assertEquals("https://video.substack.com/chunklist_720.m3u8", master.variants[0].url)
        assertEquals("720p HD", master.variants[0].qualityLabel)
    }

    @Test
    fun testMediaFileIntegrityWithValidMp4Header() {
        val tempFile = File.createTempFile("valid_mp4_", ".mp4")
        try {
            FileOutputStream(tempFile).use { out ->
                // Standard MP4 box header: size (4 bytes), 'ftyp' (4 bytes), 'isom' (4 bytes)
                val mp4Header = byteArrayOf(
                    0x00, 0x00, 0x00, 0x20,
                    'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(),
                    'i'.code.toByte(), 's'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(),
                    0x00, 0x00, 0x02, 0x00
                )
                out.write(mp4Header)
                out.write(ByteArray(64))
            }
            assertTrue(SecurityGuard.verifyMediaFileIntegrity(tempFile, isAudio = false))
        } finally {
            tempFile.delete()
        }
    }

    @Test
    fun testTikTokShortLinkResolutionPatterns() {
        assertTrue(TikTokParser.isTikTokUrl("https://vt.tiktok.com/ZSbWy4qSM/"))
        assertTrue(TikTokParser.isTikTokUrl("https://vm.tiktok.com/ZM123456/"))
        assertTrue(TikTokParser.isTikTokUrl("https://www.tiktok.com/@creator/video/1234567890"))
        assertFalse(TikTokParser.isTikTokUrl("https://substack.com/@author/p/123"))
    }

    @Test
    fun testSharedStorageSubfolderConstant() {
        assertEquals("SubstackDownloader", com.example.ui.util.MediaExportHelper.SUBFOLDER_NAME)
    }
}
