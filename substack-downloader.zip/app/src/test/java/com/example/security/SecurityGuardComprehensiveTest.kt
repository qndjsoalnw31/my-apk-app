package com.example.security

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SecurityGuardComprehensiveTest {

    @Test
    fun testUrlSanitizationAndSsrfBlocking() {
        val loopback = "http://127.0.0.1:8080/admin"
        assertFalse(SecurityGuard.validateAndSanitizeUrl(loopback).isSuccess)

        val metadata = "http://169.254.169.254/latest/meta-data/"
        assertFalse(SecurityGuard.validateAndSanitizeUrl(metadata).isSuccess)

        val localhost = "https://localhost/private"
        assertFalse(SecurityGuard.validateAndSanitizeUrl(localhost).isSuccess)

        val validSubstack = "https://substack.com/@tech/note/c-12345"
        assertTrue(SecurityGuard.validateAndSanitizeUrl(validSubstack).isSuccess)
    }

    @Test
    fun testPathTraversalValidation() {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "substack_test_safe")
        tempDir.mkdirs()

        val safeFile = File(tempDir, "video_123.mp4")
        assertTrue(SecurityGuard.isPathStrictlyInsideDirectory(safeFile, tempDir))

        val escapedFile = File(tempDir, "../../../etc/shadow")
        assertFalse(SecurityGuard.isPathStrictlyInsideDirectory(escapedFile, tempDir))

        tempDir.deleteRecursively()
    }

    @Test
    fun testTextSanitization() {
        val raw = "<script>alert('XSS')</script><b>Hello</b> World\u0000"
        val clean = SecurityGuard.sanitizeText(raw)
        assertFalse(clean.contains("<script>"))
        assertFalse(clean.contains("<b>"))
        assertFalse(clean.contains("\u0000"))
        assertTrue(clean.contains("Hello"))
        assertTrue(clean.contains("World"))
    }
}
