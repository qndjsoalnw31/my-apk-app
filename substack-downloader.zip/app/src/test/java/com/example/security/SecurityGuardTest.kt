package com.example.security

import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.io.FileOutputStream

class SecurityGuardTest {

    @Test
    fun `test SSRF protection blocks localhost and private IPs`() {
        val dangerousUrls = listOf(
            "http://localhost:8080/admin",
            "http://127.0.0.1:8000/api",
            "http://0.0.0.0/",
            "http://169.254.169.254/latest/meta-data/",
            "http://10.0.0.1/secret",
            "http://192.168.1.1/router",
            "http://172.16.0.5/internal",
            "file:///etc/passwd",
            "javascript:alert(1)",
            "ftp://127.0.0.1/test"
        )

        for (url in dangerousUrls) {
            val result = SecurityGuard.validateAndSanitizeUrl(url)
            assertTrue("Expected URL '$url' to be rejected by SSRF protection", result.isFailure)
        }
    }

    @Test
    fun `test valid HTTPS Substack and CDN URLs are accepted`() {
        val validUrls = listOf(
            "https://substack.com/@user/note/c-12345678",
            "https://example.substack.com/p/my-post",
            "https://substackcdn.com/media/video.mp4",
            "https://videodelivery.net/abc12345/manifest/video.m3u8"
        )

        for (url in validUrls) {
            val result = SecurityGuard.validateAndSanitizeUrl(url)
            assertTrue("Expected URL '$url' to be accepted", result.isSuccess)
        }
    }

    @Test
    fun `test Path Traversal protection in filename sanitization`() {
        val attackNames = listOf(
            "../../../../etc/passwd",
            "..\\..\\windows\\system32\\calc.exe",
            "../../../evil.sh",
            "some_note\u0000.mp4",
            "note; rm -rf /; echo.mp4",
            "note | cat /etc/shadow",
            "note`whoami`.mp4"
        )

        for (attack in attackNames) {
            val sanitized = SecurityGuard.sanitizeFileName(attack, isAudio = false)
            assertFalse("Sanitized name should not contain path traversal: $sanitized", sanitized.contains(".."))
            assertFalse("Sanitized name should not contain forward slashes: $sanitized", sanitized.contains("/"))
            assertFalse("Sanitized name should not contain backslashes: $sanitized", sanitized.contains("\\"))
            assertFalse("Sanitized name should not contain null bytes: $sanitized", sanitized.contains("\u0000"))
            assertFalse("Sanitized name should not contain shell characters: $sanitized", sanitized.contains(";"))
            assertFalse("Sanitized name should not contain shell characters: $sanitized", sanitized.contains("|"))
            assertFalse("Sanitized name should not contain shell characters: $sanitized", sanitized.contains("`"))
            assertTrue("Sanitized filename should end with .mp4", sanitized.endsWith(".mp4"))
        }
    }

    @Test
    fun `test XSS and HTML injection sanitization`() {
        val maliciousInputs = listOf(
            "<script>alert('XSS')</script>Hello World" to "Hello World",
            "<img src=x onerror=alert(1)>Title" to "Title",
            "<style>body{display:none}</style>Clean Text" to "Clean Text",
            "Normal Text with <b>bold</b> tag" to "Normal Text with bold tag"
        )

        for ((input, expectedClean) in maliciousInputs) {
            val cleaned = SecurityGuard.sanitizeText(input)
            assertFalse("Cleaned text must not contain script tags", cleaned.contains("<script>", ignoreCase = true))
            assertFalse("Cleaned text must not contain img tags", cleaned.contains("<img", ignoreCase = true))
            assertEquals(expectedClean, cleaned)
        }
    }

    @Test
    fun `test Magic Byte detection blocks executable binaries disguised as media`() {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "sec_tests").apply { mkdirs() }

        // 1. Fake ELF binary
        val elfFile = File(tempDir, "evil_elf.mp4")
        FileOutputStream(elfFile).use {
            it.write(byteArrayOf(0x7F, 'E'.code.toByte(), 'L'.code.toByte(), 'F'.code.toByte(), 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0))
        }
        assertFalse("ELF binary disguised as mp4 must be rejected", SecurityGuard.verifyMediaFileIntegrity(elfFile, isAudio = false))

        // 2. Fake Shell script
        val shFile = File(tempDir, "evil_script.mp4")
        FileOutputStream(shFile).use {
            it.write("#!/bin/bash\nrm -rf /\n".toByteArray(Charsets.US_ASCII))
        }
        assertFalse("Shell script disguised as mp4 must be rejected", SecurityGuard.verifyMediaFileIntegrity(shFile, isAudio = false))

        // 3. Fake HTML script
        val htmlFile = File(tempDir, "evil_page.mp4")
        FileOutputStream(htmlFile).use {
            it.write("<html><script>alert(1)</script></html>".toByteArray(Charsets.US_ASCII))
        }
        assertFalse("HTML file disguised as mp4 must be rejected", SecurityGuard.verifyMediaFileIntegrity(htmlFile, isAudio = false))

        // 4. Clean up
        elfFile.delete()
        shFile.delete()
        htmlFile.delete()
        tempDir.delete()
    }

    @Test
    fun `test Error Message Sanitization prevents internal path and secret leakage`() {
        val sensitiveException = Exception("Failed writing to /data/user/0/com.example/databases/secrets.db?token=super_secret_12345")
        val sanitized = SecurityGuard.sanitizeErrorMessage(sensitiveException)

        assertFalse("Error message should not expose internal private paths", sanitized.contains("/data/user/0/com.example"))
        assertFalse("Error message should not expose secret token values", sanitized.contains("super_secret_12345"))
    }
}
