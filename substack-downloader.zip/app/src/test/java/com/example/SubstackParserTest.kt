package com.example

import com.example.network.SubstackParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SubstackParserTest {

    @Test
    fun testExtractNoteIdFromVariousFormats() {
        val url1 = "https://substack.com/@alex/note/c-12345678"
        assertEquals("12345678", SubstackParser.extractNoteId(url1))

        val url2 = "https://author.substack.com/notes/c-9876543210"
        assertEquals("9876543210", SubstackParser.extractNoteId(url2))

        val url3 = "https://open.substack.com/pub/alex/note/c-55443322?r=abc"
        assertEquals("55443322", SubstackParser.extractNoteId(url3))

        val url4 = "https://substack.com/api/v1/reader/comment/778899"
        assertEquals("778899", SubstackParser.extractNoteId(url4))
    }

    @Test
    fun testExtractPostSlug() {
        val url = "https://newsletter.substack.com/p/building-great-software"
        val (host, slug) = SubstackParser.extractPostSlug(url)
        assertEquals("newsletter.substack.com", host)
        assertEquals("building-great-software", slug)
    }

    @Test
    fun testSafeFilenameSanitization() {
        val dangerousTitle = "How to Hack <script>alert(1)</script> / ../ etc/passwd"
        val safeName = SubstackParser.safeFilename(dangerousTitle, downloadId = "test1234", isAudio = false)

        assertTrue(safeName.endsWith(".mp4"))
        assertTrue(!safeName.contains("/"))
        assertTrue(!safeName.contains("\\"))
        assertTrue(!safeName.contains("<"))
        assertTrue(!safeName.contains(".."))
    }
}
