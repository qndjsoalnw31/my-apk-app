package com.example

import com.example.data.model.ContentType
import com.example.data.model.DownloadItem
import com.example.network.TikTokParser
import com.example.security.SecurityGuard
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class TikTokParserTest {

    private val parser = TikTokParser()

    @Test
    fun testIsTikTokUrl() {
        assertTrue(TikTokParser.isTikTokUrl("https://www.tiktok.com/@user/video/1234567890"))
        assertTrue(TikTokParser.isTikTokUrl("https://tiktok.com/@user/video/1234567890"))
        assertTrue(TikTokParser.isTikTokUrl("https://vt.tiktok.com/ZS123456/"))
        assertTrue(TikTokParser.isTikTokUrl("https://vm.tiktok.com/ZM123456/"))
        assertTrue(TikTokParser.isTikTokUrl("https://m.tiktok.com/v/1234567890.html"))
        assertTrue(TikTokParser.isTikTokUrl("https://vt.tiktok.com/ZSbWy4qSM/"))

        assertFalse(TikTokParser.isTikTokUrl("https://substack.com/@writer/post/123"))
        assertFalse(TikTokParser.isTikTokUrl("https://youtube.com/watch?v=123"))
        assertFalse(TikTokParser.isTikTokUrl(""))
        assertFalse(TikTokParser.isTikTokUrl(null))
    }

    @Test
    fun testParseTikWmImageCarousel() {
        val json = JSONObject().apply {
            put("id", "7123456789")
            put("title", "Beautiful photo slide collection")
            put("cover", "https://p16.tiktokcdn.com/cover.jpeg")
            put("music", "https://sf16.tiktokcdn.com/music.mp3")
            put("images", JSONArray().apply {
                put("https://p16.tiktokcdn.com/img1.jpeg")
                put("https://p16.tiktokcdn.com/img2.jpeg")
                put("https://p16.tiktokcdn.com/img3.jpeg")
            })
            put("author", JSONObject().apply {
                put("unique_id", "photo_creator")
                put("nickname", "Photo Creator")
            })
        }

        val details = parser.parseTikWmData(json, "https://vt.tiktok.com/ZSbWy4qSM/")

        assertEquals(ContentType.IMAGE_CAROUSEL, details.contentType)
        assertEquals(3, details.imageUrls.size)
        assertEquals("https://p16.tiktokcdn.com/img1.jpeg", details.imageUrls[0])
        assertEquals("https://p16.tiktokcdn.com/img2.jpeg", details.imageUrls[1])
        assertEquals("https://p16.tiktokcdn.com/img3.jpeg", details.imageUrls[2])
        // Music must be retained as an audio source without transforming the post to video
        assertTrue(details.videoSources.any { it.type == "audio" })
        assertEquals("@photo_creator", details.author)
    }

    @Test
    fun testParseTikWmSingleImage() {
        val json = JSONObject().apply {
            put("id", "7123456790")
            put("title", "Single photo post")
            put("cover", "https://p16.tiktokcdn.com/single.jpeg")
            put("images", JSONArray().apply {
                put("https://p16.tiktokcdn.com/single.jpeg")
            })
            put("author", JSONObject().apply {
                put("unique_id", "solo_artist")
            })
        }

        val details = parser.parseTikWmData(json, "https://tiktok.com/@solo_artist/video/7123456790")

        assertEquals(ContentType.IMAGE, details.contentType)
        assertEquals(1, details.imageUrls.size)
        assertEquals("https://p16.tiktokcdn.com/single.jpeg", details.imageUrls[0])
    }

    @Test
    fun testParseTikWmStandardVideo() {
        val json = JSONObject().apply {
            put("id", "7123456791")
            put("title", "Cool viral video")
            put("cover", "https://p16.tiktokcdn.com/thumb.jpeg")
            put("play", "https://www.tikwm.com/video/play.mp4")
            put("hdplay", "https://www.tikwm.com/video/hdplay.mp4")
            put("music", "https://sf16.tiktokcdn.com/bgm.mp3")
            put("author", JSONObject().apply {
                put("unique_id", "dancer123")
            })
        }

        val details = parser.parseTikWmData(json, "https://tiktok.com/@dancer123/video/7123456791")

        assertEquals(ContentType.VIDEO, details.contentType)
        assertEquals(0, details.imageUrls.size)
        assertTrue(details.videoSources.any { it.type == "mp4" && it.quality.contains("1080p") })
        assertTrue(details.videoSources.any { it.type == "audio" })
    }

    @Test
    fun testImageMagicBytesValidationInSecurityGuard() {
        // 1. JPEG: FF D8 FF
        val jpegFile = File.createTempFile("test_", ".jpg")
        try {
            FileOutputStream(jpegFile).use { out ->
                out.write(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte()))
                out.write(ByteArray(32))
            }
            assertTrue(SecurityGuard.verifyMediaFileIntegrity(jpegFile, isAudio = false, isImage = true))
        } finally {
            jpegFile.delete()
        }

        // 2. PNG: 89 50 4E 47
        val pngFile = File.createTempFile("test_", ".png")
        try {
            FileOutputStream(pngFile).use { out ->
                out.write(byteArrayOf(0x89.toByte(), 0x50.toByte(), 0x4E.toByte(), 0x47.toByte(), 0x0D.toByte(), 0x0A.toByte(), 0x1A.toByte(), 0x0A.toByte()))
                out.write(ByteArray(32))
            }
            assertTrue(SecurityGuard.verifyMediaFileIntegrity(pngFile, isAudio = false, isImage = true))
        } finally {
            pngFile.delete()
        }

        // 3. WebP: RIFF .... WEBP
        val webpFile = File.createTempFile("test_", ".webp")
        try {
            FileOutputStream(webpFile).use { out ->
                val webpHeader = byteArrayOf(
                    'R'.code.toByte(), 'I'.code.toByte(), 'F'.code.toByte(), 'F'.code.toByte(),
                    0x20, 0x00, 0x00, 0x00,
                    'W'.code.toByte(), 'E'.code.toByte(), 'B'.code.toByte(), 'P'.code.toByte(),
                    'V'.code.toByte(), 'P'.code.toByte(), '8'.code.toByte(), ' '.code.toByte()
                )
                out.write(webpHeader)
                out.write(ByteArray(32))
            }
            assertTrue(SecurityGuard.verifyMediaFileIntegrity(webpFile, isAudio = false, isImage = true))
        } finally {
            webpFile.delete()
        }
    }

    @Test
    fun testSanitizeFileNameWithIsImage() {
        val imageFileName = SecurityGuard.sanitizeFileName(
            rawTitle = "TikTok Photo Slide 1",
            isAudio = false,
            isImage = true,
            suffixId = "img_01"
        )
        assertTrue(imageFileName.endsWith(".jpg"))
        assertTrue(imageFileName.contains("img_01"))

        val videoFileName = SecurityGuard.sanitizeFileName(
            rawTitle = "TikTok Video 1",
            isAudio = false,
            isImage = false
        )
        assertTrue(videoFileName.endsWith(".mp4"))

        val audioFileName = SecurityGuard.sanitizeFileName(
            rawTitle = "TikTok Sound 1",
            isAudio = true,
            isImage = false
        )
        assertTrue(audioFileName.endsWith(".mp3"))
    }

    @Test
    fun testParseTikWmVerticalVideo() {
        val json = JSONObject().apply {
            put("id", "719999901")
            put("title", "Vertical portrait video 9:16")
            put("cover", "https://p16.tiktokcdn.com/vertical_thumb.jpeg")
            put("play", "https://www.tikwm.com/video/vertical_play.mp4")
            put("hdplay", "https://www.tikwm.com/video/vertical_hd.mp4")
            put("author", JSONObject().apply {
                put("unique_id", "vertical_creator")
            })
        }

        val details = parser.parseTikWmData(json, "https://tiktok.com/@vertical_creator/video/719999901")

        assertEquals(ContentType.VIDEO, details.contentType)
        assertEquals(0, details.imageUrls.size)
        val hdSource = details.videoSources.firstOrNull { it.quality.contains("HD") }
        assertTrue(hdSource != null)
        assertEquals("video/mp4", hdSource?.mimeType)
        // Ensure original stream URL is untouched
        assertEquals("https://www.tikwm.com/video/vertical_hd.mp4", hdSource?.url)
    }

    @Test
    fun testParseTikWmHorizontalVideo() {
        val json = JSONObject().apply {
            put("id", "719999902")
            put("title", "Horizontal landscape video 16:9")
            put("cover", "https://p16.tiktokcdn.com/horizontal_thumb.jpeg")
            put("play", "https://www.tikwm.com/video/horizontal_play.mp4")
            put("hdplay", "https://www.tikwm.com/video/horizontal_hd.mp4")
            put("author", JSONObject().apply {
                put("unique_id", "landscape_creator")
            })
        }

        val details = parser.parseTikWmData(json, "https://tiktok.com/@landscape_creator/video/719999902")

        assertEquals(ContentType.VIDEO, details.contentType)
        assertEquals(0, details.imageUrls.size)
        val hdSource = details.videoSources.firstOrNull { it.quality.contains("HD") }
        assertTrue(hdSource != null)
        assertEquals("https://www.tikwm.com/video/horizontal_hd.mp4", hdSource?.url)
    }

    @Test
    fun testParseTikWmPhotoWithAudioDoesNotConvertToVideo() {
        val json = JSONObject().apply {
            put("id", "719999903")
            put("title", "Carousel with background music")
            put("music", "https://sf16.tiktokcdn.com/music_track.mp3")
            put("images", JSONArray().apply {
                put("https://p16.tiktokcdn.com/photo1.jpg")
                put("https://p16.tiktokcdn.com/photo2.jpg")
            })
            put("play", "https://www.tikwm.com/video/slideshow_rendered.mp4") // Rendered slideshow from source
            put("author", JSONObject().apply {
                put("unique_id", "photographer")
            })
        }

        val details = parser.parseTikWmData(json, "https://tiktok.com/@photographer/video/719999903")

        // CRITICAL REQUIREMENT: Must NOT convert photos into video even if music or slideshow mp4 is present!
        assertEquals(ContentType.IMAGE_CAROUSEL, details.contentType)
        assertEquals(2, details.imageUrls.size)
        assertFalse(details.videoSources.any { it.type == "mp4" })
        assertTrue(details.videoSources.any { it.type == "audio" })
    }

    @Test
    fun testParseTikWmUnsupportedOrEmptyPost() {
        val json = JSONObject().apply {
            put("id", "719999904")
            put("title", "Empty or corrupt post")
        }

        val details = parser.parseTikWmData(json, "https://tiktok.com/@user/video/719999904")

        assertEquals(ContentType.UNSUPPORTED, details.contentType)
        assertEquals(0, details.imageUrls.size)
        assertEquals(0, details.videoSources.size)
    }

    @Test
    fun testSingleImageFailureInCarouselDoesNotCorruptOthers() {
        val images = listOf(
            "https://p16.tiktokcdn.com/valid1.jpg",
            "https://p16.tiktokcdn.com/broken2.jpg",
            "https://p16.tiktokcdn.com/valid3.jpg"
        )
        val downloaded = mutableListOf<String>()
        val failed = mutableListOf<String>()

        images.forEachIndexed { index, url ->
            try {
                if (url.contains("broken")) {
                    throw IllegalStateException("Network timeout on image $index")
                }
                val filename = SecurityGuard.sanitizeFileName("Photo", isAudio = false, suffixId = "img_$index", isImage = true)
                downloaded.add(filename)
            } catch (e: Exception) {
                failed.add(url)
            }
        }

        assertEquals(2, downloaded.size)
        assertEquals(1, failed.size)
        assertTrue(downloaded[0].endsWith(".jpg"))
        assertTrue(downloaded[1].endsWith(".jpg"))
    }
}
