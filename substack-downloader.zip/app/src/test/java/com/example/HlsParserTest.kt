package com.example

import com.example.network.hls.HlsParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HlsParserTest {

    private val parser = HlsParser()

    @Test
    fun testParseMasterPlaylist() {
        val masterContent = """
            #EXTM3U
            #EXT-X-VERSION:3
            #EXT-X-STREAM-INF:BANDWIDTH=4500000,RESOLUTION=1920x1080,FRAME-RATE=30.000,CODECS="avc1.640028,mp4a.40.2"
            1080p/index.m3u8
            #EXT-X-STREAM-INF:BANDWIDTH=2200000,RESOLUTION=1280x720,FRAME-RATE=30.000,CODECS="avc1.4d401f,mp4a.40.2"
            720p/index.m3u8
            #EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=854x480,FRAME-RATE=30.000,CODECS="avc1.4d401e,mp4a.40.2"
            480p/index.m3u8
        """.trimIndent()

        val baseUrl = "https://cdn.substack.com/videos/master.m3u8"
        val playlist = parser.parseMasterContent(baseUrl, masterContent)

        assertEquals(3, playlist.variants.size)
        assertEquals("1920x1080", playlist.variants[0].resolution)
        assertEquals("1080p Full HD", playlist.variants[0].qualityLabel)
        assertEquals("https://cdn.substack.com/videos/1080p/index.m3u8", playlist.variants[0].url)

        assertEquals("1280x720", playlist.variants[1].resolution)
        assertEquals("720p HD", playlist.variants[1].qualityLabel)
    }

    @Test
    fun testParseMediaPlaylist() {
        val mediaContent = """
            #EXTM3U
            #EXT-X-VERSION:3
            #EXT-X-TARGETDURATION:6
            #EXT-X-MEDIA-SEQUENCE:0
            #EXTINF:5.000,
            segment0.ts
            #EXTINF:5.000,
            segment1.ts
            #EXTINF:3.200,
            segment2.ts
            #EXT-X-ENDLIST
        """.trimIndent()

        val baseUrl = "https://cdn.substack.com/videos/1080p/index.m3u8"
        val playlist = parser.parseMediaContent(baseUrl, mediaContent)

        assertEquals(3, playlist.segments.size)
        assertEquals(13.2, playlist.totalDuration, 0.01)
        assertTrue(playlist.isEndList)
        assertEquals("https://cdn.substack.com/videos/1080p/segment0.ts", playlist.segments[0].url)
        assertEquals("https://cdn.substack.com/videos/1080p/segment1.ts", playlist.segments[1].url)
    }
}
