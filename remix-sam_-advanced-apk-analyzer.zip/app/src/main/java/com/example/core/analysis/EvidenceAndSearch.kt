package com.example.core.analysis

import com.example.core.model.ApkAnalysisResult
import com.example.core.model.EvidenceLevel
import com.example.core.model.MethodInfo
import com.example.core.model.SearchResult
import com.example.core.model.SearchTargetType
import com.example.core.model.TextSearchOptions
import com.example.core.model.TextSearchScope
import com.example.core.model.TypeCategory

/**
 * Strong Evidence Scoring System.
 * Calculates confidence score (0-100%) and categorizes into Strong (90-100%), Medium (60-89%), and Weak (0-59%).
 */
object EvidenceEngine {

    fun calculateMethodEvidence(
        methodName: String,
        className: String,
        packageName: String,
        returnCategory: TypeCategory,
        parameters: List<String>,
        strings: List<String>,
        callersCount: Int,
        calleesCount: Int
    ): Pair<Int, List<String>> {
        var score = 0
        val reasons = mutableListOf<String>()

        val lowerMethod = methodName.lowercase()
        val lowerClass = className.lowercase()

        // 1. Method Name Scoring (up to 40)
        when {
            lowerMethod.contains("premium") || lowerMethod.contains("ispro") ||
                    lowerMethod.contains("issubscribed") || lowerMethod.contains("entitlement") ||
                    lowerMethod.contains("checklicense") || lowerMethod.contains("checkuserstatus") -> {
                score += 35
                reasons.add("High-value entitlement method identifier: '$methodName'")
            }
            lowerMethod.contains("billing") || lowerMethod.contains("purchase") ||
                    lowerMethod.contains("verify") || lowerMethod.contains("unlock") ||
                    lowerMethod.contains("auth") || lowerMethod.contains("vip") -> {
                score += 25
                reasons.add("Commercial/Security action keyword in method name: '$methodName'")
            }
            lowerMethod.contains("get") || lowerMethod.contains("set") || lowerMethod.contains("is") -> {
                score += 10
                reasons.add("Accessor method pattern")
            }
        }

        // 2. Class Name & Package Context (up to 25)
        if (lowerClass.contains("billing") || lowerClass.contains("subscription") ||
            lowerClass.contains("license") || lowerClass.contains("premium") ||
            lowerClass.contains("security") || lowerClass.contains("entitlement")) {
            score += 25
            reasons.add("Defined within sensitive domain class: '$className'")
        } else if (lowerClass.contains("manager") || lowerClass.contains("service") ||
            lowerClass.contains("controller") || lowerClass.contains("helper")) {
            score += 12
            reasons.add("Located in core business logic component: '$className'")
        }

        // 3. Associated Strings in Method Body (up to 25)
        val sensitiveStrings = strings.filter { str ->
            val l = str.lowercase()
            l.contains("sku") || l.contains("purchase") || l.contains("premium") ||
                    l.contains("subscription") || l.contains("token") || l.contains("license") ||
                    l.contains("billing") || l.contains("granted") || l.contains("expired")
        }
        if (sensitiveStrings.isNotEmpty()) {
            val stringBoost = (sensitiveStrings.size * 10).coerceAtMost(25)
            score += stringBoost
            reasons.add("Referenced key string constants: ${sensitiveStrings.take(2).joinToString(", ")}")
        }

        // 4. Return Type Pattern (up to 15)
        if (returnCategory == TypeCategory.BOOLEAN) {
            score += 15
            reasons.add("Boolean verification predicate (flag evaluation)")
        } else if (returnCategory == TypeCategory.STRING || returnCategory == TypeCategory.OBJECT) {
            score += 8
            reasons.add("Data carrier return type")
        }

        // 5. Call Graph & Interactions (up to 10)
        if (callersCount > 0 && calleesCount > 0) {
            score += 10
            reasons.add("Active nexus in call graph ($callersCount callers, $calleesCount outgoing invokes)")
        } else if (callersCount > 0 || calleesCount > 0) {
            score += 5
            reasons.add("Connected node in call hierarchy")
        }

        // Normalize to max 100
        val finalScore = score.coerceIn(5, 100)
        return Pair(finalScore, reasons)
    }

    fun toEvidenceLevel(score: Int): EvidenceLevel {
        return when {
            score >= 90 -> EvidenceLevel.STRONG
            score >= 60 -> EvidenceLevel.MEDIUM
            else -> EvidenceLevel.WEAK
        }
    }
}

/**
 * Smart Search Engine.
 * Expands concepts into semantic synonyms and returns ranked results with full evidence justification.
 */
object SearchEngine {

    private val SYNONYM_MAP = mapOf(
        "premium" to listOf("premium", "pro", "vip", "subscription", "purchase", "billing", "trial", "entitlement", "upgrade", "license", "tier", "paywall"),
        "pro" to listOf("pro", "premium", "vip", "subscription", "purchase", "billing", "unlocked"),
        "subscription" to listOf("subscription", "subscribe", "sub", "billing", "purchase", "auto_renew", "expiry", "tier", "plan"),
        "billing" to listOf("billing", "inapp", "purchase", "play_billing", "sku", "order", "receipt", "acknowledge"),
        "auth" to listOf("auth", "login", "authenticate", "token", "jwt", "session", "credential", "oauth", "password", "user", "bearer"),
        "login" to listOf("login", "signin", "auth", "token", "password", "session", "credential"),
        "network" to listOf("http", "retrofit", "okhttp", "endpoint", "url", "api", "request", "response", "client", "download"),
        "api" to listOf("api", "endpoint", "rest", "url", "service", "retrofit", "fetch"),
        "security" to listOf("security", "crypto", "cipher", "ssl", "cert", "pinning", "keystore", "aes", "rsa", "hash", "integrity"),
        "root" to listOf("root", "su", "superuser", "busybox", "magisk", "jailbreak", "xposed", "frida"),
        "ads" to listOf("admob", "ads", "advertisement", "interstitial", "rewarded", "banner", "unityads", "applovin")
    )

    fun search(
        query: String,
        methods: List<MethodInfo>,
        strings: List<com.example.core.model.StringItem>,
        classes: List<com.example.core.model.ClassInfo>
    ): List<SearchResult> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()

        // Find concept synonyms
        val synonyms = mutableSetOf(q)
        for ((concept, synList) in SYNONYM_MAP) {
            if (concept.contains(q) || q.contains(concept) || synList.any { it.contains(q) }) {
                synonyms.addAll(synList)
            }
        }

        val results = mutableListOf<SearchResult>()

        // Search in Methods
        for (m in methods) {
            val lowerMethod = m.name.lowercase()
            val lowerClass = m.className.lowercase()

            val directMatch = synonyms.firstOrNull { lowerMethod.contains(it) }
            val classMatch = synonyms.firstOrNull { lowerClass.contains(it) }
            val stringMatch = m.associatedStrings.firstOrNull { str ->
                synonyms.any { syn -> str.lowercase().contains(syn) }
            }

            if (directMatch != null || classMatch != null || stringMatch != null) {
                val matched = directMatch ?: classMatch ?: stringMatch ?: q
                val reason = when {
                    directMatch != null -> "Matched semantic term '$directMatch' in method name"
                    classMatch != null -> "Matched term '$classMatch' in enclosing class name"
                    else -> "Method references matched string constant '$stringMatch'"
                }

                results.add(
                    SearchResult(
                        id = m.id,
                        title = "${m.className.substringAfterLast('.')}.${m.name}()",
                        subtitle = "${m.packageName} • Returns: ${m.returnType.displayName}",
                        targetType = SearchTargetType.METHOD,
                        matchedTerm = matched,
                        evidenceScore = m.evidenceScore,
                        evidenceLevel = m.evidenceLevel,
                        reason = reason,
                        associatedObject = m
                    )
                )
            }
        }

        // Search in Classes
        for (c in classes) {
            val lowerClass = c.id.lowercase()
            val matchedSyn = synonyms.firstOrNull { lowerClass.contains(it) }
            if (matchedSyn != null) {
                val level = when {
                    c.evidenceScore >= 90 -> EvidenceLevel.STRONG
                    c.evidenceScore >= 60 -> EvidenceLevel.MEDIUM
                    else -> EvidenceLevel.WEAK
                }
                results.add(
                    SearchResult(
                        id = c.id,
                        title = c.simpleName,
                        subtitle = "${c.packageName} (${c.methods.size} methods, ${c.fields.size} fields)",
                        targetType = SearchTargetType.CLASS,
                        matchedTerm = matchedSyn,
                        evidenceScore = c.evidenceScore,
                        evidenceLevel = level,
                        reason = "Class identifier matches concept '$matchedSyn'",
                        associatedObject = c
                    )
                )
            }
        }

        // Search in Strings
        for (s in strings) {
            val lowerVal = s.value.lowercase()
            val matched = synonyms.firstOrNull { lowerVal.contains(it) }
            if (matched != null) {
                results.add(
                    SearchResult(
                        id = "str_${s.value.hashCode()}",
                        title = "\"${s.value}\"",
                        subtitle = "Category: ${s.category.name} • Occurrences: ${s.occurrences}",
                        targetType = if (s.value.startsWith("http")) SearchTargetType.URL else SearchTargetType.STRING,
                        matchedTerm = matched,
                        evidenceScore = if (s.category == com.example.core.model.StringCategory.SUBSCRIPTION || s.category == com.example.core.model.StringCategory.AUTHENTICATION) 88 else 65,
                        evidenceLevel = if (s.category == com.example.core.model.StringCategory.SUBSCRIPTION) EvidenceLevel.STRONG else EvidenceLevel.MEDIUM,
                        reason = "String constant classified under ${s.category.name}",
                        associatedObject = s
                    )
                )
            }
        }

        // Rank by Evidence Score (strongest first)
        return results.sortedByDescending { it.evidenceScore }
    }
}

/**
 * Dedicated Engine for Exact & Specific Text Searching across the entire APK.
 * Searches across DEX Constant Strings, Smali Bytecode instructions, Classes, Methods,
 * Manifest components/permissions, and APK File structures.
 */
object SpecificTextSearchEngine {

    fun search(options: TextSearchOptions, analysis: ApkAnalysisResult): List<SearchResult> {
        val rawQuery = options.query.trim()
        if (rawQuery.isEmpty()) return emptyList()

        val results = mutableListOf<SearchResult>()
        val scope = options.scope

        // Regex or Whole Word or Exact or Substring match strategy
        val regex: Regex? = try {
            when {
                options.isRegex -> {
                    val opts = if (options.isCaseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE)
                    Regex(rawQuery, opts)
                }
                options.isWholeWord -> {
                    val opts = if (options.isCaseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE)
                    Regex("\\b${Regex.escape(rawQuery)}\\b", opts)
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }

        val testMatch: (String) -> Boolean = { text ->
            when {
                regex != null -> regex.containsMatchIn(text)
                options.isExactMatch -> {
                    if (options.isCaseSensitive) text == rawQuery
                    else text.equals(rawQuery, ignoreCase = true)
                }
                else -> {
                    text.contains(rawQuery, ignoreCase = !options.isCaseSensitive)
                }
            }
        }

        // 1. DEX Constant Strings & URLs
        if (scope == TextSearchScope.ALL || scope == TextSearchScope.STRINGS) {
            for (s in analysis.strings) {
                if (testMatch(s.value)) {
                    val isUrl = s.value.startsWith("http://") || s.value.startsWith("https://")
                    results.add(
                        SearchResult(
                            id = "str_${s.value.hashCode()}_${results.size}",
                            title = "\"${s.value}\"",
                            subtitle = "DEX String Constant • ${s.category.name} (${s.occurrences} references)",
                            targetType = if (isUrl) SearchTargetType.URL else SearchTargetType.STRING,
                            matchedTerm = rawQuery,
                            evidenceScore = if (isUrl) 95 else 90,
                            evidenceLevel = EvidenceLevel.STRONG,
                            reason = "Exact text matched in DEX string constant pool",
                            associatedObject = s,
                            matchedSnippet = s.value
                        )
                    )
                    if (results.size >= 400) break
                }
            }
        }

        // 2. Smali Bytecode & Dalvik Instructions
        if ((scope == TextSearchScope.ALL || scope == TextSearchScope.SMALI) && results.size < 400) {
            for (m in analysis.methods) {
                if (m.rawInstructions.isNotEmpty()) {
                    for ((idx, ins) in m.rawInstructions.withIndex()) {
                        if (testMatch(ins.smaliText) || (ins.stringRef != null && testMatch(ins.stringRef)) || (ins.methodRef != null && testMatch(ins.methodRef))) {
                            results.add(
                                SearchResult(
                                    id = "smali_${m.id}_${idx}",
                                    title = "${m.className.substringAfterLast('.')}.${m.name}()",
                                    subtitle = "${m.packageName} • Offset ${ins.offsetHex}",
                                    targetType = SearchTargetType.SMALI,
                                    matchedTerm = rawQuery,
                                    evidenceScore = 96,
                                    evidenceLevel = EvidenceLevel.STRONG,
                                    reason = "Specific text located in Dalvik instruction at offset ${ins.offsetHex}",
                                    associatedObject = m,
                                    matchedSnippet = ins.smaliText.trim(),
                                    lineNumber = idx + 1
                                )
                            )
                            if (results.size >= 400) break
                        }
                    }
                }
                if (results.size >= 400) break
            }
        }

        // 3. Classes & Methods Signatures
        if ((scope == TextSearchScope.ALL || scope == TextSearchScope.CLASSES_METHODS) && results.size < 400) {
            // Methods
            for (m in analysis.methods) {
                if (testMatch(m.name) || testMatch(m.className) || testMatch(m.returnType.displayName)) {
                    results.add(
                        SearchResult(
                            id = "meth_${m.id}",
                            title = "${m.className.substringAfterLast('.')}.${m.name}()",
                            subtitle = "Method in ${m.packageName} • Returns ${m.returnType.displayName}",
                            targetType = SearchTargetType.METHOD,
                            matchedTerm = rawQuery,
                            evidenceScore = 88,
                            evidenceLevel = EvidenceLevel.STRONG,
                            reason = "Matched method declaration / signature",
                            associatedObject = m,
                            matchedSnippet = "${m.accessFlags.joinToString(" ")} ${m.returnType.displayName} ${m.name}(${m.parameterTypes.joinToString(", ") { it.displayName }})"
                        )
                    )
                    if (results.size >= 400) break
                }
            }

            // Classes & Fields
            for (c in analysis.classes) {
                if (testMatch(c.simpleName) || testMatch(c.id) || testMatch(c.packageName)) {
                    results.add(
                        SearchResult(
                            id = "cls_${c.id}",
                            title = c.simpleName,
                            subtitle = "Class (${c.packageName}) • ${c.methods.size} methods, ${c.fields.size} fields",
                            targetType = SearchTargetType.CLASS,
                            matchedTerm = rawQuery,
                            evidenceScore = 85,
                            evidenceLevel = EvidenceLevel.MEDIUM,
                            reason = "Matched class identifier or package",
                            associatedObject = c,
                            matchedSnippet = "class ${c.simpleName} : ${c.superClassName.substringAfterLast('.')}"
                        )
                    )
                    if (results.size >= 400) break
                }

                for (f in c.fields) {
                    if (testMatch(f.name) || testMatch(f.type.displayName) || (f.initialValue != null && testMatch(f.initialValue))) {
                        results.add(
                            SearchResult(
                                id = "fld_${c.id}_${f.name}",
                                title = "${c.simpleName}.${f.name}",
                                subtitle = "Field in ${c.packageName} (${f.type.displayName})",
                                targetType = SearchTargetType.FIELD,
                                matchedTerm = rawQuery,
                                evidenceScore = 80,
                                evidenceLevel = EvidenceLevel.MEDIUM,
                                reason = "Matched field name or type descriptor",
                                associatedObject = c,
                                matchedSnippet = "${f.accessFlags.joinToString(" ")} ${f.type.displayName} ${f.name}${if (f.initialValue != null) " = ${f.initialValue}" else ""}"
                            )
                        )
                        if (results.size >= 400) break
                    }
                }
            }
        }

        // 4. AndroidManifest.xml (Permissions, Components, Metadata)
        if ((scope == TextSearchScope.ALL || scope == TextSearchScope.MANIFEST) && results.size < 400) {
            for (p in analysis.manifest.permissions) {
                if (testMatch(p.name) || testMatch(p.description)) {
                    results.add(
                        SearchResult(
                            id = "perm_${p.name}",
                            title = p.name.substringAfterLast('.'),
                            subtitle = "Permission • ${p.protectionLevel}",
                            targetType = SearchTargetType.MANIFEST,
                            matchedTerm = rawQuery,
                            evidenceScore = 82,
                            evidenceLevel = EvidenceLevel.MEDIUM,
                            reason = "Matched permission entry in AndroidManifest.xml",
                            associatedObject = p,
                            matchedSnippet = "<uses-permission android:name=\"${p.name}\" />"
                        )
                    )
                    if (results.size >= 400) break
                }
            }

            for (comp in analysis.manifest.components) {
                if (testMatch(comp.name) || (comp.permission != null && testMatch(comp.permission)) || comp.intentFilters.any { testMatch(it) }) {
                    results.add(
                        SearchResult(
                            id = "comp_${comp.name}",
                            title = comp.name.substringAfterLast('.'),
                            subtitle = "Component: ${comp.type.name} (Exported: ${comp.isExported})",
                            targetType = SearchTargetType.MANIFEST,
                            matchedTerm = rawQuery,
                            evidenceScore = 80,
                            evidenceLevel = EvidenceLevel.MEDIUM,
                            reason = "Matched application component in AndroidManifest.xml",
                            associatedObject = comp,
                            matchedSnippet = "<${comp.type.name.lowercase()} android:name=\"${comp.name}\" android:exported=\"${comp.isExported}\" />"
                        )
                    )
                    if (results.size >= 400) break
                }
            }
        }

        // 5. APK Archive Files & Asset paths
        if ((scope == TextSearchScope.ALL || scope == TextSearchScope.FILES) && results.size < 400) {
            for (f in analysis.apkFiles) {
                if (testMatch(f.path)) {
                    results.add(
                        SearchResult(
                            id = "file_${f.path}",
                            title = f.path.substringAfterLast('/'),
                            subtitle = "${f.category} • ${f.path}",
                            targetType = SearchTargetType.FILE,
                            matchedTerm = rawQuery,
                            evidenceScore = 75,
                            evidenceLevel = EvidenceLevel.MEDIUM,
                            reason = "Matched entry in APK zip directory tree",
                            associatedObject = f,
                            matchedSnippet = f.path
                        )
                    )
                    if (results.size >= 400) break
                }
            }
        }

        return results.distinctBy { it.id }.sortedByDescending { it.evidenceScore }
    }
}
