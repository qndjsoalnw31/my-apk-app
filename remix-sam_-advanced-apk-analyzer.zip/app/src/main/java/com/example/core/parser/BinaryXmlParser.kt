package com.example.core.parser

import com.example.core.model.ComponentType
import com.example.core.model.ManifestComponent
import com.example.core.model.ManifestInfo
import com.example.core.model.PermissionInfo
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Authentic Android Binary XML (AXML) parser.
 * Directly decodes Android's binary XML format with String Pool, Resource Map, and XML chunks.
 * Does NOT contain any fallback mock data. If the XML is corrupt or invalid, throws an exception.
 */
class BinaryXmlParser {

    companion object {
        private const val CHUNK_AXML_FILE = 0x00080003
        private const val CHUNK_STRING_POOL = 0x001C0001
        private const val CHUNK_RESOURCE_MAP = 0x00080180
        private const val CHUNK_XML_START_TAG = 0x00100102
        private const val CHUNK_XML_END_TAG = 0x00100103

        // Well-known Android attribute resource IDs
        private const val ATTR_NAME = 0x01010003
        private const val ATTR_EXPORTED = 0x01010010
        private const val ATTR_PERMISSION = 0x01010006
        private const val ATTR_PROCESS = 0x01010011
        private const val ATTR_COMPILE_SDK = 0x01010572
        private const val ATTR_VERSION_CODE = 0x0101021b
        private const val ATTR_VERSION_NAME = 0x0101021c
        private const val ATTR_MIN_SDK = 0x0101020c
        private const val ATTR_TARGET_SDK = 0x01010270
        private const val ATTR_DEBUGGABLE = 0x0101000f
        private const val ATTR_ALLOW_BACKUP = 0x01010028
        private const val ATTR_USES_CLEARTEXT = 0x010104ec
        private const val ATTR_NETWORK_SEC_CONFIG = 0x01010377

        private val DANGEROUS_PERMISSIONS = setOf(
            "android.permission.READ_CALENDAR",
            "android.permission.WRITE_CALENDAR",
            "android.permission.CAMERA",
            "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS",
            "android.permission.GET_ACCOUNTS",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION",
            "android.permission.RECORD_AUDIO",
            "android.permission.READ_PHONE_STATE",
            "android.permission.READ_PHONE_NUMBERS",
            "android.permission.CALL_PHONE",
            "android.permission.ANSWER_PHONE_CALLS",
            "android.permission.READ_CALL_LOG",
            "android.permission.WRITE_CALL_LOG",
            "android.permission.ADD_VOICEMAIL",
            "android.permission.USE_SIP",
            "android.permission.PROCESS_OUTGOING_CALLS",
            "android.permission.BODY_SENSORS",
            "android.permission.BODY_SENSORS_BACKGROUND",
            "android.permission.SEND_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.READ_SMS",
            "android.permission.RECEIVE_WAP_PUSH",
            "android.permission.RECEIVE_MMS",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.ACCESS_MEDIA_LOCATION",
            "android.permission.POST_NOTIFICATIONS",
            "android.permission.NEARBY_WIFI_DEVICES",
            "android.permission.BLUETOOTH_SCAN",
            "android.permission.BLUETOOTH_CONNECT",
            "android.permission.BLUETOOTH_ADVERTISE"
        )
    }

    fun parse(inputStream: InputStream): ManifestInfo {
        val bytes = inputStream.readBytes()
        if (bytes.size < 8) {
            throw IllegalArgumentException("AndroidManifest.xml is empty or too short (${bytes.size} bytes).")
        }

        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val magic = buffer.int
        if (magic != CHUNK_AXML_FILE) {
            throw IllegalArgumentException("Invalid Android Binary XML magic header: 0x${Integer.toHexString(magic)}. Expected 0x00080003.")
        }

        val fileSize = buffer.int
        val stringPool = mutableListOf<String>()
        val resourceMap = mutableListOf<Int>()

        var packageName = ""
        var versionCode = 0L
        var versionName = "1.0"
        var minSdk = 21
        var targetSdk = 34
        var compileSdk: Int? = null
        var applicationProcess: String? = null
        var isDebuggable = false
        var allowBackup = true
        var usesCleartextTraffic = false
        var networkSecurityConfig = ""

        val permissions = mutableListOf<PermissionInfo>()
        val components = mutableListOf<ManifestComponent>()

        // Parsing state
        var currentComponent: MutableComponent? = null
        var currentIntentFilterActions = mutableListOf<String>()
        var currentIntentFilterCategories = mutableListOf<String>()

        while (buffer.remaining() >= 8) {
            val chunkStart = buffer.position()
            val chunkType = buffer.int
            val chunkSize = buffer.int

            when (chunkType) {
                CHUNK_STRING_POOL -> {
                    val stringCount = buffer.int
                    val styleCount = buffer.int
                    val flags = buffer.int
                    val stringsOffset = buffer.int
                    val stylesOffset = buffer.int

                    val isUtf8 = (flags and (1 shl 8)) != 0
                    val offsets = IntArray(stringCount)
                    for (i in 0 until stringCount) {
                        offsets[i] = buffer.int
                    }

                    val baseStringsPos = chunkStart + stringsOffset
                    for (offset in offsets) {
                        val targetPos = baseStringsPos + offset
                        if (targetPos in 0 until bytes.size) {
                            buffer.position(targetPos)
                            if (isUtf8) {
                                val len = buffer.get().toInt() and 0xFF
                                val strBytes = ByteArray(len.coerceAtLeast(0).coerceAtMost(buffer.remaining()))
                                buffer.get(strBytes)
                                stringPool.add(String(strBytes, Charsets.UTF_8))
                            } else {
                                val charLen = buffer.short.toInt() and 0xFFFF
                                val chars = CharArray(charLen.coerceAtLeast(0).coerceAtMost(buffer.remaining() / 2))
                                for (c in chars.indices) {
                                    chars[c] = buffer.short.toInt().toChar()
                                }
                                stringPool.add(String(chars))
                            }
                        } else {
                            stringPool.add("")
                        }
                    }
                }
                CHUNK_RESOURCE_MAP -> {
                    val resCount = (chunkSize - 8) / 4
                    for (i in 0 until resCount) {
                        if (buffer.remaining() >= 4) {
                            resourceMap.add(buffer.int)
                        }
                    }
                }
                CHUNK_XML_START_TAG -> {
                    buffer.int // lineNumber
                    buffer.int // comment
                    val namespaceUri = buffer.int
                    val nameIdx = buffer.int
                    val attrStart = buffer.short.toInt() and 0xFFFF
                    val attrSize = buffer.short.toInt() and 0xFFFF
                    val attrCount = buffer.short.toInt() and 0xFFFF
                    buffer.short // idIndex
                    buffer.short // classIndex
                    buffer.short // styleIndex

                    val tagName = if (nameIdx in stringPool.indices) stringPool[nameIdx] else ""

                    // Read attributes
                    val attrs = mutableMapOf<String, String>()
                    val attrResIds = mutableMapOf<Int, String>()

                    for (i in 0 until attrCount) {
                        buffer.int // attrNamespace
                        val attrNameIdx = buffer.int
                        val attrRawValIdx = buffer.int
                        val attrType = buffer.int
                        val attrData = buffer.int

                        val attrName = if (attrNameIdx in stringPool.indices) stringPool[attrNameIdx] else "attr_$i"
                        val attrVal = if (attrRawValIdx in stringPool.indices && stringPool[attrRawValIdx].isNotEmpty()) {
                            stringPool[attrRawValIdx]
                        } else if (attrType == 0x03) { // string
                            if (attrData in stringPool.indices) stringPool[attrData] else attrData.toString()
                        } else if (attrType == 0x12) { // boolean
                            if (attrData != 0) "true" else "false"
                        } else {
                            attrData.toString()
                        }
                        attrs[attrName] = attrVal

                        if (attrNameIdx in resourceMap.indices) {
                            val resId = resourceMap[attrNameIdx]
                            attrResIds[resId] = attrVal
                        }
                    }

                    when (tagName) {
                        "manifest" -> {
                            attrs["package"]?.let { packageName = it }
                            attrResIds[ATTR_VERSION_CODE]?.toLongOrNull()?.let { versionCode = it }
                                ?: attrs["versionCode"]?.toLongOrNull()?.let { versionCode = it }
                            attrResIds[ATTR_VERSION_NAME]?.let { versionName = it }
                                ?: attrs["versionName"]?.let { versionName = it }
                        }
                        "uses-sdk" -> {
                            attrResIds[ATTR_MIN_SDK]?.toIntOrNull()?.let { minSdk = it }
                                ?: attrs["minSdkVersion"]?.toIntOrNull()?.let { minSdk = it }
                            attrResIds[ATTR_TARGET_SDK]?.toIntOrNull()?.let { targetSdk = it }
                                ?: attrs["targetSdkVersion"]?.toIntOrNull()?.let { targetSdk = it }
                            attrResIds[ATTR_COMPILE_SDK]?.toIntOrNull()?.let { compileSdk = it }
                                ?: attrs["compileSdkVersion"]?.toIntOrNull()?.let { compileSdk = it }
                        }
                        "uses-permission" -> {
                            val permName = attrResIds[ATTR_NAME] ?: attrs["name"] ?: ""
                            if (permName.isNotBlank()) {
                                val isDangerous = DANGEROUS_PERMISSIONS.contains(permName) ||
                                        permName.contains("LOCATION") ||
                                        permName.contains("CAMERA") ||
                                        permName.contains("STORAGE") ||
                                        permName.contains("CONTACTS") ||
                                        permName.contains("SMS") ||
                                        permName.contains("AUDIO")
                                permissions.add(
                                    PermissionInfo(
                                        name = permName,
                                        protectionLevel = if (isDangerous) "Dangerous" else "Normal",
                                        isDangerous = isDangerous,
                                        description = getPermissionDescription(permName)
                                    )
                                )
                            }
                        }
                        "application" -> {
                            val debug = attrResIds[ATTR_DEBUGGABLE] ?: attrs["debuggable"]
                            if (debug == "true" || debug == "1") isDebuggable = true

                            val backup = attrResIds[ATTR_ALLOW_BACKUP] ?: attrs["allowBackup"]
                            if (backup == "false" || backup == "0") allowBackup = false

                            val cleartext = attrResIds[ATTR_USES_CLEARTEXT] ?: attrs["usesCleartextTraffic"]
                            if (cleartext == "true" || cleartext == "1") usesCleartextTraffic = true

                            attrResIds[ATTR_NETWORK_SEC_CONFIG]?.let { networkSecurityConfig = it }
                                ?: attrs["networkSecurityConfig"]?.let { networkSecurityConfig = it }

                            attrResIds[ATTR_PROCESS]?.let { applicationProcess = it }
                                ?: attrs["process"]?.let { applicationProcess = it }
                        }
                        "activity", "activity-alias" -> {
                            val name = attrResIds[ATTR_NAME] ?: attrs["name"] ?: "UnknownActivity"
                            val expStr = attrResIds[ATTR_EXPORTED] ?: attrs["exported"]
                            val perm = attrResIds[ATTR_PERMISSION] ?: attrs["permission"]
                            val proc = attrResIds[ATTR_PROCESS] ?: attrs["process"]
                            currentComponent = MutableComponent(
                                name = resolveComponentName(name, packageName),
                                type = ComponentType.ACTIVITY,
                                isExportedExplicit = expStr?.toBoolean(),
                                permission = perm,
                                process = proc
                            )
                        }
                        "service" -> {
                            val name = attrResIds[ATTR_NAME] ?: attrs["name"] ?: "UnknownService"
                            val expStr = attrResIds[ATTR_EXPORTED] ?: attrs["exported"]
                            val perm = attrResIds[ATTR_PERMISSION] ?: attrs["permission"]
                            val proc = attrResIds[ATTR_PROCESS] ?: attrs["process"]
                            currentComponent = MutableComponent(
                                name = resolveComponentName(name, packageName),
                                type = ComponentType.SERVICE,
                                isExportedExplicit = expStr?.toBoolean(),
                                permission = perm,
                                process = proc
                            )
                        }
                        "receiver" -> {
                            val name = attrResIds[ATTR_NAME] ?: attrs["name"] ?: "UnknownReceiver"
                            val expStr = attrResIds[ATTR_EXPORTED] ?: attrs["exported"]
                            val perm = attrResIds[ATTR_PERMISSION] ?: attrs["permission"]
                            val proc = attrResIds[ATTR_PROCESS] ?: attrs["process"]
                            currentComponent = MutableComponent(
                                name = resolveComponentName(name, packageName),
                                type = ComponentType.RECEIVER,
                                isExportedExplicit = expStr?.toBoolean(),
                                permission = perm,
                                process = proc
                            )
                        }
                        "provider" -> {
                            val name = attrResIds[ATTR_NAME] ?: attrs["name"] ?: "UnknownProvider"
                            val expStr = attrResIds[ATTR_EXPORTED] ?: attrs["exported"]
                            val perm = attrResIds[ATTR_PERMISSION] ?: attrs["permission"]
                            val proc = attrResIds[ATTR_PROCESS] ?: attrs["process"]
                            currentComponent = MutableComponent(
                                name = resolveComponentName(name, packageName),
                                type = ComponentType.PROVIDER,
                                isExportedExplicit = expStr?.toBoolean(),
                                permission = perm,
                                process = proc
                            )
                        }
                        "intent-filter" -> {
                            currentIntentFilterActions.clear()
                            currentIntentFilterCategories.clear()
                        }
                        "action" -> {
                            val aName = attrResIds[ATTR_NAME] ?: attrs["name"]
                            if (aName != null) currentIntentFilterActions.add(aName)
                        }
                        "category" -> {
                            val cName = attrResIds[ATTR_NAME] ?: attrs["name"]
                            if (cName != null) currentIntentFilterCategories.add(cName)
                        }
                    }
                }
                CHUNK_XML_END_TAG -> {
                    buffer.int // lineNumber
                    buffer.int // comment
                    buffer.int // namespaceUri
                    val nameIdx = buffer.int
                    val tagName = if (nameIdx in stringPool.indices) stringPool[nameIdx] else ""

                    when (tagName) {
                        "intent-filter" -> {
                            currentComponent?.let { comp ->
                                comp.intentFilterActions.addAll(currentIntentFilterActions)
                                comp.intentFilterCategories.addAll(currentIntentFilterCategories)
                                if (currentIntentFilterActions.contains("android.intent.action.MAIN") &&
                                    currentIntentFilterCategories.contains("android.intent.category.LAUNCHER")
                                ) {
                                    comp.isLauncher = true
                                }
                            }
                            currentIntentFilterActions.clear()
                            currentIntentFilterCategories.clear()
                        }
                        "activity", "activity-alias", "service", "receiver", "provider" -> {
                            currentComponent?.let { comp ->
                                val hasIntentFilters = comp.intentFilterActions.isNotEmpty()
                                // Android rule: if exported not explicitly set, having intent-filters defaults to exported=true
                                val finalExported = comp.isExportedExplicit ?: hasIntentFilters
                                components.add(
                                    ManifestComponent(
                                        name = comp.name,
                                        type = comp.type,
                                        isExported = finalExported,
                                        permission = comp.permission,
                                        intentFilters = comp.intentFilterActions.toList(),
                                        isLauncher = comp.isLauncher,
                                        process = comp.process
                                    )
                                )
                            }
                            currentComponent = null
                        }
                    }
                }
            }

            val nextPos = chunkStart + chunkSize
            if (nextPos > buffer.position() && nextPos <= bytes.size) {
                buffer.position(nextPos)
            }
        }

        if (packageName.isBlank()) {
            throw IllegalArgumentException("Failed to decode valid Android package name from AndroidManifest.xml binary data.")
        }

        return ManifestInfo(
            packageName = packageName,
            versionCode = versionCode,
            versionName = versionName,
            minSdk = minSdk,
            targetSdk = targetSdk,
            compileSdk = compileSdk,
            applicationProcess = applicationProcess,
            isDebuggable = isDebuggable,
            allowBackup = allowBackup,
            usesCleartextTraffic = usesCleartextTraffic,
            networkSecurityConfig = networkSecurityConfig.ifBlank { null },
            permissions = permissions.distinctBy { it.name },
            components = components
        )
    }

    private data class MutableComponent(
        val name: String,
        val type: ComponentType,
        val isExportedExplicit: Boolean?,
        val permission: String?,
        val intentFilterActions: MutableList<String> = mutableListOf(),
        val intentFilterCategories: MutableList<String> = mutableListOf(),
        var isLauncher: Boolean = false,
        val process: String? = null
    )

    private fun resolveComponentName(name: String, pkg: String): String {
        return when {
            name.startsWith(".") -> "$pkg$name"
            !name.contains(".") && pkg.isNotBlank() -> "$pkg.$name"
            else -> name
        }
    }

    private fun getPermissionDescription(perm: String): String {
        return when {
            perm.contains("INTERNET") -> "Allows opening network sockets"
            perm.contains("ACCESS_FINE_LOCATION") -> "Allows precise GPS location"
            perm.contains("ACCESS_COARSE_LOCATION") -> "Allows approximate network location"
            perm.contains("CAMERA") -> "Allows capturing images and video"
            perm.contains("RECORD_AUDIO") -> "Allows microphone audio recording"
            perm.contains("READ_EXTERNAL_STORAGE") -> "Allows reading files from shared storage"
            perm.contains("WRITE_EXTERNAL_STORAGE") -> "Allows writing files to shared storage"
            perm.contains("READ_CONTACTS") -> "Allows reading user contacts"
            perm.contains("POST_NOTIFICATIONS") -> "Allows sending system notifications"
            perm.contains("BILLING") -> "Google Play In-app Billing"
            perm.contains("BLUETOOTH") -> "Allows connecting to Bluetooth peripherals"
            else -> "Declared application permission"
        }
    }
}
