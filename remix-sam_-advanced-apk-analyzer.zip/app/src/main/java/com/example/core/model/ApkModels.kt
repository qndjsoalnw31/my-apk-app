package com.example.core.model

import java.io.Serializable

/**
 * Core models representing Android APK structure and inspection results.
 */

data class ApkInfo(
    val fileName: String,
    val packageName: String,
    val appName: String,
    val versionName: String,
    val versionCode: Long,
    val minSdk: Int,
    val targetSdk: Int,
    val fileSizeFormatted: String,
    val fileSizeBytes: Long,
    val totalDexCount: Int = 1,
    val totalClasses: Int = 0,
    val totalMethods: Int = 0,
    val totalFields: Int = 0,
    val totalStrings: Int = 0,
    val isDebuggable: Boolean = false,
    val certificateDigest: String = "",
    val sha256Hash: String = "",
    val md5Hash: String = "",
    val signatureSchemes: List<String> = emptyList()
) : Serializable

data class ClassInfo(
    val id: String, // e.g., com.example.app.BillingService
    val simpleName: String,
    val packageName: String,
    val superClassName: String = "java.lang.Object",
    val interfaces: List<String> = emptyList(),
    val accessFlags: List<String> = listOf("public"),
    val isInterface: Boolean = false,
    val isAbstract: Boolean = false,
    val fields: List<FieldInfo> = emptyList(),
    val methods: List<MethodInfo> = emptyList(),
    val stringsContained: List<String> = emptyList(),
    val relatedClasses: List<String> = emptyList(),
    val evidenceScore: Int = 0,
    val evidenceReason: String = ""
) : Serializable

data class MethodInfo(
    val id: String, // class.name(params):return
    val name: String,
    val className: String,
    val packageName: String,
    val accessFlags: List<String> = listOf("public"),
    val isConstructor: Boolean = false,
    val isStatic: Boolean = false,
    val parameterTypes: List<TypeInfo> = emptyList(),
    val returnType: TypeInfo = TypeInfo.VOID,
    val callersCount: Int = 0,
    val callers: List<String> = emptyList(), // method IDs calling this
    val callees: List<String> = emptyList(), // method IDs called by this
    val associatedStrings: List<String> = emptyList(),
    val codeOffset: String = "0x0000",
    val registersCount: Int = 4,
    private var explicitSmaliCode: String? = null,
    private var explicitDecompiledCode: String? = null,
    private var explicitFlowBlocks: List<FlowBlock>? = null,
    val rawInstructions: List<DalvikInstruction> = emptyList(),
    val insSize: Int = 0,
    val outsSize: Int = 0,
    val triesCount: Int = 0,
    val tryCatches: List<TryCatchInfo> = emptyList(),
    val evidenceScore: Int = 0,
    val evidenceLevel: EvidenceLevel = EvidenceLevel.WEAK,
    val evidenceReasons: List<String> = emptyList()
) : Serializable {
    val localsCount: Int get() = (registersCount - insSize).coerceAtLeast(0)

    val smaliCode: String
        get() {
            if (explicitSmaliCode == null) {
                explicitSmaliCode = com.example.core.analysis.SmaliAndDecompiler.generateSmali(this)
            }
            return explicitSmaliCode ?: ""
        }

    val decompiledPseudoCode: String
        get() {
            if (explicitDecompiledCode == null) {
                explicitDecompiledCode = com.example.core.analysis.SmaliAndDecompiler.decompileToPseudoCode(this)
            }
            return explicitDecompiledCode ?: ""
        }

    val flowBlocks: List<FlowBlock>
        get() {
            if (explicitFlowBlocks == null) {
                explicitFlowBlocks = com.example.core.analysis.SmaliAndDecompiler.buildFlowBlocks(this)
            }
            return explicitFlowBlocks ?: emptyList()
        }
}

data class TryCatchInfo(
    val startAddr: Int,
    val endAddr: Int,
    val handlerType: String?, // null = catchall
    val targetAddr: Int
) : Serializable

data class DalvikInstruction(
    val offset: Int,
    val opcode: Int,
    val mnemonic: String,
    val registers: List<Int> = emptyList(),
    val targetOffset: Int? = null,
    val stringRef: String? = null,
    val typeRef: String? = null,
    val methodRef: String? = null,
    val fieldRef: String? = null,
    val literal: Long? = null,
    val smaliText: String
) : Serializable {
    val offsetHex: String get() = "0x" + (offset and 0xFFFF).toString(16).uppercase().padStart(4, '0')
    fun toSmali(): String = smaliText
}

data class FieldInfo(
    val name: String,
    val type: TypeInfo,
    val accessFlags: List<String> = listOf("private"),
    val initialValue: String? = null
) : Serializable

data class TypeInfo(
    val rawName: String,
    val displayName: String,
    val category: TypeCategory
) : Serializable {
    companion object {
        val VOID = TypeInfo("V", "void", TypeCategory.VOID)
        val BOOLEAN = TypeInfo("Z", "boolean", TypeCategory.BOOLEAN)
        val INT = TypeInfo("I", "int", TypeCategory.INTEGER)
        val LONG = TypeInfo("J", "long", TypeCategory.INTEGER)
        val FLOAT = TypeInfo("F", "float", TypeCategory.FLOAT)
        val DOUBLE = TypeInfo("D", "double", TypeCategory.FLOAT)
        val STRING = TypeInfo("Ljava/lang/String;", "String", TypeCategory.STRING)
        val OBJECT = TypeInfo("Ljava/lang/Object;", "Object", TypeCategory.OBJECT)

        fun parse(descriptor: String): TypeInfo {
            return when {
                descriptor == "V" -> VOID
                descriptor == "Z" -> BOOLEAN
                descriptor == "I" -> INT
                descriptor == "J" -> LONG
                descriptor == "F" -> FLOAT
                descriptor == "D" -> DOUBLE
                descriptor == "B" -> TypeInfo("B", "byte", TypeCategory.BYTE)
                descriptor == "C" -> TypeInfo("C", "char", TypeCategory.CHAR)
                descriptor == "S" -> TypeInfo("S", "short", TypeCategory.INTEGER)
                descriptor == "Ljava/lang/String;" -> STRING
                descriptor.startsWith("[") -> {
                    val inner = parse(descriptor.substring(1))
                    TypeInfo(descriptor, "${inner.displayName}[]", TypeCategory.ARRAY)
                }
                descriptor.startsWith("L") && descriptor.endsWith(";") -> {
                    val clean = descriptor.substring(1, descriptor.length - 1).replace('/', '.')
                    val simple = clean.substringAfterLast('.')
                    TypeInfo(descriptor, simple, TypeCategory.OBJECT)
                }
                else -> TypeInfo(descriptor, descriptor.substringAfterLast('.'), TypeCategory.OBJECT)
            }
        }
    }
}

enum class TypeCategory {
    BOOLEAN,
    INTEGER,
    STRING,
    OBJECT,
    VOID,
    ARRAY,
    FLOAT,
    BYTE,
    CHAR,
    OTHER
}

enum class EvidenceLevel {
    STRONG,  // 90-100%
    MEDIUM,  // 60-89%
    WEAK     // 0-59%
}

data class FlowBlock(
    val id: String,
    val title: String,
    val type: FlowBlockType,
    val description: String,
    val codeSnippet: String = "",
    val nextBlockIds: List<String> = emptyList()
) : Serializable {
    val branchTargets: List<String> get() = nextBlockIds
    val statements: List<String> get() = if (codeSnippet.isBlank()) emptyList() else codeSnippet.lines()
}

enum class FlowBlockType {
    ENTRY,
    CONDITION,     // if / else
    SWITCH,        // switch / packed-switch
    INVOKE,        // call to other method
    RETURN,        // return
    ASSIGNMENT,    // register move / const
    EXCEPTION      // try / catch
}

data class StringUsage(
    val className: String,
    val methodName: String,
    val dexOffset: String
) : Serializable

data class StringItem(
    val value: String,
    val occurrences: Int = 1,
    val category: StringCategory = StringCategory.GENERAL,
    val foundInClasses: List<String> = emptyList(),
    val foundInMethods: List<String> = emptyList(),
    val usages: List<StringUsage> = emptyList()
) : Serializable

enum class StringCategory {
    FEATURE_NAMES,
    ERROR_MESSAGES,
    URLS,
    DOMAINS,
    IP_ADDRESSES,
    EMAILS,
    FILE_PATHS,
    API_ENDPOINTS,
    JSON_KEYS,
    POSSIBLE_TOKENS,
    POSSIBLE_API_KEYS,
    BASE64,
    CONFIGURATION,
    SUBSCRIPTION,
    AUTHENTICATION,
    UI_TEXT,
    GENERAL
}

data class LibraryInfo(
    val name: String,
    val category: LibraryCategory,
    val packageName: String,
    val classCount: Int,
    val description: String,
    val confidence: Int = 100
) : Serializable

enum class LibraryCategory {
    BILLING,
    ADS,
    ANALYTICS,
    NETWORKING,
    DATABASE,
    AUTHENTICATION,
    IMAGE_PROCESSING,
    DEPENDENCY_INJECTION,
    OTHER
}

data class ManifestComponent(
    val name: String,
    val type: ComponentType,
    val isExported: Boolean,
    val permission: String? = null,
    val intentFilters: List<String> = emptyList(),
    val isLauncher: Boolean = false,
    val process: String? = null
) : Serializable

enum class ComponentType {
    ACTIVITY,
    SERVICE,
    RECEIVER,
    PROVIDER
}

data class ManifestInfo(
    val packageName: String,
    val versionCode: Long,
    val versionName: String,
    val minSdk: Int,
    val targetSdk: Int,
    val compileSdk: Int? = null,
    val applicationProcess: String? = null,
    val isDebuggable: Boolean = false,
    val allowBackup: Boolean = true,
    val usesCleartextTraffic: Boolean = false,
    val networkSecurityConfig: String? = null,
    val permissions: List<PermissionInfo> = emptyList(),
    val components: List<ManifestComponent> = emptyList()
) : Serializable

data class PermissionInfo(
    val name: String,
    val protectionLevel: String = "Normal",
    val isDangerous: Boolean = false,
    val description: String = ""
) : Serializable

data class SearchResult(
    val id: String,
    val title: String,
    val subtitle: String,
    val targetType: SearchTargetType,
    val matchedTerm: String,
    val evidenceScore: Int,
    val evidenceLevel: EvidenceLevel,
    val reason: String,
    val associatedObject: Any? = null,
    val matchedSnippet: String? = null,
    val lineNumber: Int? = null
)

enum class SearchTargetType {
    METHOD,
    CLASS,
    PACKAGE,
    STRING,
    FIELD,
    URL,
    FEATURE,
    SMALI,
    MANIFEST,
    FILE
}

enum class SearchMode {
    SPECIFIC_TEXT,
    SEMANTIC
}

enum class TextSearchScope {
    ALL,
    STRINGS,
    SMALI,
    CLASSES_METHODS,
    MANIFEST,
    FILES
}

data class TextSearchOptions(
    val query: String = "",
    val scope: TextSearchScope = TextSearchScope.ALL,
    val isExactMatch: Boolean = false,
    val isCaseSensitive: Boolean = false,
    val isRegex: Boolean = false,
    val isWholeWord: Boolean = false
)

data class FeatureItem(
    val id: String,
    val title: String,
    val category: String,
    val severity: FeatureSeverity,
    val confidenceScore: Int,
    val description: String,
    val evidenceMethods: List<String> = emptyList(),
    val evidenceClasses: List<String> = emptyList(),
    val evidenceStrings: List<String> = emptyList()
)

enum class FeatureSeverity {
    HIGH_INTEREST,
    SECURITY_SENSITIVE,
    INFO,
    COMMERCIAL
}

data class DexFileInfo(
    val fileName: String,
    val fileSizeBytes: Long,
    val formattedSize: String,
    val classCount: Int,
    val methodCount: Int,
    val fieldCount: Int,
    val stringCount: Int,
    val typeCount: Int,
    val protoCount: Int,
    val sha1Hash: String = ""
) : Serializable

data class NativeLibraryInfo(
    val name: String,
    val architecture: String,
    val sizeBytes: Long,
    val formattedSize: String,
    val elfType: String = "ELF 32/64-bit",
    val isSuspicious: Boolean = false,
    val suspiciousReason: String? = null
) : Serializable

data class ApkFileEntry(
    val path: String,
    val category: String, // DEX, NATIVE, ASSET, RES, META-INF, MANIFEST, OTHER
    val sizeBytes: Long,
    val compressedSizeBytes: Long,
    val formattedSize: String
) : Serializable

data class CertificateInfo(
    val subject: String,
    val issuer: String,
    val serialNumber: String,
    val validFrom: String,
    val validTo: String,
    val sigAlgName: String,
    val sha256Fingerprint: String,
    val sha1Fingerprint: String,
    val md5Fingerprint: String,
    val isExpired: Boolean
) : Serializable

data class ApkAnalysisResult(
    val apkInfo: ApkInfo,
    val manifest: ManifestInfo,
    val classes: List<ClassInfo>,
    val methods: List<MethodInfo>,
    val strings: List<StringItem>,
    val libraries: List<LibraryInfo>,
    val features: List<FeatureItem>,
    val analysisTimestamp: Long = System.currentTimeMillis(),
    val obfuscationReport: ObfuscationReport = ObfuscationReport(),
    val securityReport: SecurityAuditReport = SecurityAuditReport(),
    val networkReport: NetworkAuditReport = NetworkAuditReport(),
    val dependencyGraph: DependencyGraphData = DependencyGraphData(),
    val healthReport: ApkHealthReport = ApkHealthReport(),
    val featureMapGroups: List<FeatureMapGroup> = emptyList(),
    val dexFiles: List<DexFileInfo> = emptyList(),
    val nativeLibraries: List<NativeLibraryInfo> = emptyList(),
    val apkFiles: List<ApkFileEntry> = emptyList(),
    val certificates: List<CertificateInfo> = emptyList()
) : Serializable

data class DiffResult(
    val oldApkName: String,
    val newApkName: String,
    val newClasses: List<String>,
    val removedClasses: List<String>,
    val newMethods: List<String>,
    val removedMethods: List<String>,
    val changedMethods: List<String>,
    val newStrings: List<String>,
    val removedStrings: List<String>,
    val changedLibraries: List<String>,
    val manifestChanges: List<String>
) : Serializable

// Obfuscation Analysis Models
data class ObfuscationReport(
    val score: Int = 0,
    val isObfuscated: Boolean = false,
    val minifiedClassRatio: Float = 0f,
    val minifiedMethodRatio: Float = 0f,
    val flattenedPackageRatio: Float = 0f,
    val reflectionDetected: Boolean = false,
    val stringEncryptionDetected: Boolean = false,
    val proguardMarkersFound: List<String> = emptyList(),
    val indicators: List<ObfuscationIndicator> = emptyList()
) : Serializable

data class ObfuscationIndicator(
    val name: String,
    val severity: String,
    val detail: String
) : Serializable

// Security Vulnerability & Audit Models
enum class SecuritySeverity {
    CRITICAL,
    HIGH,
    MEDIUM,
    LOW,
    INFO
}

enum class SecurityCategory {
    EXPORTED_COMPONENTS,
    CLEARTEXT_TRAFFIC,
    NETWORK_SECURITY,
    WEBVIEW_VULN,
    EMBEDDED_SECRETS,
    DANGEROUS_PERMISSIONS,
    WEAK_CRYPTOGRAPHY,
    DYNAMIC_CODE_LOADING,
    REFLECTION,
    SSL_BYPASS,
    COMMAND_EXECUTION,
    STORAGE_ACCESS,
    ANTI_TAMPER
}

data class SecurityVulnerability(
    val id: String,
    val title: String,
    val severity: SecuritySeverity,
    val category: SecurityCategory,
    val description: String,
    val affectedComponent: String,
    val recommendation: String,
    val evidenceCode: String = "",
    val className: String? = null,
    val methodName: String? = null,
    val instructionOrString: String? = null
) : Serializable

data class SecurityAuditReport(
    val overallRiskScore: Int = 25,
    val vulnerabilities: List<SecurityVulnerability> = emptyList(),
    val exportedComponentsCount: Int = 0,
    val dangerousPermissionsCount: Int = 0,
    val hardcodedSecretsCount: Int = 0,
    val cleartextTrafficAllowed: Boolean = false
) : Serializable

// Network Analysis Models
enum class EndpointProtocol {
    HTTPS,
    HTTP,
    WSS,
    WS,
    REST
}

data class NetworkEndpoint(
    val url: String,
    val domain: String,
    val protocol: EndpointProtocol,
    val isCleartext: Boolean,
    val foundInClass: String,
    val foundInMethod: String,
    val category: String = "API Endpoint"
) : Serializable {
    val rawUrl: String get() = url
}

data class NetworkAuditReport(
    val endpoints: List<NetworkEndpoint> = emptyList(),
    val uniqueDomains: List<String> = emptyList(),
    val cleartextCount: Int = 0,
    val securedHttpsCount: Int = 0
) : Serializable {
    val httpsEndpointsCount: Int get() = securedHttpsCount
    val cleartextEndpointsCount: Int get() = cleartextCount
    val ipAddresses: List<String> get() = uniqueDomains.filter { it.matches(Regex("\\d+\\.\\d+\\.\\d+\\.\\d+")) }
}

// Dependency Graph Models
data class DependencyNode(
    val id: String,
    val name: String,
    val category: LibraryCategory,
    val isInternal: Boolean,
    val classCount: Int,
    val riskLevel: String = "Normal"
) : Serializable

data class DependencyEdge(
    val fromId: String,
    val toId: String,
    val callCount: Int,
    val sampleInvoke: String
) : Serializable

data class DependencyGraphData(
    val nodes: List<DependencyNode> = emptyList(),
    val edges: List<DependencyEdge> = emptyList()
) : Serializable

// APK Health Dashboard Models
data class HealthMetric(
    val title: String,
    val score: Int,
    val status: String,
    val summary: String,
    val details: String
) : Serializable

data class ApkHealthReport(
    val overallHealthScore: Int = 85,
    val codeQualityScore: Int = 80,
    val securityHealthScore: Int = 75,
    val bloatIndexScore: Int = 90,
    val metrics: List<HealthMetric> = emptyList()
) : Serializable

// Feature Map Models
data class FeatureMapGroup(
    val id: String,
    val name: String,
    val description: String,
    val category: String,
    val confidenceScore: Int,
    val classIds: List<String> = emptyList(),
    val methodIds: List<String> = emptyList(),
    val stringValues: List<String> = emptyList(),
    val permissions: List<String> = emptyList()
) : Serializable

// Investigation Timeline Models
data class TimelineStep(
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val title: String,
    val description: String,
    val category: String
) : Serializable

// Plugin Architecture Models
enum class PluginType {
    SCANNER,
    ANALYZER,
    EXPORTER
}

data class PluginInfo(
    val id: String,
    val name: String,
    val version: String,
    val type: PluginType,
    val description: String,
    val author: String = "SAM Core",
    val isEnabled: Boolean = true
) : Serializable

data class PluginOutput(
    val pluginId: String,
    val title: String,
    val summary: String,
    val items: List<String>
) : Serializable

// Device Installed App Model
data class InstalledAppInfo(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val isSystemApp: Boolean,
    val apkPath: String,
    val fileSizeFormatted: String = "",
    val fileSizeBytes: Long = 0L
) : Serializable
