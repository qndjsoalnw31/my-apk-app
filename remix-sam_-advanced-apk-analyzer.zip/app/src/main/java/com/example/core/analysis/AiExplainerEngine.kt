package com.example.core.analysis

import com.example.BuildConfig
import com.example.core.model.ClassInfo
import com.example.core.model.MethodInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * AI Code Explainer Engine.
 * Uses Gemini API (gemini-3.5-flash) when key is configured, or provides instant static heuristic decompilation breakdown.
 */
object AiExplainerEngine {

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    suspend fun explainMethod(method: MethodInfo): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (!apiKey.isNullOrBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val prompt = """
                    You are SAM APK Analyzer AI. Analyze this Android decompiled method and provide a clear, concise Arabic/English explanation:
                    Method: ${method.name}
                    Class: ${method.className}
                    Return Type: ${method.returnType.displayName}
                    Parameters: ${method.parameterTypes.joinToString { it.displayName }}
                    Associated Strings: ${method.associatedStrings.joinToString()}
                    Evidence Score: ${method.evidenceScore}%
                    Callers: ${method.callers.joinToString()}
                    Callees: ${method.callees.joinToString()}
                    
                    Smali Code:
                    ${method.smaliCode}
                    
                    Explain:
                    1. Purpose & Core Function (وظيفة الدالة)
                    2. Inputs & Outputs (المدخلات والمخرجات)
                    3. Dependencies & Callees (الدوال التي تعتمد عليها)
                    4. Impact & Callers (الجهات المستدعية وتأثيرها على منطق التطبيق)
                    5. Security/Entitlement Implication (الأهمية الأمنية أو التجارية)
                """.trimIndent()

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
                val jsonBody = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", prompt)
                                })
                            })
                        })
                    })
                }

                val request = Request.Builder()
                    .url(url)
                    .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val respStr = response.body?.string() ?: ""
                    val root = JSONObject(respStr)
                    val candidate = root.optJSONArray("candidates")?.optJSONObject(0)
                    val text = candidate?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                    if (!text.isNullOrBlank()) {
                        return@withContext text
                    }
                }
            } catch (e: Exception) {
                // Fallback to static heuristic
            }
        }

        // Static Heuristic AI explanation (fast, offline, reliable)
        return@withContext generateHeuristicMethodExplanation(method)
    }

    suspend fun explainClass(clazz: ClassInfo): String = withContext(Dispatchers.IO) {
        val methodsSummary = clazz.methods.take(6).joinToString(", ") { "${it.name}(): ${it.returnType.displayName}" }
        val stringsSummary = clazz.stringsContained.take(4).joinToString(", ")

        return@withContext """
            [Class Architectural Breakdown - تحليل الـ Class]:
            
            • Identity: ${clazz.simpleName} (${clazz.packageName})
            • Superclass: ${clazz.superClassName}
            • Interfaces: ${if (clazz.interfaces.isEmpty()) "None" else clazz.interfaces.joinToString()}
            • Methods: ${clazz.methods.size} methods (${methodsSummary})
            • Fields: ${clazz.fields.size} fields
            
            [Primary Purpose & Role]:
            ${if (clazz.evidenceScore >= 80) "This is a critical domain module responsible for application monetization, access control, or license validation." else "Standard component executing business logic or UI presentation."}
            
            [Referenced String Signatures]:
            ${if (stringsSummary.isNotEmpty()) stringsSummary else "No sensitive string constants referenced."}
            
            [Evidence Evaluation]:
            Score: ${clazz.evidenceScore}% • ${if (clazz.evidenceReason.isNotEmpty()) clazz.evidenceReason else "Standard domain classification"}
        """.trimIndent()
    }

    private fun generateHeuristicMethodExplanation(method: MethodInfo): String {
        val isEntitlement = method.evidenceScore >= 80 || method.name.contains("sub", ignoreCase = true) || method.name.contains("premium", ignoreCase = true)
        val returnDesc = when (method.returnType.displayName) {
            "boolean" -> "Boolean predicate (true/false) determining access status or success."
            "void" -> "Void action procedure executing side-effects or SDK operations."
            "String" -> "Returns a formatted string token, status code, or resource identifier."
            else -> "Returns an instance of ${method.returnType.displayName}."
        }

        val callersDesc = if (method.callers.isNotEmpty()) {
            method.callers.joinToString("\n   • ")
        } else {
            "No direct local callers detected in primary DEX (may be called dynamically via reflection or framework callback)."
        }

        val calleesDesc = if (method.callees.isNotEmpty()) {
            method.callees.joinToString("\n   • ")
        } else {
            "Self-contained or uses direct bytecode register operations."
        }

        val stringsDesc = if (method.associatedStrings.isNotEmpty()) {
            method.associatedStrings.joinToString(", ") { "\"$it\"" }
        } else {
            "None"
        }

        return """
            [SAM Deep Method Analysis - تحليل وظيفة الدالة]:
            
            1. Method Purpose (الغرض الأساسي):
            Dives into '${method.name}' of '${method.className.substringAfterLast('.')}'.
            ${if (isEntitlement) "This method acts as an entitlement gatekeeper or license evaluation check. It determines whether features or subscription privileges are unlocked for the current user." else "Executes routine application procedures or UI event handling."}
            
            2. Inputs & Outputs (المدخلات والمخرجات):
            • Parameters: ${if (method.parameterTypes.isEmpty()) "None (0 parameters)" else method.parameterTypes.joinToString { it.displayName }}
            • Return Type: ${method.returnType.displayName} -> $returnDesc
            
            3. Dependencies & Callees (الدوال المستدعاة):
               • $calleesDesc
            
            4. Inbound Callers (الجهات المستدعية):
               • $callersDesc
            
            5. Associated String Constants (النصوص المرتبطة):
            $stringsDesc
            
            [Security & Evidence Rating]:
            Confidence Score: ${method.evidenceScore}% (${method.evidenceLevel})
            Key indicators: ${method.evidenceReasons.joinToString("; ")}
        """.trimIndent()
    }
}
