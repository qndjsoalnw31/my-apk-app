package com.example.core.parser

import com.example.core.model.DalvikInstruction
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Pure Kotlin parser for Dalvik Executable (.dex) binary format.
 * Accurately reads headers, string pool, type descriptors, proto IDs, field IDs, method IDs,
 * class definitions, class_data_item (fields/methods), and decodes Dalvik bytecode instructions.
 */
class DexParser {

    private fun hex4(v: Int): String = (v.coerceAtLeast(0) and 0xFFFF).toString(16).padStart(4, '0')

    data class DexHeader(
        val magic: String,
        val checksum: Long,
        val fileSize: Int,
        val stringIdsSize: Int,
        val stringIdsOff: Int,
        val typeIdsSize: Int,
        val typeIdsOff: Int,
        val protoIdsSize: Int,
        val protoIdsOff: Int,
        val fieldIdsSize: Int,
        val fieldIdsOff: Int,
        val methodIdsSize: Int,
        val methodIdsOff: Int,
        val classDefsSize: Int,
        val classDefsOff: Int
    )

    data class RawProto(
        val shorty: String,
        val returnType: String,
        val paramTypes: List<String>
    )

    data class RawField(
        val fieldIdx: Int,
        val classType: String,
        val type: String,
        val name: String
    )

    data class RawMethod(
        val methodIdx: Int,
        val classType: String,
        val protoReturn: String,
        val protoParams: List<String>,
        val name: String
    )

    data class ParsedTryCatch(
        val startAddr: Int,
        val insnCount: Int,
        val handlerType: String?, // null if catch-all
        val targetAddr: Int
    )

    data class ParsedCodeItem(
        val registersSize: Int,
        val insSize: Int,
        val outsSize: Int,
        val triesSize: Int,
        val debugInfoOff: Int,
        val instructions: List<DalvikInstruction>,
        val tryCatches: List<ParsedTryCatch>
    )

    data class ParsedMethod(
        val methodIdx: Int,
        val classType: String,
        val name: String,
        val protoReturn: String,
        val protoParams: List<String>,
        val accessFlags: Int,
        val codeItem: ParsedCodeItem?
    )

    data class ParsedField(
        val fieldIdx: Int,
        val classType: String,
        val type: String,
        val name: String,
        val accessFlags: Int
    )

    data class ParsedClass(
        val classType: String,
        val accessFlags: Int,
        val superclassType: String?,
        val interfaces: List<String>,
        val sourceFile: String?,
        val staticFields: List<ParsedField>,
        val instanceFields: List<ParsedField>,
        val directMethods: List<ParsedMethod>,
        val virtualMethods: List<ParsedMethod>
    ) {
        val allMethods: List<ParsedMethod> get() = directMethods + virtualMethods
        val allFields: List<ParsedField> get() = staticFields + instanceFields
    }

    data class RawDexData(
        val header: DexHeader,
        val strings: List<String>,
        val types: List<String>,
        val protos: List<RawProto>,
        val fields: List<RawField>,
        val methods: List<RawMethod>,
        val classes: List<ParsedClass>
    )

    fun parse(inputStream: InputStream): RawDexData {
        val bytes = inputStream.readBytes()
        if (bytes.size < 0x70) {
            throw IllegalArgumentException("DEX file truncated: size ${bytes.size} bytes is smaller than header.")
        }
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        // Verify magic
        val magic = ByteArray(8)
        buffer.get(magic)
        val magicStr = String(magic)
        if (!magicStr.startsWith("dex\n")) {
            throw IllegalArgumentException("Invalid DEX magic header: $magicStr")
        }

        val checksum = buffer.int.toLong() and 0xFFFFFFFFL
        val signature = ByteArray(20)
        buffer.get(signature)
        val fileSize = buffer.int
        val headerSize = buffer.int
        val endianTag = buffer.int

        buffer.position(0x38) // string_ids_size
        val stringIdsSize = buffer.int
        val stringIdsOff = buffer.int
        val typeIdsSize = buffer.int
        val typeIdsOff = buffer.int
        val protoIdsSize = buffer.int
        val protoIdsOff = buffer.int
        val fieldIdsSize = buffer.int
        val fieldIdsOff = buffer.int
        val methodIdsSize = buffer.int
        val methodIdsOff = buffer.int
        val classDefsSize = buffer.int
        val classDefsOff = buffer.int

        val header = DexHeader(
            magic = magicStr.trim(),
            checksum = checksum,
            fileSize = fileSize,
            stringIdsSize = stringIdsSize,
            stringIdsOff = stringIdsOff,
            typeIdsSize = typeIdsSize,
            typeIdsOff = typeIdsOff,
            protoIdsSize = protoIdsSize,
            protoIdsOff = protoIdsOff,
            fieldIdsSize = fieldIdsSize,
            fieldIdsOff = fieldIdsOff,
            methodIdsSize = methodIdsSize,
            methodIdsOff = methodIdsOff,
            classDefsSize = classDefsSize,
            classDefsOff = classDefsOff
        )

        // 1. Parse Strings
        val strings = mutableListOf<String>()
        val stringOffsets = IntArray(stringIdsSize)
        if (stringIdsOff in 0 until bytes.size) {
            buffer.position(stringIdsOff)
            for (i in 0 until stringIdsSize) {
                stringOffsets[i] = buffer.int
            }

            for (offset in stringOffsets) {
                if (offset in 0 until bytes.size) {
                    buffer.position(offset)
                    readUleb128(buffer) // utf16_size
                    val sb = StringBuilder()
                    while (buffer.hasRemaining()) {
                        val b = buffer.get().toInt() and 0xFF
                        if (b == 0) break
                        if (b < 0x80) {
                            sb.append(b.toChar())
                        } else if ((b and 0xE0) == 0xC0 && buffer.hasRemaining()) {
                            val b2 = buffer.get().toInt() and 0xFF
                            sb.append((((b and 0x1F) shl 6) or (b2 and 0x3F)).toChar())
                        } else if ((b and 0xF0) == 0xE0 && buffer.remaining() >= 2) {
                            val b2 = buffer.get().toInt() and 0xFF
                            val b3 = buffer.get().toInt() and 0xFF
                            sb.append((((b and 0x0F) shl 12) or ((b2 and 0x3F) shl 6) or (b3 and 0x3F)).toChar())
                        } else {
                            sb.append(b.toChar())
                        }
                    }
                    strings.add(sb.toString())
                } else {
                    strings.add("")
                }
            }
        }

        // 2. Parse Types
        val types = mutableListOf<String>()
        if (typeIdsOff in 0 until bytes.size) {
            buffer.position(typeIdsOff)
            for (i in 0 until typeIdsSize) {
                val descriptorIdx = buffer.int
                if (descriptorIdx in strings.indices) {
                    types.add(strings[descriptorIdx])
                } else {
                    types.add("Lunknown;")
                }
            }
        }

        // 3. Parse Protos
        val protos = mutableListOf<RawProto>()
        if (protoIdsOff in 0 until bytes.size) {
            buffer.position(protoIdsOff)
            for (i in 0 until protoIdsSize) {
                val shortyIdx = buffer.int
                val returnTypeIdx = buffer.int
                val parametersOff = buffer.int

                val shorty = if (shortyIdx in strings.indices) strings[shortyIdx] else ""
                val ret = if (returnTypeIdx in types.indices) types[returnTypeIdx] else "V"

                val paramList = mutableListOf<String>()
                if (parametersOff > 0 && parametersOff < bytes.size) {
                    val savedPos = buffer.position()
                    buffer.position(parametersOff)
                    val pSize = buffer.int
                    for (p in 0 until pSize) {
                        val pTypeIdx = buffer.short.toInt() and 0xFFFF
                        if (pTypeIdx in types.indices) {
                            paramList.add(types[pTypeIdx])
                        }
                    }
                    buffer.position(savedPos)
                }
                protos.add(RawProto(shorty, ret, paramList))
            }
        }

        // 4. Parse Fields
        val fields = mutableListOf<RawField>()
        if (fieldIdsOff in 0 until bytes.size) {
            buffer.position(fieldIdsOff)
            for (i in 0 until fieldIdsSize) {
                val classIdx = buffer.short.toInt() and 0xFFFF
                val typeIdx = buffer.short.toInt() and 0xFFFF
                val nameIdx = buffer.int

                val cType = if (classIdx in types.indices) types[classIdx] else "Lunknown;"
                val fType = if (typeIdx in types.indices) types[typeIdx] else "Lunknown;"
                val fName = if (nameIdx in strings.indices) strings[nameIdx] else "field$i"

                fields.add(RawField(i, cType, fType, fName))
            }
        }

        // 5. Parse Methods
        val methods = mutableListOf<RawMethod>()
        if (methodIdsOff in 0 until bytes.size) {
            buffer.position(methodIdsOff)
            for (i in 0 until methodIdsSize) {
                val classIdx = buffer.short.toInt() and 0xFFFF
                val protoIdx = buffer.short.toInt() and 0xFFFF
                val nameIdx = buffer.int

                val cType = if (classIdx in types.indices) types[classIdx] else "Lunknown;"
                val proto = if (protoIdx in protos.indices) protos[protoIdx] else RawProto("V", "V", emptyList())
                val mName = if (nameIdx in strings.indices) strings[nameIdx] else "method$i"

                methods.add(RawMethod(i, cType, proto.returnType, proto.paramTypes, mName))
            }
        }

        // 6. Parse Class Definitions and class_data_items
        val classes = mutableListOf<ParsedClass>()
        if (classDefsOff in 0 until bytes.size) {
            buffer.position(classDefsOff)
            for (i in 0 until classDefsSize) {
                val classIdx = buffer.int
                val accessFlags = buffer.int
                val superclassIdx = buffer.int
                val interfacesOff = buffer.int
                val sourceFileIdx = buffer.int
                val annotationsOff = buffer.int
                val classDataOff = buffer.int
                val staticValuesOff = buffer.int

                val cType = if (classIdx in types.indices) types[classIdx] else "Lunknown;"
                val sType = if (superclassIdx in types.indices) types[superclassIdx] else null
                val sourceFile = if (sourceFileIdx in strings.indices) strings[sourceFileIdx] else null

                val ifaces = mutableListOf<String>()
                if (interfacesOff > 0 && interfacesOff < bytes.size) {
                    val savedPos = buffer.position()
                    buffer.position(interfacesOff)
                    val ifaceSize = buffer.int
                    for (k in 0 until ifaceSize) {
                        val ifaceIdx = buffer.short.toInt() and 0xFFFF
                        if (ifaceIdx in types.indices) {
                            ifaces.add(types[ifaceIdx])
                        }
                    }
                    buffer.position(savedPos)
                }

                // Parse class_data_item if present
                val staticFields = mutableListOf<ParsedField>()
                val instanceFields = mutableListOf<ParsedField>()
                val directMethods = mutableListOf<ParsedMethod>()
                val virtualMethods = mutableListOf<ParsedMethod>()

                if (classDataOff > 0 && classDataOff < bytes.size) {
                    val savedPos = buffer.position()
                    buffer.position(classDataOff)

                    val staticFieldsSize = readUleb128(buffer)
                    val instanceFieldsSize = readUleb128(buffer)
                    val directMethodsSize = readUleb128(buffer)
                    val virtualMethodsSize = readUleb128(buffer)

                    // Static fields
                    var currentFieldIdx = 0
                    for (f in 0 until staticFieldsSize) {
                        val fieldIdxDiff = readUleb128(buffer)
                        val fAccessFlags = readUleb128(buffer)
                        currentFieldIdx += fieldIdxDiff
                        val rawF = fields.getOrNull(currentFieldIdx)
                        if (rawF != null) {
                            staticFields.add(
                                ParsedField(currentFieldIdx, cType, rawF.type, rawF.name, fAccessFlags)
                            )
                        }
                    }

                    // Instance fields
                    currentFieldIdx = 0
                    for (f in 0 until instanceFieldsSize) {
                        val fieldIdxDiff = readUleb128(buffer)
                        val fAccessFlags = readUleb128(buffer)
                        currentFieldIdx += fieldIdxDiff
                        val rawF = fields.getOrNull(currentFieldIdx)
                        if (rawF != null) {
                            instanceFields.add(
                                ParsedField(currentFieldIdx, cType, rawF.type, rawF.name, fAccessFlags)
                            )
                        }
                    }

                    // Direct methods
                    var currentMethodIdx = 0
                    for (m in 0 until directMethodsSize) {
                        val methodIdxDiff = readUleb128(buffer)
                        val mAccessFlags = readUleb128(buffer)
                        val codeOff = readUleb128(buffer)
                        currentMethodIdx += methodIdxDiff
                        val rawM = methods.getOrNull(currentMethodIdx)
                        if (rawM != null) {
                            val codeItem = if (codeOff > 0 && codeOff < bytes.size) {
                                parseCodeItem(bytes, codeOff, strings, types, fields, methods)
                            } else null
                            directMethods.add(
                                ParsedMethod(
                                    methodIdx = currentMethodIdx,
                                    classType = cType,
                                    name = rawM.name,
                                    protoReturn = rawM.protoReturn,
                                    protoParams = rawM.protoParams,
                                    accessFlags = mAccessFlags,
                                    codeItem = codeItem
                                )
                            )
                        }
                    }

                    // Virtual methods
                    currentMethodIdx = 0
                    for (m in 0 until virtualMethodsSize) {
                        val methodIdxDiff = readUleb128(buffer)
                        val mAccessFlags = readUleb128(buffer)
                        val codeOff = readUleb128(buffer)
                        currentMethodIdx += methodIdxDiff
                        val rawM = methods.getOrNull(currentMethodIdx)
                        if (rawM != null) {
                            val codeItem = if (codeOff > 0 && codeOff < bytes.size) {
                                parseCodeItem(bytes, codeOff, strings, types, fields, methods)
                            } else null
                            virtualMethods.add(
                                ParsedMethod(
                                    methodIdx = currentMethodIdx,
                                    classType = cType,
                                    name = rawM.name,
                                    protoReturn = rawM.protoReturn,
                                    protoParams = rawM.protoParams,
                                    accessFlags = mAccessFlags,
                                    codeItem = codeItem
                                )
                            )
                        }
                    }

                    buffer.position(savedPos)
                }

                classes.add(
                    ParsedClass(
                        classType = cType,
                        accessFlags = accessFlags,
                        superclassType = sType,
                        interfaces = ifaces,
                        sourceFile = sourceFile,
                        staticFields = staticFields,
                        instanceFields = instanceFields,
                        directMethods = directMethods,
                        virtualMethods = virtualMethods
                    )
                )
            }
        }

        return RawDexData(header, strings, types, protos, fields, methods, classes)
    }

    /**
     * Parses a code_item struct and decodes Dalvik bytecode instructions.
     */
    private fun parseCodeItem(
        bytes: ByteArray,
        offset: Int,
        strings: List<String>,
        types: List<String>,
        fields: List<RawField>,
        methods: List<RawMethod>
    ): ParsedCodeItem? {
        if (offset + 16 > bytes.size) return null
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        buf.position(offset)

        val registersSize = buf.short.toInt() and 0xFFFF
        val insSize = buf.short.toInt() and 0xFFFF
        val outsSize = buf.short.toInt() and 0xFFFF
        val triesSize = buf.short.toInt() and 0xFFFF
        val debugInfoOff = buf.int
        val insnsSize = buf.int

        if (insnsSize <= 0 || buf.position() + insnsSize * 2 > bytes.size) {
            return ParsedCodeItem(registersSize, insSize, outsSize, triesSize, debugInfoOff, emptyList(), emptyList())
        }

        val insns = ShortArray(insnsSize)
        for (i in 0 until insnsSize) {
            insns[i] = buf.short
        }

        // Tries & Catches
        val tryCatches = mutableListOf<ParsedTryCatch>()
        if (triesSize > 0) {
            if ((insnsSize and 1) != 0) {
                buf.short // 2 bytes padding
            }
            val triesStartPos = buf.position()
            val encodedHandlerBase = triesStartPos + triesSize * 8
            for (t in 0 until triesSize) {
                buf.position(triesStartPos + t * 8)
                val startAddr = buf.int
                val insnCount = buf.short.toInt() and 0xFFFF
                val handlerOff = buf.short.toInt() and 0xFFFF

                // Read handler if possible
                val hPos = encodedHandlerBase + handlerOff
                if (hPos in 0 until bytes.size) {
                    val hBuf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                    hBuf.position(hPos)
                    val size = readSleb128(hBuf)
                    val count = Math.abs(size)
                    for (c in 0 until count) {
                        val typeIdx = readUleb128(hBuf)
                        val targetAddr = readUleb128(hBuf)
                        val typeName = types.getOrNull(typeIdx)
                        tryCatches.add(ParsedTryCatch(startAddr, insnCount, typeName, targetAddr))
                    }
                    if (size <= 0) {
                        val catchAllAddr = readUleb128(hBuf)
                        tryCatches.add(ParsedTryCatch(startAddr, insnCount, null, catchAllAddr))
                    }
                }
            }
        }

        // Decode Dalvik instructions
        val instructions = decodeBytecode(insns, strings, types, fields, methods)

        return ParsedCodeItem(
            registersSize = registersSize,
            insSize = insSize,
            outsSize = outsSize,
            triesSize = triesSize,
            debugInfoOff = debugInfoOff,
            instructions = instructions,
            tryCatches = tryCatches
        )
    }

    /**
     * Comprehensive Dalvik instruction decoder.
     */
    private fun decodeBytecode(
        insns: ShortArray,
        strings: List<String>,
        types: List<String>,
        fields: List<RawField>,
        methods: List<RawMethod>
    ): List<DalvikInstruction> {
        val list = mutableListOf<DalvikInstruction>()
        var pc = 0

        while (pc < insns.size) {
            val u0 = insns[pc].toInt() and 0xFFFF
            val opcode = u0 and 0xFF
            val high8 = (u0 ushr 8) and 0xFF

            val startPc = pc
            var targetOffset: Int? = null
            var stringRef: String? = null
            var typeRef: String? = null
            var methodRef: String? = null
            var fieldRef: String? = null
            var literal: Long? = null
            val regs = mutableListOf<Int>()
            var mnemonic = "unknown-0x${Integer.toHexString(opcode)}"
            var smali = ""

            when (opcode) {
                0x00 -> { // nop
                    mnemonic = "nop"
                    smali = "nop"
                    pc += 1
                }
                0x01 -> { // move vA, vB (12x)
                    mnemonic = "move"
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    regs.add(vA); regs.add(vB)
                    smali = "move v$vA, v$vB"
                    pc += 1
                }
                0x02 -> { // move/from16 vAA, vBBBB (22x)
                    mnemonic = "move/from16"
                    val vA = high8
                    val vB = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    regs.add(vA); regs.add(vB)
                    smali = "move/from16 v$vA, v$vB"
                    pc += 2
                }
                0x03 -> { // move/16 vAAAA, vBBBB (32x)
                    mnemonic = "move/16"
                    val vA = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val vB = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                    regs.add(vA); regs.add(vB)
                    smali = "move/16 v$vA, v$vB"
                    pc += 3
                }
                0x04 -> { // move-wide vA, vB
                    mnemonic = "move-wide"
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    regs.add(vA); regs.add(vB)
                    smali = "move-wide v$vA, v$vB"
                    pc += 1
                }
                0x07 -> { // move-object vA, vB
                    mnemonic = "move-object"
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    regs.add(vA); regs.add(vB)
                    smali = "move-object v$vA, v$vB"
                    pc += 1
                }
                0x08 -> { // move-object/from16
                    mnemonic = "move-object/from16"
                    val vA = high8
                    val vB = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    regs.add(vA); regs.add(vB)
                    smali = "move-object/from16 v$vA, v$vB"
                    pc += 2
                }
                0x0a -> { // move-result vAA
                    mnemonic = "move-result"
                    val vA = high8
                    regs.add(vA)
                    smali = "move-result v$vA"
                    pc += 1
                }
                0x0b -> { // move-result-wide vAA
                    mnemonic = "move-result-wide"
                    val vA = high8
                    regs.add(vA)
                    smali = "move-result-wide v$vA"
                    pc += 1
                }
                0x0c -> { // move-result-object vAA
                    mnemonic = "move-result-object"
                    val vA = high8
                    regs.add(vA)
                    smali = "move-result-object v$vA"
                    pc += 1
                }
                0x0d -> { // move-exception vAA
                    mnemonic = "move-exception"
                    val vA = high8
                    regs.add(vA)
                    smali = "move-exception v$vA"
                    pc += 1
                }
                0x0e -> { // return-void
                    mnemonic = "return-void"
                    smali = "return-void"
                    pc += 1
                }
                0x0f -> { // return vAA
                    mnemonic = "return"
                    val vA = high8
                    regs.add(vA)
                    smali = "return v$vA"
                    pc += 1
                }
                0x10 -> { // return-wide vAA
                    mnemonic = "return-wide"
                    val vA = high8
                    regs.add(vA)
                    smali = "return-wide v$vA"
                    pc += 1
                }
                0x11 -> { // return-object vAA
                    mnemonic = "return-object"
                    val vA = high8
                    regs.add(vA)
                    smali = "return-object v$vA"
                    pc += 1
                }
                0x12 -> { // const/4 vA, #+B (11n)
                    mnemonic = "const/4"
                    val vA = high8 and 0x0F
                    var lit = ((high8 ushr 4) and 0x0F)
                    if (lit >= 8) lit -= 16 // sign extend 4 bits
                    regs.add(vA)
                    literal = lit.toLong()
                    smali = "const/4 v$vA, 0x${Integer.toHexString(lit)}"
                    pc += 1
                }
                0x13 -> { // const/16 vAA, #+BBBB (21s)
                    mnemonic = "const/16"
                    val vA = high8
                    val lit = if (pc + 1 < insns.size) insns[pc + 1].toLong() else 0L
                    regs.add(vA)
                    literal = lit
                    smali = "const/16 v$vA, 0x${java.lang.Long.toHexString(lit)}"
                    pc += 2
                }
                0x14 -> { // const vAA, #+BBBBBBBB (31i)
                    mnemonic = "const"
                    val vA = high8
                    val litLow = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val litHigh = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                    val lit = ((litHigh shl 16) or litLow).toLong()
                    regs.add(vA)
                    literal = lit
                    smali = "const v$vA, 0x${java.lang.Long.toHexString(lit)}"
                    pc += 3
                }
                0x15 -> { // const/high16 vAA, #+BBBB0000
                    mnemonic = "const/high16"
                    val vA = high8
                    val litShort = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val lit = (litShort shl 16).toLong()
                    regs.add(vA)
                    literal = lit
                    smali = "const/high16 v$vA, 0x${java.lang.Long.toHexString(lit)}"
                    pc += 2
                }
                0x16 -> { // const-wide/16
                    mnemonic = "const-wide/16"
                    val vA = high8
                    val lit = if (pc + 1 < insns.size) insns[pc + 1].toLong() else 0L
                    regs.add(vA)
                    literal = lit
                    smali = "const-wide/16 v$vA, 0x${java.lang.Long.toHexString(lit)}"
                    pc += 2
                }
                0x17 -> { // const-wide/32
                    mnemonic = "const-wide/32"
                    val vA = high8
                    val litLow = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val litHigh = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                    val lit = ((litHigh shl 16) or litLow).toLong()
                    regs.add(vA)
                    literal = lit
                    smali = "const-wide/32 v$vA, 0x${java.lang.Long.toHexString(lit)}"
                    pc += 3
                }
                0x18 -> { // const-wide (51l)
                    mnemonic = "const-wide"
                    val vA = high8
                    var lit = 0L
                    for (k in 1..4) {
                        val part = if (pc + k < insns.size) insns[pc + k].toLong() and 0xFFFFL else 0L
                        lit = lit or (part shl ((k - 1) * 16))
                    }
                    regs.add(vA)
                    literal = lit
                    smali = "const-wide v$vA, 0x${java.lang.Long.toHexString(lit)}"
                    pc += 5
                }
                0x1a -> { // const-string vAA, string@BBBB (21c)
                    mnemonic = "const-string"
                    val vA = high8
                    val sIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val s = strings.getOrNull(sIdx) ?: "unknown_string_$sIdx"
                    stringRef = s
                    regs.add(vA)
                    val escaped = s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r")
                    smali = "const-string v$vA, \"${escaped.take(120)}\""
                    pc += 2
                }
                0x1b -> { // const-string/jumbo vAA, string@BBBBBBBB (31c)
                    mnemonic = "const-string/jumbo"
                    val vA = high8
                    val sLow = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val sHigh = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                    val sIdx = (sHigh shl 16) or sLow
                    val s = strings.getOrNull(sIdx) ?: "unknown_string_$sIdx"
                    stringRef = s
                    regs.add(vA)
                    val escaped = s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r")
                    smali = "const-string/jumbo v$vA, \"${escaped.take(120)}\""
                    pc += 3
                }
                0x1c -> { // const-class vAA, type@BBBB
                    mnemonic = "const-class"
                    val vA = high8
                    val tIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val t = types.getOrNull(tIdx) ?: "Lunknown;"
                    typeRef = t
                    regs.add(vA)
                    smali = "const-class v$vA, $t"
                    pc += 2
                }
                0x1d -> { // monitor-enter vAA
                    mnemonic = "monitor-enter"
                    regs.add(high8)
                    smali = "monitor-enter v$high8"
                    pc += 1
                }
                0x1e -> { // monitor-exit vAA
                    mnemonic = "monitor-exit"
                    regs.add(high8)
                    smali = "monitor-exit v$high8"
                    pc += 1
                }
                0x1f -> { // check-cast vAA, type@BBBB
                    mnemonic = "check-cast"
                    val vA = high8
                    val tIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val t = types.getOrNull(tIdx) ?: "Lunknown;"
                    typeRef = t
                    regs.add(vA)
                    smali = "check-cast v$vA, $t"
                    pc += 2
                }
                0x20 -> { // instance-of vA, vB, type@CCCC
                    mnemonic = "instance-of"
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    val tIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val t = types.getOrNull(tIdx) ?: "Lunknown;"
                    typeRef = t
                    regs.add(vA); regs.add(vB)
                    smali = "instance-of v$vA, v$vB, $t"
                    pc += 2
                }
                0x21 -> { // array-length vA, vB
                    mnemonic = "array-length"
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    regs.add(vA); regs.add(vB)
                    smali = "array-length v$vA, v$vB"
                    pc += 1
                }
                0x22 -> { // new-instance vAA, type@BBBB
                    mnemonic = "new-instance"
                    val vA = high8
                    val tIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val t = types.getOrNull(tIdx) ?: "Lunknown;"
                    typeRef = t
                    regs.add(vA)
                    smali = "new-instance v$vA, $t"
                    pc += 2
                }
                0x23 -> { // new-array vA, vB, type@CCCC
                    mnemonic = "new-array"
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    val tIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val t = types.getOrNull(tIdx) ?: "Lunknown;"
                    typeRef = t
                    regs.add(vA); regs.add(vB)
                    smali = "new-array v$vA, v$vB, $t"
                    pc += 2
                }
                0x24 -> { // filled-new-array {vC, vD, vE, vF, vG}, type@BBBB (35c)
                    mnemonic = "filled-new-array"
                    val count = (high8 ushr 4) and 0x0F
                    val regG = high8 and 0x0F
                    val tIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val regWord = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                    val regList = mutableListOf<Int>()
                    if (count > 0) regList.add(regWord and 0x0F)
                    if (count > 1) regList.add((regWord ushr 4) and 0x0F)
                    if (count > 2) regList.add((regWord ushr 8) and 0x0F)
                    if (count > 3) regList.add((regWord ushr 12) and 0x0F)
                    if (count > 4) regList.add(regG)
                    regs.addAll(regList)
                    val t = types.getOrNull(tIdx) ?: "Lunknown;"
                    typeRef = t
                    smali = "filled-new-array {${regList.joinToString(", ") { "v$it" }}}, $t"
                    pc += 3
                }
                0x25 -> { // filled-new-array/range {vCCCC .. vNNNN}, type@BBBB (3rc)
                    mnemonic = "filled-new-array/range"
                    val count = high8
                    val tIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val startReg = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                    for (r in 0 until count) regs.add(startReg + r)
                    val t = types.getOrNull(tIdx) ?: "Lunknown;"
                    typeRef = t
                    val regRange = if (count > 0) "v$startReg .. v${startReg + count - 1}" else ""
                    smali = "filled-new-array/range {$regRange}, $t"
                    pc += 3
                }
                0x26 -> { // fill-array-data vAA, +BBBBBBBB (31t)
                    mnemonic = "fill-array-data"
                    val vA = high8
                    val offLow = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val offHigh = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                    val offset = (offHigh shl 16) or offLow
                    targetOffset = startPc + offset
                    regs.add(vA)
                    smali = "fill-array-data v$vA, :array_${hex4(startPc + offset)}"
                    pc += 3
                }
                0x27 -> { // throw vAA
                    mnemonic = "throw"
                    regs.add(high8)
                    smali = "throw v$high8"
                    pc += 1
                }
                0x28 -> { // goto +AA (10t)
                    mnemonic = "goto"
                    var offset = high8.toByte().toInt()
                    targetOffset = startPc + offset
                    smali = "goto :target_${hex4(startPc + offset)}"
                    pc += 1
                }
                0x29 -> { // goto/16 +AAAA (20t)
                    mnemonic = "goto/16"
                    val offset = if (pc + 1 < insns.size) insns[pc + 1].toInt() else 0
                    targetOffset = startPc + offset
                    smali = "goto/16 :target_${hex4(startPc + offset)}"
                    pc += 2
                }
                0x2a -> { // goto/32 +AAAAAAAA (30t)
                    mnemonic = "goto/32"
                    val offLow = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val offHigh = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                    val offset = (offHigh shl 16) or offLow
                    targetOffset = startPc + offset
                    smali = "goto/32 :target_${hex4(startPc + offset)}"
                    pc += 3
                }
                in 0x32..0x37 -> { // if-test vA, vB, +CCCC (22t)
                    val opName = when (opcode) {
                        0x32 -> "if-eq"
                        0x33 -> "if-ne"
                        0x34 -> "if-lt"
                        0x35 -> "if-ge"
                        0x36 -> "if-gt"
                        else -> "if-le"
                    }
                    mnemonic = opName
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    val branchOffset = if (pc + 1 < insns.size) insns[pc + 1].toInt() else 0
                    targetOffset = startPc + branchOffset
                    regs.add(vA); regs.add(vB)
                    smali = "$opName v$vA, v$vB, :cond_${hex4(startPc + branchOffset)}"
                    pc += 2
                }
                in 0x38..0x3d -> { // if-testz vAA, +BBBB (21t)
                    val opName = when (opcode) {
                        0x38 -> "if-eqz"
                        0x39 -> "if-nez"
                        0x3a -> "if-ltz"
                        0x3b -> "if-gez"
                        0x3c -> "if-gtz"
                        else -> "if-lez"
                    }
                    mnemonic = opName
                    val vA = high8
                    val branchOffset = if (pc + 1 < insns.size) insns[pc + 1].toInt() else 0
                    targetOffset = startPc + branchOffset
                    regs.add(vA)
                    smali = "$opName v$vA, :cond_${hex4(startPc + branchOffset)}"
                    pc += 2
                }
                in 0x52..0x5f -> { // iget / iput vA, vB, field@CCCC (22c)
                    val opName = when (opcode) {
                        0x52 -> "iget"; 0x53 -> "iget-wide"; 0x54 -> "iget-object"; 0x55 -> "iget-boolean"
                        0x56 -> "iget-byte"; 0x57 -> "iget-char"; 0x58 -> "iget-short"
                        0x59 -> "iput"; 0x5a -> "iput-wide"; 0x5b -> "iput-object"; 0x5c -> "iput-boolean"
                        0x5d -> "iput-byte"; 0x5e -> "iput-char"; else -> "iput-short"
                    }
                    mnemonic = opName
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    val fIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val f = fields.getOrNull(fIdx)
                    val fStr = if (f != null) "${f.classType}->${f.name}:${f.type}" else "field@$fIdx"
                    fieldRef = fStr
                    regs.add(vA); regs.add(vB)
                    smali = "$opName v$vA, v$vB, $fStr"
                    pc += 2
                }
                in 0x60..0x6d -> { // sget / sput vAA, field@BBBB (21c)
                    val opName = when (opcode) {
                        0x60 -> "sget"; 0x61 -> "sget-wide"; 0x62 -> "sget-object"; 0x63 -> "sget-boolean"
                        0x64 -> "sget-byte"; 0x65 -> "sget-char"; 0x66 -> "sget-short"
                        0x67 -> "sput"; 0x68 -> "sput-wide"; 0x69 -> "sput-object"; 0x6a -> "sput-boolean"
                        0x6b -> "sput-byte"; 0x6c -> "sput-char"; else -> "sput-short"
                    }
                    mnemonic = opName
                    val vA = high8
                    val fIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val f = fields.getOrNull(fIdx)
                    val fStr = if (f != null) "${f.classType}->${f.name}:${f.type}" else "field@$fIdx"
                    fieldRef = fStr
                    regs.add(vA)
                    smali = "$opName v$vA, $fStr"
                    pc += 2
                }
                in 0x6e..0x72 -> { // invoke-kind {vC, vD, vE, vF, vG}, meth@BBBB (35c)
                    val opName = when (opcode) {
                        0x6e -> "invoke-virtual"
                        0x6f -> "invoke-super"
                        0x70 -> "invoke-direct"
                        0x71 -> "invoke-static"
                        else -> "invoke-interface"
                    }
                    mnemonic = opName
                    val count = (high8 ushr 4) and 0x0F
                    val regG = high8 and 0x0F
                    val mIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val regWord = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0

                    val regC = regWord and 0x0F
                    val regD = (regWord ushr 4) and 0x0F
                    val regE = (regWord ushr 8) and 0x0F
                    val regF = (regWord ushr 12) and 0x0F

                    val regList = mutableListOf<Int>()
                    if (count > 0) regList.add(regC)
                    if (count > 1) regList.add(regD)
                    if (count > 2) regList.add(regE)
                    if (count > 3) regList.add(regF)
                    if (count > 4) regList.add(regG)

                    regs.addAll(regList)
                    val m = methods.getOrNull(mIdx)
                    val mStr = if (m != null) {
                        val params = m.protoParams.joinToString("")
                        "${m.classType}->${m.name}($params)${m.protoReturn}"
                    } else "method@$mIdx"
                    methodRef = mStr

                    val regStr = regList.joinToString(", ") { "v$it" }
                    smali = "$opName {$regStr}, $mStr"
                    pc += 3
                }
                in 0x74..0x78 -> { // invoke-kind/range {vCCCC .. vNNNN}, meth@BBBB (3rc)
                    val opName = when (opcode) {
                        0x74 -> "invoke-virtual/range"
                        0x75 -> "invoke-super/range"
                        0x76 -> "invoke-direct/range"
                        0x77 -> "invoke-static/range"
                        else -> "invoke-interface/range"
                    }
                    mnemonic = opName
                    val count = high8
                    val mIdx = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val startReg = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0

                    val regList = mutableListOf<Int>()
                    for (r in 0 until count) {
                        regList.add(startReg + r)
                    }
                    regs.addAll(regList)

                    val m = methods.getOrNull(mIdx)
                    val mStr = if (m != null) {
                        val params = m.protoParams.joinToString("")
                        "${m.classType}->${m.name}($params)${m.protoReturn}"
                    } else "method@$mIdx"
                    methodRef = mStr

                    val regStr = if (count > 0) "v$startReg .. v${startReg + count - 1}" else ""
                    smali = "$opName {$regStr}, $mStr"
                    pc += 3
                }
                0x2b, 0x2c -> { // packed-switch / sparse-switch (31t)
                    mnemonic = if (opcode == 0x2b) "packed-switch" else "sparse-switch"
                    val vA = high8
                    val offLow = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val offHigh = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                    val offset = (offHigh shl 16) or offLow
                    targetOffset = startPc + offset
                    regs.add(vA)
                    smali = "$mnemonic v$vA, :switch_${hex4(startPc + offset)}"
                    pc += 3
                }
                in 0x2d..0x31 -> { // cmpkind vAA, vBB, vCC (23x)
                    mnemonic = when (opcode) {
                        0x2d -> "cmpl-float"
                        0x2e -> "cmpg-float"
                        0x2f -> "cmpl-double"
                        0x30 -> "cmpg-double"
                        else -> "cmp-long"
                    }
                    val vAA = high8
                    val word = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val vBB = word and 0xFF
                    val vCC = (word ushr 8) and 0xFF
                    regs.add(vAA); regs.add(vBB); regs.add(vCC)
                    smali = "$mnemonic v$vAA, v$vBB, v$vCC"
                    pc += 2
                }
                in 0x44..0x4a -> { // aget-kind vAA, vBB, vCC (23x)
                    mnemonic = when (opcode) {
                        0x44 -> "aget"
                        0x45 -> "aget-wide"
                        0x46 -> "aget-object"
                        0x47 -> "aget-boolean"
                        0x48 -> "aget-byte"
                        0x49 -> "aget-char"
                        else -> "aget-short"
                    }
                    val vAA = high8
                    val word = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val vBB = word and 0xFF
                    val vCC = (word ushr 8) and 0xFF
                    regs.add(vAA); regs.add(vBB); regs.add(vCC)
                    smali = "$mnemonic v$vAA, v$vBB, v$vCC"
                    pc += 2
                }
                in 0x4b..0x51 -> { // aput-kind vAA, vBB, vCC (23x)
                    mnemonic = when (opcode) {
                        0x4b -> "aput"
                        0x4c -> "aput-wide"
                        0x4d -> "aput-object"
                        0x4e -> "aput-boolean"
                        0x4f -> "aput-byte"
                        0x50 -> "aput-char"
                        else -> "aput-short"
                    }
                    val vAA = high8
                    val word = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val vBB = word and 0xFF
                    val vCC = (word ushr 8) and 0xFF
                    regs.add(vAA); regs.add(vBB); regs.add(vCC)
                    smali = "$mnemonic v$vAA, v$vBB, v$vCC"
                    pc += 2
                }
                in 0x7b..0x8f -> { // unop vA, vB (12x)
                    mnemonic = when (opcode) {
                        0x7b -> "neg-int"; 0x7c -> "not-int"; 0x7d -> "neg-long"; 0x7e -> "not-long"
                        0x7f -> "neg-float"; 0x80 -> "neg-double"; 0x81 -> "int-to-long"; 0x82 -> "int-to-float"
                        0x83 -> "int-to-double"; 0x84 -> "long-to-int"; 0x85 -> "long-to-float"; 0x86 -> "long-to-double"
                        0x87 -> "float-to-int"; 0x88 -> "float-to-long"; 0x89 -> "float-to-double"; 0x8a -> "double-to-int"
                        0x8b -> "double-to-long"; 0x8c -> "double-to-float"; 0x8d -> "int-to-byte"; 0x8e -> "int-to-char"
                        else -> "int-to-short"
                    }
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    regs.add(vA); regs.add(vB)
                    smali = "$mnemonic v$vA, v$vB"
                    pc += 1
                }
                in 0x90..0xaf -> { // binop vAA, vBB, vCC (23x)
                    mnemonic = when (opcode) {
                        0x90 -> "add-int"; 0x91 -> "sub-int"; 0x92 -> "mul-int"; 0x93 -> "div-int"; 0x94 -> "rem-int"
                        0x95 -> "and-int"; 0x96 -> "or-int"; 0x97 -> "xor-int"; 0x98 -> "shl-int"; 0x99 -> "shr-int"; 0x9a -> "ushr-int"
                        0x9b -> "add-long"; 0x9c -> "sub-long"; 0x9d -> "mul-long"; 0x9e -> "div-long"; 0x9f -> "rem-long"
                        0xa0 -> "and-long"; 0xa1 -> "or-long"; 0xa2 -> "xor-long"; 0xa3 -> "shl-long"; 0xa4 -> "shr-long"; 0xa5 -> "ushr-long"
                        0xa6 -> "add-float"; 0xa7 -> "sub-float"; 0xa8 -> "mul-float"; 0xa9 -> "div-float"; 0xaa -> "rem-float"
                        0xab -> "add-double"; 0xac -> "sub-double"; 0xad -> "mul-double"; 0xae -> "div-double"; else -> "rem-double"
                    }
                    val vAA = high8
                    val word = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val vBB = word and 0xFF
                    val vCC = (word ushr 8) and 0xFF
                    regs.add(vAA); regs.add(vBB); regs.add(vCC)
                    smali = "$mnemonic v$vAA, v$vBB, v$vCC"
                    pc += 2
                }
                in 0xb0..0xcf -> { // binop/2addr vA, vB (12x)
                    val baseName = when (opcode - 0x20) {
                        0x90 -> "add-int"; 0x91 -> "sub-int"; 0x92 -> "mul-int"; 0x93 -> "div-int"; 0x94 -> "rem-int"
                        0x95 -> "and-int"; 0x96 -> "or-int"; 0x97 -> "xor-int"; 0x98 -> "shl-int"; 0x99 -> "shr-int"; 0x9a -> "ushr-int"
                        0x9b -> "add-long"; 0x9c -> "sub-long"; 0x9d -> "mul-long"; 0x9e -> "div-long"; 0x9f -> "rem-long"
                        0xa0 -> "and-long"; 0xa1 -> "or-long"; 0xa2 -> "xor-long"; 0xa3 -> "shl-long"; 0xa4 -> "shr-long"; 0xa5 -> "ushr-long"
                        0xa6 -> "add-float"; 0xa7 -> "sub-float"; 0xa8 -> "mul-float"; 0xa9 -> "div-float"; 0xaa -> "rem-float"
                        0xab -> "add-double"; 0xac -> "sub-double"; 0xad -> "mul-double"; 0xae -> "div-double"; else -> "rem-double"
                    }
                    mnemonic = "$baseName/2addr"
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    regs.add(vA); regs.add(vB)
                    smali = "$mnemonic v$vA, v$vB"
                    pc += 1
                }
                in 0xd0..0xd7 -> { // binop/lit16 vA, vB, #+CCCC (22s)
                    mnemonic = when (opcode) {
                        0xd0 -> "add-int/lit16"; 0xd1 -> "rsub-int"; 0xd2 -> "mul-int/lit16"; 0xd3 -> "div-int/lit16"
                        0xd4 -> "rem-int/lit16"; 0xd5 -> "and-int/lit16"; 0xd6 -> "or-int/lit16"; else -> "xor-int/lit16"
                    }
                    val vA = high8 and 0x0F
                    val vB = (high8 ushr 4) and 0x0F
                    val lit = if (pc + 1 < insns.size) insns[pc + 1].toLong() else 0L
                    literal = lit
                    regs.add(vA); regs.add(vB)
                    smali = "$mnemonic v$vA, v$vB, #$lit"
                    pc += 2
                }
                in 0xd8..0xe2 -> { // binop/lit8 vAA, vBB, #+CC (22b)
                    mnemonic = when (opcode) {
                        0xd8 -> "add-int/lit8"; 0xd9 -> "rsub-int/lit8"; 0xda -> "mul-int/lit8"; 0xdb -> "div-int/lit8"
                        0xdc -> "rem-int/lit8"; 0xdd -> "and-int/lit8"; 0xde -> "or-int/lit8"; 0xdf -> "xor-int/lit8"
                        0xe0 -> "shl-int/lit8"; 0xe1 -> "shr-int/lit8"; else -> "ushr-int/lit8"
                    }
                    val vAA = high8
                    val word = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                    val vBB = word and 0xFF
                    val litCC = (word ushr 8).toByte().toLong()
                    literal = litCC
                    regs.add(vAA); regs.add(vBB)
                    smali = "$mnemonic v$vAA, v$vBB, #$litCC"
                    pc += 2
                }
                in 0xfa..0xfd -> { // invoke-polymorphic / invoke-custom
                    mnemonic = when (opcode) {
                        0xfa -> "invoke-polymorphic"
                        0xfb -> "invoke-polymorphic/range"
                        0xfc -> "invoke-custom"
                        else -> "invoke-custom/range"
                    }
                    smali = "$mnemonic"
                    pc += 4
                }
                else -> {
                    // Fallback for payload pseudoinstructions or unknown opcodes
                    if (opcode == 0x00 && high8 == 0x01) {
                        mnemonic = "packed-switch-payload"
                        val size = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                        smali = ".packed-switch payload (size: $size)"
                        pc += (4 + size * 2).coerceAtLeast(1)
                    } else if (opcode == 0x00 && high8 == 0x02) {
                        mnemonic = "sparse-switch-payload"
                        val size = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                        smali = ".sparse-switch payload (size: $size)"
                        pc += (2 + size * 4).coerceAtLeast(1)
                    } else if (opcode == 0x00 && high8 == 0x03) {
                        mnemonic = "fill-array-data-payload"
                        val elemWidth = if (pc + 1 < insns.size) insns[pc + 1].toInt() and 0xFFFF else 0
                        val sizeLow = if (pc + 2 < insns.size) insns[pc + 2].toInt() and 0xFFFF else 0
                        val sizeHigh = if (pc + 3 < insns.size) insns[pc + 3].toInt() and 0xFFFF else 0
                        val size = (sizeHigh shl 16) or sizeLow
                        smali = ".array-data payload (elemWidth: $elemWidth, size: $size)"
                        pc += (4 + (size * elemWidth + 1) / 2).coerceAtLeast(1)
                    } else {
                        mnemonic = "op_0x${Integer.toHexString(opcode)}"
                        val vA = high8
                        regs.add(vA)
                        smali = "$mnemonic v$vA"
                        pc += 1
                    }
                }
            }

            list.add(
                DalvikInstruction(
                    offset = startPc,
                    opcode = opcode,
                    mnemonic = mnemonic,
                    registers = regs,
                    targetOffset = targetOffset,
                    stringRef = stringRef,
                    typeRef = typeRef,
                    methodRef = methodRef,
                    fieldRef = fieldRef,
                    literal = literal,
                    smaliText = smali
                )
            )
        }

        return list
    }

    private fun readUleb128(buffer: ByteBuffer): Int {
        var result = 0
        var shift = 0
        while (buffer.hasRemaining()) {
            val b = buffer.get().toInt()
            result = result or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
        }
        return result
    }

    private fun readSleb128(buffer: ByteBuffer): Int {
        var result = 0
        var shift = 0
        var b = 0
        do {
            if (!buffer.hasRemaining()) break
            b = buffer.get().toInt()
            result = result or ((b and 0x7F) shl shift)
            shift += 7
        } while ((b and 0x80) != 0)

        if ((shift < 32) && ((b and 0x40) != 0)) {
            result = result or -(1 shl shift)
        }
        return result
    }
}
