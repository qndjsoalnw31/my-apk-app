package com.example.core.parser

import com.example.core.analysis.EvidenceEngine
import com.example.core.analysis.FeatureScanner
import com.example.core.analysis.LibraryDetector
import com.example.core.analysis.SmaliAndDecompiler
import com.example.core.analysis.StringIntelligenceEngine
import com.example.core.model.ApkAnalysisResult
import com.example.core.model.ApkFileEntry
import com.example.core.model.ApkInfo
import com.example.core.model.CertificateInfo
import com.example.core.model.ClassInfo
import com.example.core.model.DexFileInfo
import com.example.core.model.FieldInfo
import com.example.core.model.ManifestInfo
import com.example.core.model.MethodInfo
import com.example.core.model.NativeLibraryInfo
import com.example.core.model.StringItem
import com.example.core.model.StringUsage
import com.example.core.model.TryCatchInfo
import com.example.core.model.TypeInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class ApkParseException(message: String, cause: Throwable? = null) : Exception(message, cause)

class ApkParser {

    suspend fun parseApkFile(
        fileInputStream: InputStream,
        fileName: String,
        fileSizeBytes: Long,
        onProgress: (String, Int, Int) -> Unit
    ): ApkAnalysisResult = withContext(Dispatchers.IO) {
        onProgress("Reading APK archive entries and assets...", 1, 6)

        val apkBytes = try {
            fileInputStream.readBytes()
        } catch (e: Exception) {
            throw ApkParseException("Failed to read APK file stream: ${e.message}", e)
        }

        if (apkBytes.size < 100) {
            throw ApkParseException("The provided file is empty or too small to be a valid Android APK (${apkBytes.size} bytes).")
        }

        // Calculate APK file hashes
        val sha256Hash = computeHash(apkBytes, "SHA-256")
        val md5Hash = computeHash(apkBytes, "MD5")

        // Unpack ZIP entries
        val dexMap = mutableMapOf<String, ByteArray>()
        var manifestBytes: ByteArray? = null
        val nativeLibs = mutableListOf<NativeLibraryInfo>()
        val apkFiles = mutableListOf<ApkFileEntry>()
        val certBytesList = mutableListOf<ByteArray>()

        val zip = ZipInputStream(ByteArrayInputStream(apkBytes))
        var entry: ZipEntry? = zip.nextEntry

        while (entry != null) {
            val name = entry.name
            val size = if (entry.size >= 0) entry.size else 0L
            val compressedSize = if (entry.compressedSize >= 0) entry.compressedSize else 0L
            val category = categorizeZipEntry(name)

            val isManifest = name == "AndroidManifest.xml"
            val isDex = name.endsWith(".dex")
            val isCert = name.startsWith("META-INF/") && (name.endsWith(".RSA") || name.endsWith(".DSA") || name.endsWith(".EC"))

            val actualSize: Long
            if (isManifest || isDex || isCert) {
                val entryBytes = zip.readBytes()
                actualSize = if (size > 0) size else entryBytes.size.toLong()
                if (isManifest) {
                    manifestBytes = entryBytes
                } else if (isDex) {
                    dexMap[name] = entryBytes
                } else if (isCert) {
                    certBytesList.add(entryBytes)
                }
            } else {
                if (size >= 0) {
                    actualSize = size
                } else {
                    var count = 0L
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (zip.read(buffer).also { read = it } != -1) {
                        count += read
                    }
                    actualSize = count
                }
            }

            if (apkFiles.size < 2000) {
                apkFiles.add(
                    ApkFileEntry(
                        path = name,
                        category = category,
                        sizeBytes = actualSize,
                        compressedSizeBytes = compressedSize,
                        formattedSize = formatBytes(actualSize)
                    )
                )
            }

            if (name.startsWith("lib/") && name.endsWith(".so")) {
                val parts = name.split('/')
                val arch = if (parts.size >= 2) parts[1] else "unknown"
                val libName = parts.last()
                val isSuspicious = libName.contains("hook") || libName.contains("xposed") ||
                        libName.contains("frida") || libName.contains("root") || libName.contains("substrate")
                val suspiciousReason = if (isSuspicious) "Matches known dynamic instrumentation or rooting library name pattern" else null
                val elfType = if (arch.contains("64")) "ELF 64-bit LSB shared object" else "ELF 32-bit LSB shared object"
                nativeLibs.add(
                    NativeLibraryInfo(
                        name = libName,
                        architecture = arch,
                        sizeBytes = actualSize,
                        formattedSize = formatBytes(actualSize),
                        elfType = elfType,
                        isSuspicious = isSuspicious,
                        suspiciousReason = suspiciousReason
                    )
                )
            }

            entry = zip.nextEntry
        }

        // Parse AndroidManifest.xml
        onProgress("Decoding binary AndroidManifest.xml...", 2, 6)
        if (manifestBytes == null) {
            throw ApkParseException("AndroidManifest.xml not found in APK archive.")
        }

        val manifest: ManifestInfo = try {
            BinaryXmlParser().parse(ByteArrayInputStream(manifestBytes))
        } catch (e: Exception) {
            throw ApkParseException("Failed to parse AndroidManifest.xml: ${e.message}", e)
        }

        // Parse Certificates from META-INF
        val certificates = parseCertificates(certBytesList)

        // Parse DEX files
        onProgress("Parsing Dalvik Executable (.dex) bytecode...", 3, 6)
        if (dexMap.isEmpty()) {
            throw ApkParseException("No Dalvik Executable (.dex) files found in the APK archive.")
        }

        val dexParser = DexParser()
        val dexInfoList = mutableListOf<DexFileInfo>()
        val allRawClasses = mutableListOf<DexParser.ParsedClass>()
        val allRawStrings = mutableListOf<String>()
        var totalRawMethods = 0
        var totalRawFields = 0

        for ((dexName, dexData) in dexMap.entries.sortedBy { it.key }) {
            try {
                val rawDex = dexParser.parse(ByteArrayInputStream(dexData))
                val sha1 = computeHash(dexData, "SHA-1")

                dexInfoList.add(
                    DexFileInfo(
                        fileName = dexName,
                        fileSizeBytes = dexData.size.toLong(),
                        formattedSize = formatBytes(dexData.size.toLong()),
                        classCount = rawDex.classes.size,
                        methodCount = rawDex.methods.size,
                        fieldCount = rawDex.fields.size,
                        stringCount = rawDex.strings.size,
                        typeCount = rawDex.types.size,
                        protoCount = rawDex.protos.size,
                        sha1Hash = sha1
                    )
                )

                allRawClasses.addAll(rawDex.classes)
                allRawStrings.addAll(rawDex.strings)
                totalRawMethods += rawDex.methods.size
                totalRawFields += rawDex.fields.size
            } catch (e: Exception) {
                throw ApkParseException("Failed to parse Dalvik structure of $dexName: ${e.message}", e)
            }
        }
        val totalDexFilesCount = dexInfoList.size
        dexMap.clear()

        // Process Classes and Methods
        onProgress("Analyzing classes, Dalvik instructions, and call graph...", 4, 6)
        val domainClasses = mutableListOf<ClassInfo>()
        val domainMethods = mutableListOf<MethodInfo>()
        val methodLookup = mutableMapOf<String, MethodInfo>()
        val stringUsagesMap = mutableMapOf<String, MutableList<StringUsage>>()
        val stringClassesMap = mutableMapOf<String, MutableSet<String>>()
        val stringMethodsMap = mutableMapOf<String, MutableSet<String>>()

        for (rc in allRawClasses) {
            val cleanClassName = rc.classType.removePrefix("L").removeSuffix(";").replace('/', '.')
            val pkgName = cleanClassName.substringBeforeLast('.', "default")
            val simpleName = cleanClassName.substringAfterLast('.')

            val classFields = rc.allFields.map { rf ->
                val fAccess = parseAccessFlags(rf.accessFlags, isMethod = false)
                FieldInfo(
                    name = rf.name,
                    type = TypeInfo.parse(rf.type),
                    accessFlags = fAccess
                )
            }

            val classMethods = mutableListOf<MethodInfo>()
            for (rm in rc.allMethods) {
                val retType = TypeInfo.parse(rm.protoReturn)
                val paramTypes = rm.protoParams.map { TypeInfo.parse(it) }
                val accessFlags = parseAccessFlags(rm.accessFlags, isMethod = true)
                val isStatic = rm.accessFlags and 0x0008 != 0
                val isConstructor = rm.name == "<init>" || rm.name == "<clinit>"

                val codeItem = rm.codeItem
                val instructions = codeItem?.instructions ?: emptyList()

                // Track string usages and references
                for (ins in instructions) {
                    val s = ins.stringRef
                    if (s != null) {
                        val usages = stringUsagesMap.getOrPut(s) { mutableListOf() }
                        if (usages.size < 25) {
                            usages.add(
                                StringUsage(
                                    className = cleanClassName,
                                    methodName = rm.name,
                                    dexOffset = "0x" + (ins.offset and 0xFFFF).toString(16).padStart(4, '0')
                                )
                            )
                        }
                        stringClassesMap.getOrPut(s) { mutableSetOf() }.add(cleanClassName)
                        stringMethodsMap.getOrPut(s) { mutableSetOf() }.add("$cleanClassName->${rm.name}")
                    }
                }

                val referencedStrings = instructions
                    .mapNotNull { it.stringRef }
                    .distinct()

                val mId = "$cleanClassName.${rm.name}(${paramTypes.joinToString(",") { it.displayName }}):${retType.displayName}"

                // Outbound callees from invoke-* instructions
                val callees = instructions
                    .mapNotNull { it.methodRef }
                    .distinct()

                val (evidenceScore, reasons) = EvidenceEngine.calculateMethodEvidence(
                    methodName = rm.name,
                    className = cleanClassName,
                    packageName = pkgName,
                    returnCategory = retType.category,
                    parameters = rm.protoParams,
                    strings = referencedStrings,
                    callersCount = 0,
                    calleesCount = callees.size
                )

                val tryCatches = codeItem?.tryCatches?.map {
                    TryCatchInfo(
                        startAddr = it.startAddr,
                        endAddr = it.startAddr + it.insnCount,
                        handlerType = it.handlerType,
                        targetAddr = it.targetAddr
                    )
                } ?: emptyList()

                val mInfo = MethodInfo(
                    id = mId,
                    name = rm.name,
                    className = cleanClassName,
                    packageName = pkgName,
                    accessFlags = accessFlags,
                    isConstructor = isConstructor,
                    isStatic = isStatic,
                    parameterTypes = paramTypes,
                    returnType = retType,
                    callersCount = 0,
                    callers = emptyList(),
                    callees = callees,
                    associatedStrings = referencedStrings,
                    codeOffset = "0x" + (rm.methodIdx and 0xFFFF).toString(16).padStart(4, '0'),
                    registersCount = codeItem?.registersSize ?: 0,
                    insSize = codeItem?.insSize ?: 0,
                    outsSize = codeItem?.outsSize ?: 0,
                    triesCount = codeItem?.triesSize ?: 0,
                    tryCatches = tryCatches,
                    rawInstructions = instructions,
                    evidenceScore = evidenceScore,
                    evidenceLevel = EvidenceEngine.toEvidenceLevel(evidenceScore),
                    evidenceReasons = reasons
                )

                classMethods.add(mInfo)
                domainMethods.add(mInfo)
                methodLookup[mId] = mInfo
            }

            val cEvidence = classMethods.maxOfOrNull { it.evidenceScore } ?: 0
            domainClasses.add(
                ClassInfo(
                    id = cleanClassName,
                    simpleName = simpleName,
                    packageName = pkgName,
                    superClassName = rc.superclassType?.removePrefix("L")?.removeSuffix(";")?.replace('/', '.') ?: "java.lang.Object",
                    interfaces = rc.interfaces.map { it.removePrefix("L").removeSuffix(";").replace('/', '.') },
                    accessFlags = parseAccessFlags(rc.accessFlags, isMethod = false),
                    isInterface = rc.accessFlags and 0x0200 != 0,
                    isAbstract = rc.accessFlags and 0x0400 != 0,
                    fields = classFields,
                    methods = classMethods,
                    stringsContained = classMethods.flatMap { it.associatedStrings }.distinct(),
                    evidenceScore = cEvidence
                )
            )
        }

        // Cross-reference Inbound Callers across all methods
        val callerMap = mutableMapOf<String, MutableList<String>>()
        for (m in domainMethods) {
            for (callee in m.callees) {
                callerMap.getOrPut(callee) { mutableListOf() }.add(m.id)
            }
        }

        // Update callers for methods that have incoming invocations
        val updatedDomainMethods = domainMethods.map { m ->
            val callers = callerMap[m.id] ?: emptyList()
            if (callers.isNotEmpty()) {
                m.copy(callers = callers, callersCount = callers.size)
            } else {
                m
            }
        }

        // Strings processing with full usage mapping
        onProgress("Indexing string pool and cross-references...", 5, 6)
        val stringCountMap = allRawStrings.filter { it.length > 2 }.groupingBy { it }.eachCount()
        val stringItems = stringCountMap.entries
            .sortedByDescending { it.value }
            .take(600)
            .map { (str, count) ->
                StringItem(
                    value = str,
                    occurrences = count,
                    category = StringIntelligenceEngine.categorizeString(str),
                    foundInClasses = stringClassesMap[str]?.toList() ?: emptyList(),
                    foundInMethods = stringMethodsMap[str]?.toList() ?: emptyList(),
                    usages = stringUsagesMap[str] ?: emptyList()
                )
            }

        onProgress("Evaluating security posture, obfuscation, and health...", 6, 6)
        val libraries = LibraryDetector.detect(domainClasses.map { it.packageName }.distinct())
        val features = FeatureScanner.scan(updatedDomainMethods, stringItems, libraries)

        val totalBytes = if (fileSizeBytes > 0) fileSizeBytes else apkBytes.size.toLong()
        val appName = manifest.packageName.substringAfterLast('.').replaceFirstChar {
            if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
        }

        // Detect APK Signature Schemes
        val detectedSchemes = mutableListOf<String>()
        if (certificates.isNotEmpty()) {
            detectedSchemes.add("v1 (JAR Signature)")
        }
        try {
            val magic = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)
            val scanStart = (apkBytes.size - 65536).coerceAtLeast(0)
            for (i in scanStart until (apkBytes.size - magic.size)) {
                var match = true
                for (j in magic.indices) {
                    if (apkBytes[i + j] != magic[j]) {
                        match = false
                        break
                    }
                }
                if (match) {
                    detectedSchemes.add("v2 (APK Signature Scheme)")
                    detectedSchemes.add("v3 (APK Signature Scheme v3)")
                    break
                }
            }
        } catch (_: Exception) { }
        if (detectedSchemes.isEmpty() && certificates.isNotEmpty()) {
            detectedSchemes.add("v1")
        }

        val apkInfo = ApkInfo(
            fileName = fileName,
            packageName = manifest.packageName,
            appName = appName,
            versionName = manifest.versionName,
            versionCode = manifest.versionCode,
            minSdk = manifest.minSdk,
            targetSdk = manifest.targetSdk,
            fileSizeFormatted = formatBytes(totalBytes),
            fileSizeBytes = totalBytes,
            totalDexCount = totalDexFilesCount,
            totalClasses = allRawClasses.size,
            totalMethods = totalRawMethods,
            totalFields = totalRawFields,
            totalStrings = allRawStrings.size,
            isDebuggable = manifest.permissions.any { it.name.contains("DEBUG") },
            certificateDigest = certificates.firstOrNull()?.sha256Fingerprint ?: "",
            sha256Hash = sha256Hash,
            md5Hash = md5Hash,
            signatureSchemes = detectedSchemes
        )

        val obfReport = com.example.core.analysis.ObfuscationDetector.analyze(domainClasses, updatedDomainMethods, stringItems)
        val secReport = com.example.core.analysis.SecurityAnalyzer.audit(manifest, domainClasses, updatedDomainMethods, stringItems)
        val netReport = com.example.core.analysis.NetworkAnalyzer.analyze(updatedDomainMethods, stringItems)
        val depGraph = com.example.core.analysis.DependencyGraphEngine.build(apkInfo.packageName, domainClasses, updatedDomainMethods, libraries)
        val featureGroups = com.example.core.analysis.FeatureMapEngine.generate(apkInfo.packageName, manifest, domainClasses, updatedDomainMethods, stringItems)
        val healthReport = com.example.core.analysis.ApkHealthEngine.evaluate(apkInfo, manifest, domainClasses, updatedDomainMethods, obfReport, secReport)

        return@withContext ApkAnalysisResult(
            apkInfo = apkInfo,
            manifest = manifest,
            classes = domainClasses,
            methods = updatedDomainMethods,
            strings = stringItems,
            libraries = libraries,
            features = features,
            obfuscationReport = obfReport,
            securityReport = secReport,
            networkReport = netReport,
            dependencyGraph = depGraph,
            healthReport = healthReport,
            featureMapGroups = featureGroups,
            dexFiles = dexInfoList,
            nativeLibraries = nativeLibs,
            apkFiles = apkFiles,
            certificates = certificates
        )
    }

    private fun categorizeZipEntry(path: String): String {
        return when {
            path == "AndroidManifest.xml" -> "MANIFEST"
            path.endsWith(".dex") -> "DEX"
            path.startsWith("lib/") -> "NATIVE_LIB"
            path.startsWith("assets/") -> "ASSET"
            path.startsWith("res/") || path == "resources.arsc" -> "RESOURCE"
            path.startsWith("META-INF/") -> "SIGNATURE"
            else -> "OTHER"
        }
    }

    private fun parseCertificates(certBytesList: List<ByteArray>): List<CertificateInfo> {
        val certList = mutableListOf<CertificateInfo>()
        if (certBytesList.isEmpty()) return certList

        val certFactory = try {
            CertificateFactory.getInstance("X.509")
        } catch (e: Exception) {
            return certList
        }

        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val now = Date()

        for (certBytes in certBytesList) {
            try {
                val certs = certFactory.generateCertificates(ByteArrayInputStream(certBytes))
                for (c in certs) {
                    if (c is X509Certificate) {
                        val sha256 = computeHash(c.encoded, "SHA-256")
                        val sha1 = computeHash(c.encoded, "SHA-1")
                        val md5 = computeHash(c.encoded, "MD5")
                        val isExpired = now.before(c.notBefore) || now.after(c.notAfter)

                        certList.add(
                            CertificateInfo(
                                subject = c.subjectDN?.name ?: "Unknown Subject",
                                issuer = c.issuerDN?.name ?: "Unknown Issuer",
                                serialNumber = c.serialNumber?.toString(16) ?: "",
                                validFrom = dateFormat.format(c.notBefore),
                                validTo = dateFormat.format(c.notAfter),
                                sigAlgName = c.sigAlgName ?: "Unknown",
                                sha256Fingerprint = sha256,
                                sha1Fingerprint = sha1,
                                md5Fingerprint = md5,
                                isExpired = isExpired
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                // Ignore corrupt signature block
            }
        }
        return certList
    }

    private fun computeHash(bytes: ByteArray, algorithm: String): String {
        return try {
            val md = MessageDigest.getInstance(algorithm)
            val digest = md.digest(bytes)
            digest.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    private fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 -> "%.2f MB".format(bytes / (1024.0 * 1024.0))
            bytes >= 1024 -> "%.1f KB".format(bytes / 1024.0)
            else -> "$bytes B"
        }
    }

    private fun parseAccessFlags(flags: Int, isMethod: Boolean): List<String> {
        val list = mutableListOf<String>()
        if (flags and 0x0001 != 0) list.add("public")
        if (flags and 0x0002 != 0) list.add("private")
        if (flags and 0x0004 != 0) list.add("protected")
        if (flags and 0x0008 != 0) list.add("static")
        if (flags and 0x0010 != 0) list.add("final")
        if (flags and 0x0020 != 0) list.add(if (isMethod) "synchronized" else "super")
        if (flags and 0x0040 != 0) list.add(if (isMethod) "bridge" else "volatile")
        if (flags and 0x0080 != 0) list.add(if (isMethod) "varargs" else "transient")
        if (flags and 0x0100 != 0) list.add("native")
        if (flags and 0x0200 != 0) list.add("interface")
        if (flags and 0x0400 != 0) list.add("abstract")
        if (flags and 0x1000 != 0) list.add("synthetic")
        if (list.isEmpty()) list.add("package-private")
        return list
    }
}
