package com.example.core.analysis

import com.example.core.model.FeatureItem
import com.example.core.model.FeatureSeverity
import com.example.core.model.LibraryCategory
import com.example.core.model.LibraryInfo
import com.example.core.model.MethodInfo
import com.example.core.model.StringCategory
import com.example.core.model.StringItem

/**
 * String Intelligence Engine.
 * Categorizes extracted strings into domain categories.
 */
object StringIntelligenceEngine {

    private val IPV4_REGEX = Regex("""^(\d{1,3}\.){3}\d{1,3}(:\d+)?$""")
    private val EMAIL_REGEX = Regex("""^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$""")
    private val BASE64_REGEX = Regex("""^[A-Za-z0-9+/]{16,}={0,2}$""")

    fun categorizeString(value: String): StringCategory {
        val trimmed = value.trim()
        val lower = trimmed.lowercase()

        return when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") ||
                    trimmed.startsWith("ftp://") || trimmed.startsWith("ws://") || trimmed.startsWith("wss://") -> StringCategory.URLS
            IPV4_REGEX.matches(trimmed) -> StringCategory.IP_ADDRESSES
            EMAIL_REGEX.matches(trimmed) -> StringCategory.EMAILS
            trimmed.startsWith("AIzaSy") || trimmed.startsWith("AKIA") ||
                    trimmed.startsWith("sk_live_") || trimmed.startsWith("sk_test_") ||
                    trimmed.startsWith("ghp_") -> StringCategory.POSSIBLE_API_KEYS
            trimmed.startsWith("eyJh") || lower.startsWith("bearer ") ||
                    lower.contains("access_token") || lower.contains("jwt") ||
                    lower.contains("refresh_token") || lower.contains("oauth") -> StringCategory.POSSIBLE_TOKENS
            trimmed.startsWith("/v1/") || trimmed.startsWith("/v2/") || trimmed.startsWith("/v3/") ||
                    trimmed.startsWith("/api/") || trimmed.startsWith("/auth/") ||
                    trimmed.startsWith("/graphql") || trimmed.startsWith("/rest/") -> StringCategory.API_ENDPOINTS
            (trimmed.startsWith("/") || trimmed.startsWith("file://") || trimmed.startsWith("content://")) &&
                    (trimmed.contains(".json") || trimmed.contains(".xml") || trimmed.contains(".png") ||
                            trimmed.contains(".db") || trimmed.contains(".so") || trimmed.contains("/data/") ||
                            trimmed.contains("/system/")) -> StringCategory.FILE_PATHS
            (lower.endsWith(".com") || lower.endsWith(".org") || lower.endsWith(".net") ||
                    lower.endsWith(".io") || lower.endsWith(".app") || lower.endsWith(".dev")) &&
                    !trimmed.contains(" ") && trimmed.contains(".") -> StringCategory.DOMAINS
            trimmed.length >= 16 && trimmed.length % 4 == 0 && BASE64_REGEX.matches(trimmed) -> StringCategory.BASE64
            (trimmed.startsWith("{\"") || trimmed.startsWith("[\"") ||
                    (trimmed.startsWith("\"") && trimmed.endsWith("\""))) -> StringCategory.JSON_KEYS
            lower.contains("subscription") || lower.contains("billing") || lower.contains("inapp") ||
                    lower.contains("sku_") || lower.contains("purchased") || lower.contains("entitlement") ||
                    lower.contains("paywall") -> StringCategory.SUBSCRIPTION
            lower.contains("password") || lower.contains("credential") || lower.contains("login") ||
                    lower.contains("user_secret") -> StringCategory.AUTHENTICATION
            lower.contains("exception") || lower.contains("error:") || lower.contains("failed to") ||
                    lower.contains("invalid") || lower.contains("timeout") || lower.contains("nullpointer") -> StringCategory.ERROR_MESSAGES
            lower.contains("config") || lower.contains("setting") || lower.contains("enable_") ||
                    lower.contains("pref_") || lower.contains("app_id") || lower.contains("client_id") -> StringCategory.CONFIGURATION
            lower.contains("premium") || lower.contains("dark_mode") || lower.contains("pro_features") ||
                    lower.contains("vip_tier") || lower.contains("feature_") -> StringCategory.FEATURE_NAMES
            value.length in 3..60 && !value.contains(".") && !value.contains("_") && value.contains(" ") -> StringCategory.UI_TEXT
            else -> StringCategory.GENERAL
        }
    }
}

/**
 * Library & SDK Fingerprinting Detector.
 */
object LibraryDetector {

    data class KnownLibrary(
        val name: String,
        val packagePrefix: String,
        val category: LibraryCategory,
        val description: String
    )

    private val KNOWN_LIBRARIES = listOf(
        KnownLibrary("Google Play Billing", "com.android.vending.billing", LibraryCategory.BILLING, "Google Play In-app purchases & subscriptions"),
        KnownLibrary("RevenueCat SDK", "com.revenuecat.purchases", LibraryCategory.BILLING, "Subscription management and server-side receipts"),
        KnownLibrary("Google AdMob", "com.google.android.gms.ads", LibraryCategory.ADS, "Banner, interstitial and rewarded ads"),
        KnownLibrary("Unity Ads", "com.unity3d.ads", LibraryCategory.ADS, "Mobile game monetization SDK"),
        KnownLibrary("Firebase Analytics", "com.google.firebase.analytics", LibraryCategory.ANALYTICS, "Event telemetry and user audience insights"),
        KnownLibrary("Retrofit", "retrofit2", LibraryCategory.NETWORKING, "Type-safe HTTP client for Android & Kotlin"),
        KnownLibrary("OkHttp", "okhttp3", LibraryCategory.NETWORKING, "HTTP & HTTP/2 client engine"),
        KnownLibrary("Room Persistence", "androidx.room", LibraryCategory.DATABASE, "SQLite object mapping abstraction"),
        KnownLibrary("Firebase Firestore", "com.google.firebase.firestore", LibraryCategory.DATABASE, "NoSQL cloud real-time document database"),
        KnownLibrary("Firebase Auth", "com.google.firebase.auth", LibraryCategory.AUTHENTICATION, "Authentication and identity provider"),
        KnownLibrary("Coil", "coil", LibraryCategory.IMAGE_PROCESSING, "Kotlin Coroutines-backed image loader"),
        KnownLibrary("Glide", "com.bumptech.glide", LibraryCategory.IMAGE_PROCESSING, "Fast and efficient media management and image loading"),
        KnownLibrary("Dagger Hilt", "dagger.hilt", LibraryCategory.DEPENDENCY_INJECTION, "Android dependency injection framework")
    )

    fun detect(packageNames: List<String>): List<LibraryInfo> {
        val detected = mutableListOf<LibraryInfo>()
        for (lib in KNOWN_LIBRARIES) {
            val matchingCount = packageNames.count { it.startsWith(lib.packagePrefix) }
            if (matchingCount > 0) {
                detected.add(
                    LibraryInfo(
                        name = lib.name,
                        category = lib.category,
                        packageName = lib.packagePrefix,
                        classCount = matchingCount,
                        description = lib.description,
                        confidence = 100
                    )
                )
            }
        }
        return detected
    }
}

/**
 * Feature Scanner.
 * Automatically scans for important capabilities, security controls, and commercial features.
 */
object FeatureScanner {

    fun scan(
        methods: List<MethodInfo>,
        strings: List<StringItem>,
        libraries: List<LibraryInfo>
    ): List<FeatureItem> {
        val features = mutableListOf<FeatureItem>()

        // 1. In-App Purchases & Subscriptions
        val billingMethods = methods.filter {
            it.name.contains("billing", ignoreCase = true) ||
                    it.name.contains("purchase", ignoreCase = true) ||
                    it.name.contains("subscription", ignoreCase = true) ||
                    it.name.contains("entitlement", ignoreCase = true)
        }
        if (billingMethods.isNotEmpty() || libraries.any { it.category == LibraryCategory.BILLING }) {
            features.add(
                FeatureItem(
                    id = "feat_billing",
                    title = "In-App Purchases & Subscriptions",
                    category = "Monetization",
                    severity = FeatureSeverity.COMMERCIAL,
                    confidenceScore = 98,
                    description = "Detected Google Play Billing or subscription verification logic with active entitlement checks.",
                    evidenceMethods = billingMethods.take(4).map { "${it.className}.${it.name}()" },
                    evidenceStrings = strings.filter { it.category == StringCategory.SUBSCRIPTION }.take(3).map { it.value }
                )
            )
        }

        // 2. Authentication & User Sessions
        val authMethods = methods.filter {
            it.name.contains("login", ignoreCase = true) ||
                    it.name.contains("auth", ignoreCase = true) ||
                    it.name.contains("token", ignoreCase = true)
        }
        if (authMethods.isNotEmpty()) {
            features.add(
                FeatureItem(
                    id = "feat_auth",
                    title = "User Authentication & JWT Tokens",
                    category = "Security",
                    severity = FeatureSeverity.HIGH_INTEREST,
                    confidenceScore = 92,
                    description = "Contains dedicated token management, OAuth or credential verification flows.",
                    evidenceMethods = authMethods.take(4).map { "${it.className}.${it.name}()" },
                    evidenceStrings = strings.filter { it.category == StringCategory.AUTHENTICATION }.take(3).map { it.value }
                )
            )
        }

        // 3. Root / Jailbreak Detection
        val rootStrings = strings.filter {
            it.value.contains("/system/bin/su", ignoreCase = true) ||
                    it.value.contains("test-keys", ignoreCase = true) ||
                    it.value.contains("busybox", ignoreCase = true) ||
                    it.value.contains("magisk", ignoreCase = true)
        }
        if (rootStrings.isNotEmpty()) {
            features.add(
                FeatureItem(
                    id = "feat_root",
                    title = "Root & Environment Integrity Detection",
                    category = "Anti-Tamper",
                    severity = FeatureSeverity.SECURITY_SENSITIVE,
                    confidenceScore = 95,
                    description = "Contains anti-tampering heuristics inspecting superuser binaries, build tags, and hooked packages.",
                    evidenceStrings = rootStrings.take(3).map { it.value }
                )
            )
        }

        // 4. Remote API Endpoints & Networking
        val apiStrings = strings.filter { it.category == StringCategory.API_ENDPOINTS || it.category == StringCategory.URLS }
        if (apiStrings.isNotEmpty()) {
            features.add(
                FeatureItem(
                    id = "feat_network",
                    title = "REST / GraphQL Backend Integration",
                    category = "Network",
                    severity = FeatureSeverity.INFO,
                    confidenceScore = 90,
                    description = "Integrates external web services with configured HTTP endpoints and backend contracts.",
                    evidenceStrings = apiStrings.take(4).map { it.value }
                )
            )
        }

        return features
    }
}
