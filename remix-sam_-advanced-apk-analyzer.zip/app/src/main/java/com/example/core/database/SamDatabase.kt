package com.example.core.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val packageName: String,
    val versionName: String,
    val totalClasses: Int,
    val totalMethods: Int,
    val strongCount: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val targetType: String, // "METHOD", "CLASS", "STRING"
    val targetId: String,
    val title: String,
    val subtitle: String,
    val score: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: String,
    val title: String,
    val content: String,
    val targetId: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface SamDao {
    @Query("SELECT * FROM projects ORDER BY timestamp DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: String)

    @Query("DELETE FROM projects WHERE id LIKE 'sample_%' OR packageName = 'com.apex.media.player' OR packageName = 'com.cryptovault.vip'")
    suspend fun deleteSampleProjects()

    @Query("DELETE FROM projects")
    suspend fun deleteAllProjects()

    @Query("SELECT * FROM bookmarks WHERE projectId = :projectId ORDER BY timestamp DESC")
    fun getBookmarksForProject(projectId: String): Flow<List<BookmarkEntity>>

    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteBookmark(id: String)

    @Query("SELECT * FROM notes WHERE projectId = :projectId ORDER BY timestamp DESC")
    fun getNotesForProject(projectId: String): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)

    @Delete
    suspend fun deleteNote(note: NoteEntity)
}

@Database(
    entities = [ProjectEntity::class, BookmarkEntity::class, NoteEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SamDatabase : RoomDatabase() {
    abstract fun samDao(): SamDao

    companion object {
        @Volatile
        private var INSTANCE: SamDatabase? = null

        fun getDatabase(context: Context): SamDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SamDatabase::class.java,
                    "sam_analyzer.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
