package com.example.core.analysis

import com.example.core.model.ApkAnalysisResult
import com.example.core.model.DiffResult
import com.example.core.model.MethodInfo

/**
 * Call Graph representation and engine.
 */
data class CallGraphNode(
    val id: String,
    val title: String,
    val subtitle: String,
    val depth: Int,
    val isRoot: Boolean = false,
    val methodId: String = id
)

data class CallGraphEdge(
    val fromNodeId: String,
    val toNodeId: String,
    val label: String = "calls"
)

data class CallGraphData(
    val nodes: List<CallGraphNode>,
    val edges: List<CallGraphEdge>
)

object CallGraphEngine {

    fun buildCallGraph(selectedMethod: MethodInfo, allMethods: List<MethodInfo>): CallGraphData {
        val nodes = mutableListOf<CallGraphNode>()
        val edges = mutableListOf<CallGraphEdge>()

        // Root Node
        nodes.add(
            CallGraphNode(
                id = selectedMethod.id,
                title = "${selectedMethod.className.substringAfterLast('.')}.${selectedMethod.name}()",
                subtitle = "Target Method (${selectedMethod.returnType.displayName})",
                depth = 0,
                isRoot = true,
                methodId = selectedMethod.id
            )
        )

        // Add Callers (Inbound)
        for ((idx, caller) in selectedMethod.callers.withIndex()) {
            val callerId = "caller_$idx"
            nodes.add(
                CallGraphNode(
                    id = callerId,
                    title = caller.substringAfterLast('.'),
                    subtitle = "Caller #${idx + 1}",
                    depth = -1,
                    methodId = caller
                )
            )
            edges.add(CallGraphEdge(fromNodeId = callerId, toNodeId = selectedMethod.id, label = "invokes"))
        }

        // Add Callees (Outbound)
        for ((idx, callee) in selectedMethod.callees.withIndex()) {
            val calleeId = "callee_$idx"
            nodes.add(
                CallGraphNode(
                    id = calleeId,
                    title = callee.substringAfterLast('.'),
                    subtitle = "Callee #${idx + 1}",
                    depth = 1,
                    methodId = callee
                )
            )
            edges.add(CallGraphEdge(fromNodeId = selectedMethod.id, toNodeId = calleeId, label = "calls"))

            // Find sub-callees for depth 2 if available
            val subMethod = allMethods.firstOrNull { it.id.contains(callee) || it.name == callee.substringAfterLast('.').substringBefore('(') }
            if (subMethod != null && subMethod.callees.isNotEmpty()) {
                val subCallee = subMethod.callees.first()
                val subCalleeId = "subcallee_$idx"
                nodes.add(
                    CallGraphNode(
                        id = subCalleeId,
                        title = subCallee.substringAfterLast('.'),
                        subtitle = "Sub-Callee",
                        depth = 2,
                        methodId = subCallee
                    )
                )
                edges.add(CallGraphEdge(fromNodeId = calleeId, toNodeId = subCalleeId, label = "calls"))
            }
        }

        return CallGraphData(nodes, edges)
    }
}

/**
 * APK Comparison / Diff Engine.
 */
object DiffEngine {

    fun compare(apk1: ApkAnalysisResult, apk2: ApkAnalysisResult): DiffResult {
        val classes1 = apk1.classes.map { it.id }.toSet()
        val classes2 = apk2.classes.map { it.id }.toSet()
        val newClasses = (classes2 - classes1).toList()
        val removedClasses = (classes1 - classes2).toList()

        val methods1 = apk1.methods.map { it.id }.toSet()
        val methods2 = apk2.methods.map { it.id }.toSet()
        val newMethods = (methods2 - methods1).toList()
        val removedMethods = (methods1 - methods2).toList()

        // Check changed methods
        val commonMethodIds = methods1.intersect(methods2)
        val methodMap1 = apk1.methods.associateBy { it.id }
        val methodMap2 = apk2.methods.associateBy { it.id }
        val changedMethods = commonMethodIds.filter { id ->
            val m1 = methodMap1[id]
            val m2 = methodMap2[id]
            m1 != null && m2 != null && (m1.evidenceScore != m2.evidenceScore || m1.associatedStrings != m2.associatedStrings)
        }.toList()

        val strings1 = apk1.strings.map { it.value }.toSet()
        val strings2 = apk2.strings.map { it.value }.toSet()
        val newStrings = (strings2 - strings1).toList()
        val removedStrings = (strings1 - strings2).toList()

        val libs1 = apk1.libraries.map { it.name }.toSet()
        val libs2 = apk2.libraries.map { it.name }.toSet()
        val changedLibraries = (libs2 - libs1).map { "+ Added $it" } + (libs1 - libs2).map { "- Removed $it" }

        val manifestChanges = mutableListOf<String>()
        if (apk1.apkInfo.versionCode != apk2.apkInfo.versionCode) {
            manifestChanges.add("Version Code changed: ${apk1.apkInfo.versionCode} -> ${apk2.apkInfo.versionCode}")
        }
        if (apk1.apkInfo.targetSdk != apk2.apkInfo.targetSdk) {
            manifestChanges.add("Target SDK changed: ${apk1.apkInfo.targetSdk} -> ${apk2.apkInfo.targetSdk}")
        }
        val perms1 = apk1.manifest.permissions.map { it.name }.toSet()
        val perms2 = apk2.manifest.permissions.map { it.name }.toSet()
        val addedPerms = perms2 - perms1
        if (addedPerms.isNotEmpty()) {
            manifestChanges.add("New permissions: ${addedPerms.joinToString(", ")}")
        }

        return DiffResult(
            oldApkName = apk1.apkInfo.fileName,
            newApkName = apk2.apkInfo.fileName,
            newClasses = newClasses,
            removedClasses = removedClasses,
            newMethods = newMethods,
            removedMethods = removedMethods,
            changedMethods = changedMethods,
            newStrings = newStrings,
            removedStrings = removedStrings,
            changedLibraries = changedLibraries,
            manifestChanges = manifestChanges
        )
    }
}

/**
 * Report Generator: TXT, JSON, HTML, CSV.
 */
object ReportGenerator {

    fun generateTxt(result: ApkAnalysisResult): String {
        val sb = StringBuilder()
        sb.append("====================================================\n")
        sb.append("          SAM APK ANALYSIS REPORT\n")
        sb.append("====================================================\n\n")
        sb.append("File Name       : ${result.apkInfo.fileName}\n")
        sb.append("Package Name    : ${result.apkInfo.packageName}\n")
        sb.append("Version         : ${result.apkInfo.versionName} (${result.apkInfo.versionCode})\n")
        sb.append("Min / Target SDK: ${result.apkInfo.minSdk} / ${result.apkInfo.targetSdk}\n")
        sb.append("Total Classes   : ${result.apkInfo.totalClasses}\n")
        sb.append("Total Methods   : ${result.apkInfo.totalMethods}\n")
        sb.append("Total Strings   : ${result.apkInfo.totalStrings}\n\n")

        sb.append("----------------------------------------------------\n")
        sb.append("STRONG & MEDIUM EVIDENCE ENTITLEMENT METHODS:\n")
        sb.append("----------------------------------------------------\n")
        val highEvidence = result.methods.filter { it.evidenceScore >= 60 }.sortedByDescending { it.evidenceScore }
        for (m in highEvidence.take(20)) {
            sb.append("[${m.evidenceScore}% - ${m.evidenceLevel}] ${m.className}.${m.name}() -> ${m.returnType.displayName}\n")
            for (r in m.evidenceReasons) {
                sb.append("   * $r\n")
            }
        }

        sb.append("\n----------------------------------------------------\n")
        sb.append("DETECTED THIRD-PARTY LIBRARIES:\n")
        sb.append("----------------------------------------------------\n")
        for (lib in result.libraries) {
            sb.append("- ${lib.name} [${lib.category.name}] (${lib.classCount} classes)\n")
        }

        return sb.toString()
    }

    fun generateJson(result: ApkAnalysisResult): String {
        val sb = StringBuilder()
        sb.append("{\n")
        sb.append("  \"apkInfo\": {\n")
        sb.append("    \"fileName\": \"${result.apkInfo.fileName}\",\n")
        sb.append("    \"packageName\": \"${result.apkInfo.packageName}\",\n")
        sb.append("    \"versionCode\": ${result.apkInfo.versionCode},\n")
        sb.append("    \"totalClasses\": ${result.apkInfo.totalClasses},\n")
        sb.append("    \"totalMethods\": ${result.apkInfo.totalMethods}\n")
        sb.append("  },\n")
        sb.append("  \"strongEvidenceMethods\": [\n")
        val strong = result.methods.filter { it.evidenceScore >= 80 }.take(15)
        for ((idx, m) in strong.withIndex()) {
            sb.append("    {\n")
            sb.append("      \"id\": \"${m.id}\",\n")
            sb.append("      \"score\": ${m.evidenceScore},\n")
            sb.append("      \"returnType\": \"${m.returnType.displayName}\"\n")
            sb.append("    }${if (idx < strong.size - 1) "," else ""}\n")
        }
        sb.append("  ]\n")
        sb.append("}")
        return sb.toString()
    }

    fun generateHtml(result: ApkAnalysisResult): String {
        return """
            <!DOCTYPE html>
            <html dir="ltr" lang="en">
            <head>
                <meta charset="utf-8">
                <title>SAM Analysis: ${result.apkInfo.packageName}</title>
                <style>
                    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0b111e; color: #e2e8f0; margin: 24px; }
                    .header { background: #131f37; border: 1px solid #1e293b; border-radius: 12px; padding: 24px; margin-bottom: 24px; }
                    .title { font-size: 24px; font-weight: 700; color: #38bdf8; margin: 0 0 8px 0; }
                    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-top: 16px; }
                    .card { background: #1a2744; padding: 16px; border-radius: 8px; border-left: 4px solid #38bdf8; }
                    .card-num { font-size: 22px; font-weight: bold; color: #f8fafc; }
                    .badge-strong { background: #10b981; color: #fff; padding: 4px 8px; border-radius: 4px; font-size: 12px; }
                    .badge-medium { background: #f59e0b; color: #fff; padding: 4px 8px; border-radius: 4px; font-size: 12px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 20px; background: #131f37; border-radius: 8px; overflow: hidden; }
                    th, td { padding: 12px 16px; text-align: left; border-bottom: 1px solid #1e293b; }
                    th { background: #0f172a; color: #94a3b8; font-weight: 600; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1 class="title">SAM APK Inspection Report</h1>
                    <p>${result.apkInfo.fileName} • <strong>${result.apkInfo.packageName}</strong></p>
                    <div class="grid">
                        <div class="card"><div class="card-num">${result.apkInfo.totalClasses}</div><div>Total Classes</div></div>
                        <div class="card"><div class="card-num">${result.apkInfo.totalMethods}</div><div>Total Methods</div></div>
                        <div class="card"><div class="card-num">${result.apkInfo.totalStrings}</div><div>Total Strings</div></div>
                        <div class="card"><div class="card-num">${result.libraries.size}</div><div>Detected Libraries</div></div>
                    </div>
                </div>
                <h2>High-Evidence Methods</h2>
                <table>
                    <thead>
                        <tr><th>Score</th><th>Level</th><th>Method</th><th>Class</th><th>Return Type</th></tr>
                    </thead>
                    <tbody>
                        ${
            result.methods.filter { it.evidenceScore >= 60 }.take(25).joinToString("") { m ->
                val badge = if (m.evidenceScore >= 90) "badge-strong" else "badge-medium"
                "<tr><td><strong>${m.evidenceScore}%</strong></td><td><span class=\"$badge\">${m.evidenceLevel}</span></td><td>${m.name}()</td><td>${m.className}</td><td><code>${m.returnType.displayName}</code></td></tr>"
            }
        }
                    </tbody>
                </table>
            </body>
            </html>
        """.trimIndent()
    }

    fun generateCsv(result: ApkAnalysisResult): String {
        val sb = StringBuilder()
        sb.append("EvidenceScore,Level,MethodName,ClassName,PackageName,ReturnType,CallersCount,AssociatedStrings\n")
        for (m in result.methods) {
            val safeStrings = m.associatedStrings.joinToString(";").replace("\"", "\"\"")
            sb.append("${m.evidenceScore},\"${m.evidenceLevel}\",\"${m.name}\",\"${m.className}\",\"${m.packageName}\",\"${m.returnType.displayName}\",${m.callersCount},\"$safeStrings\"\n")
        }
        return sb.toString()
    }
}
