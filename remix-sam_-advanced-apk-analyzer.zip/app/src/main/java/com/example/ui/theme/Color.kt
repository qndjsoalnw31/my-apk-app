package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SAM Refined Modern Dark Palette
val CyanNeon = Color(0xFF38BDF8) // High-readability vibrant sky cyan (replaces harsh 00E5FF)
val ElectricBlue = Color(0xFF60A5FA) // Refined electric azure
val DeepNavyBackground = Color(0xFF0A0F1A) // Obsidian midnight canvas
val CardNavySurface = Color(0xFF111827) // Elevated slate surface
val SurfaceVariantDark = Color(0xFF1E293B) // Secondary surface
val BorderDark = Color(0xFF283548) // Subtle structural border

val EvidenceStrong = Color(0xFF10B981) // 90-100% Emerald
val EvidenceMedium = Color(0xFFF59E0B) // 60-89% Amber
val EvidenceWeak = Color(0xFF64748B)   // 0-59% Slate
val CriticalRed = Color(0xFFEF4444)    // Alert red
val VioletCode = Color(0xFFA78BFA)     // Violet accent

// Light Theme Palette (Crisp, high-contrast)
val CyanPrimaryLight = Color(0xFF0284C7)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)


