package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Brightness7
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import com.example.core.model.SearchMode
import com.example.core.model.SearchResult
import com.example.core.model.SearchTargetType
import com.example.core.model.TextSearchScope
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.ApkAnalysisResult
import com.example.core.model.ApkFileEntry
import com.example.core.model.CertificateInfo
import com.example.core.model.ClassInfo
import com.example.core.model.ComponentType
import com.example.core.model.DexFileInfo
import com.example.core.model.EvidenceLevel
import com.example.core.model.MethodInfo
import com.example.core.model.NativeLibraryInfo
import com.example.core.model.NetworkEndpoint
import com.example.core.model.PermissionInfo
import com.example.core.model.SecuritySeverity
import com.example.core.model.SecurityVulnerability
import com.example.core.model.StringItem
import com.example.ui.AppLanguage
import com.example.ui.SamStrings
import com.example.ui.SamTab
import com.example.ui.SamViewModel
import com.example.ui.components.AddNoteDialog
import com.example.ui.components.AiExplainerDialog
import com.example.ui.components.EvidenceBadge
import com.example.ui.components.InteractiveCallGraphView
import com.example.ui.components.MetricCard
import com.example.ui.components.PseudoCodeView
import com.example.ui.components.SyntaxHighlightedSmaliView
import com.example.ui.components.TypeBadge
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EvidenceMedium
import com.example.ui.theme.EvidenceStrong
import com.example.ui.theme.EvidenceWeak

@Composable
fun DashboardScreen(
    analysis: ApkAnalysisResult,
    viewModel: SamViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsState()
    val isDark by viewModel.isDarkMode.collectAsState()
    val lang by viewModel.appLanguage.collectAsState()
    val selectedClass by viewModel.selectedClass.collectAsState()
    val selectedMethod by viewModel.selectedMethod.collectAsState()
    val callGraphData by viewModel.callGraphData.collectAsState()
    val diffResult by viewModel.diffResult.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    val aiExplanation by viewModel.aiExplanation.collectAsState()
    val savedBookmarks by viewModel.savedBookmarks.collectAsState()
    val savedNotes by viewModel.savedNotes.collectAsState()

    var showNoteDialog by remember { mutableStateOf(false) }

    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        viewModel.showToast(SamStrings.copied(lang))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top App Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 4.dp
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                        modifier = Modifier.size(34.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Image(
                                painter = painterResource(id = R.drawable.img_sam_logo),
                                contentDescription = "SAM Logo",
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = analysis.apkInfo.appName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1
                        )
                        Text(
                            text = "${analysis.apkInfo.packageName} (v${analysis.apkInfo.versionName})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }

                    IconButton(onClick = { viewModel.toggleLanguage() }) {
                        Icon(imageVector = Icons.Default.Language, contentDescription = "Language", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { viewModel.toggleDarkMode() }) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.Brightness7 else Icons.Default.Brightness4,
                            contentDescription = "Theme",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Quick Metric Carousel
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        MetricCard(
                            title = "APK Health",
                            value = "${analysis.healthReport.overallHealthScore}%",
                            icon = Icons.Default.Verified,
                            color = CyanNeon,
                            onClick = { viewModel.setTab(SamTab.DASHBOARD) }
                        )
                    }
                    item {
                        MetricCard(
                            title = "Security Risk",
                            value = "${analysis.securityReport.overallRiskScore}%",
                            icon = Icons.Default.Security,
                            color = if (analysis.securityReport.overallRiskScore > 40) EvidenceWeak else CyanNeon,
                            onClick = { viewModel.setTab(SamTab.SECURITY) }
                        )
                    }
                    item {
                        MetricCard(
                            title = "DEX Files",
                            value = "${analysis.dexFiles.size.coerceAtLeast(analysis.apkInfo.totalDexCount)}",
                            icon = Icons.Default.FolderZip,
                            color = CyanNeon,
                            onClick = { viewModel.setTab(SamTab.DEX_FILES) }
                        )
                    }
                    item {
                        MetricCard(
                            title = "Classes",
                            value = "${analysis.apkInfo.totalClasses}",
                            icon = Icons.Default.AccountTree,
                            onClick = { viewModel.setTab(SamTab.CLASSES) }
                        )
                    }
                    item {
                        MetricCard(
                            title = "Methods",
                            value = "${analysis.apkInfo.totalMethods}",
                            icon = Icons.Default.Code,
                            onClick = { viewModel.setTab(SamTab.METHODS) }
                        )
                    }
                    item {
                        MetricCard(
                            title = "Native Libs",
                            value = "${analysis.nativeLibraries.size}",
                            icon = Icons.Default.Terminal,
                            onClick = { viewModel.setTab(SamTab.NATIVE_LIBS) }
                        )
                    }
                    item {
                        MetricCard(
                            title = "Strings",
                            value = "${analysis.apkInfo.totalStrings}",
                            icon = Icons.Default.Description,
                            onClick = { viewModel.setTab(SamTab.STRINGS) }
                        )
                    }
                    item {
                        MetricCard(
                            title = "Obfuscation",
                            value = "${analysis.obfuscationReport.score}%",
                            icon = Icons.Default.Hub,
                            color = ElectricBlue,
                            onClick = { viewModel.setTab(SamTab.OBFUSCATION) }
                        )
                    }
                }

                // 16 Core + Auxiliary Tabs
                ScrollableTabRow(
                    selectedTabIndex = currentTab.ordinal,
                    edgePadding = 12.dp,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    SamTab.values().forEach { tab ->
                        Tab(
                            selected = currentTab == tab,
                            onClick = { viewModel.setTab(tab) },
                            text = {
                                val label = when (tab) {
                                    SamTab.DASHBOARD -> SamStrings.tabOverview(lang)
                                    SamTab.APK_INFO -> SamStrings.tabApkInfo(lang)
                                    SamTab.MANIFEST -> SamStrings.tabManifest(lang)
                                    SamTab.DEX_FILES -> SamStrings.tabDex(lang)
                                    SamTab.CLASSES -> SamStrings.tabClasses(lang)
                                    SamTab.METHODS -> SamStrings.tabMethods(lang)
                                    SamTab.STRINGS -> SamStrings.tabStrings(lang)
                                    SamTab.PERMISSIONS -> SamStrings.tabPermissions(lang)
                                    SamTab.SECURITY -> SamStrings.tabSecurity(lang)
                                    SamTab.NETWORK -> SamStrings.tabNetwork(lang)
                                    SamTab.OBFUSCATION -> SamStrings.tabObfuscation(lang)
                                    SamTab.CALL_GRAPH -> SamStrings.tabCallGraph(lang)
                                    SamTab.CONTROL_FLOW -> SamStrings.tabControlFlow(lang)
                                    SamTab.NATIVE_LIBS -> SamStrings.tabNativeLibs(lang)
                                    SamTab.FILES -> SamStrings.tabFiles(lang)
                                    SamTab.CERTIFICATES -> SamStrings.tabCertificates(lang)
                                    SamTab.SEARCH -> SamStrings.tabSearch(lang)
                                    SamTab.DIFF -> SamStrings.tabDiff(lang)
                                    SamTab.FEATURE_MAP -> SamStrings.tabFeatureMap(lang)
                                    SamTab.REPORTS -> SamStrings.tabReports(lang)
                                    SamTab.WORKSPACE -> SamStrings.tabWorkspace(lang)
                                }
                                Text(
                                    text = label,
                                    fontWeight = if (currentTab == tab) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        )
                    }
                }
            }
        }

        // Active Tab Screen
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            when (currentTab) {
                SamTab.DASHBOARD -> DashboardTabView(
                    analysis = analysis,
                    onNavigate = { viewModel.setTab(it) },
                    onSelectMethod = {
                        viewModel.selectMethod(it)
                        viewModel.setTab(SamTab.METHODS)
                    }
                )

                SamTab.APK_INFO -> ApkInfoTabView(
                    analysis = analysis,
                    onCopy = { copyToClipboard("APK Info", it) }
                )

                SamTab.MANIFEST -> ManifestTabView(
                    manifest = analysis.manifest,
                    onCopy = { copyToClipboard("Manifest", it) }
                )

                SamTab.DEX_FILES -> DexFilesTabView(
                    dexFiles = analysis.dexFiles,
                    onCopy = { copyToClipboard("DEX Info", it) }
                )

                SamTab.CLASSES -> ClassesTabView(
                    classes = analysis.classes,
                    selectedClass = selectedClass,
                    onSelect = { viewModel.selectClass(it) },
                    onMethodSelect = {
                        viewModel.selectMethod(it)
                        viewModel.setTab(SamTab.METHODS)
                    }
                )

                SamTab.METHODS -> MethodsTabView(
                    methods = analysis.methods,
                    selectedMethod = selectedMethod,
                    onSelect = { viewModel.selectMethod(it) },
                    onExplainAi = { viewModel.explainCurrentMethodWithAi() },
                    onBookmark = { viewModel.toggleBookmarkCurrentMethod() },
                    onAddNote = { showNoteDialog = true },
                    onCopy = { copyToClipboard("Method Info", it) },
                    onOpenCallGraph = { viewModel.setTab(SamTab.CALL_GRAPH) },
                    onOpenControlFlow = { viewModel.setTab(SamTab.CONTROL_FLOW) }
                )

                SamTab.STRINGS -> StringsTabView(
                    strings = analysis.strings,
                    onCopy = { copyToClipboard("String", it) }
                )

                SamTab.PERMISSIONS -> PermissionsTabView(
                    permissions = analysis.manifest.permissions,
                    onCopy = { copyToClipboard("Permission", it) }
                )

                SamTab.SECURITY -> SecurityTabView(
                    security = analysis.securityReport,
                    onCopy = { copyToClipboard("Security Finding", it) }
                )

                SamTab.NETWORK -> NetworkTabView(
                    network = analysis.networkReport,
                    onSelectMethod = {
                        viewModel.selectMethod(it)
                        viewModel.setTab(SamTab.METHODS)
                    },
                    allMethods = analysis.methods
                )

                SamTab.OBFUSCATION -> ObfuscationTabView(
                    obfuscation = analysis.obfuscationReport
                )

                SamTab.CALL_GRAPH -> CallGraphTabView(
                    data = callGraphData,
                    onNodeClick = { node ->
                        val target = analysis.methods.firstOrNull { it.id == node.methodId }
                        if (target != null) {
                            viewModel.selectMethod(target)
                        }
                    }
                )

                SamTab.CONTROL_FLOW -> ControlFlowTabView(
                    method = selectedMethod ?: analysis.methods.firstOrNull { it.rawInstructions.isNotEmpty() },
                    onCopy = { copyToClipboard("CFG Block", it) }
                )

                SamTab.NATIVE_LIBS -> NativeLibsTabView(
                    nativeLibs = analysis.nativeLibraries,
                    onCopy = { copyToClipboard("Native Lib", it) }
                )

                SamTab.FILES -> FilesTabView(
                    files = analysis.apkFiles,
                    onCopy = { copyToClipboard("File Path", it) }
                )

                SamTab.CERTIFICATES -> CertificatesTabView(
                    certificates = analysis.certificates,
                    onCopy = { copyToClipboard("Certificate Info", it) }
                )

                SamTab.SEARCH -> SearchTabView(
                    viewModel = viewModel,
                    onSelectMethod = {
                        viewModel.selectMethod(it)
                        viewModel.setTab(SamTab.METHODS)
                    },
                    onSelectClass = {
                        viewModel.selectClass(it)
                        viewModel.setTab(SamTab.CLASSES)
                    },
                    onCopy = { copyToClipboard("Search Match", it) },
                    lang = lang
                )

                SamTab.DIFF -> DiffTabView(
                    diffResult = diffResult,
                    onCopy = { copyToClipboard("Diff", it) }
                )

                SamTab.FEATURE_MAP -> FeatureMapTabView(
                    groups = analysis.featureMapGroups,
                    allMethods = analysis.methods,
                    onSelectMethod = {
                        viewModel.selectMethod(it)
                        viewModel.setTab(SamTab.METHODS)
                    }
                )

                SamTab.REPORTS -> ReportsTabView(onExport = { format ->
                    val reportText = viewModel.exportReport(format)
                    copyToClipboard("SAM Report ($format)", reportText)
                })

                SamTab.WORKSPACE -> WorkspaceTabView(
                    bookmarks = savedBookmarks,
                    notes = savedNotes,
                    onAddNote = { showNoteDialog = true },
                    onDeleteNote = { viewModel.deleteNote(it) }
                )
            }
        }
    }

    // AI Explainer Dialog
    if (isAiLoading || !aiExplanation.isNullOrBlank()) {
        AiExplainerDialog(
            isLoading = isAiLoading,
            explanation = aiExplanation,
            onDismiss = { viewModel.dismissAiDialog() },
            onCopy = {
                aiExplanation?.let { copyToClipboard("AI Explanation", it) }
            }
        )
    }

    // Add Note Dialog
    if (showNoteDialog) {
        AddNoteDialog(
            onDismiss = { showNoteDialog = false },
            onSave = { t, c ->
                viewModel.addNote(t, c)
                showNoteDialog = false
            }
        )
    }
}

// -------------------------------------------------------------
// 1. DASHBOARD TAB
// -------------------------------------------------------------
@Composable
private fun DashboardTabView(
    analysis: ApkAnalysisResult,
    onNavigate: (SamTab) -> Unit,
    onSelectMethod: (MethodInfo) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // App Summary Banner
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = CircleShape, color = CyanNeon.copy(alpha = 0.15f), modifier = Modifier.size(44.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = CyanNeon)
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = analysis.apkInfo.appName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(text = analysis.apkInfo.packageName, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (analysis.securityReport.overallRiskScore > 50) Color(0xFFEF4444).copy(alpha = 0.2f) else CyanNeon.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = if (analysis.securityReport.overallRiskScore > 50) "HIGH RISK" else "SECURE",
                            color = if (analysis.securityReport.overallRiskScore > 50) Color(0xFFEF4444) else CyanNeon,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Version: ${analysis.apkInfo.versionName} (${analysis.apkInfo.versionCode})", fontSize = 13.sp)
                        Text("File Size: ${analysis.apkInfo.fileSizeFormatted}", fontSize = 13.sp)
                        Text("Min SDK: ${analysis.apkInfo.minSdk} • Target: ${analysis.apkInfo.targetSdk}", fontSize = 13.sp)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("DEX Files: ${analysis.dexFiles.size.coerceAtLeast(analysis.apkInfo.totalDexCount)}", fontSize = 13.sp)
                        Text("Classes: ${analysis.apkInfo.totalClasses}", fontSize = 13.sp)
                        Text("Methods: ${analysis.apkInfo.totalMethods}", fontSize = 13.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Navigation Grid
        Text(text = "Quick Inspection Panels", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onNavigate(SamTab.APK_INFO) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(8.dp)) {
                Text("APK Info", fontSize = 12.sp)
            }
            Button(onClick = { onNavigate(SamTab.DEX_FILES) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(8.dp)) {
                Text("DEX Bytecode", fontSize = 12.sp)
            }
            Button(onClick = { onNavigate(SamTab.SECURITY) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(8.dp)) {
                Text("Security (${analysis.securityReport.vulnerabilities.size})", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onNavigate(SamTab.MANIFEST) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(8.dp)) {
                Text("Manifest", fontSize = 12.sp)
            }
            Button(onClick = { onNavigate(SamTab.NATIVE_LIBS) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(8.dp)) {
                Text("Native Libs (${analysis.nativeLibraries.size})", fontSize = 12.sp)
            }
            Button(onClick = { onNavigate(SamTab.CERTIFICATES) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(8.dp)) {
                Text("Certificates (${analysis.certificates.size})", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // High Evidence Methods List
        Text(text = "Highest Evidence Methods in Bytecode", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(6.dp))

        val topMethods = analysis.methods.sortedByDescending { it.evidenceScore }.take(8)
        for (m in topMethods) {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clickable { onSelectMethod(m) }
            ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    TypeBadge(category = m.returnType.category, displayName = m.returnType.displayName)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${m.name}()", fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        Text(text = m.className, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    EvidenceBadge(score = m.evidenceScore, level = m.evidenceLevel)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 2. APK INFO TAB
// -------------------------------------------------------------
@Composable
private fun ApkInfoTabView(
    analysis: ApkAnalysisResult,
    onCopy: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Application Metadata", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CyanNeon)
                Spacer(modifier = Modifier.height(10.dp))

                InfoRow(label = "Application Name", value = analysis.apkInfo.appName, onCopy = onCopy)
                InfoRow(label = "Package Name", value = analysis.apkInfo.packageName, onCopy = onCopy)
                InfoRow(label = "Version Name", value = analysis.apkInfo.versionName, onCopy = onCopy)
                InfoRow(label = "Version Code", value = analysis.apkInfo.versionCode.toString(), onCopy = onCopy)
                InfoRow(label = "Min SDK Version", value = analysis.apkInfo.minSdk.toString(), onCopy = onCopy)
                InfoRow(label = "Target SDK Version", value = analysis.apkInfo.targetSdk.toString(), onCopy = onCopy)
                analysis.manifest.compileSdk?.let {
                    InfoRow(label = "Compile SDK Version", value = it.toString(), onCopy = onCopy)
                }
                analysis.manifest.applicationProcess?.let {
                    InfoRow(label = "Application Process", value = it, onCopy = onCopy, isMonospace = true)
                }
                InfoRow(label = "File Size", value = "${analysis.apkInfo.fileSizeFormatted} (${analysis.apkInfo.fileSizeBytes} bytes)", onCopy = onCopy)
                InfoRow(label = "Debuggable", value = if (analysis.apkInfo.isDebuggable) "YES (Insecure)" else "NO", onCopy = onCopy)
                InfoRow(label = "Allow Backup", value = if (analysis.manifest.allowBackup) "YES" else "NO", onCopy = onCopy)
                InfoRow(label = "Uses Cleartext Traffic", value = if (analysis.manifest.usesCleartextTraffic) "YES (Insecure HTTP)" else "NO", onCopy = onCopy)
                analysis.manifest.networkSecurityConfig?.let {
                    InfoRow(label = "Network Security Config", value = it, onCopy = onCopy, isMonospace = true)
                }
                if (analysis.apkInfo.signatureSchemes.isNotEmpty()) {
                    InfoRow(label = "Signature Schemes", value = analysis.apkInfo.signatureSchemes.joinToString(", "), onCopy = onCopy)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Bytecode & Architecture Statistics", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CyanNeon)
                Spacer(modifier = Modifier.height(10.dp))

                InfoRow(label = "Total DEX Files", value = "${analysis.dexFiles.size.coerceAtLeast(analysis.apkInfo.totalDexCount)}", onCopy = onCopy)
                InfoRow(label = "Total Classes", value = "${analysis.apkInfo.totalClasses}", onCopy = onCopy)
                InfoRow(label = "Total Methods", value = "${analysis.apkInfo.totalMethods}", onCopy = onCopy)
                InfoRow(label = "Total Fields", value = "${analysis.apkInfo.totalFields}", onCopy = onCopy)
                InfoRow(label = "Total Strings", value = "${analysis.apkInfo.totalStrings}", onCopy = onCopy)
                InfoRow(label = "Native Libraries (.so)", value = "${analysis.nativeLibraries.size}", onCopy = onCopy)
                InfoRow(label = "Total Archive Files", value = "${analysis.apkFiles.size}", onCopy = onCopy)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Cryptographic Checksums & Fingerprints", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CyanNeon)
                Spacer(modifier = Modifier.height(10.dp))

                InfoRow(label = "APK SHA-256 Hash", value = analysis.apkInfo.sha256Hash.ifEmpty { "Not calculated" }, onCopy = onCopy, isMonospace = true)
                InfoRow(label = "APK MD5 Hash", value = analysis.apkInfo.md5Hash.ifEmpty { "Not calculated" }, onCopy = onCopy, isMonospace = true)
                InfoRow(label = "Certificate Digest (SHA-256)", value = analysis.apkInfo.certificateDigest.ifEmpty { "N/A" }, onCopy = onCopy, isMonospace = true)
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String, onCopy: (String) -> Unit, isMonospace: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.4f))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            modifier = Modifier.weight(0.6f)
        )
        IconButton(onClick = { onCopy(value) }, modifier = Modifier.size(24.dp)) {
            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(14.dp), tint = CyanNeon)
        }
    }
}

// -------------------------------------------------------------
// 3. MANIFEST TAB
// -------------------------------------------------------------
@Composable
private fun ManifestTabView(
    manifest: com.example.core.model.ManifestInfo,
    onCopy: (String) -> Unit
) {
    var selectedFilter by remember { mutableStateOf<ComponentType?>(null) }
    val filtered = if (selectedFilter == null) manifest.components else manifest.components.filter { it.type == selectedFilter }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CategoryChip(label = "ALL (${manifest.components.size})", isSelected = selectedFilter == null, onClick = { selectedFilter = null })
            CategoryChip(label = "ACTIVITIES (${manifest.components.count { it.type == ComponentType.ACTIVITY }})", isSelected = selectedFilter == ComponentType.ACTIVITY, onClick = { selectedFilter = ComponentType.ACTIVITY })
            CategoryChip(label = "SERVICES (${manifest.components.count { it.type == ComponentType.SERVICE }})", isSelected = selectedFilter == ComponentType.SERVICE, onClick = { selectedFilter = ComponentType.SERVICE })
            CategoryChip(label = "RECEIVERS (${manifest.components.count { it.type == ComponentType.RECEIVER }})", isSelected = selectedFilter == ComponentType.RECEIVER, onClick = { selectedFilter = ComponentType.RECEIVER })
            CategoryChip(label = "PROVIDERS (${manifest.components.count { it.type == ComponentType.PROVIDER }})", isSelected = selectedFilter == ComponentType.PROVIDER, onClick = { selectedFilter = ComponentType.PROVIDER })
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filtered) { comp ->
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = when (comp.type) {
                                    ComponentType.ACTIVITY -> CyanNeon.copy(alpha = 0.15f)
                                    ComponentType.SERVICE -> ElectricBlue.copy(alpha = 0.15f)
                                    ComponentType.RECEIVER -> Color(0xFFF59E0B).copy(alpha = 0.15f)
                                    ComponentType.PROVIDER -> Color(0xFF10B981).copy(alpha = 0.15f)
                                }
                            ) {
                                Text(
                                    text = comp.type.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = when (comp.type) {
                                        ComponentType.ACTIVITY -> CyanNeon
                                        ComponentType.SERVICE -> ElectricBlue
                                        ComponentType.RECEIVER -> Color(0xFFF59E0B)
                                        ComponentType.PROVIDER -> Color(0xFF10B981)
                                    },
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = comp.name.substringAfterLast('.'),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            if (comp.isExported) {
                                Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFFEF4444).copy(alpha = 0.2f)) {
                                    Text("EXPORTED", color = Color(0xFFEF4444), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = comp.name, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        if (!comp.permission.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Enforced Permission: ${comp.permission}", fontSize = 11.sp, color = CyanNeon)
                        }

                        if (!comp.process.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Process: ${comp.process}", fontSize = 11.sp, color = ElectricBlue, fontFamily = FontFamily.Monospace)
                        }

                        if (comp.intentFilters.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Intent Actions: ${comp.intentFilters.joinToString(", ")}", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 4. DEX FILES TAB
// -------------------------------------------------------------
@Composable
private fun DexFilesTabView(
    dexFiles: List<DexFileInfo>,
    onCopy: (String) -> Unit
) {
    if (dexFiles.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No DEX file breakdown available.")
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(dexFiles) { dex ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.FolderZip, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = dex.fileName, fontWeight = FontWeight.Bold, fontSize = 16.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.weight(1f))
                        Text(text = dex.formattedSize, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CyanNeon)
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Classes: ${dex.classCount}", fontSize = 13.sp)
                            Text("Methods: ${dex.methodCount}", fontSize = 13.sp)
                            Text("Fields: ${dex.fieldCount}", fontSize = 13.sp)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Strings: ${dex.stringCount}", fontSize = 13.sp)
                            Text("Type IDs: ${dex.typeCount}", fontSize = 13.sp)
                            Text("Proto IDs: ${dex.protoCount}", fontSize = 13.sp)
                        }
                    }

                    if (dex.sha1Hash.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "SHA-1: ${dex.sha1Hash}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                            IconButton(onClick = { onCopy(dex.sha1Hash) }, modifier = Modifier.size(20.dp)) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(14.dp), tint = CyanNeon)
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 5. CLASSES TAB
// -------------------------------------------------------------
@Composable
private fun ClassesTabView(
    classes: List<ClassInfo>,
    selectedClass: ClassInfo?,
    onSelect: (ClassInfo) -> Unit,
    onMethodSelect: (MethodInfo) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = classes.filter {
        it.simpleName.contains(searchQuery, ignoreCase = true) || it.packageName.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Filter classes by name or package...") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filtered) { clazz ->
                val isSelected = clazz.id == selectedClass?.id
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) CyanNeon.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onSelect(clazz) }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = clazz.simpleName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (isSelected) CyanNeon else MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            if (clazz.accessFlags.isNotEmpty()) {
                                Text(
                                    text = clazz.accessFlags.joinToString(" "),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.Gray
                                )
                            }
                        }
                        Text(
                            text = clazz.packageName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontFamily = FontFamily.Monospace
                        )

                        if (isSelected) {
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "Superclass: ${clazz.superClassName}", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            if (clazz.interfaces.isNotEmpty()) {
                                Text(text = "Interfaces: ${clazz.interfaces.joinToString(", ")}", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text(text = "Fields: ${clazz.fields.size} • Methods: ${clazz.methods.size}", fontSize = 12.sp)

                            if (clazz.methods.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "Methods:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                for (m in clazz.methods.take(6)) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp)
                                            .clickable { onMethodSelect(m) }
                                    ) {
                                        Text(
                                            text = "• ${m.name}(): ${m.returnType.displayName}",
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.padding(6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 6. METHODS TAB
// -------------------------------------------------------------
@Composable
private fun MethodsTabView(
    methods: List<MethodInfo>,
    selectedMethod: MethodInfo?,
    onSelect: (MethodInfo) -> Unit,
    onExplainAi: () -> Unit,
    onBookmark: () -> Unit,
    onAddNote: () -> Unit,
    onCopy: (String) -> Unit,
    onOpenCallGraph: () -> Unit,
    onOpenControlFlow: () -> Unit
) {
    var searchMethod by remember { mutableStateOf("") }
    var methodViewSubTab by remember { mutableStateOf(0) } // 0: Smali, 1: PseudoCode, 2: Bytecode Instructions
    val filtered = methods.filter {
        it.name.contains(searchMethod, ignoreCase = true) || it.className.contains(searchMethod, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchMethod,
            onValueChange = { searchMethod = it },
            placeholder = { Text("Filter methods by name or class...") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Selected Method Inspector Card
        if (selectedMethod != null) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyanNeon, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TypeBadge(category = selectedMethod.returnType.category, displayName = selectedMethod.returnType.displayName)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${selectedMethod.className.substringAfterLast('.')}.${selectedMethod.name}()",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        EvidenceBadge(score = selectedMethod.evidenceScore, level = selectedMethod.evidenceLevel)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = selectedMethod.className,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Registers: ${selectedMethod.registersCount}", fontSize = 12.sp, color = CyanNeon)
                        Text("Callers: ${selectedMethod.callersCount}", fontSize = 12.sp, color = ElectricBlue)
                        Text("Callees: ${selectedMethod.callees.size}", fontSize = 12.sp, color = Color(0xFF10B981))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = onExplainAi,
                            colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = Color.Black),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Explain", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onOpenCallGraph,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Hub, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Callers", fontSize = 11.sp)
                        }
                        Button(
                            onClick = onOpenControlFlow,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.AccountTree, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("CFG", fontSize = 11.sp)
                        }
                        IconButton(onClick = onBookmark) {
                            Icon(imageVector = Icons.Default.Bookmark, contentDescription = "Bookmark", tint = CyanNeon)
                        }
                        IconButton(onClick = onAddNote) {
                            Icon(imageVector = Icons.Default.Notes, contentDescription = "Add Note", tint = ElectricBlue)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Bytecode Sub-Tab Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CategoryChip(label = "Smali Code", isSelected = methodViewSubTab == 0, onClick = { methodViewSubTab = 0 })
                        CategoryChip(label = "Decompiled Code", isSelected = methodViewSubTab == 1, onClick = { methodViewSubTab = 1 })
                        CategoryChip(label = "Raw Bytecode (${selectedMethod.rawInstructions.size})", isSelected = methodViewSubTab == 2, onClick = { methodViewSubTab = 2 })
                        if (selectedMethod.tryCatches.isNotEmpty()) {
                            CategoryChip(label = "Try/Catch (${selectedMethod.tryCatches.size})", isSelected = methodViewSubTab == 3, onClick = { methodViewSubTab = 3 })
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    when (methodViewSubTab) {
                        0 -> SyntaxHighlightedSmaliView(
                            code = selectedMethod.smaliCode,
                            onCopy = { onCopy(selectedMethod.smaliCode) },
                            modifier = Modifier.height(200.dp)
                        )
                        1 -> PseudoCodeView(
                            code = selectedMethod.decompiledPseudoCode,
                            onCopy = { onCopy(selectedMethod.decompiledPseudoCode) },
                            modifier = Modifier.height(200.dp)
                        )
                        2 -> {
                            LazyColumn(modifier = Modifier.height(200.dp)) {
                                items(selectedMethod.rawInstructions) { inst ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = inst.offsetHex, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = CyanNeon, modifier = Modifier.width(50.dp))
                                        Text(text = inst.mnemonic, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.width(110.dp))
                                        Text(text = inst.toSmali(), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFF94A3B8), modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                        3 -> {
                            LazyColumn(modifier = Modifier.height(200.dp)) {
                                items(selectedMethod.tryCatches) { tc ->
                                    Card(
                                        shape = RoundedCornerShape(6.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(8.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(shape = RoundedCornerShape(3.dp), color = Color(0xFFF59E0B).copy(alpha = 0.2f)) {
                                                    Text("CATCH", color = Color(0xFFF59E0B), fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(text = tc.handlerType ?: "finally (all)", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = CyanNeon)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Range: 0x${tc.startAddr.toString(16).padStart(4, '0')} .. 0x${tc.endAddr.toString(16).padStart(4, '0')} -> Target: 0x${tc.targetAddr.toString(16).padStart(4, '0')}",
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Methods List
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filtered) { m ->
                val isSelected = m.id == selectedMethod?.id
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) CyanNeon.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clickable { onSelect(m) }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TypeBadge(category = m.returnType.category, displayName = m.returnType.displayName)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${m.className.substringAfterLast('.')}.${m.name}()",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Callers: ${m.callersCount} • Callees: ${m.callees.size} • Regs: ${m.registersCount}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        EvidenceBadge(score = m.evidenceScore, level = m.evidenceLevel)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 7. STRINGS TAB
// -------------------------------------------------------------
@Composable
private fun StringsTabView(
    strings: List<StringItem>,
    onCopy: (String) -> Unit
) {
    var searchStr by remember { mutableStateOf("") }
    val filtered = strings.filter { it.value.contains(searchStr, ignoreCase = true) }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchStr,
            onValueChange = { searchStr = it },
            placeholder = { Text("Filter strings in APK string pool...") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filtered) { item ->
                var expanded by remember { mutableStateOf(false) }
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = CyanNeon.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = item.category.name,
                                    color = CyanNeon,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = item.value,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                            if (item.usages.isNotEmpty() || item.foundInClasses.isNotEmpty()) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = CyanNeon.copy(alpha = 0.15f),
                                    modifier = Modifier.clickable { expanded = !expanded }
                                ) {
                                    Text(
                                        text = if (expanded) "▲ Ref" else "▼ Ref",
                                        fontSize = 10.sp,
                                        color = CyanNeon,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            IconButton(onClick = { onCopy(item.value) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyanNeon, modifier = Modifier.size(16.dp))
                            }
                        }

                        if (expanded && (item.usages.isNotEmpty() || item.foundInClasses.isNotEmpty())) {
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Cross-References (${item.usages.size.coerceAtLeast(item.foundInClasses.size)} locations):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            if (item.usages.isNotEmpty()) {
                                for (usage in item.usages.take(6)) {
                                    Text(
                                        text = "• ${usage.className}->${usage.methodName}() [${usage.dexOffset}]",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            } else {
                                for (cls in item.foundInClasses.take(4)) {
                                    Text(
                                        text = "• $cls",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 8. PERMISSIONS TAB
// -------------------------------------------------------------
@Composable
private fun PermissionsTabView(
    permissions: List<PermissionInfo>,
    onCopy: (String) -> Unit
) {
    if (permissions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No permissions declared in AndroidManifest.xml.")
        }
        return
    }

    val dangerous = permissions.filter { it.isDangerous }
    val normal = permissions.filter { !it.isDangerous }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        if (dangerous.isNotEmpty()) {
            Text(text = "Dangerous Permissions (${dangerous.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFFEF4444))
            Spacer(modifier = Modifier.height(6.dp))
            for (p in dangerous) {
                PermissionCard(perm = p, isDangerous = true, onCopy = onCopy)
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (normal.isNotEmpty()) {
            Text(text = "Normal Permissions (${normal.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CyanNeon)
            Spacer(modifier = Modifier.height(6.dp))
            for (p in normal) {
                PermissionCard(perm = p, isDangerous = false, onCopy = onCopy)
            }
        }
    }
}

@Composable
private fun PermissionCard(perm: PermissionInfo, isDangerous: Boolean, onCopy: (String) -> Unit) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isDangerous) Icons.Default.Warning else Icons.Default.CheckCircle,
                contentDescription = null,
                tint = if (isDangerous) Color(0xFFEF4444) else CyanNeon,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = perm.name.substringAfterLast('.'), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = perm.name, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (perm.description.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = perm.description, fontSize = 11.sp, color = Color.Gray)
                }
            }
            IconButton(onClick = { onCopy(perm.name) }) {
                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyanNeon, modifier = Modifier.size(16.dp))
            }
        }
    }
}

// -------------------------------------------------------------
// 9. SECURITY TAB
// -------------------------------------------------------------
@Composable
private fun SecurityTabView(
    security: com.example.core.model.SecurityAuditReport,
    onCopy: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Overall Security Score Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = if (security.overallRiskScore > 40) Color(0xFFEF4444).copy(alpha = 0.2f) else CyanNeon.copy(alpha = 0.2f),
                    modifier = Modifier.size(54.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "${security.overallRiskScore}%",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = if (security.overallRiskScore > 40) Color(0xFFEF4444) else CyanNeon
                        )
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(text = "Security Risk Assessment", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        text = "${security.vulnerabilities.size} vulnerabilities audited directly in DEX bytecode & Manifest.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text(text = "Security Vulnerability Findings", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(8.dp))

        if (security.vulnerabilities.isEmpty()) {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                    Text("No critical security vulnerabilities found in bytecode or manifest.", color = Color(0xFF10B981))
                }
            }
        } else {
            for (vuln in security.vulnerabilities) {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = when (vuln.severity) {
                                    SecuritySeverity.CRITICAL -> Color(0xFFEF4444)
                                    SecuritySeverity.HIGH -> Color(0xFFF97316)
                                    SecuritySeverity.MEDIUM -> Color(0xFFF59E0B)
                                    SecuritySeverity.LOW -> Color(0xFF3B82F6)
                                    SecuritySeverity.INFO -> Color(0xFF6B7280)
                                }
                            ) {
                                Text(
                                    text = vuln.severity.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = vuln.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.weight(1f))
                            IconButton(onClick = { onCopy("${vuln.title}\n${vuln.description}") }) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyanNeon, modifier = Modifier.size(16.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = vuln.description, style = MaterialTheme.typography.bodySmall)

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "Affected: ${vuln.affectedComponent}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = CyanNeon)
                        if (!vuln.evidenceCode.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(3.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "Evidence: ${vuln.evidenceCode}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = Color(0xFFF97316),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(text = "Remediation: ${vuln.recommendation}", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 10. NETWORK TAB
// -------------------------------------------------------------
@Composable
private fun NetworkTabView(
    network: com.example.core.model.NetworkAuditReport,
    onSelectMethod: (MethodInfo) -> Unit,
    allMethods: List<MethodInfo>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Summary Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Network Endpoints & Cleartext Audit", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CyanNeon)
                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Total Endpoints: ${network.endpoints.size}", fontSize = 13.sp)
                        Text("HTTPS Endpoints: ${network.httpsEndpointsCount}", fontSize = 13.sp, color = Color(0xFF10B981))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Cleartext HTTP: ${network.cleartextEndpointsCount}", fontSize = 13.sp, color = if (network.cleartextEndpointsCount > 0) Color(0xFFEF4444) else Color.Gray)
                        Text("IP Addresses: ${network.ipAddresses.size}", fontSize = 13.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text(text = "Discovered Network Endpoints", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(8.dp))

        if (network.endpoints.isEmpty()) {
            Text("No network endpoints or URLs extracted from bytecode strings.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            for (ep in network.endpoints) {
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (ep.isCleartext) Color(0xFFEF4444).copy(alpha = 0.2f) else Color(0xFF10B981).copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = ep.protocol.name,
                                color = if (ep.isCleartext) Color(0xFFEF4444) else Color(0xFF10B981),
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = ep.rawUrl, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 11. OBFUSCATION TAB
// -------------------------------------------------------------
@Composable
private fun ObfuscationTabView(obfuscation: com.example.core.model.ObfuscationReport) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = ElectricBlue.copy(alpha = 0.2f),
                    modifier = Modifier.size(54.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(text = "${obfuscation.score}%", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = ElectricBlue)
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = if (obfuscation.isObfuscated) "Code Obfuscation Detected" else "Minimal / No Obfuscation",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "Class minification: ${(obfuscation.minifiedClassRatio * 100).toInt()}% • Method stripping: ${(obfuscation.minifiedMethodRatio * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text(text = "Obfuscation & Hardening Indicators", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(8.dp))

        for (ind in obfuscation.indicators) {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = ind.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = ind.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 12. CALL GRAPH TAB
// -------------------------------------------------------------
@Composable
private fun CallGraphTabView(
    data: com.example.core.analysis.CallGraphData?,
    onNodeClick: (com.example.core.analysis.CallGraphNode) -> Unit
) {
    if (data == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select a method in the Methods tab to inspect its caller-callee call graph.")
        }
        return
    }
    InteractiveCallGraphView(data = data, onNodeClick = onNodeClick)
}

// -------------------------------------------------------------
// 13. CONTROL FLOW TAB (CFG)
// -------------------------------------------------------------
@Composable
private fun ControlFlowTabView(
    method: MethodInfo?,
    onCopy: (String) -> Unit
) {
    if (method == null || method.flowBlocks.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select a method with Dalvik bytecode to inspect its Control Flow Graph (CFG).")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "CFG for ${method.name}()", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CyanNeon)
                Text(text = method.className, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = "Basic Blocks: ${method.flowBlocks.size}", fontSize = 12.sp, color = ElectricBlue)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        for ((idx, block) in method.flowBlocks.withIndex()) {
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(4.dp), color = CyanNeon.copy(alpha = 0.15f)) {
                            Text(text = "BLOCK #${idx + 1} (${block.type.name})", color = CyanNeon, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        if (block.branchTargets.isNotEmpty()) {
                            Text(text = "Branches to: ${block.branchTargets.joinToString(", ")}", fontSize = 11.sp, color = Color(0xFFF59E0B), fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFF0F172A)) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            for (line in block.statements) {
                                Text(text = line, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFE2E8F0))
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 14. NATIVE LIBS TAB (.so)
// -------------------------------------------------------------
@Composable
private fun NativeLibsTabView(
    nativeLibs: List<NativeLibraryInfo>,
    onCopy: (String) -> Unit
) {
    if (nativeLibs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No native shared libraries (.so) found in APK (pure Java/Kotlin application).")
        }
        return
    }

    val grouped = nativeLibs.groupBy { it.architecture }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        for ((arch, libs) in grouped) {
            Text(text = "Architecture: $arch (${libs.size} libraries)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CyanNeon)
            Spacer(modifier = Modifier.height(6.dp))

            for (lib in libs) {
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Terminal, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(text = lib.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            if (lib.isSuspicious) {
                                Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFFEF4444).copy(alpha = 0.2f)) {
                                    Text("SUSPICIOUS", color = Color(0xFFEF4444), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(text = lib.formattedSize, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            IconButton(onClick = { onCopy(lib.name) }) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyanNeon, modifier = Modifier.size(16.dp))
                            }
                        }
                        if (lib.elfType.isNotBlank() || lib.suspiciousReason != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(text = "Format: ${lib.elfType}", fontSize = 11.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                                lib.suspiciousReason?.let {
                                    Text(text = "• $it", fontSize = 11.sp, color = Color(0xFFF97316))
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

// -------------------------------------------------------------
// 15. FILES TAB
// -------------------------------------------------------------
@Composable
private fun FilesTabView(
    files: List<ApkFileEntry>,
    onCopy: (String) -> Unit
) {
    var filterCategory by remember { mutableStateOf<String?>(null) }
    val filtered = if (filterCategory == null) files else files.filter { it.category == filterCategory }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CategoryChip(label = "ALL (${files.size})", isSelected = filterCategory == null, onClick = { filterCategory = null })
            listOf("DEX", "NATIVE_LIB", "ASSET", "RESOURCE", "MANIFEST", "SIGNATURE", "OTHER").forEach { cat ->
                val count = files.count { it.category == cat }
                if (count > 0) {
                    CategoryChip(label = "$cat ($count)", isSelected = filterCategory == cat, onClick = { filterCategory = cat })
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filtered) { file ->
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(4.dp), color = CyanNeon.copy(alpha = 0.15f)) {
                            Text(text = file.category, color = CyanNeon, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = file.path, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text(text = file.formattedSize, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        IconButton(onClick = { onCopy(file.path) }, modifier = Modifier.size(24.dp)) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(14.dp), tint = CyanNeon)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 16. CERTIFICATES TAB
// -------------------------------------------------------------
@Composable
private fun CertificatesTabView(
    certificates: List<CertificateInfo>,
    onCopy: (String) -> Unit
) {
    if (certificates.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No X.509 signature block found in APK archive (unsigned APK or modern APK Signature Scheme v2/v3 without v1 block).")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        for (cert in certificates) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = "X.509 Signature Certificate", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(modifier = Modifier.weight(1f))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (cert.isExpired) Color(0xFFEF4444).copy(alpha = 0.2f) else Color(0xFF10B981).copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = if (cert.isExpired) "EXPIRED" else "VALID",
                                color = if (cert.isExpired) Color(0xFFEF4444) else Color(0xFF10B981),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(10.dp))

                    InfoRow(label = "Subject", value = cert.subject, onCopy = onCopy)
                    InfoRow(label = "Issuer", value = cert.issuer, onCopy = onCopy)
                    InfoRow(label = "Serial Number", value = cert.serialNumber, onCopy = onCopy, isMonospace = true)
                    InfoRow(label = "Valid From", value = cert.validFrom, onCopy = onCopy)
                    InfoRow(label = "Valid To", value = cert.validTo, onCopy = onCopy)
                    InfoRow(label = "Algorithm", value = cert.sigAlgName, onCopy = onCopy)
                    InfoRow(label = "SHA-256 Fingerprint", value = cert.sha256Fingerprint, onCopy = onCopy, isMonospace = true)
                    InfoRow(label = "SHA-1 Fingerprint", value = cert.sha1Fingerprint, onCopy = onCopy, isMonospace = true)
                    InfoRow(label = "MD5 Fingerprint", value = cert.md5Fingerprint, onCopy = onCopy, isMonospace = true)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SEARCH TAB
// -------------------------------------------------------------
@Composable
private fun SearchTabView(
    viewModel: SamViewModel,
    onSelectMethod: (MethodInfo) -> Unit,
    onSelectClass: (ClassInfo) -> Unit,
    onCopy: (String) -> Unit,
    lang: AppLanguage
) {
    val searchMode by viewModel.searchMode.collectAsState()
    val options by viewModel.textSearchOptions.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val results by viewModel.searchResults.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Mode Switcher: Specific Text Search vs Semantic Concept Search
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (searchMode == SearchMode.SPECIFIC_TEXT) CyanNeon.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                border = if (searchMode == SearchMode.SPECIFIC_TEXT) BorderStroke(1.dp, CyanNeon) else null,
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.setSearchMode(SearchMode.SPECIFIC_TEXT) }
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = if (searchMode == SearchMode.SPECIFIC_TEXT) CyanNeon else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = SamStrings.searchModeSpecific(lang),
                        fontSize = 12.sp,
                        fontWeight = if (searchMode == SearchMode.SPECIFIC_TEXT) FontWeight.Bold else FontWeight.Medium,
                        color = if (searchMode == SearchMode.SPECIFIC_TEXT) CyanNeon else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (searchMode == SearchMode.SEMANTIC) ElectricBlue.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                border = if (searchMode == SearchMode.SEMANTIC) BorderStroke(1.dp, ElectricBlue) else null,
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.setSearchMode(SearchMode.SEMANTIC) }
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = if (searchMode == SearchMode.SEMANTIC) ElectricBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = SamStrings.searchModeSemantic(lang),
                        fontSize = 12.sp,
                        fontWeight = if (searchMode == SearchMode.SEMANTIC) FontWeight.Bold else FontWeight.Medium,
                        color = if (searchMode == SearchMode.SEMANTIC) ElectricBlue else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Search Input TextField
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.onSearchQueryChanged(it) },
            placeholder = {
                Text(
                    if (searchMode == SearchMode.SPECIFIC_TEXT) SamStrings.specificTextPlaceholder(lang)
                    else SamStrings.searchPlaceholder(lang)
                )
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = if (searchMode == SearchMode.SPECIFIC_TEXT) CyanNeon else ElectricBlue
                )
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
            singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        // When in SPECIFIC TEXT SEARCH mode: Show exact match options and scopes
        if (searchMode == SearchMode.SPECIFIC_TEXT) {
            // Options toggles (Exact Match, Case Sensitive, Regex, Whole Word)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SearchOptionPill(
                    label = SamStrings.exactMatchToggle(lang),
                    symbol = "\" \"",
                    isActive = options.isExactMatch,
                    onClick = {
                        viewModel.updateTextSearchOptions { it.copy(isExactMatch = !it.isExactMatch) }
                    }
                )

                SearchOptionPill(
                    label = SamStrings.caseSensitiveToggle(lang),
                    symbol = "Aa",
                    isActive = options.isCaseSensitive,
                    onClick = {
                        viewModel.updateTextSearchOptions { it.copy(isCaseSensitive = !it.isCaseSensitive) }
                    }
                )

                SearchOptionPill(
                    label = SamStrings.wholeWordToggle(lang),
                    symbol = "\\b",
                    isActive = options.isWholeWord,
                    onClick = {
                        viewModel.updateTextSearchOptions { it.copy(isWholeWord = !it.isWholeWord) }
                    }
                )

                SearchOptionPill(
                    label = SamStrings.regexToggle(lang),
                    symbol = ".*",
                    isActive = options.isRegex,
                    onClick = {
                        viewModel.updateTextSearchOptions { it.copy(isRegex = !it.isRegex) }
                    }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Search Scope Selector Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = SamStrings.searchScopeLabel(lang),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                val scopes = listOf(
                    TextSearchScope.ALL to SamStrings.scopeAll(lang),
                    TextSearchScope.STRINGS to SamStrings.scopeStrings(lang),
                    TextSearchScope.SMALI to SamStrings.scopeSmali(lang),
                    TextSearchScope.CLASSES_METHODS to SamStrings.scopeClassesMethods(lang),
                    TextSearchScope.MANIFEST to SamStrings.scopeManifest(lang),
                    TextSearchScope.FILES to SamStrings.scopeFiles(lang)
                )

                scopes.forEach { (sc, label) ->
                    val isSelected = options.scope == sc
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) CyanNeon.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (isSelected) BorderStroke(1.dp, CyanNeon) else null,
                        modifier = Modifier.clickable {
                            viewModel.updateTextSearchOptions { it.copy(scope = sc) }
                        }
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) CyanNeon else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Common Quick Target Chips for reverse engineers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("http://", "password", "api_key", "firebase", "secret", "bearer", "admin", "token", "v1/").forEach { tag ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.clickable { viewModel.onSearchQueryChanged(tag) }
                    ) {
                        Text(
                            text = tag,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        } else {
            // Semantic Tags Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("billing", "token", "crypto", "auth", "security", "http", "api", "database", "tamper", "root").forEach { tag ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.clickable { viewModel.onSearchQueryChanged(tag) }
                    ) {
                        Text(
                            text = "#$tag",
                            fontSize = 11.sp,
                            color = ElectricBlue,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Results stats header
        if (query.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (results.isNotEmpty()) CyanNeon else Color.Gray,
                    modifier = Modifier.size(8.dp)
                ) {}
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = SamStrings.matchesFound(lang, results.size),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        if (query.isNotEmpty() && results.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = SamStrings.emptySearch(lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(results) { res ->
                    SearchResultCard(
                        result = res,
                        onSelectMethod = onSelectMethod,
                        onSelectClass = onSelectClass,
                        onCopy = onCopy,
                        lang = lang
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchOptionPill(
    label: String,
    symbol: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isActive) CyanNeon.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant,
        border = if (isActive) BorderStroke(1.dp, CyanNeon) else null,
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = symbol,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = if (isActive) CyanNeon else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                color = if (isActive) CyanNeon else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun SearchResultCard(
    result: SearchResult,
    onSelectMethod: (MethodInfo) -> Unit,
    onSelectClass: (ClassInfo) -> Unit,
    onCopy: (String) -> Unit,
    lang: AppLanguage
) {
    val (badgeColor, badgeText) = when (result.targetType) {
        SearchTargetType.SMALI -> Color(0xFF8B5CF6) to "SMALI"
        SearchTargetType.STRING -> CyanNeon to "DEX STRING"
        SearchTargetType.METHOD -> Color(0xFF10B981) to "METHOD"
        SearchTargetType.CLASS -> ElectricBlue to "CLASS"
        SearchTargetType.MANIFEST -> Color(0xFFF59E0B) to "MANIFEST"
        SearchTargetType.URL -> Color(0xFF06B6D4) to "URL"
        SearchTargetType.FILE -> Color(0xFF64748B) to "FILE"
        SearchTargetType.FIELD -> Color(0xFF6366F1) to "FIELD"
        SearchTargetType.FEATURE -> Color(0xFFF43F5E) to "FEATURE"
        SearchTargetType.PACKAGE -> Color(0xFF3B82F6) to "PACKAGE"
    }

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header Row: Type Badge + Line Number + Evidence Badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = badgeColor.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = badgeText,
                        color = badgeColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                if (result.lineNumber != null) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = "L${result.lineNumber}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))
                EvidenceBadge(score = result.evidenceScore, level = result.evidenceLevel)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Title & Subtitle
            Text(
                text = result.title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = result.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Snippet preview box
            if (!result.matchedSnippet.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF090D16),
                    border = BorderStroke(1.dp, Color(0xFF1F293D)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .horizontalScroll(rememberScrollState()),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = result.matchedSnippet,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = CyanNeon
                        )
                    }
                }
            }

            // Reason
            if (result.reason.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = result.reason,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Copy Action
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clickable {
                        onCopy(result.matchedSnippet ?: result.title)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = SamStrings.copy(lang),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Method inspect button
                if (result.associatedObject is MethodInfo) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = CyanNeon.copy(alpha = 0.15f),
                        modifier = Modifier.clickable {
                            onSelectMethod(result.associatedObject)
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = null,
                                tint = CyanNeon,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = SamStrings.inspectMethod(lang),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon
                            )
                        }
                    }
                }

                // Class inspect button
                if (result.associatedObject is ClassInfo) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = ElectricBlue.copy(alpha = 0.15f),
                        modifier = Modifier.clickable {
                            onSelectClass(result.associatedObject)
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = null,
                                tint = ElectricBlue,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Inspect Class",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElectricBlue
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// DIFF TAB
// -------------------------------------------------------------
@Composable
private fun DiffTabView(
    diffResult: com.example.core.model.DiffResult?,
    onCopy: (String) -> Unit
) {
    if (diffResult == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No active APK comparison. Select an earlier APK release to run a diff comparison.")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text(text = "Diff: ${diffResult.oldApkName} -> ${diffResult.newApkName}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CyanNeon)
        Spacer(modifier = Modifier.height(10.dp))

        DiffCard(title = "Newly Added Classes (+${diffResult.newClasses.size})", items = diffResult.newClasses, color = EvidenceStrong)
        Spacer(modifier = Modifier.height(8.dp))
        DiffCard(title = "Newly Added Methods (+${diffResult.newMethods.size})", items = diffResult.newMethods, color = EvidenceStrong)
        Spacer(modifier = Modifier.height(8.dp))
        DiffCard(title = "Manifest & Version Changes", items = diffResult.manifestChanges, color = ElectricBlue)
    }
}

@Composable
private fun DiffCard(title: String, items: List<String>, color: Color) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = color)
            Spacer(modifier = Modifier.height(6.dp))
            if (items.isEmpty()) {
                Text(text = "No differences found", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                for (item in items.take(10)) {
                    Text(text = "• $item", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// REPORTS TAB
// -------------------------------------------------------------
@Composable
private fun ReportsTabView(onExport: (format: String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(48.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = "Export Comprehensive Inspection Report", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(text = "Generates a structured report with analysis metrics, evidence levels, and library dependencies.", style = MaterialTheme.typography.bodySmall)
        Spacer(modifier = Modifier.height(20.dp))

        listOf("TXT", "JSON", "HTML", "CSV").forEach { fmt ->
            Button(
                onClick = { onExport(fmt) },
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Copy $fmt Report")
            }
        }
    }
}

// -------------------------------------------------------------
// WORKSPACE TAB
// -------------------------------------------------------------
@Composable
private fun WorkspaceTabView(
    bookmarks: List<com.example.core.database.BookmarkEntity>,
    notes: List<com.example.core.database.NoteEntity>,
    onAddNote: () -> Unit,
    onDeleteNote: (com.example.core.database.NoteEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text(text = "Workspace Bookmarks (${bookmarks.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        if (bookmarks.isEmpty()) {
            Text(text = "No bookmarked methods yet. Tap the bookmark icon on any method to save.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            for (bm in bookmarks) {
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Bookmark, contentDescription = null, tint = CyanNeon)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = bm.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = bm.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Project Notes (${notes.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.weight(1f))
            Button(onClick = onAddNote, shape = RoundedCornerShape(6.dp)) {
                Text("Add Note")
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        for (n in notes) {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(text = n.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(text = n.content, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun CategoryChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) CyanNeon else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}
