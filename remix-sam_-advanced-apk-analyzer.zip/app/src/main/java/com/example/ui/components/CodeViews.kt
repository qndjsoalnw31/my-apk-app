package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EvidenceStrong
import com.example.ui.theme.VioletCode

@Composable
fun SyntaxHighlightedSmaliView(
    code: String,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF0D1525)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Smali Disassembly",
                    style = MaterialTheme.typography.labelMedium,
                    color = CyanNeon,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onCopy) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy Smali",
                        tint = Color.White.copy(alpha = 0.7f)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF080C16), RoundedCornerShape(6.dp))
                    .padding(8.dp)
                    .horizontalScroll(rememberScrollState())
            ) {
                Text(
                    text = highlightSmali(code),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun PseudoCodeView(
    code: String,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF0F172A)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Kotlin / Java Pseudo-Code",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFF38BDF8),
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onCopy) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy Code",
                        tint = Color.White.copy(alpha = 0.7f)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF090D1A), RoundedCornerShape(6.dp))
                    .padding(8.dp)
                    .horizontalScroll(rememberScrollState())
            ) {
                Text(
                    text = highlightPseudoCode(code),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

private fun highlightSmali(code: String) = buildAnnotatedString {
    val lines = code.split("\n")
    for (line in lines) {
        val trimmed = line.trim()
        when {
            trimmed.startsWith("#") -> {
                withStyle(SpanStyle(color = Color(0xFF64748B))) { append(line) }
            }
            trimmed.startsWith(".method") || trimmed.startsWith(".end method") || trimmed.startsWith(".registers") -> {
                withStyle(SpanStyle(color = VioletCode, fontWeight = FontWeight.Bold)) { append(line) }
            }
            trimmed.startsWith("invoke-") -> {
                withStyle(SpanStyle(color = CyanNeon)) { append(line) }
            }
            trimmed.startsWith("return") -> {
                withStyle(SpanStyle(color = EvidenceStrong, fontWeight = FontWeight.Bold)) { append(line) }
            }
            trimmed.startsWith("if-") -> {
                withStyle(SpanStyle(color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold)) { append(line) }
            }
            trimmed.startsWith("const-string") -> {
                withStyle(SpanStyle(color = Color(0xFF34D399))) { append(line) }
            }
            else -> {
                withStyle(SpanStyle(color = Color(0xFFE2E8F0))) { append(line) }
            }
        }
        append("\n")
    }
}

private fun highlightPseudoCode(code: String) = buildAnnotatedString {
    val lines = code.split("\n")
    for (line in lines) {
        val trimmed = line.trim()
        when {
            trimmed.startsWith("//") -> {
                withStyle(SpanStyle(color = Color(0xFF64748B))) { append(line) }
            }
            trimmed.startsWith("public") || trimmed.startsWith("private") || trimmed.startsWith("fun") -> {
                withStyle(SpanStyle(color = VioletCode, fontWeight = FontWeight.Bold)) { append(line) }
            }
            trimmed.startsWith("if") || trimmed.startsWith("return") -> {
                withStyle(SpanStyle(color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold)) { append(line) }
            }
            else -> {
                withStyle(SpanStyle(color = Color(0xFFE2E8F0))) { append(line) }
            }
        }
        append("\n")
    }
}
