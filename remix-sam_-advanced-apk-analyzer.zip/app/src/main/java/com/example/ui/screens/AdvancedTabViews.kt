package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.ApkHealthReport
import com.example.core.model.DependencyGraphData
import com.example.core.model.EndpointProtocol
import com.example.core.model.FeatureMapGroup
import com.example.core.model.MethodInfo
import com.example.core.model.NetworkAuditReport
import com.example.core.model.ObfuscationReport
import com.example.core.model.PluginInfo
import com.example.core.model.PluginOutput
import com.example.core.model.SecurityAuditReport
import com.example.core.model.SecuritySeverity
import com.example.core.model.TimelineStep
import com.example.ui.SamTab
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EvidenceMedium
import com.example.ui.theme.EvidenceStrong
import com.example.ui.theme.EvidenceWeak
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * APK Health Dashboard View
 */
@Composable
fun HealthDashboardTabView(
    health: ApkHealthReport,
    onNavigate: (SamTab) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Score Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "APK Health Index",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon
                            )
                            Text(
                                text = "Comprehensive architecture, security & bloat rating",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = CircleShape,
                            color = CyanNeon.copy(alpha = 0.15f),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "${health.overallHealthScore}",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CyanNeon
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Progress indicators for pillars
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        HealthProgressBar(label = "Code Architecture & Density", score = health.codeQualityScore, color = ElectricBlue)
                        HealthProgressBar(label = "Security Hardening Rating", score = health.securityHealthScore, color = if (health.securityHealthScore >= 75) EvidenceStrong else EvidenceMedium)
                        HealthProgressBar(label = "Package Footprint Efficiency", score = health.bloatIndexScore, color = CyanNeon)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Quick Jump Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onNavigate(SamTab.SECURITY) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Security Audit", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        OutlinedButton(
                            onClick = { onNavigate(SamTab.OBFUSCATION) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Obfuscation", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        OutlinedButton(
                            onClick = { onNavigate(SamTab.FEATURE_MAP) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Feature Map", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Health Metrics Breakdown
        items(health.metrics) { metric ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = metric.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (metric.score >= 80) EvidenceStrong.copy(alpha = 0.2f) else EvidenceMedium.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "${metric.status} (${metric.score}%)",
                                color = if (metric.score >= 80) EvidenceStrong else EvidenceMedium,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = metric.summary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = metric.details,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun HealthProgressBar(label: String, score: Int, color: Color) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall)
            Text(text = "$score%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { score / 100f },
            modifier = Modifier.fillMaxWidth(),
            color = color,
            trackColor = color.copy(alpha = 0.2f)
        )
    }
}

/**
 * Security Analyzer View
 */
@Composable
fun SecurityAnalyzerTabView(
    security: SecurityAuditReport,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Summary Header Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Security Audit & Vulnerability Assessment",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (security.overallRiskScore > 40) EvidenceWeak else CyanNeon
                            )
                            Text(
                                text = "Static binary analysis of manifest and decompiled bytecode",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (security.overallRiskScore > 50) EvidenceWeak.copy(alpha = 0.2f) else EvidenceMedium.copy(alpha = 0.2f)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${security.overallRiskScore}%",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (security.overallRiskScore > 50) EvidenceWeak else EvidenceMedium
                                )
                                Text(
                                    text = "Risk Score",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SecurityStatMini(label = "Exported", count = "${security.exportedComponentsCount}")
                        SecurityStatMini(label = "Dangerous Perms", count = "${security.dangerousPermissionsCount}")
                        SecurityStatMini(label = "Hardcoded Keys", count = "${security.hardcodedSecretsCount}")
                        SecurityStatMini(label = "Cleartext HTTP", count = if (security.cleartextTrafficAllowed) "Allowed" else "Blocked")
                    }
                }
            }
        }

        item {
            Text(
                text = "Identified Security Vulnerabilities (${security.vulnerabilities.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }

        items(security.vulnerabilities) { vuln ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    when (vuln.severity) {
                        SecuritySeverity.CRITICAL -> EvidenceWeak
                        SecuritySeverity.HIGH -> EvidenceWeak.copy(alpha = 0.7f)
                        SecuritySeverity.MEDIUM -> EvidenceMedium
                        SecuritySeverity.LOW -> ElectricBlue
                        SecuritySeverity.INFO -> Color.Gray
                    }
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when (vuln.severity) {
                                SecuritySeverity.CRITICAL -> EvidenceWeak.copy(alpha = 0.2f)
                                SecuritySeverity.HIGH -> EvidenceWeak.copy(alpha = 0.15f)
                                SecuritySeverity.MEDIUM -> EvidenceMedium.copy(alpha = 0.2f)
                                else -> ElectricBlue.copy(alpha = 0.2f)
                            }
                        ) {
                            Text(
                                text = vuln.severity.name,
                                color = when (vuln.severity) {
                                    SecuritySeverity.CRITICAL, SecuritySeverity.HIGH -> EvidenceWeak
                                    SecuritySeverity.MEDIUM -> EvidenceMedium
                                    else -> ElectricBlue
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }

                        Text(
                            text = vuln.category.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = vuln.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = vuln.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Affected: ${vuln.affectedComponent}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = CyanNeon
                    )

                    if (vuln.evidenceCode.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.Black,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = vuln.evidenceCode,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = EvidenceWeak,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.background,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Remediation: ${vuln.recommendation}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SecurityStatMini(label: String, count: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = count, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = CyanNeon)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/**
 * Obfuscation Detector View
 */
@Composable
fun ObfuscationTabView(
    obfuscation: ObfuscationReport,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Code Obfuscation & Minification",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon
                            )
                            Text(
                                text = "Detection of symbol stripping, repackaging, and reflection",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (obfuscation.isObfuscated) EvidenceStrong.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = if (obfuscation.isObfuscated) "Protected (${obfuscation.score}%)" else "Unobfuscated (${obfuscation.score}%)",
                                color = if (obfuscation.isObfuscated) EvidenceStrong else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        HealthProgressBar("Minified Classes", (obfuscation.minifiedClassRatio * 100).toInt(), ElectricBlue)
                        HealthProgressBar("Stripped Methods", (obfuscation.minifiedMethodRatio * 100).toInt(), CyanNeon)
                        HealthProgressBar("Flattened Package Structure", (obfuscation.flattenedPackageRatio * 100).toInt(), EvidenceMedium)
                    }

                    if (obfuscation.proguardMarkersFound.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Protection Signatures: ${obfuscation.proguardMarkersFound.joinToString(", ")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = EvidenceStrong,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Obfuscation Indicators (${obfuscation.indicators.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }

        items(obfuscation.indicators) { ind ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = when (ind.severity) {
                            "HIGH" -> EvidenceStrong.copy(alpha = 0.2f)
                            "MEDIUM" -> EvidenceMedium.copy(alpha = 0.2f)
                            else -> ElectricBlue.copy(alpha = 0.2f)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = when (ind.severity) {
                                    "HIGH" -> EvidenceStrong
                                    "MEDIUM" -> EvidenceMedium
                                    else -> ElectricBlue
                                },
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = ind.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = ind.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color.Black
                    ) {
                        Text(
                            text = ind.severity,
                            color = when (ind.severity) {
                                "HIGH" -> EvidenceStrong
                                "MEDIUM" -> EvidenceMedium
                                else -> ElectricBlue
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Network Analyzer View
 */
@Composable
fun NetworkAnalyzerTabView(
    network: NetworkAuditReport,
    allMethods: List<MethodInfo>,
    onSelectMethod: (MethodInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    var filterQuery by remember { mutableStateOf("") }
    var selectedProtocol by remember { mutableStateOf<EndpointProtocol?>(null) }

    val filteredEndpoints = remember(network.endpoints, filterQuery, selectedProtocol) {
        network.endpoints.filter { ep ->
            (selectedProtocol == null || ep.protocol == selectedProtocol) &&
                    (filterQuery.isBlank() || ep.url.contains(filterQuery, ignoreCase = true) || ep.domain.contains(filterQuery, ignoreCase = true))
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Network API & Endpoint Harvester",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Extracted all hardcoded URLs, backend domains, and REST endpoints from compiled bytecode.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SecurityStatMini(label = "Endpoints", count = "${network.endpoints.size}")
                        SecurityStatMini(label = "Unique Domains", count = "${network.uniqueDomains.size}")
                        SecurityStatMini(label = "HTTPS (Secured)", count = "${network.securedHttpsCount}")
                        SecurityStatMini(label = "Cleartext HTTP", count = "${network.cleartextCount}")
                    }
                }
            }
        }

        // Search & Protocol Filter
        item {
            OutlinedTextField(
                value = filterQuery,
                onValueChange = { filterQuery = it },
                placeholder = { Text("Filter endpoints or domains...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )
        }

        items(filteredEndpoints) { ep ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (ep.isCleartext) EvidenceWeak.copy(alpha = 0.2f) else CyanNeon.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = ep.protocol.name,
                                color = if (ep.isCleartext) EvidenceWeak else CyanNeon,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Text(
                            text = ep.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = ep.url,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Caller: ${ep.foundInClass.substringAfterLast('.')}.${ep.foundInMethod}()",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = ElectricBlue
                        )

                        val methodObj = allMethods.find { it.name == ep.foundInMethod }
                        if (methodObj != null) {
                            IconButton(
                                onClick = { onSelectMethod(methodObj) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.OpenInNew,
                                    contentDescription = "Inspect Method",
                                    tint = CyanNeon,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Feature Map View
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FeatureMapTabView(
    groups: List<FeatureMapGroup>,
    allMethods: List<MethodInfo>,
    onSelectMethod: (MethodInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "SAM Feature Map Architecture",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Discovered capability groups linking Classes, Methods, Strings, and Permissions together.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        items(groups) { group ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = group.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = CyanNeon
                        )

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = EvidenceStrong.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${group.confidenceScore}% Confidence",
                                color = EvidenceStrong,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = group.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Spacer(modifier = Modifier.height(12.dp))

                    // Linked Methods
                    if (group.methodIds.isNotEmpty()) {
                        Text(text = "Associated Methods (${group.methodIds.size}):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ElectricBlue)
                        Spacer(modifier = Modifier.height(4.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            group.methodIds.take(6).forEach { mId ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color.Black,
                                    modifier = Modifier.clickable {
                                        val m = allMethods.find { it.id == mId }
                                        if (m != null) onSelectMethod(m)
                                    }
                                ) {
                                    Text(
                                        text = mId.substringAfterLast('.'),
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = CyanNeon,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Linked Strings
                    if (group.stringValues.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Associated Constants & Strings:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        group.stringValues.take(4).forEach { str ->
                            Text(
                                text = "• $str",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Dependency Graph View
 */
@Composable
fun DependencyGraphTabView(
    depGraph: DependencyGraphData,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Dependency Graph & SDK Footprint",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Architectural mapping separating internal app modules from external SDK dependencies.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        items(depGraph.nodes) { node ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (node.isInternal) ElectricBlue.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                ),
                border = if (node.isInternal) androidx.compose.foundation.BorderStroke(1.dp, ElectricBlue) else null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = node.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (node.isInternal) CyanNeon else MaterialTheme.colorScheme.onSurface
                        )

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.Black
                        ) {
                            Text(
                                text = node.riskLevel,
                                color = if (node.isInternal) CyanNeon else ElectricBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Category: ${node.category.name} • Class Count: ${node.classCount}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Show call edge if available
                    val edge = depGraph.edges.find { it.toId == node.id }
                    if (edge != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Invocations: ${edge.callCount} calls from app bytecode",
                            fontSize = 11.sp,
                            color = EvidenceStrong
                        )
                        Text(
                            text = "Sample: ${edge.sampleInvoke}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

/**
 * Plugins System View
 */
@Composable
fun PluginsTabView(
    plugins: List<PluginInfo>,
    outputs: Map<String, PluginOutput>,
    onExecute: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "SAM Plugin Engine",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Modular inspection extensions for specialized reverse-engineering CUJs.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        items(plugins) { plugin ->
            val output = outputs[plugin.id]
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = plugin.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "v${plugin.version} • ${plugin.author}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Button(
                            onClick = { onExecute(plugin.id) },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = Color.Black)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Run Plugin", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = plugin.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    // Output results if run
                    if (output != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = output.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = CyanNeon
                                )
                                Text(
                                    text = output.summary,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                output.items.take(4).forEach { item ->
                                    Text(
                                        text = "• $item",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = EvidenceStrong
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Timeline Investigation View
 */
@Composable
fun TimelineTabView(
    steps: List<TimelineStep>,
    onAddCustom: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var newTitle by remember { mutableStateOf("") }
    var newDesc by remember { mutableStateOf("") }
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Investigation Timeline",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tracks analytical progress and reverse-engineering audit trail.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = newTitle,
                            onValueChange = { newTitle = it },
                            placeholder = { Text("Log investigation milestone...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newTitle.isNotBlank()) {
                                    onAddCustom(newTitle, newDesc)
                                    newTitle = ""
                                    newDesc = ""
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = Color.White)
                        ) {
                            Text("Log")
                        }
                    }
                }
            }
        }

        if (steps.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().height(160.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No milestones recorded yet. Actions and scans will populate here.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(steps) { step ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = CyanNeon.copy(alpha = 0.15f),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Timeline,
                                    contentDescription = null,
                                    tint = CyanNeon,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = step.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = step.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Text(
                            text = dateFormat.format(Date(step.timestamp)),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = ElectricBlue
                        )
                    }
                }
            }
        }
    }
}
