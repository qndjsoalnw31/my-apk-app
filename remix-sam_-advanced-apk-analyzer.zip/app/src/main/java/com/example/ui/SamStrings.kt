package com.example.ui

/**
 * In-app localization dictionary providing comprehensive Arabic and English text support.
 */
enum class AppLanguage {
    ARABIC,
    ENGLISH
}

object SamStrings {

    fun appTitle(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "منصة SAM لتحليل تطبيقات أندرويد" else "SAM APK Analyzer"
    fun selectApk(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "اختيار ملف APK" else "Select APK"
    fun startAnalysis(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "بدء التحليل" else "Start Analysis"
    fun sampleApks(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "حزم تجريبية جاهزة" else "Sample APKs"
    fun recentProjects(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "المشاريع المحفوظة" else "Saved Projects"

    // Dashboard Tabs
    fun tabOverview(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "لوحة المعلومات" else "Dashboard"
    fun tabApkInfo(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "معلومات APK" else "APK Info"
    fun tabHealth(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "صحة التطبيق" else "Health"
    fun tabSecurity(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "الفاحص الأمني" else "Security"
    fun tabObfuscation(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "كاشف التمويه" else "Obfuscation"
    fun tabNetwork(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "محلل الشبكة" else "Network"
    fun tabFeatureMap(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "خريطة الميزات" else "Feature Map"
    fun tabCallGraph(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "شجرة الاستدعاء" else "Call Graph"
    fun tabControlFlow(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "مخطط التدفق CFG" else "Control Flow"
    fun tabDepGraph(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "شجرة الاعتماديات" else "Dependencies"
    fun tabClasses(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "الكلاسات Classes" else "Classes"
    fun tabMethods(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "الدوال Methods" else "Methods"
    fun tabDex(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "ملفات DEX" else "DEX Files"
    fun tabNativeLibs(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "المكتبات الأصلية .so" else "Native Libs"
    fun tabFiles(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "شجرة الملفات" else "APK Files"
    fun tabCertificates(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "الشهادات والتوقيع" else "Certificates"
    fun tabPermissions(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "الأذونات" else "Permissions"
    fun tabSmali(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "كود Smali" else "Smali"
    fun tabStrings(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "النصوص الذكية" else "Strings"
    fun tabLibraries(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "المكتبات المكتشفة" else "Libraries"
    fun tabManifest(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "المانيفست Manifest" else "Manifest"
    fun tabSearch(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "البحث والتقصي" else "Search & Audit"
    fun tabEvidence(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "نظام الأدلة" else "Evidence"
    fun tabDiff(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "مقارنة APK" else "Diff"
    fun tabScanner(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "فاحص الميزات" else "Scanner"
    fun tabPlugins(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "الإضافات" else "Plugins"
    fun tabTimeline(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "خط التحقيق" else "Timeline"
    fun tabReports(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "التقارير" else "Reports"
    fun tabWorkspace(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "مساحة العمل" else "Workspace"

    // Search Modes & Specific Text Search
    fun searchModeSpecific(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "البحث عن كتابة محددة" else "Specific Text Search"
    fun searchModeSemantic(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "بحث دلالي ذكي" else "Semantic Concept Search"
    fun specificTextPlaceholder(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "اكتب النص أو العبارة المحددة للبحث عنها..." else "Enter specific text or code snippet to search..."
    fun exactMatchToggle(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "تطابق تام" else "Exact Match"
    fun caseSensitiveToggle(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "حساس للأحرف (Aa)" else "Case Sensitive (Aa)"
    fun regexToggle(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "تعبير نمطي (.*)" else "Regex (.*)"
    fun wholeWordToggle(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "كلمة كاملة" else "Whole Word"
    fun searchScopeLabel(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "نطاق البحث:" else "Search Scope:"
    fun scopeAll(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "كافة الأقسام" else "All"
    fun scopeStrings(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "النصوص الثابتة" else "Strings"
    fun scopeSmali(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "كود Smali" else "Smali Code"
    fun scopeClassesMethods(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "الدوال والفئات" else "Methods & Classes"
    fun scopeManifest(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "المانيفست" else "Manifest"
    fun scopeFiles(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "الملفات والأصول" else "Files & Assets"
    fun matchesFound(lang: AppLanguage, count: Int) = if (lang == AppLanguage.ARABIC) "تم العثور على $count مطابقة" else "Found $count matches"
    fun inspectMethod(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "معاينة الدالة" else "Inspect Method"

    // App Loading & Sources
    fun analyzeInstalledApp(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "فحص تطبيق من الجهاز" else "Analyze Installed App"
    fun selectApkFile(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "اختيار ملف APK" else "Select APK File"
    fun preAnalysisTitle(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "معاينة الحزمة قبل التحليل" else "Pre-Analysis Inspection"
    fun startDeepAnalysis(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "بدء التحليل الشامل" else "Start Deep Analysis"
    fun selectInstalledAppPrompt(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "اختر تطبيقاً مثبتاً على هاتفك للبدء في تحليله" else "Select an installed app on your device to inspect"

    // Metrics
    fun totalClasses(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "إجمالي الـ Classes" else "Total Classes"
    fun totalMethods(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "إجمالي الـ Methods" else "Total Methods"
    fun totalStrings(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "إجمالي النصوص" else "Total Strings"
    fun detectedLibs(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "المكتبات المكتشفة" else "Detected Libraries"
    fun strongEvidence(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "أدلة قوية (90-100%)" else "Strong Evidence"
    fun mediumEvidence(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "أدلة متوسطة (60-89%)" else "Medium Evidence"
    fun weakEvidence(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "أدلة ضعيفة (0-59%)" else "Weak Evidence"

    // Actions
    fun copy(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "نسخ" else "Copy"
    fun copied(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "تم النسخ بنجاح!" else "Copied to clipboard!"
    fun bookmark(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "حفظ في المفضلة" else "Bookmark"
    fun addNote(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "إضافة ملاحظة" else "Add Note"
    fun explainAi(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "شرح الذكاء الاصطناعي AI" else "AI Explainer"
    fun exportReport(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "تصدير التقرير" else "Export Report"
    fun searchPlaceholder(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "ابحث عن دالة، ميزة، نص، عنوان URL..." else "Search methods, classes, strings, URLs..."
    fun emptySearch(lang: AppLanguage) = if (lang == AppLanguage.ARABIC) "لا توجد نتائج مطابقة" else "No matching results found"
}
