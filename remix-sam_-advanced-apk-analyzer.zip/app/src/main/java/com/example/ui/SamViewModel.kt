package com.example.ui

import android.app.Application
import android.content.pm.ApplicationInfo
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.analysis.AiExplainerEngine
import com.example.core.analysis.CallGraphData
import com.example.core.analysis.CallGraphEngine
import com.example.core.analysis.DiffEngine
import com.example.core.analysis.ReportGenerator
import com.example.core.database.BookmarkEntity
import com.example.core.database.NoteEntity
import com.example.core.database.ProjectEntity
import com.example.core.database.SamDatabase
import com.example.core.model.ApkAnalysisResult
import com.example.core.model.ClassInfo
import com.example.core.model.DiffResult
import com.example.core.model.EvidenceLevel
import com.example.core.model.InstalledAppInfo
import com.example.core.model.MethodInfo
import com.example.core.model.SearchResult
import com.example.core.model.SearchMode
import com.example.core.model.TextSearchOptions
import com.example.core.model.TextSearchScope
import com.example.core.analysis.SpecificTextSearchEngine
import com.example.core.parser.ApkParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream

sealed class AnalysisStatus {
    object Idle : AnalysisStatus()
    data class Progress(val message: String, val step: Int, val totalSteps: Int) : AnalysisStatus()
    data class Success(val result: ApkAnalysisResult) : AnalysisStatus()
    data class Error(val message: String) : AnalysisStatus()
}

enum class SamTab(val title: String) {
    DASHBOARD("Dashboard"),
    APK_INFO("APK Info"),
    MANIFEST("Manifest"),
    DEX_FILES("DEX"),
    CLASSES("Classes"),
    METHODS("Methods"),
    STRINGS("Strings"),
    PERMISSIONS("Permissions"),
    SECURITY("Security"),
    NETWORK("Network"),
    OBFUSCATION("Obfuscation"),
    CALL_GRAPH("Call Graph"),
    CONTROL_FLOW("Control Flow"),
    NATIVE_LIBS("Native Libs"),
    FILES("Files"),
    CERTIFICATES("Certificates"),
    SEARCH("Search"),
    DIFF("Diff"),
    FEATURE_MAP("Feature Map"),
    REPORTS("Reports"),
    WORKSPACE("Workspace")
}

class SamViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SamDatabase.getDatabase(application)
    private val dao = db.samDao()
    private val apkParser = ApkParser()

    // Analysis State
    private val _analysisStatus = MutableStateFlow<AnalysisStatus>(AnalysisStatus.Idle)
    val analysisStatus: StateFlow<AnalysisStatus> = _analysisStatus.asStateFlow()

    private val _currentAnalysis = MutableStateFlow<ApkAnalysisResult?>(null)
    val currentAnalysis: StateFlow<ApkAnalysisResult?> = _currentAnalysis.asStateFlow()

    // Navigation & Tabs
    private val _currentTab = MutableStateFlow(SamTab.DASHBOARD)
    val currentTab: StateFlow<SamTab> = _currentTab.asStateFlow()

    // Selection
    private val _selectedClass = MutableStateFlow<ClassInfo?>(null)
    val selectedClass: StateFlow<ClassInfo?> = _selectedClass.asStateFlow()

    private val _selectedMethod = MutableStateFlow<MethodInfo?>(null)
    val selectedMethod: StateFlow<MethodInfo?> = _selectedMethod.asStateFlow()

    // Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchMode = MutableStateFlow(SearchMode.SPECIFIC_TEXT)
    val searchMode: StateFlow<SearchMode> = _searchMode.asStateFlow()

    private val _textSearchOptions = MutableStateFlow(TextSearchOptions())
    val textSearchOptions: StateFlow<TextSearchOptions> = _textSearchOptions.asStateFlow()

    private val _searchResults = MutableStateFlow<List<SearchResult>>(emptyList())
    val searchResults: StateFlow<List<SearchResult>> = _searchResults.asStateFlow()

    // Evidence Filter
    private val _evidenceFilter = MutableStateFlow<EvidenceLevel?>(null)
    val evidenceFilter: StateFlow<EvidenceLevel?> = _evidenceFilter.asStateFlow()

    // Call Graph
    private val _callGraphData = MutableStateFlow<CallGraphData?>(null)
    val callGraphData: StateFlow<CallGraphData?> = _callGraphData.asStateFlow()

    // Diff State
    private val _diffResult = MutableStateFlow<DiffResult?>(null)
    val diffResult: StateFlow<DiffResult?> = _diffResult.asStateFlow()

    // Installed Apps
    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    // AI Explainer State
    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _aiExplanation = MutableStateFlow<String?>(null)
    val aiExplanation: StateFlow<String?> = _aiExplanation.asStateFlow()

    // UI Preferences
    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _appLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val appLanguage: StateFlow<AppLanguage> = _appLanguage.asStateFlow()

    // Notification message
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Room Database Flows
    val savedProjects = dao.getAllProjects().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val savedBookmarks = dao.getAllBookmarks().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val savedNotes = dao.getAllNotes().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    init {
        loadInstalledApps()
        viewModelScope.launch {
            dao.deleteSampleProjects()
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            dao.deleteProject(project)
            showToast("Project removed")
        }
    }

    fun clearAllProjects() {
        viewModelScope.launch {
            dao.deleteAllProjects()
            showToast("All projects cleared")
        }
    }

    fun openSavedProject(project: ProjectEntity) {
        val installed = _installedApps.value.firstOrNull { it.packageName == project.packageName }
        if (installed != null) {
            analyzeInstalledApp(installed)
        } else {
            showToast("APK not found on device for ${project.packageName}")
        }
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun toggleLanguage() {
        _appLanguage.value = if (_appLanguage.value == AppLanguage.ENGLISH) AppLanguage.ARABIC else AppLanguage.ENGLISH
    }

    fun setTab(tab: SamTab) {
        _currentTab.value = tab
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun resetToHome() {
        _analysisStatus.value = AnalysisStatus.Idle
    }

    fun resetStatus() {
        resetToHome()
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingApps.value = true
            try {
                val pm = getApplication<Application>().packageManager
                val packages = pm.getInstalledPackages(0)
                val list = mutableListOf<InstalledAppInfo>()
                for (p in packages) {
                    val appInfo = p.applicationInfo ?: continue
                    val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val label = pm.getApplicationLabel(appInfo).toString()
                    val sourceDir = appInfo.sourceDir ?: ""
                    val size = if (sourceDir.isNotEmpty()) File(sourceDir).length() else 0L

                    val formatted = when {
                        size >= 1024 * 1024 -> "%.2f MB".format(size / (1024.0 * 1024.0))
                        size >= 1024 -> "%.1f KB".format(size / 1024.0)
                        else -> "$size B"
                    }

                    list.add(
                        InstalledAppInfo(
                            packageName = p.packageName,
                            appName = label,
                            versionName = p.versionName ?: "1.0",
                            versionCode = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) p.longVersionCode else @Suppress("DEPRECATION") p.versionCode.toLong(),
                            isSystemApp = isSystem,
                            apkPath = sourceDir,
                            fileSizeFormatted = formatted,
                            fileSizeBytes = size
                        )
                    )
                }
                _installedApps.value = list.sortedWith(compareBy({ it.isSystemApp }, { it.appName.lowercase() }))
            } catch (e: Exception) {
                _installedApps.value = emptyList()
            } finally {
                _isLoadingApps.value = false
            }
        }
    }

    fun analyzeInstalledApp(app: InstalledAppInfo) {
        viewModelScope.launch {
            _analysisStatus.value = AnalysisStatus.Progress("Locating ${app.appName} on device...", 1, 6)
            try {
                val file = File(app.apkPath)
                if (!file.exists()) {
                    _analysisStatus.value = AnalysisStatus.Error("APK file not found at path: ${app.apkPath}")
                    return@launch
                }
                if (!file.canRead()) {
                    _analysisStatus.value = AnalysisStatus.Error("Cannot read APK file at path: ${app.apkPath}. System permissions or scoped storage restrictions prevent access.")
                    return@launch
                }

                val stream = FileInputStream(file)
                val result = apkParser.parseApkFile(
                    fileInputStream = stream,
                    fileName = "${app.appName}.apk",
                    fileSizeBytes = app.fileSizeBytes
                ) { msg, step, total ->
                    _analysisStatus.value = AnalysisStatus.Progress(msg, step, total)
                }
                _currentAnalysis.value = result
                _analysisStatus.value = AnalysisStatus.Success(result)
                if (result.methods.isNotEmpty()) selectMethod(result.methods.first())
                saveCurrentProject()
            } catch (e: Exception) {
                _analysisStatus.value = AnalysisStatus.Error("Failed to inspect ${app.appName}: ${e.message ?: "Unknown error"}")
            }
        }
    }

    fun selectMethod(method: MethodInfo) {
        _selectedMethod.value = method
        val analysis = _currentAnalysis.value
        if (analysis != null) {
            _callGraphData.value = CallGraphEngine.buildCallGraph(method, analysis.methods)
            _selectedClass.value = analysis.classes.firstOrNull { it.id == method.className }
        }
    }

    fun selectClass(clazz: ClassInfo) {
        _selectedClass.value = clazz
        if (clazz.methods.isNotEmpty()) {
            selectMethod(clazz.methods.first())
        }
    }

    fun setEvidenceFilter(level: EvidenceLevel?) {
        _evidenceFilter.value = level
    }

    fun setSearchMode(mode: SearchMode) {
        _searchMode.value = mode
        executeSearch()
    }

    fun updateTextSearchOptions(transform: (TextSearchOptions) -> TextSearchOptions) {
        val updated = transform(_textSearchOptions.value)
        _textSearchOptions.value = updated
        _searchQuery.value = updated.query
        executeSearch()
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        _textSearchOptions.value = _textSearchOptions.value.copy(query = query)
        executeSearch()
    }

    fun executeSearch() {
        val analysis = _currentAnalysis.value ?: return
        val query = _searchQuery.value.trim()
        if (query.isEmpty()) {
            _searchResults.value = emptyList()
            return
        }

        if (_searchMode.value == SearchMode.SPECIFIC_TEXT) {
            _searchResults.value = SpecificTextSearchEngine.search(_textSearchOptions.value, analysis)
        } else {
            _searchResults.value = com.example.core.analysis.SemanticSearchEngine.search(query, analysis)
        }
    }

    fun parseUserApk(uri: Uri, fileName: String, fileSizeBytes: Long) {
        viewModelScope.launch {
            try {
                _analysisStatus.value = AnalysisStatus.Progress("Opening APK file stream...", 1, 6)
                val stream = getApplication<Application>().contentResolver.openInputStream(uri)
                if (stream == null) {
                    _analysisStatus.value = AnalysisStatus.Error("Failed to open file stream for selected APK: $fileName")
                    return@launch
                }

                val result = apkParser.parseApkFile(
                    fileInputStream = stream,
                    fileName = fileName,
                    fileSizeBytes = fileSizeBytes
                ) { msg, step, total ->
                    _analysisStatus.value = AnalysisStatus.Progress(msg, step, total)
                }

                _currentAnalysis.value = result
                _analysisStatus.value = AnalysisStatus.Success(result)
                if (result.methods.isNotEmpty()) {
                    selectMethod(result.methods.first())
                }
                saveCurrentProject()
            } catch (e: Exception) {
                _analysisStatus.value = AnalysisStatus.Error("Analysis failed: ${e.message ?: "Invalid or unsupported APK file"}")
            }
        }
    }

    fun compareWithApk(otherAnalysis: ApkAnalysisResult) {
        val current = _currentAnalysis.value ?: return
        _diffResult.value = DiffEngine.compare(otherAnalysis, current)
        setTab(SamTab.DIFF)
    }

    fun explainCurrentMethodWithAi() {
        val method = _selectedMethod.value ?: return
        viewModelScope.launch {
            _isAiLoading.value = true
            _aiExplanation.value = null
            try {
                val explanation = AiExplainerEngine.explainMethod(method)
                _aiExplanation.value = explanation
            } catch (e: Exception) {
                _aiExplanation.value = "Error generating explanation: ${e.message}"
            } finally {
                _isAiLoading.value = false
            }
        }
    }

    fun dismissAiDialog() {
        _aiExplanation.value = null
    }

    fun saveCurrentProject() {
        val current = _currentAnalysis.value ?: return
        viewModelScope.launch {
            val entity = ProjectEntity(
                id = current.apkInfo.packageName,
                title = current.apkInfo.appName,
                packageName = current.apkInfo.packageName,
                versionName = current.apkInfo.versionName,
                totalClasses = current.apkInfo.totalClasses,
                totalMethods = current.apkInfo.totalMethods,
                strongCount = current.methods.count { it.evidenceScore >= 90 }
            )
            dao.insertProject(entity)
        }
    }

    fun toggleBookmarkCurrentMethod() {
        val method = _selectedMethod.value ?: return
        val analysis = _currentAnalysis.value ?: return
        viewModelScope.launch {
            val bookmarkId = "bm_${method.id.hashCode()}"
            val existing = savedBookmarks.value.firstOrNull { it.id == bookmarkId }
            if (existing != null) {
                dao.deleteBookmark(bookmarkId)
                showToast("Bookmark removed")
            } else {
                val entity = BookmarkEntity(
                    id = bookmarkId,
                    projectId = analysis.apkInfo.packageName,
                    targetType = "METHOD",
                    targetId = method.id,
                    title = method.name,
                    subtitle = method.className,
                    score = method.evidenceScore
                )
                dao.insertBookmark(entity)
                showToast("Method bookmarked")
            }
        }
    }

    fun addNote(title: String, content: String) {
        val analysis = _currentAnalysis.value ?: return
        viewModelScope.launch {
            val entity = NoteEntity(
                projectId = analysis.apkInfo.packageName,
                title = title,
                content = content,
                targetId = _selectedMethod.value?.id
            )
            dao.insertNote(entity)
            showToast("Note saved")
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch {
            dao.deleteNote(note)
            showToast("Note deleted")
        }
    }

    fun exportReport(format: String): String {
        val analysis = _currentAnalysis.value ?: return ""
        return when (format.uppercase()) {
            "TXT" -> ReportGenerator.generateTxt(analysis)
            "JSON" -> ReportGenerator.generateJson(analysis)
            "HTML" -> ReportGenerator.generateHtml(analysis)
            "CSV" -> ReportGenerator.generateCsv(analysis)
            else -> ReportGenerator.generateTxt(analysis)
        }
    }
}
