package com.example

import com.example.core.analysis.EvidenceEngine
import com.example.core.analysis.StringIntelligenceEngine
import com.example.core.model.EvidenceLevel
import com.example.core.model.StringCategory
import com.example.core.model.TypeCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testEvidenceEngineForBillingMethod() {
    val (score, reasons) = EvidenceEngine.calculateMethodEvidence(
      methodName = "isSubscribed",
      className = "com.apex.media.player.billing.BillingManager",
      packageName = "com.apex.media.player.billing",
      returnCategory = TypeCategory.BOOLEAN,
      parameters = emptyList(),
      strings = listOf("sku_pro_yearly", "sku_vip_lifetime"),
      callersCount = 8,
      calleesCount = 2
    )

    assertTrue("Score should be >= 90 for direct subscription predicate", score >= 90)
    assertEquals(EvidenceLevel.STRONG, EvidenceEngine.toEvidenceLevel(score))
    assertTrue("Reasons should highlight billing identifiers", reasons.isNotEmpty())
  }

  @Test
  fun testStringIntelligenceEngineCategorization() {
    assertEquals(StringCategory.URLS, StringIntelligenceEngine.categorizeString("https://api.example.com/data"))
    assertEquals(StringCategory.API_ENDPOINTS, StringIntelligenceEngine.categorizeString("/v1/auth/token"))
    assertEquals(StringCategory.SUBSCRIPTION, StringIntelligenceEngine.categorizeString("sku_premium_monthly"))
    assertEquals(StringCategory.AUTHENTICATION, StringIntelligenceEngine.categorizeString("Bearer eyJhbGciOi..."))
  }
}
