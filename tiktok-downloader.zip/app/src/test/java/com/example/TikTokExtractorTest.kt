package com.example

import com.example.data.api.TikTokExtractor
import com.example.data.download.FileDownloader
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TikTokExtractorTest {

    @Test
    fun testUrlDetection() {
        assertTrue(TikTokExtractor.isTikTokUrl("https://vt.tiktok.com/ZS12345/"))
        assertTrue(TikTokExtractor.isTikTokUrl("https://www.tiktok.com/@creator/video/7123456789"))
        assertTrue(TikTokExtractor.isTikTokUrl("https://vm.tiktok.com/ZM8xY/"))
        assertFalse(TikTokExtractor.isTikTokUrl("https://youtube.com/watch?v=123"))
    }

    @Test
    fun testUrlExtractionFromSharedText() {
        val sharedText = "Check this cool video https://vt.tiktok.com/ZSabc123/ on TikTok!"
        val extracted = TikTokExtractor.extractUrlFromText(sharedText)
        assertEquals("https://vt.tiktok.com/ZSabc123/", extracted)
    }

    @Test
    fun testCleanFileName() {
        val raw = "My Video: With / Forbidden * Characters?"
        val clean = FileDownloader.cleanFileName(raw)
        assertFalse(clean.contains(":"))
        assertFalse(clean.contains("/"))
        assertFalse(clean.contains("?"))
        assertFalse(clean.contains("*"))
    }
}
