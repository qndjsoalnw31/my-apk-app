package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.api.TikTokExtractor
import com.example.data.db.DownloadedVideoEntity
import com.example.ui.components.DownloadProgressDialog
import com.example.ui.components.VideoPlayerDialog
import com.example.ui.screens.DownloadScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.theme.AccentOrange
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.MainViewModel

enum class AppTab(val title: String) {
    DOWNLOAD("تحميل"),
    HISTORY("المحفوظات")
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleSharedIntent(intent)

        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainAppContent(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleSharedIntent(intent)
    }

    private fun handleSharedIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            val extractedUrl = TikTokExtractor.extractUrlFromText(sharedText)
            if (!extractedUrl.isNullOrBlank()) {
                viewModel.pasteAndFetch(extractedUrl)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    var selectedTab by remember { mutableStateOf(AppTab.DOWNLOAD) }
    val downloadState by viewModel.downloadState.collectAsState()

    var activePlaybackVideo by remember { mutableStateOf<DownloadedVideoEntity?>(null) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBackground,
        contentWindowInsets = WindowInsets.navigationBars,
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 0.dp,
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                // Tab 1: Download
                NavigationBarItem(
                    selected = selectedTab == AppTab.DOWNLOAD,
                    onClick = { selectedTab = AppTab.DOWNLOAD },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == AppTab.DOWNLOAD) Icons.Filled.Download else Icons.Outlined.Download,
                            contentDescription = "تحميل",
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = {
                        Text(
                            text = AppTab.DOWNLOAD.title,
                            fontSize = 12.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AccentOrange,
                        selectedTextColor = AccentOrange,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = AccentOrange.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_download")
                )

                // Tab 2: History
                NavigationBarItem(
                    selected = selectedTab == AppTab.HISTORY,
                    onClick = { selectedTab = AppTab.HISTORY },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == AppTab.HISTORY) Icons.Filled.Folder else Icons.Outlined.Folder,
                            contentDescription = "المحفوظات",
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = {
                        Text(
                            text = AppTab.HISTORY.title,
                            fontSize = 12.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AccentOrange,
                        selectedTextColor = AccentOrange,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = AccentOrange.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_history")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                AppTab.DOWNLOAD -> DownloadScreen(viewModel = viewModel)
                AppTab.HISTORY -> HistoryScreen(viewModel = viewModel)
            }
        }
    }

    // Download Progress Dialog
    DownloadProgressDialog(
        state = downloadState,
        onDismiss = { viewModel.dismissDownloadState() },
        onOpenDownloadedVideo = { video ->
            activePlaybackVideo = video
        }
    )

    // Player dialog for downloaded video
    activePlaybackVideo?.let { video ->
        VideoPlayerDialog(
            videoUrlOrPath = video.localFilePath,
            title = video.title,
            onDismiss = { activePlaybackVideo = null }
        )
    }
}
