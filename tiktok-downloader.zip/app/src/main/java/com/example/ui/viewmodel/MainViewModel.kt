package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.DownloadedVideoEntity
import com.example.data.model.TikTokVideoInfo
import com.example.data.repository.VideoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ExtractUiState {
    object Idle : ExtractUiState
    object Loading : ExtractUiState
    data class Success(val info: TikTokVideoInfo) : ExtractUiState
    data class Error(val message: String) : ExtractUiState
}

sealed interface DownloadUiState {
    object Idle : DownloadUiState
    data class Downloading(
        val title: String,
        val percentage: Int,
        val bytesDownloaded: Long,
        val totalBytes: Long,
        val quality: String
    ) : DownloadUiState
    data class Completed(val video: DownloadedVideoEntity) : DownloadUiState
    data class Failed(val error: String) : DownloadUiState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = VideoRepository(application)

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _extractState = MutableStateFlow<ExtractUiState>(ExtractUiState.Idle)
    val extractState: StateFlow<ExtractUiState> = _extractState.asStateFlow()

    private val _downloadState = MutableStateFlow<DownloadUiState>(DownloadUiState.Idle)
    val downloadState: StateFlow<DownloadUiState> = _downloadState.asStateFlow()

    val downloadsList: StateFlow<List<DownloadedVideoEntity>> = repository.downloadsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onUrlChange(newUrl: String) {
        _urlInput.value = newUrl
        if (_extractState.value is ExtractUiState.Error) {
            _extractState.value = ExtractUiState.Idle
        }
    }

    fun clearUrl() {
        _urlInput.value = ""
        _extractState.value = ExtractUiState.Idle
    }

    fun pasteAndFetch(text: String) {
        _urlInput.value = text.trim()
        fetchVideo()
    }

    fun fetchVideo(overrideUrl: String? = null) {
        val targetUrl = (overrideUrl ?: _urlInput.value).trim()
        if (targetUrl.isBlank()) {
            _extractState.value = ExtractUiState.Error("يرجى إدخال أو لصق رابط فيديو TikTok")
            return
        }

        viewModelScope.launch {
            _extractState.value = ExtractUiState.Loading
            val result = repository.extractVideoInfo(targetUrl)
            result.fold(
                onSuccess = { info ->
                    _extractState.value = ExtractUiState.Success(info)
                },
                onFailure = { err ->
                    _extractState.value = ExtractUiState.Error(
                        err.message ?: "فشل استخراج الفيديو. تأكد من أن الحساب ليس خاصاً والإنترنت متصل."
                    )
                }
            )
        }
    }

    fun startDownload(info: TikTokVideoInfo, quality: String = "HD", isAudio: Boolean = false) {
        viewModelScope.launch {
            _downloadState.value = DownloadUiState.Downloading(
                title = info.title,
                percentage = 0,
                bytesDownloaded = 0L,
                totalBytes = if (quality == "HD") info.hdSizeBytes else info.sizeBytes,
                quality = if (isAudio) "MP3" else quality
            )

            val result = repository.downloadMedia(
                videoInfo = info,
                quality = quality,
                isAudio = isAudio,
                onProgress = { percent, downloaded, total ->
                    _downloadState.value = DownloadUiState.Downloading(
                        title = info.title,
                        percentage = percent,
                        bytesDownloaded = downloaded,
                        totalBytes = total,
                        quality = if (isAudio) "MP3" else quality
                    )
                }
            )

            result.fold(
                onSuccess = { savedEntity ->
                    _downloadState.value = DownloadUiState.Completed(savedEntity)
                },
                onFailure = { error ->
                    _downloadState.value = DownloadUiState.Failed(
                        error.message ?: "حدث خطأ أثناء تنزيل الملف"
                    )
                }
            )
        }
    }

    fun dismissDownloadState() {
        _downloadState.value = DownloadUiState.Idle
    }

    fun deleteDownload(item: DownloadedVideoEntity) {
        viewModelScope.launch {
            repository.deleteDownload(item)
        }
    }

    fun clearAllDownloads() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }
}
