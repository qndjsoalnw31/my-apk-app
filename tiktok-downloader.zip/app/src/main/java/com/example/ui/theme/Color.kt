package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Dark Palette for TikTok Downloader
val DarkBackground = Color(0xFF0D0F12)
val DarkSurface = Color(0xFF15181D)
val DarkSurfaceVariant = Color(0xFF1B2027)
val DarkCardBorder = Color(0xFF252A32)
val DarkDivider = Color(0xFF22262D)

// Accents
val AccentOrange = Color(0xFFFF6719)
val AccentOrangeHover = Color(0xFFE55710)
val AccentOrangeContainer = Color(0x33FF6719)

val AccentCyan = Color(0xFF00E5FF)
val AccentCyanContainer = Color(0x2200E5FF)

val StatusSuccess = Color(0xFF72D49B)
val StatusSuccessContainer = Color(0x2A72D49B)

val StatusError = Color(0xFFFF6B6B)
val StatusErrorContainer = Color(0x2AFF6B6B)

val TextPrimary = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFF8D939B)
val TextMuted = Color(0xFF5E6570)
