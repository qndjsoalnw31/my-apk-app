package com.example.data.repository

import android.content.Context
import com.example.data.api.TikTokExtractor
import com.example.data.db.AppDatabase
import com.example.data.db.DownloadedVideoEntity
import com.example.data.download.FileDownloader
import com.example.data.model.TikTokVideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class VideoRepository(context: Context) {

    private val extractor = TikTokExtractor()
    private val downloader = FileDownloader(context)
    private val dao = AppDatabase.getInstance(context).downloadedVideoDao()

    val downloadsFlow: Flow<List<DownloadedVideoEntity>> = dao.getAllDownloads()

    suspend fun extractVideoInfo(url: String): Result<TikTokVideoInfo> {
        return extractor.extractVideoInfo(url)
    }

    suspend fun downloadMedia(
        videoInfo: TikTokVideoInfo,
        quality: String,
        isAudio: Boolean,
        onProgress: (Int, Long, Long) -> Unit
    ): Result<DownloadedVideoEntity> = withContext(Dispatchers.IO) {
        val targetUrl = when {
            isAudio -> videoInfo.musicUrl ?: videoInfo.standardVideoUrl
            quality == "HD" && !videoInfo.hdVideoUrl.isNullOrBlank() -> videoInfo.hdVideoUrl
            else -> videoInfo.standardVideoUrl
        }

        val downloadResult = downloader.downloadMedia(
            downloadUrl = targetUrl,
            title = if (isAudio) "${videoInfo.title}_audio" else videoInfo.title,
            isAudio = isAudio,
            onProgress = onProgress
        )

        downloadResult.fold(
            onSuccess = { (file, publicUri) ->
                val entity = DownloadedVideoEntity(
                    videoId = videoInfo.id,
                    title = videoInfo.title,
                    authorName = videoInfo.authorName,
                    coverUrl = videoInfo.coverUrl,
                    localFilePath = file.absolutePath,
                    contentUriString = publicUri?.toString(),
                    fileSize = file.length(),
                    durationSeconds = videoInfo.durationSeconds,
                    isAudioOnly = isAudio,
                    quality = quality,
                    sourceUrl = videoInfo.originalUrl
                )
                val id = dao.insertDownload(entity)
                Result.success(entity.copy(id = id))
            },
            onFailure = { error ->
                Result.failure(error)
            }
        )
    }

    suspend fun deleteDownload(item: DownloadedVideoEntity) = withContext(Dispatchers.IO) {
        try {
            val file = File(item.localFilePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (_: Exception) { }
        dao.deleteDownload(item)
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        dao.clearAll()
    }
}
