package com.example.data.download

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit

sealed interface DownloadStatus {
    object Idle : DownloadStatus
    data class Progress(val percentage: Int, val bytesDownloaded: Long, val totalBytes: Long) : DownloadStatus
    data class Success(val file: File, val contentUri: Uri?, val title: String) : DownloadStatus
    data class Failure(val errorMessage: String) : DownloadStatus
}

class FileDownloader(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "FileDownloader"
        private const val SUBFOLDER = "TikTok Downloader"

        fun cleanFileName(raw: String): String {
            val sanitized = raw.replace(Regex("[\\\\/:*?\"<>|]"), " ").trim()
                .replace(Regex("\\s+"), " ")
            val short = if (sanitized.length > 60) sanitized.substring(0, 60).trim() else sanitized
            return if (short.isBlank()) "TikTok_Video" else short
        }
    }

    suspend fun downloadMedia(
        downloadUrl: String,
        title: String,
        isAudio: Boolean = false,
        onProgress: (Int, Long, Long) -> Unit
    ): Result<Pair<File, Uri?>> = withContext(Dispatchers.IO) {
        val extension = if (isAudio) "mp3" else "mp4"
        val mimeType = if (isAudio) "audio/mpeg" else "video/mp4"
        val safeTitle = cleanFileName(title)
        val shortUuid = UUID.randomUUID().toString().substring(0, 6)
        val fileName = "${safeTitle}_$shortUuid.$extension"

        try {
            val request = Request.Builder()
                .url(downloadUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36")
                .header("Referer", "https://www.tiktok.com/")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("خطأ في الخادم (HTTP ${response.code})"))
            }

            val body = response.body ?: return@withContext Result.failure(Exception("استجابة الخادم فارغة"))
            val contentLength = body.contentLength()
            val inputStream = body.byteStream()

            // Determine target file location in app accessible folder
            val appStorageDir = File(
                context.getExternalFilesDir(if (isAudio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES),
                SUBFOLDER
            ).apply { mkdirs() }

            val localFile = File(appStorageDir, fileName)

            var downloadedBytes = 0L
            var lastReportedPercent = -1

            FileOutputStream(localFile).use { output ->
                val buffer = ByteArray(64 * 1024)
                var read: Int
                while (inputStream.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                    downloadedBytes += read

                    if (contentLength > 0) {
                        val percent = ((downloadedBytes * 100) / contentLength).toInt().coerceIn(0, 100)
                        if (percent != lastReportedPercent) {
                            lastReportedPercent = percent
                            onProgress(percent, downloadedBytes, contentLength)
                        }
                    } else {
                        onProgress(-1, downloadedBytes, -1)
                    }
                }
                output.flush()
            }

            if (localFile.length() <= 0) {
                localFile.delete()
                return@withContext Result.failure(Exception("الملف فارغ أو لم يكتمل التنزيل"))
            }

            // Export to public MediaStore / Downloads directory if available
            val publicUri = saveToPublicDownloads(localFile, fileName, mimeType, isAudio)

            // Notify media scanner
            MediaScannerConnection.scanFile(
                context,
                arrayOf(localFile.absolutePath),
                arrayOf(mimeType),
                null
            )

            Result.success(Pair(localFile, publicUri))
        } catch (e: Exception) {
            Log.e(TAG, "Download failed: ${e.message}", e)
            Result.failure(Exception(e.message ?: "فشل تنزيل الملف"))
        }
    }

    private fun saveToPublicDownloads(
        sourceFile: File,
        fileName: String,
        mimeType: String,
        isAudio: Boolean
    ): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        "${Environment.DIRECTORY_DOWNLOADS}/$SUBFOLDER"
                    )
                }

                val resolver = context.contentResolver
                val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val uri = resolver.insert(collection, contentValues) ?: return null

                resolver.openOutputStream(uri)?.use { out ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(out)
                    }
                }
                uri
            } else {
                val publicDir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    SUBFOLDER
                ).apply { mkdirs() }
                val publicFile = File(publicDir, fileName)
                sourceFile.copyTo(publicFile, overwrite = true)
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(publicFile.absolutePath),
                    arrayOf(mimeType),
                    null
                )
                Uri.fromFile(publicFile)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not save copy to public downloads: ${e.message}")
            null
        }
    }
}
