package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloaded_videos")
data class DownloadedVideoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val videoId: String,
    val title: String,
    val authorName: String,
    val coverUrl: String?,
    val localFilePath: String,
    val contentUriString: String?,
    val fileSize: Long,
    val durationSeconds: Int,
    val isAudioOnly: Boolean = false,
    val quality: String = "HD",
    val sourceUrl: String,
    val downloadedAt: Long = System.currentTimeMillis()
)
