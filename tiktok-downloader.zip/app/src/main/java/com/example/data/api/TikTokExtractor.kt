package com.example.data.api

import android.util.Log
import com.example.data.model.TikTokVideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URI
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class TikTokExtractor {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    companion object {
        private const val TAG = "TikTokExtractor"
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

        private val URL_REGEX = Pattern.compile(
            "https?://[a-zA-Z0-9.-]*tiktok\\.com/[^\\s]+"
        )

        fun extractUrlFromText(text: String?): String? {
            if (text.isNullOrBlank()) return null
            val matcher = URL_REGEX.matcher(text)
            return if (matcher.find()) {
                matcher.group()
            } else {
                val trimmed = text.trim()
                if (isTikTokUrl(trimmed)) trimmed else null
            }
        }

        fun isTikTokUrl(url: String?): Boolean {
            if (url.isNullOrBlank()) return false
            return try {
                val uri = URI(url.trim())
                val host = uri.host?.lowercase() ?: ""
                val cleanHost = if (host.startsWith("www.")) host.substring(4) else host
                cleanHost == "tiktok.com" ||
                        cleanHost.endsWith(".tiktok.com")
            } catch (e: Exception) {
                url.contains("tiktok.com")
            }
        }
    }

    suspend fun resolveUrl(rawUrl: String): String = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(rawUrl)
                .header("User-Agent", USER_AGENT)
                .head()
                .build()

            client.newCall(request).execute().use { response ->
                response.request.url.toString()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to resolve short url: ${e.message}")
            rawUrl
        }
    }

    suspend fun extractVideoInfo(rawInputUrl: String): Result<TikTokVideoInfo> = withContext(Dispatchers.IO) {
        val extractedUrl = extractUrlFromText(rawInputUrl)
            ?: return@withContext Result.failure(IllegalArgumentException("الرابط المدخل لا يحتوي على رابط TikTok صحيح"))

        val resolvedUrl = resolveUrl(extractedUrl)

        // Method 1: TikWM API
        try {
            val tikwmResult = fetchFromTikWM(resolvedUrl)
            if (tikwmResult != null) {
                return@withContext Result.success(tikwmResult)
            }
        } catch (e: Exception) {
            Log.e(TAG, "TikWM extraction failed: ${e.message}")
        }

        // Method 2: Worker API
        try {
            val workerResult = fetchFromWorker(resolvedUrl)
            if (workerResult != null) {
                return@withContext Result.success(workerResult)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Worker extraction failed: ${e.message}")
        }

        Result.failure(Exception("تعذر استخراج بيانات الفيديو. يرجى التأكد من الرابط والمحاولة مجددا."))
    }

    private fun fetchFromTikWM(url: String): TikTokVideoInfo? {
        val apiUrl = "https://www.tikwm.com/api/"

        val formBody = FormBody.Builder()
            .add("url", url)
            .add("hd", "1")
            .build()

        val request = Request.Builder()
            .url(apiUrl)
            .header("User-Agent", USER_AGENT)
            .header("Referer", "https://www.tikwm.com/")
            .header("Accept", "application/json")
            .post(formBody)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.w(TAG, "TikWM HTTP ${response.code}")
                return null
            }

            val body = response.body?.string() ?: return null
            val json = JSONObject(body)

            val code = json.optInt("code", -1)
            if (code != 0) {
                Log.w(TAG, "TikWM returned code $code: ${json.optString("msg")}")
                return null
            }

            val data = json.optJSONObject("data") ?: return null

            val id = data.optString("id", System.currentTimeMillis().toString())
            val title = data.optString("title", "فيديو TikTok").takeIf { it.isNotBlank() } ?: "فيديو TikTok"
            val duration = data.optInt("duration", 0)

            var play = data.optString("play", "")
            if (play.startsWith("//")) play = "https:$play"
            else if (play.startsWith("/")) play = "https://www.tikwm.com$play"

            var hdplay = data.optString("hdplay", "")
            if (hdplay.startsWith("//")) hdplay = "https:$hdplay"
            else if (hdplay.startsWith("/")) hdplay = "https://www.tikwm.com$hdplay"

            var wmplay = data.optString("wmplay", "")
            if (wmplay.startsWith("//")) wmplay = "https:$wmplay"
            else if (wmplay.startsWith("/")) wmplay = "https://www.tikwm.com$wmplay"

            var cover = data.optString("cover", "")
            if (cover.startsWith("//")) cover = "https:$cover"

            var music = data.optString("music", "")
            if (music.startsWith("//")) music = "https:$music"

            val musicInfo = data.optJSONObject("music_info")
            val musicTitle = musicInfo?.optString("title")
            val musicAuthor = musicInfo?.optString("author")

            val authorObj = data.optJSONObject("author")
            val authorName = authorObj?.optString("nickname", "TikTok User") ?: "TikTok User"
            val authorUsername = authorObj?.optString("unique_id", "") ?: ""
            var authorAvatar = authorObj?.optString("avatar", "")
            if (authorAvatar != null && authorAvatar.startsWith("//")) authorAvatar = "https:$authorAvatar"

            val size = data.optLong("size", 0L)
            val hdSize = data.optLong("hd_size", 0L)

            val playCount = data.optLong("play_count", 0L)
            val diggCount = data.optLong("digg_count", 0L)
            val commentCount = data.optLong("comment_count", 0L)
            val shareCount = data.optLong("share_count", 0L)

            if (play.isBlank() && hdplay.isBlank()) {
                return null
            }

            return TikTokVideoInfo(
                id = id,
                title = title,
                authorName = authorName,
                authorUsername = authorUsername,
                authorAvatarUrl = authorAvatar?.takeIf { it.isNotBlank() },
                coverUrl = cover.takeIf { it.isNotBlank() },
                durationSeconds = duration,
                standardVideoUrl = play.ifBlank { hdplay },
                hdVideoUrl = hdplay.takeIf { it.isNotBlank() },
                watermarkVideoUrl = wmplay.takeIf { it.isNotBlank() },
                musicUrl = music.takeIf { it.isNotBlank() },
                musicTitle = musicTitle,
                musicAuthor = musicAuthor,
                playCount = playCount,
                diggCount = diggCount,
                commentCount = commentCount,
                shareCount = shareCount,
                originalUrl = url,
                sizeBytes = size,
                hdSizeBytes = hdSize
            )
        }
    }

    private fun fetchFromWorker(url: String): TikTokVideoInfo? {
        val apiUrl = "https://tdownv4.sl-bjs.workers.dev/?down=$url"

        val request = Request.Builder()
            .url(apiUrl)
            .header("User-Agent", USER_AGENT)
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val body = response.body?.string() ?: return null
            val json = JSONObject(body)

            var downloadUrl = json.optString("download_url")
                .ifBlank { json.optString("downloadUrl") }
                .ifBlank { json.optString("url") }
                .ifBlank { json.optString("video_url") }

            if (downloadUrl.isBlank()) {
                val dataObj = json.optJSONObject("data")
                if (dataObj != null) {
                    downloadUrl = dataObj.optString("download_url")
                        .ifBlank { dataObj.optString("downloadUrl") }
                        .ifBlank { dataObj.optString("play") }
                        .ifBlank { dataObj.optString("video_url") }
                }
            }

            if (downloadUrl.isBlank()) return null

            val title = json.optString("title")
                .ifBlank { json.optString("desc") }
                .ifBlank { "فيديو TikTok" }

            return TikTokVideoInfo(
                id = System.currentTimeMillis().toString(),
                title = title,
                authorName = "TikTok User",
                authorUsername = "",
                authorAvatarUrl = null,
                coverUrl = null,
                durationSeconds = 0,
                standardVideoUrl = downloadUrl,
                hdVideoUrl = downloadUrl,
                watermarkVideoUrl = null,
                musicUrl = null,
                musicTitle = null,
                musicAuthor = null,
                originalUrl = url
            )
        }
    }
}
