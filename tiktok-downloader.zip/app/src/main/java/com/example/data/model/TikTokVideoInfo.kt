package com.example.data.model

data class TikTokVideoInfo(
    val id: String,
    val title: String,
    val authorName: String,
    val authorUsername: String,
    val authorAvatarUrl: String?,
    val coverUrl: String?,
    val durationSeconds: Int,
    val standardVideoUrl: String,
    val hdVideoUrl: String?,
    val watermarkVideoUrl: String?,
    val musicUrl: String?,
    val musicTitle: String?,
    val musicAuthor: String?,
    val playCount: Long = 0,
    val diggCount: Long = 0,
    val commentCount: Long = 0,
    val shareCount: Long = 0,
    val originalUrl: String,
    val sizeBytes: Long = 0,
    val hdSizeBytes: Long = 0
) {
    val bestVideoUrl: String
        get() = hdVideoUrl?.takeIf { it.isNotBlank() } ?: standardVideoUrl
}
